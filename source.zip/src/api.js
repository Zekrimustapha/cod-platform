'use strict';
const { D, prime, getSetting, setSetting, storeSettings, DEFAULTS, PLATFORM_KEYS, productRow, landingRow, orderRow, parseJson, storeById, storeBySlug } = require('./db');
const { randomHex } = require('./crypto');
const files = require('./files');
const U = require('./util');
const auth = require('./auth');
const geo = require('./geo');
const O = require('./orders');
const ai = require('./ai');
const integ = require('./integrations');
const LAI = require('./landing-ai');

const SECRET_KEYS = { tracking: ['metaCapiToken'], integrations: ['metaAdsToken'], couriers: ['apiToken', 'apiKey'], ai: ['geminiKey', 'openaiKey', 'cfApiToken'] };
const C = require('./couriers');
const SECTION_FOR_SETTING = { store: 'settings', theme: 'design', delivery: 'settings', costs: 'settings', fraud: 'settings', tracking: 'settings', integrations: 'settings', form: 'settings', couriers: 'settings' };
const TZ = '+1 hour'; // Algeria (UTC+1, no DST)
const RESERVED = new Set(['admin', 'api', 'www', 'app', 'assets', 'uploads', 's', 'signup', 'login', 'register', 'platform', 'mail', 'static', 'cdn', 'health', 'support', 'help', 'blog', 'store-admin', 'root', 'test']);

function range(q) {
  const to = q.get('to') || new Date(Date.now() + 3600e3).toISOString().slice(0, 10);
  const from = q.get('from') || new Date(Date.now() + 3600e3 - 6 * 864e5).toISOString().slice(0, 10);
  return { from, to };
}
const inRange = `date(created_at, '${TZ}') BETWEEN ? AND ?`;
const dzToday = () => new Date(Date.now() + 3600e3).toISOString().slice(0, 10);

const hide = (v) => (v ? '••••' + String(v).slice(-4) : '');
function mask(obj, key) {
  const out = structuredClone(obj);
  for (const f of SECRET_KEYS[key] || []) if (out[f]) out[f] = hide(out[f]);
  if (key === 'tracking') for (const list of ['meta', 'tiktok']) out[list] = (out[list] || []).map((x) => ({ ...x, token: hide(x.token) }));
  return out;
}
// Settings-specific cleaning (runs on save).
const MODEL_RE = /^[a-z0-9][a-z0-9._\-\/@:]{1,80}$/i;
function cleanPixels(list, old, isMeta) {
  return (Array.isArray(list) ? list : []).slice(0, 10).map((x) => {
    const id = String((x && x.id) || '').trim().replace(isMeta ? /\D/g : /[^A-Za-z0-9]/g, '').slice(0, 40);
    let token = String((x && x.token) || '').trim();
    if (token.startsWith('••••')) token = ((old || []).find((o) => o.id === id) || {}).token || '';
    return { id, token: token.slice(0, 400), test: String((x && x.test) || '').trim().replace(/[^A-Za-z0-9]/g, '').slice(0, 30), on: x && x.on !== false, name: String((x && x.name) || '').slice(0, 40) };
  }).filter((x) => x.id);
}
function cleanForm(f) {
  const allowed = ['name', 'phone', 'phone2', 'wilaya', 'commune', 'address', 'note'];
  const seen = new Set();
  const fields = (Array.isArray(f.fields) ? f.fields : []).slice(0, 25).map((x) => {
    let key = String((x && x.key) || '');
    if (!allowed.includes(key) && !/^c_[a-z0-9]{1,20}$/.test(key)) return null;
    if (seen.has(key)) return null;
    seen.add(key);
    const o = { key, on: !!x.on, req: !!x.req, label: U.str(x.label, 60), ph: U.str(x.ph, 80) };
    if (key.startsWith('c_')) { o.type = ['text', 'textarea', 'select', 'number'].includes(x.type) ? x.type : 'text'; o.options = (Array.isArray(x.options) ? x.options : String(x.options || '').split(',')).map((v) => U.str(v, 40)).filter(Boolean).slice(0, 30); }
    return o;
  }).filter(Boolean);
  for (const k of ['name', 'phone', 'wilaya', 'commune']) if (!seen.has(k)) fields.push({ key: k, on: true, req: true, label: '', ph: '' });
  return { title: U.str(f.title, 80), subtitle: U.str(f.subtitle, 160), button: U.str(f.button, 40), showOffers: f.showOffers !== false, showSummary: f.showSummary !== false, showTrust: f.showTrust !== false, fields };
}
function cleanAi(n) {
  const d = DEFAULTS.ai;
  for (const k of ['geminiModel', 'geminiImageModel', 'openaiImageModel', 'cfImageModel', 'ollamaModel']) {
    const v = String(n[k] || '').trim().replace(/^models\//, '');
    n[k] = MODEL_RE.test(v) && !v.includes('@gmail') && !/\s/.test(v) && (k !== 'cfImageModel' || v.startsWith('@cf/')) ? v : d[k];
  }
  n.cfAccountId = /^[a-f0-9]{32}$/i.test(String(n.cfAccountId || '').trim()) ? String(n.cfAccountId).trim() : '';
  for (const k of ['geminiKey', 'openaiKey', 'cfApiToken']) n[k] = String(n[k] || '').trim().replace(/\s+/g, '');
  n.cfSteps = Math.max(1, Math.min(8, U.int(n.cfSteps, 6)));
  if (!['auto', 'gemini', 'workers', 'ollama', 'none'].includes(n.provider)) n.provider = 'auto';
  n.modelV = 2;
  return n;
}
function maskAll(s) {
  const out = {};
  for (const [k, v] of Object.entries(s)) out[k] = mask(v, k);
  return out;
}
function mergeSetting(key, cur, body) {
  const next = { ...cur };
  for (const k of Object.keys(DEFAULTS[key])) {
    if (body[k] === undefined) continue;
    if ((SECRET_KEYS[key] || []).includes(k) && String(body[k]).startsWith('••••')) continue; // unchanged masked secret
    next[k] = typeof DEFAULTS[key][k] === 'number' ? U.num(body[k], DEFAULTS[key][k]) : body[k];
  }
  return next;
}

async function uniqueSlug(table, sid, base, exceptId = 0) {
  const root = U.slugify(base) || 'page';
  let slug = root;
  let i = 1;
  while ((await D.get(`SELECT id FROM ${table} WHERE store_id = ? AND slug = ? AND id != ?`, sid, slug, exceptId))) slug = root + '-' + ++i;
  return slug;
}

async function checkStoreSlug(raw) {
  const slug = String(raw || '').toLowerCase().trim();
  if (!/^[a-z0-9](?:[a-z0-9-]{1,28}[a-z0-9])$/.test(slug)) return { ok: false, error: 'Link: 3–30 letters a-z, numbers or "-"' };
  if (RESERVED.has(slug)) return { ok: false, error: 'This link is reserved' };
  if (await storeBySlug(slug)) return { ok: false, error: 'This link is already taken' };
  return { ok: true, slug };
}

function storeUrl(req, slug) {
  const P = getSetting('platform');
  const proto = req.headers['x-forwarded-proto'] === 'https' || /"scheme":"https"/.test(String(req.headers['cf-visitor'] || '')) ? 'https' : 'http';
  if (P.baseDomain) return `${proto}://${slug}.${String(P.baseDomain).replace(/^\.+/, '')}`;
  return `${proto}://${req.headers.host}/s/${slug}`;
}

// Create a store + its owner (used by first setup, public signup and super admin)
async function createStore({ storeName, slug, name, email, password, phone, aiDaily, isSuper }) {
  const c = await checkStoreSlug(slug);
  if (!c.ok) throw U.httpError(400, c.error);
  const sname = U.str(storeName, 80);
  if (sname.length < 2) throw U.httpError(400, 'Store name required');
  // validate the owner first so a failed sign-up never leaves an empty store behind
  if (!email || !/^[^@\s]+@[^@\s]+$/.test(email)) throw U.httpError(400, 'Valid email required');
  if (!password || String(password).length < 8) throw U.httpError(400, 'Password must be at least 8 characters');
  if (await D.get('SELECT id FROM users WHERE email = ?', String(email).toLowerCase())) throw U.httpError(409, 'Email already used');
  const r = await D.run('INSERT INTO stores(slug, name, status, ai_daily_images, created_at) VALUES(?,?,?,?,?)', c.slug, sname, 'active', aiDaily ?? 30, U.nowIso());
  const sid = Number(r.lastInsertRowid);
  try {
    await auth.createUser({ name, email, password, role: 'owner', storeId: sid, isSuper: !!isSuper });
  } catch (e) {
    await D.run('DELETE FROM stores WHERE id = ?', sid);
    throw e;
  }
  await setSetting('store', { ...DEFAULTS.store, name: sname, phone: U.str(phone, 20), whatsapp: U.str(phone, 20) }, sid);
  return sid;
}

// ---------- AI quota (per store, per Algerian day) ----------
async function aiUsage(sid) {
  const st = await storeById(sid);
  const row = (await D.get('SELECT images, analyses FROM ai_usage WHERE store_id = ? AND date = ?', sid, dzToday())) || { images: 0, analyses: 0 };
  const limit = st ? st.ai_daily_images : 0;
  return { images: row.images, imagesLimit: limit, analyses: row.analyses, analysesLimit: Math.max(5, Math.ceil(limit / 2)) };
}
async function bumpAi(sid, field) {
  (await D.run(`INSERT INTO ai_usage(store_id, date, images, analyses) VALUES(?, ?, ?, ?) ON CONFLICT(store_id, date) DO UPDATE SET ${field} = ${field} + 1`, sid, dzToday(), field === 'images' ? 1 : 0, field === 'analyses' ? 1 : 0));
}
async function aiStatus(sid) {
  const c = getSetting('ai');
  const text = (['gemini', 'auto'].includes(c.provider) && !!c.geminiKey) || c.provider === 'ollama' || (['gemini', 'auto', 'workers'].includes(c.provider) && LAI.hasAiBinding());
  const images = (c.imageProvider === 'cloudflare' && ((!!c.cfAccountId && !!c.cfApiToken) || LAI.hasAiBinding())) || (c.imageProvider === 'gemini' && !!c.geminiKey) || (c.imageProvider === 'openai' && !!c.openaiKey);
  return { text, images, refImages: LAI.refImages(), textProvider: c.provider, imageProvider: c.imageProvider, defaultLang: c.defaultLang, usage: await aiUsage(sid) };
}

function cleanProduct(b) {
  const offers = (Array.isArray(b.offers) ? b.offers : []).map((o) => ({ qty: U.int(o.qty), price: U.int(o.price), label: U.str(o.label, 60) })).filter((o) => o.qty > 0 && o.price > 0).slice(0, 6);
  const variants = (Array.isArray(b.variants) ? b.variants : []).map((v) => ({ name: U.str(v.name, 60), sku: U.str(v.sku, 40), stock: U.int(v.stock), color: /^#[0-9a-f]{6}$/i.test(String(v.color || '')) && v.color !== '#000000' ? v.color : '', price: Math.max(0, U.int(v.price)), image: String(v.image || '').startsWith('/uploads/') ? U.str(v.image, 300) : '' })).filter((v) => v.name).slice(0, 50);
  const images = (Array.isArray(b.images) ? b.images : []).map((x) => U.str(x, 300)).filter((x) => x.startsWith('/uploads/')).slice(0, 20);
  return {
    name: U.str(b.name, 140) || 'Product', short_desc: U.str(b.short_desc, 500), description: U.str(b.description, 8000), specs: U.str(b.specs, 3000),
    price: Math.max(0, U.int(b.price)), old_price: Math.max(0, U.int(b.old_price)), cost: Math.max(0, U.int(b.cost)), category: U.str(b.category, 60),
    images: JSON.stringify(images), offers: JSON.stringify(offers), variants: JSON.stringify(variants), live: b.live ? 1 : 0, seo_title: U.str(b.seo_title, 120), sort: U.int(b.sort),
    stock: b.stock === '' || b.stock == null || Number(b.stock) < 0 ? -1 : U.int(b.stock), preorder: b.preorder ? 1 : 0, preorder_note: U.str(b.preorder_note, 120)
  };
}

function cleanLandingContent(c) {
  const s = (v, n = 300) => U.str(v, n);
  const list = (v, n, f) => (Array.isArray(v) ? v : []).slice(0, n).map(f);
  const img = (v) => (String(v || '').startsWith('/uploads/') ? s(v, 300) : '');
  return {
    hook: s(c.hook, 200), headline: s(c.headline, 200), subheadline: s(c.subheadline, 400), badge: s(c.badge, 40),
    bullets: list(c.bullets, 5, (x) => s(x, 150)).filter(Boolean),
    problem: { title: s(c.problem?.title, 200), pains: list(c.problem?.pains, 5, (x) => s(x, 200)).filter(Boolean), bridge: s(c.problem?.bridge, 300) },
    benefits: list(c.benefits, 6, (x) => ({ title: s(x?.title, 100), text: s(x?.text, 300) })).filter((x) => x.title),
    comparison: list(c.comparison, 6, (x) => s(x, 120)).filter(Boolean),
    steps: list(c.steps, 5, (x) => ({ title: s(x?.title, 100), text: s(x?.text, 300) })).filter((x) => x.title),
    faq: list(c.faq, 8, (x) => ({ q: s(x?.q, 200), a: s(x?.a, 600) })).filter((x) => x.q),
    final_cta: s(c.final_cta, 200), guarantee: s(c.guarantee, 200),
    hero_img: img(c.hero_img), before_img: img(c.before_img), after_img: img(c.after_img), video: img(c.video),
    gallery: list(c.gallery, 10, img).filter(Boolean), review_imgs: list(c.review_imgs, 12, img).filter(Boolean),
    upsell: c.upsell && U.int(c.upsell.price) > 0 ? { title: s(c.upsell.title, 120), price: U.int(c.upsell.price), image: img(c.upsell.image) } : null,
    layout: c.layout === 'panels' ? 'panels' : 'sections',
    use_photos: !!c.use_photos,
    palette: c.palette && /^#[0-9a-fA-F]{6}$/.test(c.palette.primary || '') ? { primary: c.palette.primary, accent: /^#[0-9a-fA-F]{6}$/.test(c.palette.accent || '') ? c.palette.accent : '#F2A93B', dark: /^#[0-9a-fA-F]{6}$/.test(c.palette.dark || '') ? c.palette.dark : '#111111' } : null,
    plan: c.plan ? { niche: s(c.plan.niche, 20), audience: s(c.plan.audience, 200), angle: s(c.plan.angle, 200) } : null,
    panels: list(c.panels, 10, (x) => ({
      type: LAI.PANEL_TYPES.includes(x?.type) ? x.type : 'features', image: img(x?.image), scene: img(x?.scene), scene2: img(x?.scene2),
      title: s(x?.title, 90), highlight: s(x?.highlight, 40), subtitle: s(x?.subtitle, 140), badge: s(x?.badge, 40),
      bullets: list(x?.bullets, 6, (b) => s(b, 80)), before_points: list(x?.before_points, 3, (b) => s(b, 80)), after_points: list(x?.after_points, 3, (b) => s(b, 80)), steps: list(x?.steps, 3, (b) => s(b, 90)),
      sceneHasProduct: !!x?.sceneHasProduct, scene_prompt: s(x?.scene_prompt, 700), before_scene: s(x?.before_scene, 700), after_scene: s(x?.after_scene, 700)
    })).filter((x) => x.image),
    sections: { problem: c.sections?.problem !== false, beforeafter: c.sections?.beforeafter !== false, benefits: c.sections?.benefits !== false, comparison: c.sections?.comparison !== false, reviews: c.sections?.reviews !== false, steps: c.sections?.steps !== false, faq: c.sections?.faq !== false }
  };
}

// ---------- Stats ----------
async function overview(sid, from, to) {
  const costs = getSetting('costs', sid);
  const W = `store_id = ${Number(sid)} AND ${inRange}`;
  const rows = (await D.all(`SELECT status, COUNT(*) n, SUM(items_price + upsell_price) rev, SUM(unit_cost * quantity) pc FROM orders WHERE ${W} GROUP BY status`, from, to));
  const by = Object.fromEntries(O.STATUSES.map((s) => [s, { n: 0, rev: 0, pc: 0 }]));
  rows.forEach((r) => (by[r.status] = { n: r.n, rev: r.rev || 0, pc: r.pc || 0 }));
  const total = rows.reduce((a, r) => a + r.n, 0);
  const confirmedish = by.confirmed.n + by.shipped.n + by.delivered.n + by.returned.n;
  const closed = by.delivered.n + by.returned.n;
  const spendUsd = (await D.get('SELECT COALESCE(SUM(spend_usd),0) s FROM ad_spend WHERE store_id = ? AND date BETWEEN ? AND ?', sid, from, to)).s;
  const ads = spendUsd * (costs.usdRate || 255);
  const revenue = by.delivered.rev;
  const product = by.delivered.pc; // returned stock comes back
  const courier = by.delivered.n * costs.courierPerDelivered;
  const confirm = by.delivered.n * costs.confirmPerDelivered;
  const returns = by.returned.n * (costs.returnFee || 0);
  const pack = (by.delivered.n + by.returned.n) * (costs.packaging || 0);
  const net = revenue - product - courier - confirm - returns - pack - ads;
  const daily = (await D.all(`SELECT date(created_at, '${TZ}') d, COUNT(*) n, SUM(status='delivered') del FROM orders WHERE ${W} GROUP BY d ORDER BY d`, from, to));
  const products = (await D.all(`SELECT product_id id, product_name name, COUNT(*) n, SUM(status IN ('confirmed','shipped','delivered','returned')) c, SUM(status='delivered') d, SUM(status='returned') r,
      SUM(CASE WHEN status='delivered' THEN items_price + upsell_price - unit_cost*quantity ELSE 0 END) gross FROM orders WHERE ${W} GROUP BY product_id ORDER BY n DESC LIMIT 8`, from, to));
  const wilayas = (await D.all(`SELECT wilaya_code code, wilaya_name name, COUNT(*) n, SUM(status='delivered') d, SUM(status='returned') r FROM orders WHERE ${W} GROUP BY wilaya_code ORDER BY n DESC LIMIT 8`, from, to));
  const agents = (await D.all(`SELECT u.name, COUNT(o.id) n, SUM(o.status IN ('confirmed','shipped','delivered','returned')) c FROM orders o JOIN users u ON u.id = o.agent_id WHERE o.store_id = ? AND ${inRange.replace('created_at', 'o.created_at')} GROUP BY u.id ORDER BY c DESC`, sid, from, to));
  const waiting = (await D.get(`SELECT COUNT(*) n, MIN(created_at) oldest FROM orders WHERE store_id = ? AND status = 'new'`, sid));
  const abandoned = (await D.get(`SELECT COUNT(*) n FROM abandoned WHERE store_id = ? AND status = 'open' AND phone != '' AND created_at > ?`, sid, new Date(Date.now() - 7 * 864e5).toISOString())).n;
  const lowStock = (await D.all('SELECT id, name, variants, stock FROM products WHERE store_id = ? AND live = 1', sid)).map((p) => { const vs = parseJson(p.variants, []); return { id: p.id, name: p.name, stock: vs.length ? vs.reduce((a, v) => a + (v.stock || 0), 0) : Number(p.stock ?? -1), hasVariants: vs.length > 0 || Number(p.stock ?? -1) >= 0 }; }).filter((p) => p.hasVariants && p.stock < 15);
  return {
    from, to, total, by: Object.fromEntries(Object.entries(by).map(([k, v]) => [k, v.n])),
    confirmationRate: total ? confirmedish / total : 0, deliveryRate: closed ? by.delivered.n / closed : null,
    revenue, ads, spendUsd, net, breakdown: { revenue, product, courier, confirm, returns, pack, ads, net },
    daily, products, wilayas, agents, waiting, abandoned, lowStock
  };
}

async function adsReport(sid, from, to) {
  const costs = getSetting('costs', sid);
  const rate = costs.usdRate || 255;
  const camps = (await D.all(`SELECT campaign_id id, MAX(campaign_name) name, MAX(platform) platform, SUM(spend_usd) spend, SUM(impressions) impr, SUM(clicks) clicks, SUM(results) results FROM ad_spend WHERE store_id = ? AND date BETWEEN ? AND ? GROUP BY campaign_id ORDER BY spend DESC`, sid, from, to));
  const orderStats = { get: (...a) => D.get(`SELECT COUNT(*) n, SUM(status IN ('confirmed','shipped','delivered','returned')) c, SUM(status='delivered') d, SUM(status='returned') r,
      SUM(CASE WHEN status='delivered' THEN items_price + upsell_price ELSE 0 END) rev, SUM(CASE WHEN status='delivered' THEN unit_cost*quantity ELSE 0 END) pc
      FROM orders WHERE store_id = ? AND ${inRange} AND (utm_campaign = ? OR (? != '' AND utm_campaign = ?))`, ...a) };
  const list = [];
  for (const c of camps) {
    const s = await orderStats.get(sid, from, to, c.id, c.name || '', c.name || '');
    const spendDa = (c.spend || 0) * rate;
    const d = s.d || 0;
    const margin = d ? ((s.rev || 0) - (s.pc || 0) - d * costs.courierPerDelivered - d * costs.confirmPerDelivered - (s.r || 0) * (costs.returnFee || 0)) / d : 0;
    const cpd = d ? spendDa / d : null;
    const profit = (s.rev || 0) - (s.pc || 0) - d * costs.courierPerDelivered - d * costs.confirmPerDelivered - (s.r || 0) * (costs.returnFee || 0) - spendDa;
    let verdict = 'Waiting';
    if (d >= 3 && margin > 0) verdict = cpd < margin * 0.7 ? 'Scale' : cpd <= margin ? 'Watch' : 'Cut';
    else if ((s.n || 0) >= 10 && d === 0) verdict = 'Watch';
    list.push({ ...c, spendDa, orders: s.n || 0, confirmed: s.c || 0, delivered: d, returned: s.r || 0, revenue: s.rev || 0,
      cpm: c.impr ? (c.spend / c.impr) * 1000 : 0, ctr: c.impr ? c.clicks / c.impr : 0, cpc: c.clicks ? c.spend / c.clicks : 0, cpl: c.results ? c.spend / c.results : (s.n ? c.spend / s.n : 0),
      cr: s.n ? (s.c || 0) / s.n : 0, dr: (d + (s.r || 0)) ? d / (d + (s.r || 0)) : 0, cpd, breakeven: margin, profit, verdict });
  }
  const unmatched = (await D.get(`SELECT COUNT(*) n FROM orders WHERE store_id = ? AND ${inRange} AND utm_campaign = ''`, sid, from, to)).n;
  return { from, to, rate, campaigns: list, unmatched };
}

async function storeExport(sid) {
  const all = (sql) => D.all(sql, sid);
  return {
    exported_at: U.nowIso(), store: await storeById(sid),
    settings: Object.fromEntries((await all('SELECT key, value FROM store_settings WHERE store_id = ?')).map((r) => [r.key, parseJson(r.value, {})])),
    products: await all('SELECT * FROM products WHERE store_id = ?'), landings: await all('SELECT * FROM landings WHERE store_id = ?'),
    orders: await all('SELECT * FROM orders WHERE store_id = ?'), abandoned: await all('SELECT * FROM abandoned WHERE store_id = ?'),
    blacklist: await all('SELECT * FROM blacklist WHERE store_id = ?'), ad_spend: await all('SELECT * FROM ad_spend WHERE store_id = ?'),
    users: await all('SELECT id, name, email, role, active, created_at FROM users WHERE store_id = ?')
  };
}

// Whole platform as JSON (images are not included; on Cloudflare, D1 "Time Travel" can also restore any minute of the last 30 days).
async function platformExport() {
  const out = { exported_at: U.nowIso() };
  for (const t of ['settings', 'stores', 'users', 'store_settings', 'products', 'landings', 'orders', 'abandoned', 'blacklist', 'ad_spend', 'landing_stats', 'ai_usage']) out[t] = await D.all(`SELECT * FROM ${t}`);
  out.files = await D.all('SELECT id, store_id, mime, size, created_at FROM files');
  return out;
}
function sendJsonFile(res, data, name) {
  return U.send(res, 200, JSON.stringify(data), { 'Content-Type': 'application/json; charset=utf-8', 'Content-Disposition': `attachment; filename="${name}-${new Date().toISOString().slice(0, 10)}.json"` });
}

// ---------- Router ----------
async function handle(req, res, url) {
  const p = url.pathname.replace(/^\/api\/admin/, '') || '/';
  const m = req.method;
  const q = url.searchParams;
  // CSRF guard: state-changing calls must come from our own fetch() with a JSON content type
  // (a cross-site HTML form cannot send application/json).
  if (m !== 'GET' && m !== 'HEAD' && !String(req.headers['content-type'] || '').includes('application/json')) throw U.httpError(415, 'JSON required');
  const body = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(m) ? await U.readJson(req) : {};
  await prime(0);
  let mm;

  // ===== public auth endpoints =====
  if (p === '/setup-status' && m === 'GET') {
    const P = getSetting('platform');
    return U.json(res, 200, { needsSetup: (await auth.userCount()) === 0, platform: { name: P.name, signupMode: P.signupMode, full: (await D.get('SELECT COUNT(*) n FROM stores')).n >= (P.maxStores || 10) } });
  }
  if (p === '/setup' && m === 'POST') {
    if ((await auth.userCount()) > 0) throw U.httpError(403, 'Already set up');
    await createStore({ storeName: body.storeName || 'متجري', slug: body.slug || 'store', name: body.name, email: body.email, password: body.password, phone: body.phone, aiDaily: 300, isSuper: true });
    if (body.platformName) await setSetting('platform', { ...getSetting('platform'), name: U.str(body.platformName, 60) });
    const r = (await auth.login(req, body.email, body.password));
    return U.json(res, 200, { user: r.user }, { 'Set-Cookie': r.cookie });
  }
  if (p === '/slug-check' && m === 'GET') return U.json(res, 200, await checkStoreSlug(q.get('slug')));
  if (p === '/signup' && m === 'POST') {
    const P = getSetting('platform');
    if ((await auth.userCount()) === 0) throw U.httpError(400, 'Platform not set up yet');
    if (P.signupMode === 'closed') throw U.httpError(403, 'Sign-up is closed for now');
    if (P.signupMode === 'invite' && String(body.invite || '').trim().toUpperCase() !== String(P.inviteCode || '').toUpperCase()) throw U.httpError(403, 'Wrong invite code');
    if ((await D.get('SELECT COUNT(*) n FROM stores')).n >= (P.maxStores || 10)) throw U.httpError(403, 'The platform is full for now. Contact us.');
    if (!U.rateLimit('signup:' + U.clientIp(req), 5, 3600e3)) throw U.httpError(429, 'Too many sign-ups. Try again later.');
    await createStore({ storeName: body.storeName, slug: body.slug, name: body.name, email: body.email, password: body.password, phone: body.phone });
    const r = (await auth.login(req, body.email, body.password));
    return U.json(res, 200, { user: r.user }, { 'Set-Cookie': r.cookie });
  }
  if (p === '/login' && m === 'POST') {
    if (!U.rateLimit('login:' + U.clientIp(req), 10, 15 * 60e3)) throw U.httpError(429, 'Too many attempts. Wait 15 minutes.');
    const r = (await auth.login(req, body.email, body.password));
    if (!r) throw U.httpError(401, 'Wrong email or password');
    if (r.suspended) throw U.httpError(403, 'This store is suspended. Contact the platform.');
    return U.json(res, 200, { user: r.user }, { 'Set-Cookie': r.cookie });
  }
  if (p === '/logout' && m === 'POST') return U.json(res, 200, { ok: true }, { 'Set-Cookie': (await auth.logout(req)) });

  const user = (await auth.currentUser(req));
  if (!user) throw U.httpError(401, 'Login required');
  const need = (section) => { if (!auth.can(user, section)) throw U.httpError(403, 'Your role cannot access ' + section); };
  const sid = user.store_id;
  await prime(sid);

  if (p === '/me' && m === 'GET') {
    const P = getSetting('platform');
    return U.json(res, 200, {
      user, store: getSetting('store', sid).name, storeSlug: user.store_slug, storeUrl: user.store_slug ? storeUrl(req, user.store_slug) : '',
      platform: { name: P.name, baseDomain: P.baseDomain }, ai: await aiStatus(sid), statuses: O.STATUSES, labels: O.STATUS_LABELS
    });
  }
  if (p === '/password' && m === 'POST') {
    const row = (await D.get('SELECT pass_hash FROM users WHERE id = ?', user.id));
    if (!(await auth.verifyPassword(body.current, row.pass_hash))) throw U.httpError(400, 'Current password is wrong');
    if (String(body.next || '').length < 8) throw U.httpError(400, 'New password: 8 characters minimum');
    (await D.run('UPDATE users SET pass_hash = ? WHERE id = ?', (await auth.hashPassword(body.next)), user.id));
    return U.json(res, 200, { ok: true });
  }

  // ===== super admin (platform owner) =====
  if (p.startsWith('/super/')) {
    if (!user.is_super) throw U.httpError(403, 'Platform admin only');
    if (p === '/super/stores' && m === 'GET') {
      const since = new Date(Date.now() - 7 * 864e5).toISOString();
      const rows = (await D.all(`SELECT s.*,
          (SELECT email FROM users u WHERE u.store_id = s.id AND u.role = 'owner' ORDER BY id LIMIT 1) owner_email,
          (SELECT name FROM users u WHERE u.store_id = s.id AND u.role = 'owner' ORDER BY id LIMIT 1) owner_name,
          (SELECT COUNT(*) FROM users u WHERE u.store_id = s.id) users,
          (SELECT COUNT(*) FROM products x WHERE x.store_id = s.id) products,
          (SELECT COUNT(*) FROM landings x WHERE x.store_id = s.id) landings,
          (SELECT COUNT(*) FROM orders x WHERE x.store_id = s.id) orders,
          (SELECT COUNT(*) FROM orders x WHERE x.store_id = s.id AND x.created_at > ?) orders7,
          (SELECT COALESCE(images,0) FROM ai_usage a WHERE a.store_id = s.id AND a.date = ?) ai_today
        FROM stores s ORDER BY s.id`, since, dzToday()));
      const aiTotal = (await D.get('SELECT COALESCE(SUM(images),0) n FROM ai_usage WHERE date = ?', dzToday())).n;
      return U.json(res, 200, { rows: rows.map((r) => ({ ...r, url: storeUrl(req, r.slug) })), aiToday: aiTotal, platform: mask(getSetting('platform'), 'platform') });
    }
    if (p === '/super/stores' && m === 'POST') {
      const id = await createStore({ storeName: body.storeName, slug: body.slug, name: body.name, email: body.email, password: body.password, phone: body.phone, aiDaily: U.int(body.aiDaily, 30) });
      return U.json(res, 200, { id });
    }
    if ((mm = p.match(/^\/super\/stores\/(\d+)(\/password)?$/))) {
      const id = U.int(mm[1]);
      const st = await storeById(id);
      await prime(id);
      if (!st) throw U.httpError(404, 'Store not found');
      if (mm[2] && m === 'POST') {
        if (String(body.password || '').length < 8) throw U.httpError(400, 'Password: 8 characters minimum');
        const owner = (await D.get("SELECT id, email FROM users WHERE store_id = ? AND role = 'owner' ORDER BY id LIMIT 1", id));
        if (!owner) throw U.httpError(404, 'No owner');
        (await D.run('UPDATE users SET pass_hash = ? WHERE id = ?', (await auth.hashPassword(body.password)), owner.id));
        (await D.run('DELETE FROM sessions WHERE user_id = ?', owner.id));
        return U.json(res, 200, { ok: true, email: owner.email });
      }
      if (m === 'PATCH') {
        if (body.status !== undefined) {
          if (!['active', 'suspended'].includes(body.status)) throw U.httpError(400, 'Bad status');
          if (id === sid && body.status !== 'active') throw U.httpError(400, 'You cannot suspend your own store');
          (await D.run('UPDATE stores SET status = ? WHERE id = ?', body.status, id));
          if (body.status !== 'active') (await D.run('DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE store_id = ? AND is_super = 0)', id));
        }
        if (body.ai_daily_images !== undefined) (await D.run('UPDATE stores SET ai_daily_images = ? WHERE id = ?', Math.max(0, Math.min(2000, U.int(body.ai_daily_images))), id));
        if (body.name) { const n = U.str(body.name, 80); (await D.run('UPDATE stores SET name = ? WHERE id = ?', n, id)); await setSetting('store', { ...getSetting('store', id), name: n }, id); }
        return U.json(res, 200, { store: await storeById(id) });
      }
      if (m === 'DELETE') {
        if (id === sid) throw U.httpError(400, 'You cannot delete your own store');
        if (st.status !== 'suspended') throw U.httpError(400, 'Suspend the store first');
        if (q.get('confirm') !== st.slug) throw U.httpError(400, 'Type the store link to confirm');
        (await D.run('DELETE FROM landing_stats WHERE landing_id IN (SELECT id FROM landings WHERE store_id = ?)', id));
        (await D.run('DELETE FROM ai_usage WHERE store_id = ?', id));
        (await D.run('DELETE FROM stores WHERE id = ?', id));
        return U.json(res, 200, { ok: true });
      }
    }
    if (p === '/super/settings' && m === 'GET') return U.json(res, 200, { ai: mask(getSetting('ai'), 'ai'), platform: getSetting('platform') });
    if ((mm = p.match(/^\/super\/settings\/(ai|platform)$/)) && m === 'PUT') {
      const key = mm[1];
      const next = mergeSetting(key, getSetting(key), body);
      if (key === 'ai') cleanAi(next);
      if (key === 'platform') {
        next.signupMode = ['open', 'invite', 'closed'].includes(next.signupMode) ? next.signupMode : 'invite';
        next.baseDomain = String(next.baseDomain || '').toLowerCase().replace(/^https?:\/\//, '').replace(/[/:].*$/, '').replace(/^\.+/, '');
        next.maxStores = Math.max(1, Math.min(1000, U.int(next.maxStores, 10)));
        if (!next.inviteCode) next.inviteCode = randomHex(4).toUpperCase();
      }
      await setSetting(key, next);
      return U.json(res, 200, { ai: mask(getSetting('ai'), 'ai'), platform: getSetting('platform') });
    }
    if (p === '/super/ai-test' && m === 'POST') {
      const out = { text: null, image: null };
      try {
        const j = await LAI.textAI('Reply with JSON only: {"ok": true, "word": "<one Darija word meaning hello>"}');
        out.text = { ok: true, detail: JSON.stringify(j).slice(0, 120) };
      } catch (e) { out.text = { ok: false, detail: e.message === 'no-ai' ? 'Text AI is off' : e.message }; }
      if (body.image) {
        try {
          const r = await LAI.scene({ prompt: 'A bright modern Algerian living room, soft daylight, photorealistic, no text', aspect: '1:1', storeId: sid });
          out.image = { ok: !!r.url, url: r.url, model: LAI.aiCfg().cfImageModel };
        } catch (e) { out.image = { ok: false, detail: e.message }; }
      }
      return U.json(res, 200, out);
    }
    if (p === '/super/backup' && m === 'GET') return sendJsonFile(res, await platformExport(), 'platform-backup');
    throw U.httpError(404, 'Unknown platform route');
  }

  if (!sid) throw U.httpError(400, 'This account has no store');

  // ----- geo -----
  if (p === '/geo' && m === 'GET') {
    const d = getSetting('delivery', sid);
    return U.json(res, 200, { mode: d.wilayaMode, wilayas: geo.wilayas(69), active: geo.wilayas(d.wilayaMode).map((w) => w.code), communes: await geo.communesCount() });
  }
  if (p === '/geo/communes' && m === 'POST') { if (!user.is_super) throw U.httpError(403, 'Platform admin only'); const n = await geo.downloadCommunes(); return U.json(res, 200, { communes: n }); }

  // ----- overview -----
  if (p === '/overview' && m === 'GET') { need('overview'); const r = range(q); return U.json(res, 200, await overview(sid, r.from, r.to)); }

  // ----- orders -----
  if (p === '/orders' && m === 'GET') {
    need('orders');
    const where = ['store_id = ?'];
    const args = [sid];
    if (q.get('from') || q.get('to')) { const r = range(q); where.push(inRange); args.push(r.from, r.to); }
    if (q.get('product')) { where.push('product_id = ?'); args.push(U.int(q.get('product'))); }
    if (q.get('flag')) where.push("flags != ''");
    if (q.get('q')) {
      const s = '%' + q.get('q').trim() + '%';
      where.push('(name LIKE ? OR phone LIKE ? OR commune LIKE ? OR wilaya_name LIKE ? OR CAST(id AS TEXT) = ? OR tracking LIKE ?)');
      args.push(s, s, s, s, q.get('q').trim(), s);
    }
    const counts = Object.fromEntries((await D.all(`SELECT status, COUNT(*) n FROM orders WHERE ${where.join(' AND ')} GROUP BY status`, ...args)).map((r) => [r.status, r.n]));
    if (q.get('status') && q.get('status') !== 'all') { where.push('status = ?'); args.push(q.get('status')); }
    const w = 'WHERE ' + where.join(' AND ');
    const limit = Math.min(500, U.int(q.get('limit'), 100));
    const offset = Math.max(0, U.int(q.get('offset'), 0));
    const rows = (await D.all(`SELECT id, created_at, name, phone, wilaya_code, wilaya_name, commune, delivery, product_id, product_name, variant, quantity, total, status, attempts, flags, note, tracking, utm_campaign, upsell, agent_id FROM orders ${w} ORDER BY id DESC LIMIT ? OFFSET ?`, ...args, limit, offset));
    const total = (await D.get(`SELECT COUNT(*) n FROM orders ${w}`, ...args)).n;
    return U.json(res, 200, { rows, total, counts });
  }
  if (p === '/orders' && m === 'POST') {
    need('orders');
    const r = await O.createOrder(sid, { ...body, landing_id: null }, { ip: 'admin', ua: 'admin' });
    await O.updateOrder(sid, r.order.id, { addNote: 'Created manually by ' + user.name }, user);
    return U.json(res, 200, { order: r.order });
  }
  if (p === '/orders/export.csv' && m === 'GET') {
    need('orders');
    const ids = (q.get('ids') || '').split(',').map((x) => U.int(x)).filter(Boolean).slice(0, 2000);
    let rows;
    if (ids.length) rows = (await D.all(`SELECT * FROM orders WHERE store_id = ? AND id IN (${ids.map(() => '?').join(',')}) ORDER BY id`, sid, ...ids));
    else if (q.get('status')) rows = (await D.all('SELECT * FROM orders WHERE store_id = ? AND status = ? ORDER BY id', sid, q.get('status')));
    else rows = (await D.all('SELECT * FROM orders WHERE store_id = ? ORDER BY id DESC LIMIT 5000', sid));
    return U.send(res, 200, integ.courierCsv(rows), { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="orders-${new Date().toISOString().slice(0, 10)}.csv"` });
  }
  if (p === '/orders/bulk' && m === 'POST') {
    need('orders');
    const ids = (body.ids || []).map((x) => U.int(x)).filter(Boolean).slice(0, 1000);
    if (!O.STATUSES.includes(body.status)) throw U.httpError(400, 'Bad status');
    let n = 0;
    for (const id of ids) { try { await O.updateOrder(sid, id, { status: body.status }, user); n++; } catch (e) { if (e.status !== 404) throw e; } }
    return U.json(res, 200, { updated: n });
  }
  if ((mm = p.match(/^\/orders\/(\d+)$/))) {
    need('orders');
    if (m === 'GET') {
      const o = orderRow((await D.get('SELECT * FROM orders WHERE id = ? AND store_id = ?', U.int(mm[1]), sid)));
      if (!o) throw U.httpError(404, 'Not found');
      const customer = await O.customerScore(sid, o.phone);
      const blacklisted = !!(await D.get('SELECT 1 FROM blacklist WHERE store_id = ? AND phone = ?', sid, o.phone));
      const agent = o.agent_id ? (await D.get('SELECT name FROM users WHERE id = ? AND store_id = ?', o.agent_id, sid)) : null;
      const ipk = U.ipKey(o.ip, getSetting('fraud', sid).blockIpv6Range !== false);
      const ipBlocked = ipk ? !!(await D.get('SELECT 1 FROM ip_blocklist WHERE store_id = ? AND ip = ?', sid, ipk)) : false;
      const ipOrders = ipk ? (await D.get('SELECT COUNT(*) n FROM orders WHERE store_id = ? AND ip LIKE ?', sid, ipk.endsWith('::/64') ? ipk.replace('::/64', ':') + '%' : ipk)).n : 0;
      return U.json(res, 200, { order: o, customer, blacklisted, agent: agent && agent.name, ipKey: ipk, ipBlocked, ipOrders, courier: getSetting('couriers', sid).provider });
    }
    if (m === 'PATCH') return U.json(res, 200, { order: await O.updateOrder(sid, mm[1], body, user) });
  }

  // ----- delivery companies -----
  if ((mm = p.match(/^\/orders\/(\d+)\/courier$/)) && m === 'POST') { need('orders'); return U.json(res, 200, await C.pushOrder(sid, U.int(mm[1]))); }
  if ((mm = p.match(/^\/orders\/(\d+)\/courier-status$/)) && m === 'POST') {
    need('orders');
    const r = await C.refreshStatus(sid, U.int(mm[1]));
    if (r.suggested) await O.updateOrder(sid, U.int(mm[1]), { status: r.suggested, addNote: 'Courier status: ' + r.courier_status }, { id: null, name: 'courier' });
    return U.json(res, 200, r);
  }
  if (p === '/orders/courier-bulk' && m === 'POST') {
    need('orders');
    const ids = (body.ids || []).map((x) => U.int(x)).filter(Boolean).slice(0, 100);
    const out = [];
    for (const id of ids) { try { out.push({ id, ok: true, ...(await C.pushOrder(sid, id)) }); } catch (e) { out.push({ id, ok: false, error: e.message }); } }
    return U.json(res, 200, { results: out });
  }
  if (p === '/orders/courier-sync' && m === 'POST') {
    need('orders');
    const rows = await D.all("SELECT id FROM orders WHERE store_id = ? AND tracking != '' AND status IN ('confirmed','shipped') ORDER BY updated_at LIMIT 40", sid);
    let changed = 0; const errors = [];
    for (const r of rows) {
      try { const x = await C.refreshStatus(sid, r.id); if (x.suggested) { await O.updateOrder(sid, r.id, { status: x.suggested, addNote: 'Courier status: ' + x.courier_status }, { id: null, name: 'courier' }); changed++; } } catch (e) { errors.push('#' + r.id + ': ' + e.message); if (errors.length > 3) break; }
    }
    return U.json(res, 200, { checked: rows.length, changed, errors });
  }
  if (p === '/couriers' && m === 'GET') { need('settings'); return U.json(res, 200, { providers: C.providerList() }); }
  if (p === '/couriers/test' && m === 'POST') { need('settings'); return U.json(res, 200, { message: await C.test(sid) }); }

  // ----- IP blocking -----
  if (p === '/ipblock' && m === 'GET') { need('customers'); return U.json(res, 200, { rows: await D.all('SELECT * FROM ip_blocklist WHERE store_id = ? ORDER BY created_at DESC LIMIT 500', sid) }); }
  if (p === '/ipblock' && m === 'POST') {
    need('customers');
    const k = U.ipKey(body.ip, getSetting('fraud', sid).blockIpv6Range !== false) || (/^[0-9a-f:]+::\/64$/i.test(String(body.ip || '')) ? String(body.ip) : '');
    if (!k) throw U.httpError(400, 'Not a valid IP address');
    await D.run('INSERT OR REPLACE INTO ip_blocklist(store_id, ip, reason, hits, created_at) VALUES(?,?,?,0,?)', sid, k, U.str(body.reason, 200) || 'manual', U.nowIso());
    return U.json(res, 200, { ok: true, ip: k });
  }
  if (p === '/ipblock' && m === 'DELETE') { need('customers'); await D.run('DELETE FROM ip_blocklist WHERE store_id = ? AND ip = ?', sid, String(q.get('ip') || '')); return U.json(res, 200, { ok: true }); }

  // ----- pixels: send a test server event -----
  if (p === '/tracking/test' && m === 'POST') {
    need('settings');
    const fake = { id: 0, store_id: sid, name: 'Test Client', phone: '0555000000', commune: 'Alger', total: 1000, quantity: 1, product_id: 0 };
    const results = await integ.metaCapi({ eventName: 'Purchase', eventId: 'test-' + Date.now(), order: fake, extra: { url: 'https://example.com/test' } });
    return U.json(res, 200, { results });
  }

  // ----- customers -----
  if (p === '/customers' && m === 'GET') {
    need('customers');
    const s = q.get('q') ? '%' + q.get('q') + '%' : '%';
    const rows = (await D.all(`SELECT phone, MAX(name) name, MAX(wilaya_code || ' ' || wilaya_name) wilaya, COUNT(*) orders, SUM(status='delivered') delivered, SUM(status='returned') returned,
      SUM(CASE WHEN status='delivered' THEN total ELSE 0 END) spent, MAX(created_at) last FROM orders WHERE store_id = ? AND (name LIKE ? OR phone LIKE ?) GROUP BY phone ORDER BY last DESC LIMIT 300`, sid, s, s));
    const black = new Set((await D.all('SELECT phone FROM blacklist WHERE store_id = ?', sid)).map((r) => r.phone));
    return U.json(res, 200, { rows: rows.map((r) => ({ ...r, blacklisted: black.has(r.phone) })) });
  }
  if (p === '/abandoned' && m === 'GET') {
    need('customers');
    const rows = (await D.all(`SELECT a.*, p.name product_name FROM abandoned a LEFT JOIN products p ON p.id = a.product_id WHERE a.store_id = ? AND a.status = 'open' AND a.phone != '' ORDER BY a.id DESC LIMIT 300`, sid));
    return U.json(res, 200, { rows });
  }
  if ((mm = p.match(/^\/abandoned\/(\d+)$/)) && m === 'POST') {
    need('customers');
    (await D.run('UPDATE abandoned SET status = ?, updated_at = ? WHERE id = ? AND store_id = ?', body.status === 'converted' ? 'converted' : 'dismissed', U.nowIso(), U.int(mm[1]), sid));
    return U.json(res, 200, { ok: true });
  }
  if (p === '/blacklist' && m === 'GET') { need('customers'); return U.json(res, 200, { rows: (await D.all('SELECT * FROM blacklist WHERE store_id = ? ORDER BY created_at DESC', sid)) }); }
  if (p === '/blacklist' && m === 'POST') {
    need('customers');
    const phone = U.normalizePhone(body.phone);
    if (!phone) throw U.httpError(400, 'Bad phone');
    (await D.run('INSERT OR REPLACE INTO blacklist(store_id, phone, reason, created_at) VALUES(?,?,?,?)', sid, phone, U.str(body.reason, 200), U.nowIso()));
    return U.json(res, 200, { ok: true });
  }
  if ((mm = p.match(/^\/blacklist\/(\d+)$/)) && m === 'DELETE') { need('customers'); (await D.run('DELETE FROM blacklist WHERE store_id = ? AND phone = ?', sid, mm[1])); return U.json(res, 200, { ok: true }); }

  // ----- uploads -----
  if (p === '/upload' && m === 'POST') {
    if (!['products', 'landings', 'design'].some((s) => auth.can(user, s))) throw U.httpError(403, 'Not allowed');
    if (!U.rateLimit('up:' + sid, 400, 3600e3)) throw U.httpError(429, 'Upload limit reached, try again in an hour');
    return U.json(res, 200, { url: await files.saveDataUrl(sid, body.data, body.mime) });
  }

  // ----- products -----
  async function insertProduct(sid2, c, slug) {
    const now = U.nowIso();
    const r = await D.run(`INSERT INTO products(store_id, name, slug, short_desc, description, specs, price, old_price, cost, category, images, offers, variants, live, seo_title, sort, stock, preorder, preorder_note, created_at, updated_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, sid2, c.name, await uniqueSlug('products', sid2, slug || c.name), c.short_desc, c.description, c.specs, c.price, c.old_price, c.cost, c.category, c.images, c.offers, c.variants, c.live, c.seo_title, c.sort, c.stock, c.preorder, c.preorder_note, now, now);
    return Number(r.lastInsertRowid);
  }
  const getProduct = async (id) => productRow((await D.get('SELECT * FROM products WHERE id = ? AND store_id = ?', id, sid)));
  if (p === '/products' && m === 'GET') {
    if (!auth.can(user, 'products') && !auth.can(user, 'landings') && !auth.can(user, 'orders')) throw U.httpError(403, 'Not allowed');
    const rows = (await D.all('SELECT * FROM products WHERE store_id = ? ORDER BY sort, id DESC', sid)).map(productRow);
    const lc = Object.fromEntries((await D.all('SELECT product_id, COUNT(*) n FROM landings WHERE store_id = ? GROUP BY product_id', sid)).map((r) => [r.product_id, r.n]));
    return U.json(res, 200, { rows: rows.map((r) => ({ ...r, landings: lc[r.id] || 0 })) });
  }
  if (p === '/products' && m === 'POST') {
    need('products');
    if ((await D.get('SELECT COUNT(*) n FROM products WHERE store_id = ?', sid)).n >= 500) throw U.httpError(400, 'Product limit reached (500)');
    const id = await insertProduct(sid, cleanProduct(body), body.slug);
    return U.json(res, 200, { product: await getProduct(id) });
  }
  // Import (CSV / Excel / Shopify): the browser parses the file and sends one product per request.
  if (p === '/products/import' && m === 'POST') {
    need('products');
    if ((await D.get('SELECT COUNT(*) n FROM products WHERE store_id = ?', sid)).n >= 500) throw U.httpError(400, 'Product limit reached (500)');
    const c = cleanProduct(body);
    if (body.skipExisting !== false) {
      const ex = await D.get('SELECT id FROM products WHERE store_id = ? AND name = ?', sid, c.name);
      if (ex) return U.json(res, 200, { skipped: true, id: ex.id });
    }
    return U.json(res, 200, { id: await insertProduct(sid, c, body.slug) });
  }
  // Copy one remote image (Shopify CDN, any https link) into the store's uploads.
  if (p === '/products/import-image' && m === 'POST') {
    need('products');
    if (!U.rateLimit('up:' + sid, 400, 3600e3)) throw U.httpError(429, 'Upload limit reached, try again in an hour');
    let u;
    try { u = new URL(String(body.url || '')); } catch { throw U.httpError(400, 'Bad image link'); }
    if (!/^https?:$/.test(u.protocol)) throw U.httpError(400, 'Bad image link');
    if (/shopify/.test(u.hostname) && !u.searchParams.has('width')) u.searchParams.set('width', '1000');
    const r = await fetch(u.toString(), { signal: AbortSignal.timeout(15000), headers: { 'User-Agent': 'Mozilla/5.0' } }).catch(() => null);
    if (!r || !r.ok) throw U.httpError(400, 'Image not reachable');
    const ct = (r.headers.get('content-type') || '').split(';')[0];
    if (!/^image\/(jpeg|png|webp|gif)$/.test(ct)) throw U.httpError(400, 'Not an image');
    const buf = new Uint8Array(await r.arrayBuffer());
    if (buf.length > 1400000) throw U.httpError(400, 'Image too big (max 1.4 MB)');
    return U.json(res, 200, { url: await files.saveBytes(sid, buf, ct) });
  }
  if ((mm = p.match(/^\/products\/(\d+)$/))) {
    const id = U.int(mm[1]);
    need('products');
    const cur = await getProduct(id);
    if (!cur) throw U.httpError(404, 'Not found');
    if (m === 'GET') return U.json(res, 200, { product: cur });
    if (m === 'PUT') {
      const c = cleanProduct(body);
      (await D.run(`UPDATE products SET name=?, slug=?, short_desc=?, description=?, specs=?, price=?, old_price=?, cost=?, category=?, images=?, offers=?, variants=?, live=?, seo_title=?, sort=?, stock=?, preorder=?, preorder_note=?, updated_at=? WHERE id=? AND store_id=?`, c.name, await uniqueSlug('products', sid, body.slug || c.name, id), c.short_desc, c.description, c.specs, c.price, c.old_price, c.cost, c.category, c.images, c.offers, c.variants, c.live, c.seo_title, c.sort, c.stock, c.preorder, c.preorder_note, U.nowIso(), id, sid));
      return U.json(res, 200, { product: await getProduct(id) });
    }
    if (m === 'DELETE') { (await D.run('DELETE FROM products WHERE id = ? AND store_id = ?', id, sid)); return U.json(res, 200, { ok: true }); }
  }

  // ----- landings -----
  const getLanding = async (id) => (await D.get('SELECT * FROM landings WHERE id = ? AND store_id = ?', id, sid));
  if (p === '/landings' && m === 'GET') {
    need('landings');
    const r = range(q);
    const rows = (await D.all(`SELECT l.*, p.name product_name, p.images product_images,
        (SELECT COALESCE(SUM(visits),0) FROM landing_stats s WHERE s.landing_id = l.id AND s.date BETWEEN ? AND ?) rv,
        (SELECT COUNT(*) FROM orders o WHERE o.landing_id = l.id AND o.store_id = l.store_id AND date(o.created_at, '${TZ}') BETWEEN ? AND ?) ro
        FROM landings l JOIN products p ON p.id = l.product_id WHERE l.store_id = ? ORDER BY l.id DESC`, r.from, r.to, r.from, r.to, sid));
    return U.json(res, 200, { rows: rows.map((x) => ({ ...landingRow(x), product_image: parseJson(x.product_images, [])[0] || '', rangeVisits: x.rv, rangeOrders: x.ro })) });
  }
  if (p === '/landings' && m === 'POST') {
    need('landings');
    const prod = (await D.get('SELECT id, name FROM products WHERE id = ? AND store_id = ?', U.int(body.product_id), sid));
    if (!prod) throw U.httpError(400, 'Choose a product');
    if ((await D.get('SELECT COUNT(*) n FROM landings WHERE store_id = ?', sid)).n >= 300) throw U.httpError(400, 'Landing page limit reached (300)');
    const now = U.nowIso();
    const r = (await D.run('INSERT INTO landings(store_id, product_id, title, slug, lang, content, pixel_meta, pixel_tiktok, live, ai, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)', sid, prod.id, U.str(body.title, 140) || prod.name, await uniqueSlug('landings', sid, body.slug || body.title || prod.name), ['ar', 'dz', 'fr'].includes(body.lang) ? body.lang : 'ar',
        JSON.stringify(cleanLandingContent(body.content || {})), U.str(body.pixel_meta, 40), U.str(body.pixel_tiktok, 40), body.live === false ? 0 : 1, body.ai ? 1 : 0, now, now));
    return U.json(res, 200, { landing: landingRow(await getLanding(Number(r.lastInsertRowid))) });
  }
  if ((mm = p.match(/^\/landings\/(\d+)(\/duplicate)?$/))) {
    need('landings');
    const id = U.int(mm[1]);
    const l = await getLanding(id);
    if (!l) throw U.httpError(404, 'Not found');
    if (mm[2] && m === 'POST') {
      const now = U.nowIso();
      const r = (await D.run('INSERT INTO landings(store_id, product_id, title, slug, lang, content, pixel_meta, pixel_tiktok, live, ai, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?,0,?,?,?)', sid, l.product_id, l.title + ' (B)', await uniqueSlug('landings', sid, l.slug + '-b'), l.lang, l.content, l.pixel_meta, l.pixel_tiktok, l.ai, now, now));
      return U.json(res, 200, { landing: landingRow(await getLanding(Number(r.lastInsertRowid))) });
    }
    if (m === 'GET') return U.json(res, 200, { landing: landingRow(l) });
    if (m === 'PUT') {
      let pid = U.int(body.product_id) || l.product_id;
      if (!(await D.get('SELECT 1 FROM products WHERE id = ? AND store_id = ?', pid, sid))) pid = l.product_id;
      (await D.run('UPDATE landings SET product_id=?, title=?, slug=?, lang=?, content=?, pixel_meta=?, pixel_tiktok=?, live=?, updated_at=? WHERE id=? AND store_id=?', pid, U.str(body.title, 140) || l.title, await uniqueSlug('landings', sid, body.slug || l.slug, id), ['ar', 'dz', 'fr'].includes(body.lang) ? body.lang : l.lang,
          JSON.stringify(cleanLandingContent(body.content || {})), U.str(body.pixel_meta, 40), U.str(body.pixel_tiktok, 40), body.live ? 1 : 0, U.nowIso(), id, sid));
      return U.json(res, 200, { landing: landingRow(await getLanding(id)) });
    }
    if (m === 'DELETE') { (await D.run('DELETE FROM landings WHERE id = ? AND store_id = ?', id, sid)); return U.json(res, 200, { ok: true }); }
  }

  // ----- AI (keys are the platform's; each store has a daily quota) -----
  if (p === '/ai/status' && m === 'GET') { need('landings'); return U.json(res, 200, await aiStatus(sid)); }
  if (p === '/ai/generate' && m === 'POST') {
    need('landings');
    const u = await aiUsage(sid);
    if (u.analyses >= u.analysesLimit) throw U.httpError(429, `Daily AI limit reached (${u.analysesLimit}). Try again tomorrow.`);
    if (!U.rateLimit('ai:' + user.id, 20, 3600e3)) throw U.httpError(429, 'AI limit: 20 pages per hour');
    let image = null;
    const mt = String(body.image || '').match(/^data:(image\/[a-z]+);base64,(.*)$/);
    if (mt) image = { mime: mt[1], data: mt[2] };
    const r = await ai.generate({ image, description: U.str(body.description, 2000), productName: U.str(body.productName, 120), price: U.int(body.price), lang: body.lang, angle: body.angle });
    await bumpAi(sid, 'analyses');
    return U.json(res, 200, r);
  }
  if (p === '/ai/analyze' && m === 'POST') {
    need('landings');
    const u = await aiUsage(sid);
    if (u.analyses >= u.analysesLimit) throw U.httpError(429, `Daily AI limit reached (${u.analysesLimit} analyses). Try again tomorrow.`);
    if (!U.rateLimit('aia:' + user.id, 30, 3600e3)) throw U.httpError(429, 'AI limit: 30 analyses per hour');
    const toImg = (x) => { const mt = String(x || '').match(/^data:(image\/[a-z]+);base64,(.*)$/); return mt ? { mime: mt[1], data: mt[2] } : null; };
    const images = (Array.isArray(body.images) ? body.images : [body.image]).slice(0, 3).map(toImg).filter(Boolean);
    const image = images[0] || null;
    const r = await LAI.analyze({ image, images, description: U.str(body.description, 2000), productName: U.str(body.productName, 120), price: U.int(body.price), lang: body.lang });
    if (r.provider !== 'template') await bumpAi(sid, 'analyses');
    return U.json(res, 200, { ...r, usage: await aiUsage(sid) });
  }
  if (p === '/ai/scene' && m === 'POST') {
    need('landings');
    const u = await aiUsage(sid);
    if (u.images >= u.imagesLimit) return U.json(res, 200, { url: null, warning: `Daily AI image limit reached (${u.imagesLimit}). Designs use your product photo instead.`, usage: u });
    if (!U.rateLimit('ais:' + user.id, 120, 3600e3)) throw U.httpError(429, 'Image limit: 120 images per hour');
    try {
      const ref = U.str(body.refUrl, 300);
      const { url, withProduct } = await LAI.scene({ prompt: U.str(body.prompt, 900), productUrl: U.str(body.productUrl, 300), refUrl: ref.startsWith('/uploads/') ? ref : '', aspect: ['1:1', '4:5', '3:4', '9:16'].includes(body.aspect) ? body.aspect : '1:1', storeId: sid });
      if (url) await bumpAi(sid, 'images');
      return U.json(res, 200, { url, withProduct: !!withProduct, usage: await aiUsage(sid) });
    } catch (e) {
      return U.json(res, 200, { url: null, warning: e.message, usage: await aiUsage(sid) });
    }
  }

  // ----- ads -----
  if (p === '/ads' && m === 'GET') { need('ads'); const r = range(q); return U.json(res, 200, await adsReport(sid, r.from, r.to)); }
  if (p === '/ads/sync' && m === 'POST') { need('ads'); const n = await integ.syncMetaAds(sid, Math.max(1, Math.min(400, U.int(body.days, 90)))); return U.json(res, 200, { rows: n }); }
  if (p === '/ads/manual' && m === 'POST') {
    need('ads');
    const date = U.str(body.date, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw U.httpError(400, 'Date YYYY-MM-DD');
    const cid = U.str(body.campaign_id, 120) || U.str(body.campaign_name, 120);
    if (!cid) throw U.httpError(400, 'Campaign ID or name');
    (await D.run(`INSERT INTO ad_spend(store_id, date, campaign_id, campaign_name, platform, spend_usd, impressions, clicks, results) VALUES(?,?,?,?,?,?,?,?,?)
      ON CONFLICT(store_id, date, campaign_id) DO UPDATE SET campaign_name=excluded.campaign_name, platform=excluded.platform, spend_usd=excluded.spend_usd, impressions=excluded.impressions, clicks=excluded.clicks, results=excluded.results`, sid, date, cid, U.str(body.campaign_name, 120) || cid, U.str(body.platform, 20) || 'manual', U.num(body.spend_usd), U.int(body.impressions), U.int(body.clicks), U.int(body.results)));
    return U.json(res, 200, { ok: true });
  }

  // ----- store settings -----
  if (p === '/settings' && m === 'GET') {
    if (!auth.can(user, 'settings') && !auth.can(user, 'design')) throw U.httpError(403, 'Not allowed');
    return U.json(res, 200, { settings: maskAll(storeSettings(sid)) });
  }
  if ((mm = p.match(/^\/settings\/([a-z]+)$/)) && m === 'PUT') {
    const key = mm[1];
    if (!DEFAULTS[key] || PLATFORM_KEYS.includes(key)) throw U.httpError(404, 'Unknown settings');
    need(SECTION_FOR_SETTING[key]);
    const cur = getSetting(key, sid);
    let next = mergeSetting(key, cur, body);
    if (key === 'tracking') { next.meta = cleanPixels(body.meta, cur.meta, true); next.tiktok = cleanPixels(body.tiktok, cur.tiktok, false); next.purchaseOn = ['placed', 'confirmed', 'delivered'].includes(next.purchaseOn) ? next.purchaseOn : 'placed'; next.events = { ...DEFAULTS.tracking.events, ...(typeof body.events === 'object' && body.events ? body.events : cur.events) }; next.metaPixel = String(next.metaPixel || '').replace(/\D/g, ''); }
    if (key === 'form') next = cleanForm(body);
    if (key === 'couriers') { next.provider = C.PROVIDERS[next.provider] ? next.provider : 'none'; next.autoPush = !!next.autoPush; for (const f of ['apiId', 'apiToken', 'apiKey', 'userGuid', 'host']) next[f] = String(next[f] || '').trim(); }
    if (key === 'integrations') { next.metaAdAccount = String(next.metaAdAccount || '').trim(); next.metaAdsToken = String(next.metaAdsToken || '').trim(); }
    if (key === 'theme') for (const c of ['primary', 'accent', 'ink', 'bg']) if (!/^#[0-9a-fA-F]{6}$/.test(next[c])) next[c] = DEFAULTS.theme[c];
    if (key === 'delivery') next.wilayaMode = Number(next.wilayaMode) === 69 ? 69 : 58;
    if (key === 'integrations' && next.sheetsUrl && !/^https:\/\/script\.google\.com\//.test(next.sheetsUrl)) throw U.httpError(400, 'Google Sheets link must start with https://script.google.com/');
    await setSetting(key, next, sid);
    return U.json(res, 200, { settings: maskAll(storeSettings(sid)) });
  }

  // ----- team (inside this store only) -----
  if (p === '/users' && m === 'GET') { need('team'); return U.json(res, 200, { rows: (await D.all('SELECT id, name, email, role, active, created_at FROM users WHERE store_id = ? ORDER BY id', sid)), roles: Object.keys(auth.ROLES) }); }
  if (p === '/users' && m === 'POST') {
    need('team');
    if ((await D.get('SELECT COUNT(*) n FROM users WHERE store_id = ?', sid)).n >= 15) throw U.httpError(400, 'Team limit reached (15)');
    const id = (await auth.createUser({ name: body.name, email: body.email, password: body.password, role: body.role, storeId: sid }));
    return U.json(res, 200, { id });
  }
  if ((mm = p.match(/^\/users\/(\d+)$/))) {
    need('team');
    const id = U.int(mm[1]);
    if (!(await D.get('SELECT 1 FROM users WHERE id = ? AND store_id = ?', id, sid))) throw U.httpError(404, 'Not found');
    if (id === user.id && (m === 'DELETE' || (body.role && body.role !== 'owner') || body.active === false)) throw U.httpError(400, 'You cannot remove or demote yourself');
    if (m === 'PATCH') {
      if (body.role && auth.ROLES[body.role]) (await D.run('UPDATE users SET role = ? WHERE id = ?', body.role, id));
      if (body.active !== undefined) (await D.run('UPDATE users SET active = ? WHERE id = ?', body.active ? 1 : 0, id));
      if (body.password) { if (String(body.password).length < 8) throw U.httpError(400, 'Password: 8 characters minimum'); (await D.run('UPDATE users SET pass_hash = ? WHERE id = ?', (await auth.hashPassword(body.password)), id)); }
      if (body.active === false || body.password) (await D.run('DELETE FROM sessions WHERE user_id = ?', id));
      return U.json(res, 200, { ok: true });
    }
    if (m === 'DELETE') { (await D.run('DELETE FROM users WHERE id = ? AND store_id = ? AND is_super = 0', id, sid)); return U.json(res, 200, { ok: true }); }
  }

  // ----- backup: own store as JSON (the full database is for the platform admin only) -----
  if (p === '/backup' && m === 'GET') {
    need('settings');
    if (user.is_super && q.get('full') === '1') return sendJsonFile(res, await platformExport(), 'platform-backup');
    return U.send(res, 200, JSON.stringify(await storeExport(sid)), { 'Content-Type': 'application/json; charset=utf-8', 'Content-Disposition': `attachment; filename="${user.store_slug || 'store'}-backup-${new Date().toISOString().slice(0, 10)}.json"` });
  }

  throw U.httpError(404, 'Unknown API route');
}

module.exports = { handle };
