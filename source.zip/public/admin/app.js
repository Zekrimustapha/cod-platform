/* Admin dashboard — vanilla JS single-page app. */
(function () {
  'use strict';
  var S = { me: null, settings: null, products: null, geo: null, labels: {}, statuses: [] };
  var app = document.getElementById('app');
  var pollTimer = null;

  // ---------- helpers ----------
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function da(n) { if (n == null || !isFinite(n)) return '—'; var r = Math.round(n); return (r < 0 ? '−' : '') + String(Math.abs(r)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' DA'; }
  function pct(n) { return n == null || !isFinite(n) ? '—' : Math.round(n * 100) + '%'; }
  function usd(n) { return n == null || !isFinite(n) ? '—' : '$' + Number(n).toFixed(2); }
  function num(v) { var n = parseFloat(v); return isFinite(n) ? n : 0; }
  function when(iso) {
    if (!iso) return '';
    var d = new Date(iso), now = new Date(), diff = (now - d) / 60000;
    if (diff < 1) return 'now'; if (diff < 60) return Math.round(diff) + ' min ago'; if (diff < 1440 && d.getDate() === now.getDate()) return d.toTimeString().slice(0, 5);
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }) + ' ' + d.toTimeString().slice(0, 5);
  }
  function today(off) { var d = new Date(Date.now() + 3600e3 - (off || 0) * 864e5); return d.toISOString().slice(0, 10); }
  function qs(o) { return Object.keys(o).filter(function (k) { return o[k] !== '' && o[k] != null; }).map(function (k) { return k + '=' + encodeURIComponent(o[k]); }).join('&'); }
  var toastT;
  function toast(msg, err) { var t = document.getElementById('toast'); t.textContent = msg; t.className = err ? 'err' : ''; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(function () { t.hidden = true; }, err ? 4500 : 2600); }
  function api(method, path, body) {
    var o = { method: method, credentials: 'same-origin', headers: {} };
    if (method !== 'GET') { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(body || {}); }
    return fetch('/api/admin' + path, o).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (r.status === 401 && path !== '/login') { S.me = null; renderLogin(); throw new Error('Login required'); }
        if (!r.ok) throw new Error(j.error || 'HTTP ' + r.status);
        return j;
      });
    });
  }
  function fail(e) { if (e && e.message !== 'Login required') toast(e.message || 'Error', true); }
  function modal(html) {
    var bg = document.createElement('div'); bg.className = 'modal-bg'; bg.innerHTML = '<div class="modal" role="dialog" aria-modal="true">' + html + '</div>';
    document.body.appendChild(bg);
    var close = function () { bg.remove(); };
    bg.addEventListener('click', function (e) { if (e.target === bg || e.target.hasAttribute('data-close')) close(); });
    return { el: bg.firstChild, close: close };
  }
  // ----- background removal (public/admin/cutout.js, loaded on demand) -----
  var cutLib = null;
  function needCutout() {
    if (window.Cutout) return Promise.resolve(window.Cutout);
    if (!cutLib) cutLib = new Promise(function (res, rej) { var sc = document.createElement('script'); sc.src = '/admin/cutout.js?v=2'; sc.onload = function () { res(window.Cutout); }; sc.onerror = function () { cutLib = null; rej(new Error('Cannot load cut-out tool')); }; document.head.appendChild(sc); });
    return cutLib;
  }
  function blobToData(b) { return new Promise(function (res, rej) { var f = new FileReader(); f.onload = function () { res(f.result); }; f.onerror = rej; f.readAsDataURL(b); }); }
  // Cut out a photo and upload the transparent result. done(url) — url '' = remove existing cut-out.
  function cutoutDialog(src, done, existing) {
    var md = modal('<h2>Remove background</h2><div class="cutGrid"><figure><img src="' + esc(src) + '" alt=""><figcaption>Original</figcaption></figure><figure class="chk"><div id="cOut" class="cOut">' + (existing ? '<img src="' + esc(existing) + '" alt="">' : '') + '</div><figcaption id="cInfo">Result</figcaption></figure></div>' +
      '<label class="f">Edge softness <input type="range" id="cFe" min="0" max="4" step="1" value="1"></label><div id="cMsg" class="small muted"></div>' +
      '<div class="row"><button class="btn pri" id="cOk" disabled>Accept</button><button class="btn" id="cRe">' + (existing ? 'Redo' : 'Retry') + '</button>' + (existing ? '<button class="btn" id="cDel">Use original photo</button>' : '') + '<button class="btn" data-close>Cancel</button></div>');
    var q = function (x) { return md.el.querySelector(x); }, last = null;
    var go = function () {
      q('#cOk').disabled = true; q('#cMsg').textContent = 'Loading the free cut-out AI (first time downloads ~120–230 MB, then it is cached)…';
      needCutout().then(function (C) {
        return C.remove(src, { feather: +q('#cFe').value, onProgress: function (pc) { q('#cMsg').textContent = 'Downloading cut-out model, one time only… ' + pc + '%'; } });
      }).then(function (r) {
        last = r; q('#cOut').innerHTML = '<img src="' + r.url + '" alt="">'; q('#cInfo').textContent = 'Result · ' + r.method + ' · ' + r.width + '×' + r.height;
        q('#cMsg').textContent = r.warning ? 'AI cut-out failed (' + r.warning + '), used the simple method.' : 'Check the edges, then Accept.'; q('#cOk').disabled = false;
      }).catch(function (e) { q('#cMsg').textContent = e.message; });
    };
    q('#cRe').onclick = go; q('#cFe').onchange = function () { if (last) go(); };
    if (q('#cDel')) q('#cDel').onclick = function () { md.close(); done(''); };
    q('#cOk').onclick = function () {
      if (!last) return; q('#cOk').disabled = true; q('#cMsg').textContent = 'Uploading…';
      blobToData(last.blob).then(function (d) { return api('POST', '/upload', { data: d }); }).then(function (j) { md.close(); done(j.url); }).catch(function (e) { q('#cOk').disabled = false; fail(e); });
    };
    if (!existing) go();
    return md;
  }
  function statusSelect(cur, attrs) {
    return '<select class="status st-' + cur + '" ' + (attrs || '') + '>' + S.statuses.map(function (s) { return '<option value="' + s + '"' + (s === cur ? ' selected' : '') + '>' + S.labels[s] + '</option>'; }).join('') + '</select>';
  }
  function chip(s) { return '<span class="chip st-' + s + '">' + esc(S.labels[s] || s) + '</span>'; }
  function flags(f) { return (f || '').split(',').filter(Boolean).map(function (x) { return '<span class="flag">' + esc({ blacklisted: 'BLACKLIST', too_many_today: 'MANY TODAY', low_score: 'LOW SCORE', ip_limit: 'MANY FROM SAME IP' }[x] || x) + '</span>'; }).join(''); }
  function can(sec) { if (sec === 'platform') return !!(S.me && S.me.is_super); return S.me && S.me.sections.indexOf(sec) >= 0; }
  function storeLink(path) { return (S.storeUrl || '') + (path || '/'); }
  function quotaText() { var u = S.ai && S.ai.usage; if (!u) return ''; return 'AI images today: ' + u.images + ' / ' + u.imagesLimit + (u.neuronsLimit ? ' · ≈ ' + u.pagesLeft + ' pages left today (' + u.neuronsToday + ' / ' + u.neuronsLimit + ' free Neurons)' : ''); }
  function useQuota(r) { if (r && r.usage && S.ai) { S.ai.usage = r.usage; var q = document.getElementById('gQuota'); if (q) q.textContent = quotaText(); } }
  function waLink(phone) { return 'https://wa.me/213' + String(phone || '').replace(/^0/, ''); }
  function wilayaOptions(cur, all) {
    var codes = all ? null : S.geo.active;
    return S.geo.wilayas.filter(function (w) { return !codes || codes.indexOf(w.code) >= 0; }).map(function (w) { return '<option value="' + w.code + '"' + (w.code === cur ? ' selected' : '') + '>' + w.code + ' - ' + esc(w.fr) + ' · ' + esc(w.ar) + '</option>'; }).join('');
  }

  // Resize images in the browser before upload: fast landing pages on 4G.
  function fileToUpload(file, maxW) {
    maxW = maxW || 1600;
    return new Promise(function (resolve, reject) {
      if (/^video\//.test(file.type)) {
        if (file.size > 1.3 * 1024 * 1024) return reject(new Error('Video too large (max 1.3 MB). Use a short compressed clip, or put the video on YouTube/TikTok.'));
        var fr = new FileReader(); fr.onload = function () { api('POST', '/upload', { data: fr.result }).then(function (j) { resolve(j.url); }, reject); }; fr.onerror = reject; fr.readAsDataURL(file); return;
      }
      if (file.type === 'image/gif') {
        if (file.size > 1.3 * 1024 * 1024) return reject(new Error('GIF too large (max 1.3 MB)'));
        var f2 = new FileReader(); f2.onload = function () { api('POST', '/upload', { data: f2.result }).then(function (j) { resolve(j.url); }, reject); }; f2.readAsDataURL(file); return;
      }
      var img = new Image(); var url = URL.createObjectURL(file);
      img.onload = function () {
        // keep every upload under ~1.3 MB (the database stores the photos)
        var w = maxW, q = 0.82, data, c;
        for (var tries = 0; tries < 6; tries++) {
          var s = Math.min(1, w / img.width); c = document.createElement('canvas');
          c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          data = c.toDataURL('image/webp', q); if (data.indexOf('data:image/webp') !== 0) data = c.toDataURL('image/jpeg', q);
          if (data.length < 1750000) break;
          w = Math.round(w * 0.8); q = Math.max(0.6, q - 0.06);
        }
        URL.revokeObjectURL(url);
        api('POST', '/upload', { data: data }).then(function (j) { resolve(j.url); }, reject);
      };
      img.onerror = function () { reject(new Error('Cannot read image')); };
      img.src = url;
    });
  }
  function uploadMany(files, done) {
    var list = Array.prototype.slice.call(files || []); if (!list.length) return;
    toast('Uploading ' + list.length + ' file(s)…');
    Promise.all(list.map(function (f) { return fileToUpload(f); })).then(function (urls) { toast('Uploaded'); done(urls); }).catch(fail);
  }
  function oneImage(name, url, label) {
    return '<div class="f"><span class="small" style="font-weight:600">' + esc(label) + '</span><div class="one-img"><div class="th">' + (url ? '<img src="' + esc(url) + '" alt="">' : '') + '</div><label class="btn sm" style="position:relative">Upload<input type="file" accept="image/*' + (name === 'video' ? ',video/mp4' : '') + '" data-one="' + name + '" style="position:absolute;inset:0;opacity:0"></label>' + (url ? '<button class="btn sm danger" type="button" data-clear="' + name + '">Remove</button>' : '') + '</div></div>';
  }

  // ---------- login / sign-up / first setup ----------
  function slugify(t) { return String(t || '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 30); }
  function renderLogin() {
    clearInterval(pollTimer);
    api('GET', '/setup-status').then(function (s) {
      var P = s.platform || {}, mode = s.needsSetup ? 'setup' : (location.hash === '#signup' && P.signupMode !== 'closed' ? 'signup' : 'login');
      var title = { setup: 'Create your platform', signup: 'Create your store', login: 'Log in' }[mode];
      var sub = { setup: 'First start: this account is the platform owner (super admin) and also gets the first store.', signup: P.full ? 'The platform is full for now — contact us to get a place.' : 'Free during the test period. Your store gets its own link.', login: esc(P.name || '') }[mode];
      var storeFields = '<label class="f">Store name<input type="text" name="storeName" required maxlength="80" dir="auto"></label>' +
        '<label class="f">Store link<input type="text" name="slug" required placeholder="mystore" dir="ltr" autocapitalize="off"><small class="muted" id="slugHint">a-z, 0-9 and “-”</small></label>';
      var who = '<label class="f">Your name<input type="text" name="name" required maxlength="80"></label>' + (mode !== 'login' ? '<label class="f">Phone / WhatsApp<input type="tel" name="phone" maxlength="20" dir="ltr"></label>' : '');
      var tick = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
      var mk = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7l8-4 8 4-8 4z"/><path d="M4 12l8 4 8-4"/><path d="M4 17l8 4 8-4"/></svg>';
      var art = '<aside class="login-art"><div class="la-top"><span class="brandmark" style="width:36px;height:36px;border-radius:11px;background:linear-gradient(135deg,#10B981,#047857);display:grid;place-items:center">' + mk + '</span>' + esc(P.name || '') + '</div><div><h2>Sell more with cash on delivery.</h2><p>Stores, AI landing pages in Darija, order confirmation, couriers and ad profit — in one dashboard.</p><ul><li>' + tick + 'AI landing pages from one product photo</li><li>' + tick + 'Yalidine, ZR Express, Noest, EcoTrack</li><li>' + tick + 'Fake-order protection & smart pixels</li></ul></div><small>© ' + new Date().getFullYear() + ' ' + esc(P.name || '') + '</small></aside>';
      app.innerHTML = '<div class="login">' + art + '<div class="login-main"><form class="card" id="lf"><span class="brandmark">' + mk + '</span><h1>' + title + '</h1><p class="muted">' + sub + '</p>' +
        (mode === 'setup' ? '<label class="f">Platform name<input type="text" name="platformName" value="' + esc(P.name || '') + '" maxlength="60" dir="auto"></label>' : '') +
        (mode !== 'login' ? storeFields + who : '') +
        '<label class="f">Email<input type="email" name="email" autocomplete="username" required></label><label class="f">Password' + (mode !== 'login' ? ' (8+ characters)' : '') + '<input type="password" name="password" autocomplete="' + (mode !== 'login' ? 'new-password' : 'current-password') + '" minlength="8" required></label>' +
        (mode === 'signup' && P.signupMode === 'invite' ? '<label class="f">Invite code<input type="text" name="invite" required autocapitalize="characters" dir="ltr"></label>' : '') +
        '<button class="btn pri" type="submit"' + (mode === 'signup' && P.full ? ' disabled' : '') + '>' + { setup: 'Create platform', signup: 'Create my store', login: 'Log in' }[mode] + '</button><p class="small" id="lerr" style="color:#9A1C12"></p>' +
        (mode === 'login' && P.signupMode !== 'closed' ? '<p class="small muted">No account? <a href="#signup" id="toSignup">Create your store</a></p>' : '') +
        (mode === 'signup' ? '<p class="small muted">Already have an account? <a href="#" id="toLogin">Log in</a></p>' : '') + '</form></div></div>';
      var f = document.getElementById('lf');
      var ts = document.getElementById('toSignup'); if (ts) ts.onclick = function (e) { e.preventDefault(); history.replaceState(null, '', '#signup'); renderLogin(); };
      var tl = document.getElementById('toLogin'); if (tl) tl.onclick = function (e) { e.preventDefault(); history.replaceState(null, '', '#'); renderLogin(); };
      if (f.storeName) {
        var touched = false, timer;
        var check = function () { clearTimeout(timer); timer = setTimeout(function () { var v = f.slug.value; if (!v) return; api('GET', '/slug-check?slug=' + encodeURIComponent(v)).then(function (r) { var h = document.getElementById('slugHint'); h.textContent = r.ok ? '✓ ' + v + ' is free' : r.error; h.style.color = r.ok ? '#0B5132' : '#9A1C12'; }).catch(function () {}); }, 350); };
        f.storeName.oninput = function () { if (!touched) { f.slug.value = slugify(f.storeName.value); check(); } };
        f.slug.oninput = function () { touched = true; f.slug.value = f.slug.value.toLowerCase().replace(/[^a-z0-9-]/g, ''); check(); };
      }
      f.addEventListener('submit', function (e) {
        e.preventDefault();
        var body = {};
        Array.prototype.forEach.call(f.elements, function (i) { if (i.name) body[i.name] = i.value; });
        api('POST', { setup: '/setup', signup: '/signup', login: '/login' }[mode], body).then(function () { if (mode !== 'login') history.replaceState(null, '', '#/overview'); boot(); }).catch(function (er) { document.getElementById('lerr').textContent = er.message; });
      });
    });
  }

  // ---------- shell ----------
  var NAV = [
    ['Sell', [['overview', 'Overview'], ['orders', 'Orders'], ['customers', 'Customers']]],
    ['Catalog', [['products', 'Products'], ['landings', 'Landing pages'], ['generate', 'AI landing generator', 'landings']]],
    ['Marketing', [['ads', 'Ads & profit'], ['simulator', 'Profit simulator']]],
    ['Store', [['design', 'Store design'], ['settings', 'Settings']]],
    ['Platform', [['platform', 'Stores & platform']]]
  ];
  function svgI(d) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + d + '</svg>'; }
  var NAV_IC = {
    overview: svgI('<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>'),
    orders: svgI('<path d="M6 2l-2 4v14a2 2 0 002 2h12a2 2 0 002-2V6l-2-4z"/><path d="M4 6h16M16 10a4 4 0 01-8 0"/>'),
    customers: svgI('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0113 0"/><path d="M16 4.2a3.5 3.5 0 010 7.6M21.5 20a6.5 6.5 0 00-4-6"/>'),
    products: svgI('<path d="M21 8l-9-5-9 5 9 5z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/>'),
    landings: svgI('<rect x="5" y="2" width="14" height="20" rx="2.5"/><path d="M9 6h6M9 18h6"/>'),
    generate: svgI('<path d="M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>'),
    ads: svgI('<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 6-6"/>'),
    simulator: svgI('<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 6h8M8 11h.01M12 11h.01M16 11h.01M8 15h.01M12 15h.01M16 15h.01M8 19h8"/>'),
    design: svgI('<circle cx="12" cy="12" r="9"/><circle cx="8" cy="10" r="1.2"/><circle cx="12" cy="7.5" r="1.2"/><circle cx="16" cy="10" r="1.2"/><path d="M12 21a3 3 0 010-6h2a3 3 0 003-3"/>'),
    settings: svgI('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/>'),
    platform: svgI('<path d="M4 7l8-4 8 4-8 4z"/><path d="M4 12l8 4 8-4"/><path d="M4 17l8 4 8-4"/>'),
    menu: svgI('<path d="M4 7h16M4 12h16M4 17h16"/>'),
    ext: svgI('<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 01-1 1H5a1 1 0 01-1-1V7a1 1 0 011-1h5"/>'),
    out: svgI('<path d="M15 4h4a1 1 0 011 1v14a1 1 0 01-1 1h-4M10 17l5-5-5-5M15 12H3"/>')
  };
  function renderShell() {
    app.innerHTML = '<div class="topbar"><button type="button" id="menuBtn" aria-label="Menu">' + NAV_IC.menu + '</button><b>' + esc(S.store) + '</b></div><div class="shell"><nav class="side" id="side" aria-label="Admin">' +
      '<a class="logo" href="#/overview"><span>' + esc((S.store || 'S').charAt(0)) + '</span><span><b>' + esc(S.store) + '</b><br><small style="color:#9AA59F">' + esc(S.me.name) + ' · ' + esc(S.me.role) + '</small></span></a>' +
      NAV.map(function (g) {
        var items = g[1].filter(function (it) { return can(it[2] || it[0]); });
        if (!items.length) return '';
        return '<div class="grp">' + g[0] + '</div>' + items.map(function (it) { return '<a class="nav" href="#/' + it[0] + '" data-nav="' + it[0] + '">' + (NAV_IC[it[0]] || '') + '<span>' + esc(it[1]) + '</span>' + (it[0] === 'orders' ? '<span class="badge" id="newBadge" hidden></span>' : '') + '</a>'; }).join('');
      }).join('') +
      '<div class="foot"><a href="' + esc(storeLink('/')) + '" target="_blank" rel="noopener">' + NAV_IC.ext + 'View my store</a><button type="button" id="logoutBtn">' + NAV_IC.out + 'Log out</button></div></nav><div class="side-bg" id="sideBg"></div><main class="main" id="view"></main></div>';
    document.getElementById('menuBtn').onclick = function () { document.getElementById('side').classList.toggle('open'); };
    document.getElementById('sideBg').onclick = function () { document.getElementById('side').classList.remove('open'); };
    document.getElementById('logoutBtn').onclick = function () { api('POST', '/logout').then(function () { S.me = null; renderLogin(); }); };
    clearInterval(pollTimer);
    pollTimer = setInterval(refreshBadge, 45000); refreshBadge();
  }
  var lastNew = null;
  function refreshBadge() {
    if (!can('orders')) return;
    api('GET', '/orders?limit=1&status=new').then(function (j) {
      var n = j.counts.new || 0, b = document.getElementById('newBadge');
      if (b) { b.hidden = !n; b.textContent = n; }
      if (lastNew !== null && n > lastNew) { toast('New order received'); try { new Audio('data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=').play(); } catch (e) {} }
      lastNew = n;
    }).catch(function () {});
  }

  function route() {
    if (!S.me) return;
    var h = (location.hash.indexOf('#/') === 0 ? location.hash : '#/overview').slice(2).split('/');
    var page = h[0] || 'overview', arg = h[1];
    document.querySelectorAll('[data-nav]').forEach(function (a) { a.classList.toggle('on', a.getAttribute('data-nav') === page); });
    var side = document.getElementById('side'); if (side) side.classList.remove('open');
    var el = document.getElementById('view');
    var fn = PAGES[page];
    var sec = page.indexOf('generate') === 0 ? 'landings' : page;
    if (!fn || !can(sec)) { el.innerHTML = '<div class="empty">This page is not available for your role.</div>'; return; }
    el.innerHTML = '<div class="empty">Loading…</div>';
    window.scrollTo(0, 0);
    try { fn(el, arg); } catch (e) { console.error(e); el.innerHTML = '<div class="empty">Error: ' + esc(e.message) + '</div>'; }
  }

  function loadProducts(force) {
    if (S.products && !force) return Promise.resolve(S.products);
    return api('GET', '/products').then(function (j) { S.products = j.rows; return j.rows; });
  }
  function loadSettings(force) {
    if (S.settings && !force) return Promise.resolve(S.settings);
    return api('GET', '/settings').then(function (j) { S.settings = j.settings; return j.settings; });
  }

  // ---------- range picker ----------
  var RANGE = { preset: '7d', from: today(6), to: today(0) };
  function rangeBar(onChange) {
    var presets = [['today', 'Today', 0], ['7d', '7 days', 6], ['30d', '30 days', 29], ['90d', '90 days', 89]];
    var html = '<div class="row"><div class="seg">' + presets.map(function (p) { return '<button type="button" data-rp="' + p[0] + '" data-d="' + p[2] + '" class="' + (RANGE.preset === p[0] ? 'on' : '') + '">' + p[1] + '</button>'; }).join('') + '</div>' +
      '<input type="date" data-rf value="' + RANGE.from + '" style="width:auto"><span class="muted">→</span><input type="date" data-rt value="' + RANGE.to + '" style="width:auto"></div>';
    return { html: html, bind: function (root) {
      root.querySelectorAll('[data-rp]').forEach(function (b) { b.onclick = function () { RANGE.preset = b.getAttribute('data-rp'); RANGE.from = today(+b.getAttribute('data-d')); RANGE.to = today(0); onChange(); }; });
      root.querySelector('[data-rf]').onchange = function (e) { RANGE.from = e.target.value; RANGE.preset = ''; onChange(); };
      root.querySelector('[data-rt]').onchange = function (e) { RANGE.to = e.target.value; RANGE.preset = ''; onChange(); };
    } };
  }

  // ================= PAGES =================
  var PAGES = {};

  // ---------- Overview ----------
  PAGES.overview = function (el) {
    function load() {
      api('GET', '/overview?' + qs({ from: RANGE.from, to: RANGE.to })).then(function (d) {
        var rb = rangeBar(load);
        var maxD = Math.max.apply(null, d.daily.map(function (x) { return x.n; }).concat([1]));
        var b = d.breakdown;
        var oldest = d.waiting.oldest ? Math.round((Date.now() - Date.parse(d.waiting.oldest)) / 3600e3) : 0;
        var alerts = [];
        if (d.waiting.n) alerts.push(['bad', d.waiting.n + ' new orders not called yet', 'Oldest waiting ' + oldest + ' h', '#/orders']);
        if (d.abandoned) alerts.push(['warn', d.abandoned + ' abandoned forms (7 days)', 'Name and phone left, no order — call them', '#/customers/abandoned']);
        d.lowStock.forEach(function (p) { alerts.push(['warn', p.name + ' stock low', p.stock + ' left', '#/products/' + p.id]); });
        el.innerHTML = '<div class="ph"><div><h1>Overview</h1><p>' + esc(d.from) + ' → ' + esc(d.to) + '</p></div>' + rb.html + '</div>' +
          '<div class="cards">' +
          '<a class="kpi" href="#/orders"><span>Orders</span><b>' + d.total + '</b><small>' + (d.by.new || 0) + ' waiting for a call</small></a>' +
          '<div class="kpi"><span>Confirmation rate</span><b>' + pct(d.confirmationRate) + '</b><small>confirmed ÷ all orders</small></div>' +
          '<div class="kpi"><span>Delivery rate</span><b>' + pct(d.deliveryRate) + '</b><small>' + (d.by.delivered || 0) + ' delivered · ' + (d.by.returned || 0) + ' returned</small></div>' +
          '<div class="kpi"><span>Cash collected</span><b>' + da(d.revenue) + '</b><small>delivered orders</small></div>' +
          '<a class="kpi" href="#/ads"><span>Ad spend</span><b>' + da(d.ads) + '</b><small>' + usd(d.spendUsd) + ((d.by.delivered) ? ' · ' + da(d.ads / d.by.delivered) + ' / delivered' : '') + '</small></a>' +
          '<div class="kpi"><span>Net profit</span><b style="color:' + (d.net >= 0 ? '#0B5132' : '#9A1C12') + '">' + da(d.net) + '</b><small>after product, courier, calls, ads</small></div></div>' +
          '<div class="cols"><div class="card w2"><h2>Orders per day <span class="muted small">· dark = delivered</span></h2>' + (d.daily.length ? '<div class="bars">' + d.daily.map(function (x) { var h = Math.round(x.n / maxD * 150); return '<div title="' + x.d + ': ' + x.n + ' orders, ' + x.del + ' delivered"><small>' + x.n + '</small><div class="b" style="height:' + h + 'px"><i style="height:' + (x.n ? Math.round(x.del / x.n * 100) : 0) + '%"></i></div></div>'; }).join('') + '</div><div class="barlbl">' + d.daily.map(function (x) { return '<span>' + x.d.slice(5) + '</span>'; }).join('') + '</div>' : '<div class="empty">No orders in this period yet.</div>') + '</div>' +
          '<div class="card"><h2>Order funnel</h2>' + S.statuses.map(function (s) { var n = d.by[s] || 0; return '<div style="margin-bottom:7px"><div class="row" style="justify-content:space-between"><span>' + chip(s) + '</span><b>' + n + '</b></div><div class="meter"><i style="width:' + (d.total ? n / d.total * 100 : 0) + '%"></i></div></div>'; }).join('') + '</div></div>' +
          '<div class="cols"><div class="card w2"><h2>Products</h2>' + (d.products.length ? '<div class="scroll"><table class="tbl"><tr><th>Product</th><th>Orders</th><th>Confirm</th><th>Deliver</th><th>Gross margin</th></tr>' + d.products.map(function (p) { return '<tr><td><b>' + esc(p.name) + '</b></td><td>' + p.n + '</td><td>' + pct(p.n ? p.c / p.n : 0) + '</td><td>' + pct((p.d + p.r) ? p.d / (p.d + p.r) : null) + '</td><td>' + da(p.gross) + '</td></tr>'; }).join('') + '</table></div>' : '<div class="empty">—</div>') + '</div>' +
          '<div class="card"><h2>Top wilayas</h2>' + (d.wilayas.length ? d.wilayas.map(function (w) { return '<div class="line"><span>' + esc(w.code + ' ' + w.name) + '</span><span><b>' + w.n + '</b> <span class="muted small">· ' + pct((w.d + w.r) ? w.d / (w.d + w.r) : null) + ' delivered</span></span></div>'; }).join('') : '<div class="empty">—</div>') + '</div></div>' +
          '<div class="cols"><div class="card"><h2>Needs attention</h2>' + (alerts.length ? alerts.map(function (a) { return '<a class="alert ' + a[0] + '" href="' + a[3] + '"><span class="dot"></span><span class="grow"><b>' + esc(a[1]) + '</b><br><span class="muted small">' + esc(a[2]) + '</span></span>›</a>'; }).join('') : '<p class="muted">All good.</p>') + '</div>' +
          '<div class="card"><h2>Confirmation team</h2>' + (d.agents.length ? d.agents.map(function (a) { return '<div class="line"><span>' + esc(a.name) + '</span><span><b>' + a.c + '</b> confirmed / ' + a.n + '</span></div>'; }).join('') : '<p class="muted">Agent stats appear when agents confirm orders.</p>') + '</div>' +
          '<div class="card"><h2>Profit (delivered)</h2>' + [['Cash collected', b.revenue], ['Product cost', -b.product], ['Courier', -b.courier], ['Confirmation', -b.confirm], ['Returns', -b.returns], ['Packaging', -b.pack], ['Ad spend', -b.ads]].map(function (x) { return '<div class="line"><span class="muted">' + x[0] + '</span><span>' + da(x[1]) + '</span></div>'; }).join('') + '<div class="line"><b>Net profit</b><b style="color:' + (b.net >= 0 ? '#0B5132' : '#9A1C12') + '">' + da(b.net) + '</b></div><p class="small muted">Costs per order are set in Settings → Costs.</p></div></div>';
        rb.bind(el);
      }).catch(fail);
    }
    load();
  };

  // ---------- Orders ----------
  var OST = { status: 'all', q: '', checked: {}, sel: null, offset: 0 };
  PAGES.orders = function (el) {
    var data = { rows: [], counts: {}, total: 0 };
    el.innerHTML = '<div class="ph"><div><h1>Orders</h1><p>Call, set the status, ship. Status changes save instantly.</p></div><div class="row"><input type="search" id="oq" placeholder="Name, phone, order #, tracking" value="' + esc(OST.q) + '" style="width:240px"><button class="btn" id="oNew">+ Manual order</button><button class="btn" id="oExport">Export CSV</button><button class="btn" id="oSync" title="Ask the delivery company for the latest status of shipped orders">Sync courier status</button><button class="btn pri" id="oCourier">Export confirmed for courier</button></div></div>' +
      '<div class="tabs" id="otabs"></div><div id="obulk"></div><div class="split"><div class="l"><div class="card" style="padding:0;overflow:hidden"><div class="scroll" id="olist"></div></div><div class="row" style="margin-top:10px" id="opager"></div></div><div class="r" id="odetail"></div></div>';
    var qT;
    el.querySelector('#oq').oninput = function (e) { clearTimeout(qT); qT = setTimeout(function () { OST.q = e.target.value; OST.offset = 0; load(); }, 300); };
    el.querySelector('#oNew').onclick = newOrder;
    el.querySelector('#oExport').onclick = function () { var ids = Object.keys(OST.checked).filter(function (k) { return OST.checked[k]; }); location.href = '/api/admin/orders/export.csv?' + (ids.length ? 'ids=' + ids.join(',') : OST.status !== 'all' ? 'status=' + OST.status : ''); };
    el.querySelector('#oCourier').onclick = function () { location.href = '/api/admin/orders/export.csv?status=confirmed'; };
    el.querySelector('#oSync').onclick = function () { toast('Checking with the delivery company…'); api('POST', '/orders/courier-sync').then(function (r) { toast(r.checked + ' checked · ' + r.changed + ' updated' + (r.errors.length ? ' · ' + r.errors[0] : ''), !!r.errors.length); load(); }).catch(fail); };

    function load(quiet) {
      api('GET', '/orders?' + qs({ status: OST.status, q: OST.q, limit: 100, offset: OST.offset })).then(function (j) { data = j; render(); if (!quiet && OST.sel) detail(OST.sel); }).catch(fail);
    }
    function render() {
      var all = Object.keys(data.counts).reduce(function (a, k) { return a + data.counts[k]; }, 0);
      el.querySelector('#otabs').innerHTML = [['all', 'All', all]].concat(S.statuses.map(function (s) { return [s, S.labels[s], data.counts[s] || 0]; })).map(function (t) { return '<button data-st="' + t[0] + '" class="' + (OST.status === t[0] ? 'on' : '') + '">' + esc(t[1]) + '<i>' + t[2] + '</i></button>'; }).join('');
      el.querySelectorAll('[data-st]').forEach(function (b) { b.onclick = function () { OST.status = b.getAttribute('data-st'); OST.offset = 0; OST.checked = {}; load(true); }; });
      var ids = Object.keys(OST.checked).filter(function (k) { return OST.checked[k]; });
      el.querySelector('#obulk').innerHTML = ids.length ? '<div class="bulk"><b>' + ids.length + ' selected</b><label class="row">Set status <select id="bulkSt"><option value="">Choose…</option>' + S.statuses.map(function (s) { return '<option value="' + s + '">' + S.labels[s] + '</option>'; }).join('') + '</select></label><button class="btn sm pri" id="bulkCourier">Send to delivery company</button><button class="btn sm" id="bulkCsv">Export selected</button><button class="btn sm" id="bulkClear" style="margin-left:auto">Clear</button></div>' : '';
      if (ids.length) {
        el.querySelector('#bulkSt').onchange = function (e) { if (!e.target.value) return; api('POST', '/orders/bulk', { ids: ids, status: e.target.value }).then(function (r) { toast(r.updated + ' orders updated'); OST.checked = {}; load(); refreshBadge(); }).catch(fail); };
        el.querySelector('#bulkCourier').onclick = function () {
          if (!confirm('Send ' + ids.length + ' orders to your delivery company?')) return;
          toast('Sending…');
          api('POST', '/orders/courier-bulk', { ids: ids }).then(function (r) {
            var ok = r.results.filter(function (x) { return x.ok; }).length, bad = r.results.filter(function (x) { return !x.ok; });
            toast(ok + ' sent' + (bad.length ? ' · ' + bad.length + ' failed: #' + bad[0].id + ' ' + bad[0].error : ''), !!bad.length); OST.checked = {}; load();
          }).catch(fail);
        };
        el.querySelector('#bulkCsv').onclick = function () { location.href = '/api/admin/orders/export.csv?ids=' + ids.join(','); };
        el.querySelector('#bulkClear').onclick = function () { OST.checked = {}; render(); };
      }
      var list = el.querySelector('#olist');
      if (!data.rows.length) { list.innerHTML = '<div class="empty">No orders here yet. Share a landing page link in your ads and orders will appear here.</div>'; el.querySelector('#opager').innerHTML = ''; return; }
      list.innerHTML = '<table class="tbl"><tr><th><input type="checkbox" id="chkAll" aria-label="Select all"></th><th>Order</th><th>Customer</th><th>Wilaya · Commune</th><th>Product</th><th>Total</th><th>Status</th></tr>' +
        data.rows.map(function (o) {
          return '<tr class="click' + (OST.sel === o.id ? ' sel' : '') + '" data-id="' + o.id + '"><td><input type="checkbox" data-chk="' + o.id + '"' + (OST.checked[o.id] ? ' checked' : '') + ' aria-label="Select ' + o.id + '"></td>' +
            '<td><b style="color:#0F5C46">#' + o.id + '</b><br><span class="muted small">' + when(o.created_at) + '</span></td>' +
            '<td><b class="ar">' + esc(o.name) + '</b>' + flags(o.flags) + '<br><a href="tel:' + esc(o.phone) + '" class="small">' + esc(o.phone) + '</a></td>' +
            '<td>' + esc(o.wilaya_code + ' ' + o.wilaya_name) + '<br><span class="muted small ar">' + esc(o.commune) + ' · ' + (o.delivery === 'home' ? 'Home' : 'Desk') + '</span></td>' +
            '<td>' + esc(o.product_name) + (o.variant ? ' <span class="muted small">' + esc(o.variant) + '</span>' : '') + '<br><span class="muted small">× ' + o.quantity + (o.upsell ? ' + upsell' : '') + '</span></td>' +
            '<td><b>' + da(o.total) + '</b></td><td>' + statusSelect(o.status, 'data-status="' + o.id + '" aria-label="Status of ' + o.id + '"') + (o.attempts ? '<br><span class="small" style="color:#8A4B00">' + o.attempts + ' call attempts</span>' : '') + '</td></tr>';
        }).join('') + '</table>';
      list.querySelector('#chkAll').onchange = function (e) { data.rows.forEach(function (o) { OST.checked[o.id] = e.target.checked; }); render(); };
      list.querySelectorAll('[data-chk]').forEach(function (c) { c.onclick = function (e) { e.stopPropagation(); }; c.onchange = function () { OST.checked[c.getAttribute('data-chk')] = c.checked; render(); }; });
      list.querySelectorAll('[data-status]').forEach(function (s) {
        s.onclick = function (e) { e.stopPropagation(); };
        s.onchange = function () { var id = +s.getAttribute('data-status'); setStatus(id, s.value); };
      });
      list.querySelectorAll('tr[data-id]').forEach(function (tr) { tr.onclick = function (e) { if (e.target.closest('a,select,input')) return; OST.sel = +tr.getAttribute('data-id'); render(); detail(OST.sel); }; });
      var pg = el.querySelector('#opager');
      pg.innerHTML = '<span class="muted">' + (OST.offset + 1) + '–' + (OST.offset + data.rows.length) + ' of ' + data.total + '</span>' + (OST.offset > 0 ? '<button class="btn sm" id="pPrev">← Newer</button>' : '') + (OST.offset + data.rows.length < data.total ? '<button class="btn sm" id="pNext">Older →</button>' : '');
      if (pg.querySelector('#pPrev')) pg.querySelector('#pPrev').onclick = function () { OST.offset = Math.max(0, OST.offset - 100); load(true); };
      if (pg.querySelector('#pNext')) pg.querySelector('#pNext').onclick = function () { OST.offset += 100; load(true); };
    }
    function setStatus(id, st) {
      api('PATCH', '/orders/' + id, { status: st }).then(function (j) {
        toast('#' + id + ' → ' + S.labels[st]);
        load(true);
        if (OST.sel === id) detail(id);
        refreshBadge();
      }).catch(fail);
    }
    function detail(id) {
      var box = el.querySelector('#odetail');
      box.innerHTML = '<div class="card">Loading…</div>';
      api('GET', '/orders/' + id).then(function (j) {
        var o = j.order, c = j.customer;
        box.innerHTML = '<div class="card drawer stack"><div class="row" style="justify-content:space-between"><h3>Order #' + o.id + '</h3><button class="btn sm" id="dClose">Close</button></div>' +
          (j.blacklisted ? '<div class="notice" style="background:#FEF3F2;border-color:#F3C1BC;color:#9A1C12">This phone is blacklisted.</div>' : '') +
          (o.flags ? '<div>' + flags(o.flags) + '</div>' : '') +
          '<label class="f">Status ' + statusSelect(o.status, 'id="dStatus"') + '</label>' +
          '<div class="row"><a class="btn pri grow" href="tel:' + esc(o.phone) + '">Call ' + esc(o.phone) + '</a><a class="btn" href="' + waLink(o.phone) + '" target="_blank" rel="noopener">WhatsApp</a></div>' +
          '<div class="small muted">Customer history: ' + c.orders + ' orders · ' + c.delivered + ' delivered · ' + c.returned + ' returned' + (c.score !== null ? ' · score ' + c.score + '%' : '') + '</div>' +
          '<div class="grid g3"><label class="f">Name<input type="text" id="dName" value="' + esc(o.name) + '" class="ar"></label><label class="f">Phone<input type="tel" id="dPhone" value="' + esc(o.phone) + '"></label></div>' +
          '<div class="grid g3"><label class="f">Wilaya<select id="dW">' + wilayaOptions(o.wilaya_code, true) + '</select></label><label class="f">Commune<input type="text" id="dC" value="' + esc(o.commune) + '" class="ar"></label></div>' +
          '<label class="f">Address (for home delivery)<input type="text" id="dA" value="' + esc(o.address) + '" class="ar"></label>' +
          '<div class="grid g3"><label class="f">Delivery<select id="dD"><option value="desk"' + (o.delivery === 'desk' ? ' selected' : '') + '>Stop desk</option><option value="home"' + (o.delivery === 'home' ? ' selected' : '') + '>Home</option></select></label><label class="f">Quantity<input type="number" id="dQ" min="1" max="20" value="' + o.quantity + '"></label><label class="f">Variant<input type="text" id="dV" value="' + esc(o.variant) + '"></label></div>' +
          '<div class="line"><span class="muted">' + esc(o.product_name) + (o.upsell ? ' + ' + esc(o.upsell) : '') + '</span><span>' + da(o.items_price + o.upsell_price) + ' + ' + da(o.delivery_fee) + ' delivery</span></div>' +
          '<div class="line"><b>Collect (COD)</b><b>' + da(o.total) + '</b></div>' +
          '<div class="grid g3"><label class="f">Tracking number<input type="text" id="dT" value="' + esc(o.tracking) + '"></label><label class="f">Courier<input type="text" id="dCo" value="' + esc(o.courier) + '" placeholder="Yalidine, ZR…"></label></div>' +
          (j.courier && j.courier !== 'none' ? '<div class="row">' + (o.tracking ? '<button class="btn sm" id="dCs">Refresh courier status</button><span class="small muted">' + esc(o.courier_status || '') + '</span>' : '<button class="btn sm pri" id="dCp">Send to delivery company</button>') + '</div>' : '<div class="small muted">Connect your delivery company in Settings → Delivery company to send orders in one click.</div>') +
          (o.phone2 ? '<div class="line"><span class="muted">2nd phone</span><a href="tel:' + esc(o.phone2) + '">' + esc(o.phone2) + '</a></div>' : '') +
          (o.extra ? (function () { try { var x = JSON.parse(o.extra); return Object.keys(x).map(function (k) { return '<div class="line"><span class="muted">' + esc(k) + '</span><b>' + esc(x[k]) + '</b></div>'; }).join(''); } catch (e) { return ''; } })() : '') +
          '<label class="f">Note<textarea id="dN" placeholder="e.g. call back after 18:00">' + esc(o.note) + '</textarea></label>' +
          '<div class="row"><button class="btn pri" id="dSave">Save changes</button>' + (j.blacklisted ? '' : '<button class="btn danger" id="dBlock">Blacklist phone</button>') + '</div>' +
          (j.ipKey ? '<div class="line"><span class="muted">IP ' + esc(j.ipKey) + ' · ' + j.ipOrders + ' order(s) from it</span>' + (j.ipBlocked ? '<span class="flag">IP BLOCKED</span>' : '<button class="btn sm danger" id="dIp">Block this IP</button>') + '</div>' : '') +
          '<div class="small muted">Source: ' + esc(o.source || '—') + (o.utm_campaign ? ' · campaign ' + esc(o.utm_campaign) : '') + (j.agent ? ' · agent ' + esc(j.agent) : '') + '</div>' +
          '<b>History</b><div class="hist">' + o.history.slice().reverse().map(function (h) { return '<span>' + when(h.at) + ' · ' + esc(h.by) + ' · ' + esc(h.action) + (h.detail ? ': ' + esc(h.detail) : '') + '</span>'; }).join('') + '</div></div>';
        box.querySelector('#dClose').onclick = function () { OST.sel = null; box.innerHTML = ''; render(); };
        box.querySelector('#dStatus').onchange = function (e) { setStatus(o.id, e.target.value); };
        box.querySelector('#dSave').onclick = function () {
          api('PATCH', '/orders/' + o.id, { name: box.querySelector('#dName').value, phone: box.querySelector('#dPhone').value, wilaya_code: box.querySelector('#dW').value, commune: box.querySelector('#dC').value, address: box.querySelector('#dA').value,
            delivery: box.querySelector('#dD').value, quantity: +box.querySelector('#dQ').value, variant: box.querySelector('#dV').value, tracking: box.querySelector('#dT').value, courier: box.querySelector('#dCo').value, note: box.querySelector('#dN').value })
            .then(function () { toast('Saved'); load(); }).catch(fail);
        };
        var ipb = box.querySelector('#dIp');
        if (ipb) ipb.onclick = function () { if (!confirm('Block IP ' + j.ipKey + '? New orders from this connection will be ignored (the visitor still sees a thank-you message).')) return; api('POST', '/ipblock', { ip: o.ip, reason: 'From order #' + o.id }).then(function () { toast('IP blocked'); detail(o.id); }).catch(fail); };
        var cp = box.querySelector('#dCp');
        if (cp) cp.onclick = function () { cp.disabled = true; api('POST', '/orders/' + o.id + '/courier').then(function (r) { toast('Sent · tracking ' + r.tracking); load(); }).catch(function (e) { cp.disabled = false; fail(e); }); };
        var cs = box.querySelector('#dCs');
        if (cs) cs.onclick = function () { api('POST', '/orders/' + o.id + '/courier-status').then(function (r) { toast('Courier: ' + (r.courier_status || 'no update') + (r.suggested ? ' → ' + S.labels[r.suggested] : '')); load(); }).catch(fail); };
        var bl = box.querySelector('#dBlock');
        if (bl) bl.onclick = function () { if (!confirm('Blacklist ' + o.phone + '? Future orders from this phone will be auto-cancelled.')) return; api('POST', '/blacklist', { phone: o.phone, reason: 'From order #' + o.id }).then(function () { return api('PATCH', '/orders/' + o.id, { status: 'cancelled' }); }).then(function () { toast('Blacklisted'); load(); }).catch(fail); };
      }).catch(fail);
    }
    function newOrder() {
      loadProducts().then(function (ps) {
        var live = ps.filter(function (p) { return p.live; });
        if (!live.length) return toast('Create a product first', true);
        var m = modal('<h2>Manual order</h2><div class="stack"><label class="f">Product<select id="mP">' + live.map(function (p) { return '<option value="' + p.id + '">' + esc(p.name) + '</option>'; }).join('') + '</select></label>' +
          '<div class="grid g3"><label class="f">Quantity<input type="number" id="mQ" value="1" min="1"></label><label class="f">Variant<input type="text" id="mV" placeholder="if any"></label></div>' +
          '<div class="grid g3"><label class="f">Name<input type="text" id="mN"></label><label class="f">Phone<input type="tel" id="mPh"></label></div>' +
          '<div class="grid g3"><label class="f">Wilaya<select id="mW">' + wilayaOptions('16') + '</select></label><label class="f">Commune<input type="text" id="mC"></label></div>' +
          '<label class="f">Delivery<select id="mD"><option value="desk">Stop desk</option><option value="home">Home</option></select></label>' +
          '<div class="row"><button class="btn pri" id="mGo">Create order</button><button class="btn" data-close>Cancel</button></div></div>');
        m.el.querySelector('#mGo').onclick = function () {
          api('POST', '/orders', { product_id: +m.el.querySelector('#mP').value, quantity: +m.el.querySelector('#mQ').value, variant: m.el.querySelector('#mV').value, name: m.el.querySelector('#mN').value, phone: m.el.querySelector('#mPh').value, wilaya: m.el.querySelector('#mW').value, commune: m.el.querySelector('#mC').value, delivery: m.el.querySelector('#mD').value })
            .then(function (j) { m.close(); toast('Order #' + j.order.id + ' created'); load(); }).catch(function (e) { toast('Check the field: ' + e.message, true); });
        };
      });
    }
    load();
  };

  // ---------- Customers ----------
  PAGES.customers = function (el, tab) {
    tab = tab || 'customers';
    el.innerHTML = '<div class="ph"><div><h1>Customers</h1><p>Who buys, who returns, who left the form.</p></div><input type="search" id="cq" placeholder="Name or phone" style="width:240px"></div><div class="utabs">' +
      [['customers', 'Customers'], ['abandoned', 'Abandoned forms'], ['blacklist', 'Blocked phones'], ['ips', 'Blocked IPs']].map(function (t) { return '<button class="' + (tab === t[0] ? 'on' : '') + '" onclick="location.hash=\'#/customers/' + t[0] + '\'">' + t[1] + '</button>'; }).join('') + '</div><div id="cbody"></div>';
    var body = el.querySelector('#cbody');
    function loadC() {
      if (tab === 'customers') api('GET', '/customers?' + qs({ q: el.querySelector('#cq').value })).then(function (j) {
        body.innerHTML = j.rows.length ? '<div class="card scroll" style="padding:0"><table class="tbl"><tr><th>Customer</th><th>Phone</th><th>Wilaya</th><th>Orders</th><th>Delivered</th><th>Returned</th><th>Score</th><th>Spent</th><th></th></tr>' + j.rows.map(function (r) {
          var closed = r.delivered + r.returned, sc = closed ? Math.round(r.delivered / closed * 100) : null;
          return '<tr><td><b class="ar">' + esc(r.name) + '</b><br><span class="muted small">last ' + when(r.last) + '</span></td><td><a href="tel:' + esc(r.phone) + '">' + esc(r.phone) + '</a></td><td class="ar">' + esc(r.wilaya) + '</td><td>' + r.orders + '</td><td>' + r.delivered + '</td><td>' + r.returned + '</td><td>' + (sc === null ? '<span class="chip st-new">New</span>' : '<span class="chip ' + (sc >= 50 ? 'st-delivered' : 'st-returned') + '">' + sc + '%</span>') + '</td><td>' + da(r.spent) + '</td><td>' + (r.blacklisted ? '<span class="flag">BLACKLIST</span>' : '<button class="btn sm danger" data-bl="' + esc(r.phone) + '">Block</button>') + '</td></tr>';
        }).join('') + '</table></div><p class="small muted">Score = delivered ÷ (delivered + returned).</p>' : '<div class="empty">No customers yet.</div>';
        body.querySelectorAll('[data-bl]').forEach(function (b) { b.onclick = function () { if (!confirm('Blacklist ' + b.getAttribute('data-bl') + '?')) return; api('POST', '/blacklist', { phone: b.getAttribute('data-bl'), reason: 'Blocked from customers list' }).then(function () { toast('Blocked'); loadC(); }).catch(fail); }; });
      }).catch(fail);
      if (tab === 'abandoned') api('GET', '/abandoned').then(function (j) {
        body.innerHTML = '<div class="notice info" style="margin-bottom:10px">People who typed their phone on a landing page but did not confirm. Call them first — they are warm leads.</div>' + (j.rows.length ? '<div class="card scroll" style="padding:0"><table class="tbl"><tr><th>When</th><th>Name</th><th>Phone</th><th>Product</th><th>Wilaya</th><th></th></tr>' + j.rows.map(function (a) {
          return '<tr><td>' + when(a.updated_at) + '</td><td class="ar">' + esc(a.name || '—') + '</td><td><a href="tel:' + esc(a.phone) + '">' + esc(a.phone) + '</a> · <a href="' + waLink(a.phone) + '" target="_blank" rel="noopener">WA</a></td><td>' + esc(a.product_name || '') + '</td><td>' + esc(a.wilaya) + ' ' + esc(a.commune) + '</td><td class="row"><button class="btn sm pri" data-conv="' + a.id + '">Create order</button><button class="btn sm" data-dis="' + a.id + '">Dismiss</button></td></tr>';
        }).join('') + '</table></div>' : '<div class="empty">No abandoned forms. Nice.</div>');
        body.querySelectorAll('[data-dis]').forEach(function (b) { b.onclick = function () { api('POST', '/abandoned/' + b.getAttribute('data-dis'), { status: 'dismissed' }).then(loadC).catch(fail); }; });
        body.querySelectorAll('[data-conv]').forEach(function (b) {
          b.onclick = function () {
            var a = j.rows.filter(function (x) { return String(x.id) === b.getAttribute('data-conv'); })[0];
            loadProducts().then(function (ps) {
              var m = modal('<h2>Create order from abandoned form</h2><div class="stack"><label class="f">Product<select id="aP">' + ps.filter(function (p) { return p.live; }).map(function (p) { return '<option value="' + p.id + '"' + (p.id === a.product_id ? ' selected' : '') + '>' + esc(p.name) + '</option>'; }).join('') + '</select></label><div class="grid g3"><label class="f">Name<input type="text" id="aN" value="' + esc(a.name) + '"></label><label class="f">Phone<input type="tel" id="aPh" value="' + esc(a.phone) + '"></label></div><div class="grid g3"><label class="f">Wilaya<select id="aW">' + wilayaOptions(a.wilaya || '16') + '</select></label><label class="f">Commune<input type="text" id="aC" value="' + esc(a.commune) + '"></label></div><label class="f">Quantity<input type="number" id="aQ" value="1" min="1"></label><div class="row"><button class="btn pri" id="aGo">Create</button><button class="btn" data-close>Cancel</button></div></div>');
              m.el.querySelector('#aGo').onclick = function () {
                api('POST', '/orders', { product_id: +m.el.querySelector('#aP').value, name: m.el.querySelector('#aN').value, phone: m.el.querySelector('#aPh').value, wilaya: m.el.querySelector('#aW').value, commune: m.el.querySelector('#aC').value, quantity: +m.el.querySelector('#aQ').value, delivery: 'desk' })
                  .then(function () { return api('POST', '/abandoned/' + a.id, { status: 'converted' }); }).then(function () { m.close(); toast('Order created'); loadC(); }).catch(fail);
              };
            });
          };
        });
      }).catch(fail);
      if (tab === 'blacklist') api('GET', '/blacklist').then(function (j) {
        body.innerHTML = '<div class="card stack"><div class="row"><input type="tel" id="bP" placeholder="Phone to block" style="width:200px"><input type="text" id="bR" placeholder="Reason" style="width:260px"><button class="btn danger" id="bAdd">Block</button></div>' +
          (j.rows.length ? '<table class="tbl"><tr><th>Phone</th><th>Reason</th><th>Since</th><th></th></tr>' + j.rows.map(function (b) { return '<tr><td><b>' + esc(b.phone) + '</b></td><td>' + esc(b.reason) + '</td><td>' + when(b.created_at) + '</td><td><button class="btn sm" data-ub="' + esc(b.phone) + '">Unblock</button></td></tr>'; }).join('') + '</table>' : '<p class="muted">No blocked phones.</p>') +
          '<p class="small muted">Orders from blocked phones are saved as Cancelled with a BLACKLIST flag. The customer sees a normal thank-you message.</p></div>';
        body.querySelector('#bAdd').onclick = function () { api('POST', '/blacklist', { phone: body.querySelector('#bP').value, reason: body.querySelector('#bR').value }).then(function () { toast('Blocked'); loadC(); }).catch(fail); };
        body.querySelectorAll('[data-ub]').forEach(function (b) { b.onclick = function () { api('DELETE', '/blacklist/' + b.getAttribute('data-ub')).then(function () { toast('Unblocked'); loadC(); }).catch(fail); }; });
      }).catch(fail);
      if (tab === 'ips') api('GET', '/ipblock').then(function (j) {
        body.innerHTML = '<div class="card stack"><div class="notice info small">Fake-order attacks change phone numbers but usually keep the same connection. Orders from a blocked IP are ignored silently: the visitor sees a normal thank-you message, nothing is saved. Set automatic blocking in Settings → Fake orders.</div>' +
          '<div class="row"><input type="text" id="iP" placeholder="IP address (e.g. 105.101.22.4)" style="width:240px" dir="ltr"><input type="text" id="iR" placeholder="Reason" style="width:240px"><button class="btn danger" id="iAdd">Block IP</button></div>' +
          (j.rows.length ? '<table class="tbl"><tr><th>IP / network</th><th>Reason</th><th>Blocked attempts</th><th>Since</th><th></th></tr>' + j.rows.map(function (b) { return '<tr><td dir="ltr"><b>' + esc(b.ip) + '</b></td><td>' + esc(b.reason) + '</td><td>' + b.hits + '</td><td>' + when(b.created_at) + '</td><td><button class="btn sm" data-uip="' + esc(b.ip) + '">Unblock</button></td></tr>'; }).join('') + '</table>' : '<p class="muted">No blocked IPs.</p>') + '</div>';
        body.querySelector('#iAdd').onclick = function () { api('POST', '/ipblock', { ip: body.querySelector('#iP').value.trim(), reason: body.querySelector('#iR').value }).then(function () { toast('IP blocked'); loadC(); }).catch(fail); };
        body.querySelectorAll('[data-uip]').forEach(function (b) { b.onclick = function () { api('DELETE', '/ipblock?ip=' + encodeURIComponent(b.getAttribute('data-uip'))).then(function () { toast('Unblocked'); loadC(); }).catch(fail); }; });
      }).catch(fail);
    }
    var cqT; el.querySelector('#cq').oninput = function () { clearTimeout(cqT); cqT = setTimeout(loadC, 300); };
    loadC();
  };

  // ---------- Product import (CSV / Excel / Shopify export) ----------
  function parseCSV(text) {
    text = String(text || '').replace(/^﻿/, '');
    var first = text.split(/\r?\n/)[0] || '', delim = (first.split(';').length > first.split(',').length) ? ';' : (first.split('\t').length > first.split(',').length ? '\t' : ',');
    var rows = [], row = [], cell = '', q = false;
    for (var i = 0; i < text.length; i++) {
      var ch = text[i];
      if (q) { if (ch === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += ch; continue; }
      if (ch === '"') q = true;
      else if (ch === delim) { row.push(cell); cell = ''; }
      else if (ch === '\n' || ch === '\r') { if (ch === '\r' && text[i + 1] === '\n') i++; row.push(cell); rows.push(row); row = []; cell = ''; }
      else cell += ch;
    }
    if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
    return rows.filter(function (r) { return r.some(function (c) { return String(c).trim() !== ''; }); });
  }
  function loadXlsxLib() {
    if (window.XLSX) return Promise.resolve(window.XLSX);
    return new Promise(function (res, rej) { var s = document.createElement('script'); s.src = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js'; s.onload = function () { res(window.XLSX); }; s.onerror = function () { rej(new Error('Could not load the Excel reader — save the file as CSV and try again')); }; document.head.appendChild(s); });
  }
  function readSheetFile(file) {
    if (/\.(xlsx|xls|ods)$/i.test(file.name)) return loadXlsxLib().then(function (X) { return file.arrayBuffer().then(function (b) { var wb = X.read(b, { type: 'array' }); return X.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: false, defval: '' }); }); });
    return file.text().then(parseCSV);
  }
  var IMPORT_COLS = {
    handle: ['handle', 'url handle'], name: ['title', 'name', 'product name', 'product', 'nom', 'produit', 'الاسم', 'اسم المنتج', 'المنتج'],
    price: ['price', 'prix', 'السعر'], vprice: ['variant price', 'variant_price', 'prix variante', 'سعر الخيار'],
    old: ['variant compare at price', 'compare at price', 'compare_at_price', 'old price', 'old_price', 'ancien prix', 'السعر القديم'],
    cost: ['cost per item', 'cost', 'coût', 'cout', 'التكلفة', 'سعر الشراء'], desc: ['body (html)', 'body html', 'description', 'الوصف'], short: ['short description', 'short_desc', 'وصف قصير'],
    cat: ['type', 'product type', 'category', 'product category', 'catégorie', 'categorie', 'الفئة', 'القسم'], img: ['image src', 'images', 'image', 'photo', 'photos', 'الصور', 'الصورة'],
    vimg: ['variant image', 'variant_image', 'صورة الخيار'], vname: ['variant', 'variante', 'option', 'الخيار'], o1: ['option1 value'], o2: ['option2 value'], o3: ['option3 value'],
    stock: ['variant inventory qty', 'inventory quantity', 'stock', 'quantity', 'qty', 'quantité', 'المخزون', 'الكمية', 'variant_stock'], sku: ['variant sku', 'sku', 'variant_sku'],
    status: ['status', 'published', 'statut']
  };
  function rowsToProducts(rows) {
    var head = (rows[0] || []).map(function (h) { return String(h).trim().toLowerCase(); }), col = {};
    Object.keys(IMPORT_COLS).forEach(function (k) { for (var i = 0; i < IMPORT_COLS[k].length; i++) { var ix = head.indexOf(IMPORT_COLS[k][i]); if (ix >= 0) { col[k] = ix; break; } } });
    if (col.name == null && col.handle == null) throw new Error('No "name" / "Title" column found. Download the template to see the columns.');
    var shopify = col.handle != null;
    var get = function (r, k) { return col[k] == null ? '' : String(r[col[k]] == null ? '' : r[col[k]]).trim(); };
    var nm = function (v) { var n = parseFloat(String(v).replace(/[^\d.,-]/g, '').replace(',', '.')); return isFinite(n) ? Math.round(n) : 0; };
    var strip = function (h) { var d = document.createElement('div'); d.innerHTML = String(h).replace(/<br\s*\/?>|<\/p>|<\/li>/gi, '\n'); return (d.textContent || '').replace(/\n{3,}/g, '\n\n').trim(); };
    var map = {}, order = [];
    rows.slice(1).forEach(function (r) {
      var key = shopify ? get(r, 'handle') : get(r, 'name'); if (!key) return;
      var p = map[key];
      if (!p) { p = map[key] = { name: '', price: 0, old_price: 0, cost: 0, description: '', short_desc: '', category: '', images: [], variants: [], live: true, stock: -1 }; order.push(key); }
      if (!p.name && get(r, 'name')) p.name = get(r, 'name');
      var price = nm(get(r, 'vprice') || get(r, 'price'));
      if (!p.price && price) p.price = price;
      if (!p.old_price && nm(get(r, 'old'))) p.old_price = nm(get(r, 'old'));
      if (!p.cost && nm(get(r, 'cost'))) p.cost = nm(get(r, 'cost'));
      if (!p.description && get(r, 'desc')) p.description = shopify || /<[a-z]/i.test(get(r, 'desc')) ? strip(get(r, 'desc')) : get(r, 'desc');
      if (!p.short_desc && get(r, 'short')) p.short_desc = get(r, 'short');
      if (!p.category && get(r, 'cat')) p.category = get(r, 'cat');
      if (col.status != null && /^(draft|archived|false|0|brouillon)$/i.test(get(r, 'status'))) p.live = false;
      get(r, 'img').split(/\s*[|\n]\s*|\s*,\s*(?=https?:)/).forEach(function (u) { u = u.trim(); if (/^https?:\/\//i.test(u) && p.images.indexOf(u) < 0) p.images.push(u); });
      var vn = shopify ? [get(r, 'o1'), get(r, 'o2'), get(r, 'o3')].filter(function (x) { return x && x !== 'Default Title'; }).join(' / ') : get(r, 'vname');
      var stockTxt = get(r, 'stock');
      if (vn) {
        var vimg = get(r, 'vimg');
        if (vimg && p.images.indexOf(vimg) < 0) p.images.push(vimg);
        p.variants.push({ name: vn, price: price, stock: stockTxt === '' ? 10 : nm(stockTxt), sku: get(r, 'sku'), color: '', image: vimg });
      } else if (stockTxt !== '' && p.stock < 0) p.stock = nm(stockTxt);
    });
    return order.map(function (k) {
      var p = map[k];
      if (!p.name) p.name = k;
      if (p.variants.length) { var mn = Math.min.apply(null, p.variants.map(function (v) { return v.price || Infinity; })); if (isFinite(mn)) p.price = mn; p.variants.forEach(function (v) { v.price = v.price && v.price !== p.price ? v.price : 0; }); }
      if (p.variants.length === 1 && !p.variants[0].image) { p.stock = p.variants[0].stock; p.variants = []; }
      p.images = p.images.slice(0, 8);
      p.offers = p.price ? [{ qty: 1, price: p.price, label: '' }] : [];
      return p;
    }).filter(function (p) { return p.name && p.price > 0; });
  }
  function importImage(url) {
    // 1) the browser downloads + compresses it (works when the site allows it), 2) else the server copies it.
    return fetch(url, { mode: 'cors' }).then(function (r) { if (!r.ok) throw new Error('x'); return r.blob(); })
      .then(function (b) { if (!/^image\//.test(b.type)) throw new Error('x'); return fileToUpload(b); })
      .catch(function () { return api('POST', '/products/import-image', { url: url }).then(function (j) { return j.url; }); })
      .catch(function () { return ''; });
  }
  function importTemplate() {
    var csv = '﻿name,price,old_price,cost,category,description,images,variant,variant_price,variant_stock,variant_sku,variant_image\n' +
      'فستان سهرة,4900,6500,2200,ملابس,فستان أنيق مناسب للأعراس,https://example.com/dress1.jpg | https://example.com/dress2.jpg,أسود / M,,8,DR-B-M,https://example.com/black.jpg\n' +
      'فستان سهرة,,,,,,,أسود / L,,5,DR-B-L,https://example.com/black.jpg\n' +
      'فستان سهرة,,,,,,,أحمر / M,5200,3,DR-R-M,https://example.com/red.jpg\n' +
      'كريم مرطب,2900,3900,900,تجميل,كريم للبشرة الجافة,https://example.com/cream.jpg,,,25,CR-01,\n';
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' })); a.download = 'products-template.csv'; a.click();
  }
  function importProducts(done) {
    var m = modal('<h2>Import products</h2><div class="stack"><p class="small muted">CSV or Excel file (.csv, .xlsx), or the <b>Shopify product export</b> (Shopify admin → Products → Export → CSV). One row per variant; rows with the same name (or Shopify “Handle”) become one product. Images from links are copied into your store.</p>' +
      '<div class="row"><label class="btn pri" style="position:relative">Choose file<input type="file" id="iF" accept=".csv,.txt,.xlsx,.xls,.ods" style="position:absolute;inset:0;opacity:0"></label><button class="btn" id="iT" type="button">Download template</button></div>' +
      '<label class="f inline"><input type="checkbox" id="iSk" checked> Skip products whose name already exists</label><label class="f inline"><input type="checkbox" id="iImg" checked> Copy images</label><div id="iOut"></div></div>');
    var out = m.el.querySelector('#iOut'), list = [];
    m.el.querySelector('#iT').onclick = importTemplate;
    m.el.querySelector('#iF').onchange = function (e) {
      var f = e.target.files[0]; if (!f) return;
      out.innerHTML = '<div class="empty small">Reading…</div>';
      readSheetFile(f).then(function (rows) {
        list = rowsToProducts(rows);
        if (!list.length) throw new Error('No products found (each product needs a name and a price).');
        var nv = list.reduce(function (a, p) { return a + p.variants.length; }, 0), ni = list.reduce(function (a, p) { return a + p.images.length; }, 0);
        out.innerHTML = '<div class="notice small">Found <b>' + list.length + '</b> products, ' + nv + ' variants, ' + ni + ' images.</div><div class="scroll" style="max-height:240px"><table class="tbl"><tr><th>Product</th><th>Price</th><th>Variants</th><th>Images</th></tr>' + list.slice(0, 50).map(function (p) { return '<tr><td>' + esc(p.name) + (p.live ? '' : ' <span class="muted small">(hidden)</span>') + '</td><td>' + da(p.price) + '</td><td>' + (p.variants.map(function (v) { return esc(v.name); }).join(', ') || '—') + '</td><td>' + p.images.length + '</td></tr>'; }).join('') + '</table></div><div class="row"><button class="btn pri" id="iGo">Import ' + list.length + ' products</button><button class="btn" data-close>Cancel</button></div><div id="iLog" class="small"></div>';
        m.el.querySelector('#iGo').onclick = run;
      }).catch(function (er) { out.innerHTML = '<div class="notice small">✗ ' + esc(er.message) + '</div>'; });
    };
    function run() {
      var go = m.el.querySelector('#iGo'); go.disabled = true;
      var log = m.el.querySelector('#iLog'), copyImg = m.el.querySelector('#iImg').checked, skip = m.el.querySelector('#iSk').checked, ok = 0, sk = 0, bad = 0, i = 0;
      function next() {
        if (i >= list.length) { log.innerHTML = '<b>Done:</b> ' + ok + ' imported, ' + sk + ' skipped, ' + bad + ' failed.'; S.products = null; toast('Import finished'); go.textContent = 'Close'; go.disabled = false; go.onclick = function () { m.close(); done(); }; return; }
        var p = list[i++]; log.textContent = 'Importing ' + i + ' / ' + list.length + ': ' + p.name + '…';
        var urls = copyImg ? p.images : [], cache = {};
        urls.reduce(function (pr, u) { return pr.then(function () { return importImage(u).then(function (n) { cache[u] = n; }); }); }, Promise.resolve()).then(function () {
          var body = JSON.parse(JSON.stringify(p));
          body.images = p.images.map(function (u) { return cache[u]; }).filter(Boolean);
          body.variants.forEach(function (v) { v.image = cache[v.image] || ''; });
          body.skipExisting = skip;
          return api('POST', '/products/import', body);
        }).then(function (r) { if (r.skipped) sk++; else ok++; next(); }).catch(function (er) { bad++; log.textContent = p.name + ': ' + er.message; next(); });
      }
      next();
    }
  }

  // ---------- Products ----------
  PAGES.products = function (el, id) {
    if (id) return productEditor(el, id);
    loadProducts(true).then(function (ps) {
      el.innerHTML = '<div class="ph"><div><h1>Products</h1><p>Catalog, prices, stock. Each product has a store page; ad pages are in Landing pages.</p></div><div class="row">' + (can('landings') ? '<a class="btn acc" href="#/generate">Create with AI</a>' : '') + '<button class="btn" id="pImp">Import CSV / Excel / Shopify</button><a class="btn pri" href="#/products/new">+ New product</a></div></div>' +
        (ps.length ? '<div class="card scroll" style="padding:0"><table class="tbl"><tr><th></th><th>Product</th><th>Price</th><th>Cost</th><th>Stock</th><th>Landing pages</th><th>Status</th><th></th></tr>' + ps.map(function (p) {
          var stock = p.variants.length ? p.variants.reduce(function (a, v) { return a + (v.stock || 0); }, 0) : (p.stock >= 0 ? p.stock : '—'); if (stock === 0) stock = p.preorder ? '0 · pre-order' : '<span class="bad">0 · sold out</span>';
          return '<tr class="click" onclick="location.hash=\'#/products/' + p.id + '\'"><td style="width:56px">' + (p.images[0] ? '<img src="' + esc(p.images[0]) + '" alt="" style="width:44px;height:44px;object-fit:cover;border-radius:8px">' : '') + '</td><td><b>' + esc(p.name) + '</b><br><span class="muted small">/p/' + esc(p.slug) + '</span></td><td>' + da(p.price) + '</td><td>' + da(p.cost) + '</td><td>' + stock + '</td><td>' + p.landings + '</td><td>' + (p.live ? '<span class="chip st-delivered">Live</span>' : '<span class="chip st-cancelled">Hidden</span>') + '</td><td><a class="btn sm" href="' + esc(storeLink('/p/' + p.slug)) + '" target="_blank" rel="noopener" onclick="event.stopPropagation()">View ↗</a></td></tr>';
        }).join('') + '</table></div>' : '<div class="card empty">No products yet. Start with <a href="#/generate">the AI generator</a> or <a href="#/products/new">add one manually</a>.</div>');
      el.querySelector('#pImp').onclick = function () { importProducts(function () { PAGES.products(el); }); };
    }).catch(fail);
  };
  function productEditor(el, id) {
    var isNew = id === 'new';
    (isNew ? Promise.resolve({ product: { name: '', price: 3900, old_price: 0, cost: 0, short_desc: '', description: '', specs: '', category: '', images: [], offers: [{ qty: 1, price: 3900, label: '' }, { qty: 2, price: 6900, label: '' }], variants: [], live: true, seo_title: '', slug: '' } }) : api('GET', '/products/' + id)).then(function (j) {
      var p = j.product, costs = (S.settings && S.settings.costs) || { courierPerDelivered: 400, confirmPerDelivered: 100, usdRate: 255 };
      function render() {
        var margin = (p.price || 0) - (p.cost || 0) - costs.courierPerDelivered - costs.confirmPerDelivered;
        el.innerHTML = '<div class="ph"><div><a href="#/products" class="small">← Products</a><h1>' + (isNew ? 'New product' : esc(p.name)) + '</h1></div><div class="row"><label class="f inline"><input type="checkbox" id="pLive"' + (p.live ? ' checked' : '') + '> Visible in store</label>' + (!isNew ? '<a class="btn" href="' + esc(storeLink('/p/' + p.slug)) + '" target="_blank" rel="noopener">View page ↗</a>' : '') + (!isNew ? '<button class="btn danger" id="pDel">Delete</button>' : '') + '<button class="btn pri" id="pSave">Save</button></div></div>' +
          '<div class="cols"><div class="stack w2">' +
          '<div class="card stack"><h2>Product page</h2><label class="f">Name<input type="text" data-p="name" value="' + esc(p.name) + '"></label><div class="grid g3"><label class="f">URL slug<input type="text" data-p="slug" value="' + esc(p.slug) + '" placeholder="auto"></label><label class="f">Category<input type="text" data-p="category" value="' + esc(p.category) + '" list="catList"></label></div>' +
          '<label class="f">Short description (under the price)<textarea data-p="short_desc" dir="auto">' + esc(p.short_desc) + '</textarea></label><label class="f">Full description<textarea data-p="description" dir="auto" style="min-height:140px">' + esc(p.description) + '</textarea></label><label class="f">Specifications (one per line)<textarea data-p="specs" dir="auto">' + esc(p.specs) + '</textarea></label><label class="f">SEO title<input type="text" data-p="seo_title" value="' + esc(p.seo_title) + '"></label></div>' +
          '<div class="card stack"><h2>Images</h2><div class="imgs">' + p.images.map(function (u, i) { return '<div class="im' + (i === 0 ? ' first' : '') + '"><img src="' + esc((p.cutouts || {})[u] || u) + '" alt=""' + ((p.cutouts || {})[u] ? ' class="isCut"' : '') + '>' + ((p.cutouts || {})[u] ? '<span class="cutTag">✂ PNG</span>' : '') + '<div class="ctl"><button type="button" data-mv="' + i + '" data-d="-1" aria-label="Move left">‹</button><button type="button" data-cut="' + i + '" title="Remove background" aria-label="Remove background">✂</button><button type="button" data-rm="' + i + '" aria-label="Remove">✕</button><button type="button" data-mv="' + i + '" data-d="1" aria-label="Move right">›</button></div></div>'; }).join('') + '<label class="upl">+ Add images<input type="file" accept="image/*" multiple id="pUp"></label></div><p class="small muted">First image = main photo. Images are compressed automatically. ✂ = remove background (free AI in your browser) — the landing generator then puts the clean product on every section.</p></div>' +
          '</div><div class="stack">' +
          '<div class="card stack"><h2>Price</h2><div class="grid g3"><label class="f">Price (DA)<input type="number" data-p="price" value="' + p.price + '"></label><label class="f">Old price (DA)<input type="number" data-p="old_price" value="' + (p.old_price || '') + '"></label><label class="f">Landed cost (DA)<input type="number" data-p="cost" value="' + p.cost + '"></label></div>' +
          '<div class="line"><span class="muted">Margin before ads</span><b id="pMargin">' + da(margin) + '</b></div><div class="line"><span class="muted">Max cost per order at 60% / 55%</span><b id="pMaxCpo">' + usd(margin * 0.6 * 0.55 / (costs.usdRate || 255)) + '</b></div><p class="small muted">price − cost − ' + costs.courierPerDelivered + ' courier − ' + costs.confirmPerDelivered + ' confirmation. <a href="#/simulator">Full simulation</a></p></div>' +
          '<div class="card stack"><h2>Quantity offers</h2><div class="rows-ed" style="--c:3"><div class="r small muted"><span>Pieces</span><span>Total price</span><span>Label (optional)</span><span></span></div>' + p.offers.map(function (o, i) { return '<div class="r"><input type="number" data-o="' + i + '" data-k="qty" value="' + o.qty + '" min="1"><input type="number" data-o="' + i + '" data-k="price" value="' + o.price + '"><input type="text" data-o="' + i + '" data-k="label" value="' + esc(o.label) + '" dir="auto"><button type="button" data-orm="' + i + '" aria-label="Remove">✕</button></div>'; }).join('') + '</div><button class="btn sm" id="oAdd" type="button">+ Add offer</button></div>' +
          '<div class="card stack"><h2>Variants &amp; stock</h2><p class="small muted">Sizes / colours. Each variant can have its own price (empty = product price), photo and stock. With 2+ variants the customer must pick one. Stock goes down when an order is <b>confirmed</b> and comes back if it is cancelled or returned.</p>' +
          (p.variants.length ? '' : '<label class="f">Stock (no variants — leave empty = not tracked)<input type="number" data-p="stock" min="0" value="' + (p.stock >= 0 ? p.stock : '') + '" placeholder="not tracked"></label>') +
          p.variants.map(function (v, i) { return '<div class="vrow"><label class="vimg">' + (v.image ? '<img src="' + esc(v.image) + '" alt="">' : '<span>+ photo</span>') + '<input type="file" accept="image/*" data-vimg="' + i + '"></label><div class="grid g3 vgrid"><label class="f">Name<input type="text" data-v="' + i + '" data-k="name" value="' + esc(v.name) + '" dir="auto" placeholder="e.g. Black / XL"></label><label class="f">Price (DA)<input type="number" data-v="' + i + '" data-k="price" value="' + (v.price || '') + '" placeholder="' + p.price + '"></label><label class="f">Stock<input type="number" data-v="' + i + '" data-k="stock" value="' + (v.stock || 0) + '"></label><label class="f">SKU<input type="text" data-v="' + i + '" data-k="sku" value="' + esc(v.sku) + '"></label><label class="f">Colour<input type="color" data-v="' + i + '" data-k="color" value="' + esc(v.color || '#000000') + '"></label></div><div class="vact">' + (v.image ? '<button type="button" class="btn sm" data-vimgrm="' + i + '">Remove photo</button>' : '') + '<button type="button" class="btn sm danger" data-vrm="' + i + '">Delete</button></div></div>'; }).join('') +
          '<div class="row"><button class="btn sm" id="vAdd" type="button">+ Add variant</button><button class="btn sm" id="vGen" type="button">Quick: sizes × colours</button></div>' +
          '<label class="f inline"><input type="checkbox" id="pPre"' + (p.preorder ? ' checked' : '') + '> Allow pre-orders when out of stock (customers can still order; the order gets a “pre-order” tag)</label>' +
          (p.preorder ? '<label class="f">Pre-order message (optional)<input type="text" data-p="preorder_note" value="' + esc(p.preorder_note || '') + '" dir="auto" placeholder="مثال: التوصيل خلال 10 أيام بعد وصول السلعة"></label>' : '') + '</div>' +
'</div></div><datalist id="catList">' + (S.products || []).map(function (x) { return x.category; }).filter(function (c, i, a) { return c && a.indexOf(c) === i; }).map(function (c) { return '<option value="' + esc(c) + '">'; }).join('') + '</datalist>';
        bind();
      }
      function bind() {
        el.querySelectorAll('[data-p]').forEach(function (i) {
          i.oninput = function () {
            var k = i.getAttribute('data-p'); p[k] = ['price', 'old_price', 'cost'].indexOf(k) >= 0 ? num(i.value) : k === 'stock' ? (i.value === '' ? -1 : num(i.value)) : i.value;
            if (k === 'price' || k === 'cost') { var mg = (p.price || 0) - (p.cost || 0) - costs.courierPerDelivered - costs.confirmPerDelivered; el.querySelector('#pMargin').textContent = da(mg); el.querySelector('#pMaxCpo').textContent = usd(mg * 0.6 * 0.55 / (costs.usdRate || 255)); }
          };
        });
        el.querySelector('#pLive').onchange = function (e) { p.live = e.target.checked; };
        el.querySelectorAll('[data-o]').forEach(function (i) { i.oninput = function () { var o = p.offers[+i.getAttribute('data-o')], k = i.getAttribute('data-k'); o[k] = k === 'label' ? i.value : num(i.value); }; });
        el.querySelectorAll('[data-orm]').forEach(function (b) { b.onclick = function () { p.offers.splice(+b.getAttribute('data-orm'), 1); render(); }; });
        el.querySelector('#oAdd').onclick = function () { var q = (p.offers.length ? p.offers[p.offers.length - 1].qty : 0) + 1; p.offers.push({ qty: q, price: Math.round(p.price * q * 0.9 / 100) * 100, label: '' }); render(); };
        el.querySelectorAll('[data-v]').forEach(function (i) { i.oninput = function () { var v = p.variants[+i.getAttribute('data-v')], k = i.getAttribute('data-k'); v[k] = k === 'stock' || k === 'price' ? num(i.value) : i.value; }; });
        el.querySelectorAll('[data-vimg]').forEach(function (inp) { inp.onchange = function (e) { var i = +inp.getAttribute('data-vimg'); uploadMany(e.target.files, function (urls) { p.variants[i].image = urls[0]; if (p.images.indexOf(urls[0]) < 0) p.images.push(urls[0]); render(); }); }; });
        el.querySelectorAll('[data-vimgrm]').forEach(function (b) { b.onclick = function () { p.variants[+b.getAttribute('data-vimgrm')].image = ''; render(); }; });
        el.querySelector('#pPre').onchange = function (e) { p.preorder = e.target.checked; render(); };
        el.querySelector('#vGen').onclick = function () {
          var m = modal('<h2>Create variants</h2><div class="stack"><label class="f">Sizes (comma separated)<input type="text" id="gS" placeholder="S, M, L, XL"></label><label class="f">Colours (comma separated)<input type="text" id="gC" placeholder="أسود, أبيض, بيج" dir="auto"></label><label class="f">Stock for each<input type="number" id="gQ" value="10"></label><div class="row"><button class="btn pri" id="gGo">Create</button><button class="btn" data-close>Cancel</button></div></div>');
          m.el.querySelector('#gGo').onclick = function () {
            var sp = function (x) { return x.split(/[,،;]/).map(function (t) { return t.trim(); }).filter(Boolean); };
            var sz = sp(m.el.querySelector('#gS').value), cl = sp(m.el.querySelector('#gC').value), q = num(m.el.querySelector('#gQ').value);
            var names = []; if (cl.length && sz.length) cl.forEach(function (c) { sz.forEach(function (z) { names.push(c + ' / ' + z); }); }); else names = cl.length ? cl : sz;
            names.forEach(function (n) { if (!p.variants.some(function (v) { return v.name === n; })) p.variants.push({ name: n, sku: '', stock: q, color: '', price: 0, image: '' }); });
            m.close(); render();
          };
        };
        el.querySelectorAll('[data-vrm]').forEach(function (b) { b.onclick = function () { p.variants.splice(+b.getAttribute('data-vrm'), 1); render(); }; });
        el.querySelector('#vAdd').onclick = function () { p.variants.push({ name: '', sku: '', stock: 0, color: '', price: 0, image: '' }); render(); };
        el.querySelector('#pUp').onchange = function (e) { uploadMany(e.target.files, function (urls) { p.images = p.images.concat(urls); render(); }); };
        el.querySelectorAll('[data-rm]').forEach(function (b) { b.onclick = function () { var u0 = p.images[+b.getAttribute('data-rm')]; if (p.cutouts) delete p.cutouts[u0]; p.images.splice(+b.getAttribute('data-rm'), 1); render(); }; });
        el.querySelectorAll('[data-cut]').forEach(function (b) { b.onclick = function () { var src = p.images[+b.getAttribute('data-cut')]; cutoutDialog(src, function (url) { p.cutouts = p.cutouts || {}; if (url) p.cutouts[src] = url; else delete p.cutouts[src]; render(); toast(url ? 'Background removed — click Save' : 'Cut-out removed — click Save'); }, (p.cutouts || {})[src]); }; });
        el.querySelectorAll('[data-mv]').forEach(function (b) { b.onclick = function () { var i = +b.getAttribute('data-mv'), j = i + +b.getAttribute('data-d'); if (j < 0 || j >= p.images.length) return; var t = p.images[i]; p.images[i] = p.images[j]; p.images[j] = t; render(); }; });
        el.querySelector('#pSave').onclick = function () {
          p.variants = p.variants.filter(function (v) { return v.name; });
          (isNew ? api('POST', '/products', p) : api('PUT', '/products/' + id, p)).then(function (r) { toast('Saved'); S.products = null; if (isNew) location.hash = '#/products/' + r.product.id; else { p = r.product; render(); } }).catch(fail);
        };
        var del = el.querySelector('#pDel');
        if (del) del.onclick = function () { if (!confirm('Delete "' + p.name + '" and its landing pages? Orders stay.')) return; api('DELETE', '/products/' + id).then(function () { S.products = null; toast('Deleted'); location.hash = '#/products'; }).catch(fail); };
      }
      loadSettings().then(function (s) { costs = s.costs; render(); }).catch(render);
    }).catch(fail);
  }

  // ---------- Landing pages ----------
  PAGES.landings = function (el, id) {
    if (id) return landingEditor(el, id);
    function load() {
      api('GET', '/landings?' + qs({ from: RANGE.from, to: RANGE.to })).then(function (j) {
        var rb = rangeBar(load);
        var tv = 0, to = 0; j.rows.forEach(function (l) { tv += l.rangeVisits; to += l.rangeOrders; });
        el.innerHTML = '<div class="ph"><div><h1>Landing pages</h1><p>One page per ad offer. No menu, one goal: the COD order.</p></div><div class="row">' + rb.html + '<a class="btn pri" href="#/generate">+ Generate with AI</a></div></div>' +
          '<div class="cards"><div class="kpi"><span>Live pages</span><b>' + j.rows.filter(function (l) { return l.live; }).length + '</b></div><div class="kpi"><span>Visits</span><b>' + tv + '</b><small>unique per day</small></div><div class="kpi"><span>Orders</span><b>' + to + '</b></div><div class="kpi"><span>Visit → order</span><b>' + (tv ? (to / tv * 100).toFixed(1) + '%' : '—') + '</b></div></div>' +
          (j.rows.length ? j.rows.map(function (l) {
            var cv = l.rangeVisits ? l.rangeOrders / l.rangeVisits * 100 : 0;
            return '<div class="lcard"><div class="thumb">' + (l.content.hero_img || l.product_image ? '<img src="' + esc(l.content.hero_img || l.product_image) + '" alt="">' : '') + '</div><div class="info"><div class="row"><b>' + esc(l.title) + '</b>' + (l.live ? '<span class="chip st-delivered">Live</span>' : '<span class="chip st-cancelled">Paused</span>') + (l.ai ? '<span class="chip" style="background:#FDF1DC;color:#7A4A00">AI</span>' : '') + '<span class="chip st-new">' + l.lang.toUpperCase() + '</span></div><div class="muted small">' + esc(l.product_name) + ' · ' + esc(storeLink('/l/' + l.slug)) + (l.pixel_meta ? ' · pixel ' + esc(l.pixel_meta) : '') + '</div></div>' +
              '<div class="stats"><span><b>' + l.rangeVisits + '</b>visits</span><span><b>' + l.rangeOrders + '</b>orders</span><span><b style="color:' + (cv >= 4.5 ? '#0B5132' : cv > 0 ? '#8A4B00' : '#57625C') + '">' + (l.rangeVisits ? cv.toFixed(1) + '%' : '—') + '</b>conversion</span></div>' +
              '<div class="acts"><a class="btn sm" href="' + esc(storeLink('/l/' + l.slug)) + '?preview=1" target="_blank" rel="noopener">Open ↗</a><a class="btn sm" href="#/landings/' + l.id + '">Edit</a><button class="btn sm" data-copy="' + esc(l.slug) + '">Copy ad link</button><button class="btn sm" data-dup="' + l.id + '">Duplicate (A/B)</button><button class="btn sm ' + (l.live ? '' : 'pri') + '" data-live="' + l.id + '">' + (l.live ? 'Pause' : 'Publish') + '</button></div></div>';
          }).join('') : '<div class="card empty">No landing pages yet. <a href="#/generate">Generate your first one with AI</a>.</div>') +
          '<div class="notice info" style="margin-top:12px"><b>Ad link tip:</b> the copied link includes <code>?utm_source=facebook&amp;utm_campaign={{campaign.id}}&amp;utm_content={{ad.id}}</code>. Paste it as the website URL in Meta Ads — Ads &amp; profit then matches every order to its campaign.</div>';
        rb.bind(el);
        el.querySelectorAll('[data-copy]').forEach(function (b) { b.onclick = function () { var u = storeLink('/l/' + b.getAttribute('data-copy')) + '?utm_source=facebook&utm_campaign={{campaign.id}}&utm_content={{ad.id}}'; try { navigator.clipboard.writeText(u); toast('Ad link copied'); } catch (e) { prompt('Copy this link', u); } }; });
        el.querySelectorAll('[data-dup]').forEach(function (b) { b.onclick = function () { api('POST', '/landings/' + b.getAttribute('data-dup') + '/duplicate').then(function (r) { toast('Copy created (paused) — change the headline to A/B test'); location.hash = '#/landings/' + r.landing.id; }).catch(fail); }; });
        el.querySelectorAll('[data-live]').forEach(function (b) { b.onclick = function () { var l = j.rows.filter(function (x) { return String(x.id) === b.getAttribute('data-live'); })[0]; l.live = !l.live; api('PUT', '/landings/' + l.id, l).then(function () { toast(l.live ? 'Published' : 'Paused'); load(); }).catch(fail); }; });
      }).catch(fail);
    }
    load();
  };

  function landingEditor(el, id) {
    Promise.all([api('GET', '/landings/' + id), loadProducts()]).then(function (res) {
      var l = res[0].landing, ps = res[1], c = l.content;
      var isPanels = c.layout === 'panels'; c.panels = c.panels || [];
      var pfont = 'Cairo', pbusy = false;
      loadSettings().then(function (s) { pfont = s.theme.font || 'Cairo'; }).catch(function () {});
      var imgOn = !!(S.ai && S.ai.images);
      function prodOf() { return ps.filter(function (p) { return p.id === l.product_id; })[0] || { images: [], offers: [] }; }
      function ropts() { var p = prodOf(); return { palette: c.palette || PALETTES.health, font: pfont, lang: l.lang, productImage: p.images[0] || '', price: p.offers && p.offers[0] ? p.offers[0].price : p.price, oldPrice: p.old_price, offers: p.offers, composite: !c.use_photos && (!S.ai || S.ai.imageProvider === 'cloudflare'), productCutout: (c.cutouts && c.cutouts[0] && c.cutouts[0].cutout) || (p.cutouts && p.images[0] && p.cutouts[p.images[0]]) || '', fx: c.fx || { glow: true } }; }
      function panelsHtml() {
        var pal = c.palette || PALETTES.health;
        return '<div class="card stack"><div class="row" style="justify-content:space-between"><h2 style="margin:0">Image panels (' + c.panels.length + ')</h2><div class="row"><input type="color" id="pc1" value="' + pal.primary + '"><input type="color" id="pc2" value="' + pal.accent + '"><input type="color" id="pc3" value="' + pal.dark + '"><button class="btn sm" id="pAll"' + (pbusy ? ' disabled' : '') + '>Re-draw all</button></div></div>' +
          '<p class="small muted">Edit a text, then “Re-draw text”. Save the page after changes. The order form always comes after panel 1.</p>' +
          c.panels.map(function (x, i) {
            return '<div class="lcard" style="align-items:flex-start"><div class="thumb" style="width:110px;height:136px;flex-basis:110px">' + (x.image ? '<img src="' + esc(x.image) + '" alt="">' : '') + '</div><div class="info stack" style="gap:8px"><b>' + (i + 1) + '. ' + esc(PANEL_LABELS[x.type] || x.type) + '</b>' + panelFields(x, i) + '</div><div class="acts" style="flex-direction:column;align-items:stretch;flex:0 0 150px">' +
              '<button class="btn sm" data-prr="' + i + '"' + (pbusy ? ' disabled' : '') + '>Re-draw text</button>' + (imgOn && !c.use_photos && window.Panels.needsScene(x.type) ? '<button class="btn sm" data-prs="' + i + '"' + (pbusy ? ' disabled' : '') + '>New AI scene</button>' : '') +
              '<button class="btn sm" data-pup="' + i + '"' + (i < 2 ? ' disabled' : '') + '>↑</button><button class="btn sm" data-pdn="' + i + '"' + (i === 0 || i >= c.panels.length - 1 ? ' disabled' : '') + '>↓</button>' + (c.panels.length > 2 ? '<button class="btn sm danger" data-prm="' + i + '">Remove</button>' : '') + '</div></div>';
          }).join('') + '</div>';
      }
      function bindPanels() {
        if (!isPanels) return;
        bindPanelFields(el, c.panels);
        var setPal = function () { c.palette = { primary: el.querySelector('#pc1').value, accent: el.querySelector('#pc2').value, dark: el.querySelector('#pc3').value }; };
        ['pc1', 'pc2', 'pc3'].forEach(function (k) { el.querySelector('#' + k).oninput = setPal; });
        var run = function (fn) { pbusy = true; render(); fn().then(function () { pbusy = false; render(); toast('Done — click Save to publish the change'); }).catch(function (e) { pbusy = false; render(); fail(e); }); };
        el.querySelectorAll('[data-prr]').forEach(function (b) { b.onclick = function () { run(function () { return panelRender(c.panels[+b.getAttribute('data-prr')], ropts()); }); }; });
        el.querySelectorAll('[data-prs]').forEach(function (b) { b.onclick = function () { var pn = c.panels[+b.getAttribute('data-prs')]; run(function () { return panelScenes(pn, prodOf().images[0] || '').then(function (w) { if (w) toast(w, true); return panelRender(pn, ropts()); }); }); }; });
        el.querySelectorAll('[data-pup]').forEach(function (b) { b.onclick = function () { var i = +b.getAttribute('data-pup'); var t = c.panels[i]; c.panels[i] = c.panels[i - 1]; c.panels[i - 1] = t; render(); }; });
        el.querySelectorAll('[data-pdn]').forEach(function (b) { b.onclick = function () { var i = +b.getAttribute('data-pdn'); var t = c.panels[i]; c.panels[i] = c.panels[i + 1]; c.panels[i + 1] = t; render(); }; });
        el.querySelectorAll('[data-prm]').forEach(function (b) { b.onclick = function () { c.panels.splice(+b.getAttribute('data-prm'), 1); render(); }; });
        el.querySelector('#pAll').onclick = function () { run(function () { return c.panels.reduce(function (pr, pn) { return pr.then(function () { return panelRender(pn, ropts()); }); }, Promise.resolve()); }); };
      }
      c.problem = c.problem || { title: '', pains: [], bridge: '' }; c.sections = c.sections || {};
      ['bullets', 'benefits', 'comparison', 'steps', 'faq', 'gallery', 'review_imgs'].forEach(function (k) { c[k] = c[k] || []; });
      function txt(path, label, area) { var v = get(path); return '<label class="f">' + esc(label) + (area ? '<textarea data-c="' + path + '" dir="auto">' + esc(v) + '</textarea>' : '<input type="text" data-c="' + path + '" value="' + esc(v) + '" dir="auto">') + '</label>'; }
      function get(path) { return path.split('.').reduce(function (o, k) { return o == null ? '' : o[k]; }, c) || ''; }
      function set(path, v) { var ks = path.split('.'), o = c; for (var i = 0; i < ks.length - 1; i++) { if (o[ks[i]] == null) o[ks[i]] = isNaN(ks[i + 1]) ? {} : []; o = o[ks[i]]; } o[ks[ks.length - 1]] = v; }
      function list(key, label, fields, max) {
        var arr = c[key];
        return '<div class="card stack"><div class="row" style="justify-content:space-between"><h2 style="margin:0">' + esc(label) + '</h2><label class="f inline"><input type="checkbox" data-sec="' + key + '"' + (c.sections[key] !== false ? ' checked' : '') + '> Show</label></div>' +
          arr.map(function (it, i) { return '<div class="row" style="align-items:flex-start">' + (fields ? fields.map(function (f) { return '<div class="grow">' + (f[2] ? '<textarea data-c="' + key + '.' + i + '.' + f[0] + '" placeholder="' + esc(f[1]) + '" dir="auto" style="min-height:60px">' + esc(it[f[0]]) + '</textarea>' : '<input type="text" data-c="' + key + '.' + i + '.' + f[0] + '" placeholder="' + esc(f[1]) + '" value="' + esc(it[f[0]]) + '" dir="auto">') + '</div>'; }).join('') : '<div class="grow"><input type="text" data-c="' + key + '.' + i + '" value="' + esc(it) + '" dir="auto"></div>') + '<button class="btn sm danger" type="button" data-del="' + key + '.' + i + '" aria-label="Remove">✕</button></div>'; }).join('') +
          (arr.length < (max || 6) ? '<button class="btn sm" type="button" data-add="' + key + '">+ Add</button>' : '') + '</div>';
      }
      function render() {
        el.innerHTML = '<div class="ph"><div><a href="#/landings" class="small">← Landing pages</a><h1>' + esc(l.title) + '</h1></div><div class="row"><label class="f inline"><input type="checkbox" id="lLive"' + (l.live ? ' checked' : '') + '> Live</label><a class="btn" href="/l/' + esc(l.slug) + '?preview=1" target="_blank" rel="noopener">Preview ↗</a><button class="btn danger" id="lDel">Delete</button><button class="btn pri" id="lSave">Save</button></div></div>' +
          '<div class="cols"><div class="stack w2">' +
          (isPanels ? panelsHtml() : '') + '<div class="stack"' + (isPanels ? ' hidden' : '') + '>' +
          '<div class="card stack"><h2>Hero</h2>' + txt('hook', 'Hook (question that touches the pain)') + txt('headline', 'Headline') + txt('subheadline', 'Sub-headline', true) + txt('badge', 'Corner badge') + oneImage('hero_img', c.hero_img, 'Hero image (default: product main photo)') + '</div>' +
          list('bullets', 'Bullets under the headline', null, 5) +
          '<div class="card stack"><div class="row" style="justify-content:space-between"><h2 style="margin:0">Problem block</h2><label class="f inline"><input type="checkbox" data-sec="problem"' + (c.sections.problem !== false ? ' checked' : '') + '> Show</label></div>' + txt('problem.title', 'Title') + [0, 1, 2].map(function (i) { return txt('problem.pains.' + i, 'Pain ' + (i + 1)); }).join('') + txt('problem.bridge', 'Bridge line (lead to the product)') + '</div>' +
          '<div class="card stack"><div class="row" style="justify-content:space-between"><h2 style="margin:0">Before / after</h2><label class="f inline"><input type="checkbox" data-sec="beforeafter"' + (c.sections.beforeafter !== false ? ' checked' : '') + '> Show</label></div><p class="small muted">Real photos only. Shown when both are set.</p><div class="grid">' + oneImage('before_img', c.before_img, 'Before') + oneImage('after_img', c.after_img, 'After') + '</div></div>' +
          list('benefits', 'Benefits', [['title', 'Title'], ['text', 'Text', true]], 6) +
          '<div class="card stack"><h2>Media</h2>' + oneImage('video', c.video, 'Video (MP4, max 18 MB, vertical)') + '<div class="small" style="font-weight:600">Extra images</div><div class="imgs">' + c.gallery.map(function (u, i) { return '<div class="im"><img src="' + esc(u) + '" alt=""><div class="ctl"><button type="button" data-grm="gallery.' + i + '">✕</button></div></div>'; }).join('') + '<label class="upl">+ Add<input type="file" accept="image/*" multiple data-many="gallery"></label></div></div>' +
          list('comparison', 'Us vs others (rows)', null, 6) +
          '</div>' +
          '<div class="card stack"><div class="row" style="justify-content:space-between"><h2 style="margin:0">Real customer reviews (screenshots)</h2><label class="f inline"><input type="checkbox" data-sec="reviews"' + (c.sections.reviews !== false ? ' checked' : '') + '> Show</label></div><div class="imgs">' + c.review_imgs.map(function (u, i) { return '<div class="im"><img src="' + esc(u) + '" alt=""><div class="ctl"><button type="button" data-grm="review_imgs.' + i + '">✕</button></div></div>'; }).join('') + '<label class="upl">+ Add<input type="file" accept="image/*" multiple data-many="review_imgs"></label></div></div>' +
          '<div class="stack"' + (isPanels ? ' hidden' : '') + '>' + list('steps', 'How to use', [['title', 'Step'], ['text', 'Detail', true]], 5) + '</div>' +
          list('faq', 'FAQ', [['q', 'Question'], ['a', 'Answer', true]], 8) +
          '<div class="card stack"><h2>Closing</h2>' + txt('final_cta', 'Final call to action') + '</div>' +
          '</div><div class="stack">' +
          '<div class="card stack"><h2>Settings</h2><label class="f">Title (admin only)<input type="text" id="lTitle" value="' + esc(l.title) + '"></label><label class="f">URL: /l/…<input type="text" id="lSlug" value="' + esc(l.slug) + '"></label><label class="f">Product<select id="lProd">' + ps.map(function (p) { return '<option value="' + p.id + '"' + (p.id === l.product_id ? ' selected' : '') + '>' + esc(p.name) + '</option>'; }).join('') + '</select></label><label class="f">Page language<select id="lLang"><option value="ar"' + (l.lang === 'ar' ? ' selected' : '') + '>العربية</option><option value="dz"' + (l.lang === 'dz' ? ' selected' : '') + '>الدارجة (Arabic UI)</option><option value="fr"' + (l.lang === 'fr' ? ' selected' : '') + '>Français</option></select></label>' +
          '<label class="f">Meta Pixel ID for this page<input type="text" id="lPx" value="' + esc(l.pixel_meta) + '" placeholder="empty = store pixel"></label><label class="f">TikTok Pixel ID<input type="text" id="lTt" value="' + esc(l.pixel_tiktok) + '" placeholder="empty = store pixel"></label><p class="small muted">Offers and prices come from the product. Layout style comes from Store design.</p></div>' +
          '<div class="card stack"><h2>One-time offer after order (upsell)</h2><p class="small muted">Shown on the thank-you screen. Added to the same parcel.</p><label class="f">Offer title<input type="text" id="uT" value="' + esc(c.upsell ? c.upsell.title : '') + '" dir="auto"></label><label class="f">Price added (DA, 0 = no upsell)<input type="number" id="uP" value="' + (c.upsell ? c.upsell.price : 0) + '"></label>' + oneImage('upsell_img', c.upsell ? c.upsell.image : '', 'Image') + '</div>' +
          '<div class="card stack"><h2>Phone preview</h2><div class="phone-frame" style="height:640px"><iframe id="lFrame" title="Preview" src="/l/' + esc(l.slug) + '?preview=1"></iframe></div><p class="small muted">Refreshes after you save.</p></div>' +
          '</div></div>';
        bind();
      }
      function bind() {
        bindPanels();
        el.querySelectorAll('[data-c]').forEach(function (i) { i.oninput = function () { set(i.getAttribute('data-c'), i.value); }; });
        el.querySelectorAll('[data-sec]').forEach(function (i) { i.onchange = function () { c.sections[i.getAttribute('data-sec')] = i.checked; }; });
        el.querySelectorAll('[data-add]').forEach(function (b) { b.onclick = function () { var k = b.getAttribute('data-add'); c[k].push(k === 'benefits' || k === 'steps' ? { title: '', text: '' } : k === 'faq' ? { q: '', a: '' } : ''); render(); }; });
        el.querySelectorAll('[data-del]').forEach(function (b) { b.onclick = function () { var p = b.getAttribute('data-del').split('.'); c[p[0]].splice(+p[1], 1); render(); }; });
        el.querySelectorAll('[data-grm]').forEach(function (b) { b.onclick = function () { var p = b.getAttribute('data-grm').split('.'); c[p[0]].splice(+p[1], 1); render(); }; });
        el.querySelectorAll('[data-many]').forEach(function (i) { i.onchange = function () { var k = i.getAttribute('data-many'); uploadMany(i.files, function (u) { c[k] = c[k].concat(u); render(); }); }; });
        el.querySelectorAll('[data-one]').forEach(function (i) { i.onchange = function () { var k = i.getAttribute('data-one'); if (!i.files[0]) return; toast('Uploading…'); fileToUpload(i.files[0]).then(function (u) { if (k === 'upsell_img') { c.upsell = c.upsell || { title: '', price: 0 }; c.upsell.image = u; } else c[k] = u; render(); toast('Uploaded'); }).catch(fail); }; });
        el.querySelectorAll('[data-clear]').forEach(function (b) { b.onclick = function () { var k = b.getAttribute('data-clear'); if (k === 'upsell_img') { if (c.upsell) c.upsell.image = ''; } else c[k] = ''; render(); }; });
        el.querySelector('#lSave').onclick = function () {
          var up = { title: el.querySelector('#uT').value, price: num(el.querySelector('#uP').value), image: c.upsell ? c.upsell.image : '' };
          c.upsell = up.price > 0 ? up : null;
          var body = { title: el.querySelector('#lTitle').value, slug: el.querySelector('#lSlug').value, product_id: +el.querySelector('#lProd').value, lang: el.querySelector('#lLang').value, pixel_meta: el.querySelector('#lPx').value, pixel_tiktok: el.querySelector('#lTt').value, live: el.querySelector('#lLive').checked, content: c };
          api('PUT', '/landings/' + l.id, body).then(function (r) { l = r.landing; c = l.content; ['bullets', 'benefits', 'comparison', 'steps', 'faq', 'gallery', 'review_imgs'].forEach(function (k) { c[k] = c[k] || []; }); c.problem = c.problem || { title: '', pains: [], bridge: '' }; c.panels = c.panels || []; c.sections = c.sections || {}; toast('Saved'); render(); var fr = el.querySelector('#lFrame'); if (fr) fr.src = fr.src; }).catch(fail);
        };
        el.querySelector('#lDel').onclick = function () { if (!confirm('Delete this landing page? Its link stops working.')) return; api('DELETE', '/landings/' + l.id).then(function () { toast('Deleted'); location.hash = '#/landings'; }).catch(fail); };
      }
      render();
    }).catch(fail);
  }

  // ---------- AI generator ----------
  PAGES.generate_classic = function (el) {
    var G = { image: null, imageUrl: '', productId: '', name: '', price: 3900, b2: 6900, b3: 9400, cost: 0, desc: '', lang: 'ar', angle: 'auto', result: null };
    Promise.all([loadProducts(), loadSettings()]).then(function (res) {
      var ps = res[0], ai = res[1].ai;
      function render() {
        el.innerHTML = '<div class="ph"><div><h1>AI landing page generator</h1><p>Photo + two lines about the product → a full mobile landing page with the COD form.</p></div><span class="chip st-new">AI: ' + esc(ai.provider === 'ollama' ? 'Ollama (' + ai.ollamaModel + ', free, on this PC)' : ai.provider === 'gemini' ? 'Gemini free tier' : 'Template only') + '</span></div>' +
          '<div class="cols"><div class="card stack">' +
          '<label class="f">Product<select id="gP"><option value="">+ New product</option>' + ps.map(function (p) { return '<option value="' + p.id + '"' + (String(p.id) === String(G.productId) ? ' selected' : '') + '>' + esc(p.name) + '</option>'; }).join('') + '</select></label>' +
          (G.productId ? '' : '<div class="grid g3"><label class="f">Product name<input type="text" id="gN" value="' + esc(G.name) + '" dir="auto"></label><label class="f">Price (DA)<input type="number" id="gPr" value="' + G.price + '"></label><label class="f">2 pieces (DA)<input type="number" id="gB2" value="' + G.b2 + '"></label><label class="f">3 pieces (DA)<input type="number" id="gB3" value="' + G.b3 + '"></label><label class="f">Landed cost (DA)<input type="number" id="gC" value="' + G.cost + '"></label></div>') +
          '<div class="f"><span class="small" style="font-weight:600">Product photo</span><div class="one-img"><div class="th" style="width:96px;height:96px;flex-basis:96px">' + (G.imageUrl ? '<img src="' + esc(G.imageUrl) + '" alt="">' : '') + '</div><label class="btn" style="position:relative">' + (G.imageUrl ? 'Change photo' : 'Upload photo') + '<input type="file" accept="image/*" id="gImg" style="position:absolute;inset:0;opacity:0"></label></div></div>' +
          (G.cut ? '<div class="row small" style="gap:12px;align-items:center"><img src="' + esc(G.cut) + '" alt="" class="isCut" style="width:56px;height:56px;object-fit:contain;border-radius:8px;background:repeating-conic-gradient(#e5e7eb 0 25%,#fff 0 50%) 0 0/12px 12px">' + [['glow', 'Glow'], ['rays', 'Light rays'], ['reflect', 'Reflection'], ['podium', 'Podium']].map(function (f) { return '<label class="f inline"><input type="checkbox" data-gfx="' + f[0] + '"' + (G.fx[f[0]] ? ' checked' : '') + '> ' + f[1] + '</label>'; }).join('') + '</div>' : '<div class="small muted">Tip: ✂ removes the background for free in your browser — the clean product is then placed on every AI scene.</div>') + '</div>' +
          '<label class="f">Short description<textarea id="gD" dir="auto" placeholder="What it is, the problem it solves, who it is for. Any language.">' + esc(G.desc) + '</textarea></label>' +
          '<div class="grid g3"><label class="f">Page language<select id="gL"><option value="ar">العربية الفصحى</option><option value="dz">الدارجة الجزائرية</option><option value="fr">Français</option></select></label><label class="f">Selling angle<select id="gA"><option value="auto">Let AI choose</option><option value="pain">Pain / problem</option><option value="result">Result / before-after</option><option value="gift">Gift</option><option value="urgency">Limited offer (honest)</option></select></label></div>' +
          '<button class="btn pri" id="gGo" style="min-height:48px">Generate landing page</button><p class="small muted">With Ollama, the first run can take 1–3 minutes while the model loads. Nothing leaves your computer.</p></div>' +
          '<div class="card stack" id="gOut">' + (G.result ? resultHtml() : '<div class="empty">The generated text appears here. You can edit everything after creating the page.</div>') + '</div></div>';
        el.querySelector('#gL').value = G.lang; el.querySelector('#gA').value = G.angle;
        el.querySelector('#gP').onchange = function (e) { G.productId = e.target.value; render(); };
        ['gN', 'gPr', 'gB2', 'gB3', 'gC'].forEach(function (k) { var i = el.querySelector('#' + k); if (i) i.oninput = function () { var map = { gN: 'name', gPr: 'price', gB2: 'b2', gB3: 'b3', gC: 'cost' }; G[map[k]] = k === 'gN' ? i.value : num(i.value); }; });
        el.querySelector('#gD').oninput = function (e) { G.desc = e.target.value; };
        el.querySelector('#gL').onchange = function (e) { G.lang = e.target.value; };
        el.querySelector('#gA').onchange = function (e) { G.angle = e.target.value; };
        el.querySelector('#gImg').onchange = function (e) {
          var f = e.target.files[0]; if (!f) return;
          toast('Uploading…');
          fileToUpload(f, 1400).then(function (u) {
            G.imageUrl = u;
            var img = new Image(); img.onload = function () { var s = Math.min(1, 768 / img.width), cv = document.createElement('canvas'); cv.width = img.width * s; cv.height = img.height * s; cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height); G.image = cv.toDataURL('image/jpeg', 0.8); render(); toast('Photo ready'); }; img.src = u;
          }).catch(fail);
        };
        el.querySelector('#gGo').onclick = generate;
        var cr = el.querySelector('#gCreate'); if (cr) cr.onclick = create;
      }
      function resultHtml() {
        var r = G.result.content;
        return (G.result.warning ? '<div class="notice">AI not reachable (' + esc(G.result.warning) + '). A ready-to-edit template was used instead. Check Settings → AI.</div>' : '<div class="notice info">Written by ' + esc(G.result.provider) + '. Read it once before publishing.</div>') +
          '<b dir="auto" style="font-size:12px;color:#0F5C46">' + esc(r.hook) + '</b><h2 dir="auto" style="font-size:20px;margin:0">' + esc(r.headline) + '</h2><p dir="auto" class="muted" style="margin:0">' + esc(r.subheadline) + '</p>' +
          '<ul dir="auto">' + r.bullets.map(function (b) { return '<li>' + esc(b) + '</li>'; }).join('') + '</ul>' +
          '<b dir="auto">' + esc(r.problem.title) + '</b><ul dir="auto">' + r.problem.pains.map(function (b) { return '<li>' + esc(b) + '</li>'; }).join('') + '</ul>' +
          '<b>Benefits</b><ul dir="auto">' + r.benefits.map(function (b) { return '<li><b>' + esc(b.title) + '</b> — ' + esc(b.text) + '</li>'; }).join('') + '</ul>' +
          '<b>FAQ</b><ul dir="auto">' + r.faq.map(function (f) { return '<li><b>' + esc(f.q) + '</b> ' + esc(f.a) + '</li>'; }).join('') + '</ul>' +
          '<div class="row"><button class="btn pri" id="gCreate">Create landing page</button><button class="btn" onclick="document.getElementById(\'gGo\').click()">Regenerate</button></div>';
      }
      function generate() {
        if (G.desc.trim().length < 8) return toast('Write a short description first', true);
        var btn = el.querySelector('#gGo'); btn.disabled = true; btn.textContent = 'Writing your page…';
        var prod = G.productId ? ps.filter(function (p) { return String(p.id) === String(G.productId); })[0] : null;
        api('POST', '/ai/generate', { image: G.image, description: G.desc, productName: prod ? prod.name : G.name, price: prod ? prod.price : G.price, lang: G.lang, angle: G.angle })
          .then(function (r) { G.result = r; render(); }).catch(function (e) { fail(e); btn.disabled = false; btn.textContent = 'Generate landing page'; });
      }
      function create() {
        var r = G.result.content;
        var ensure = G.productId ? Promise.resolve(+G.productId) : api('POST', '/products', {
          name: G.name || r.product_name || 'New product', price: G.price, cost: G.cost, short_desc: r.subheadline, description: r.benefits.map(function (b) { return b.title + ': ' + b.text; }).join('\n'), images: G.imageUrl ? [G.imageUrl] : [], live: true, seo_title: r.seo_title,
          offers: [{ qty: 1, price: G.price }, { qty: 2, price: G.b2 }, { qty: 3, price: G.b3 }].filter(function (o) { return o.price > 0; }), variants: []
        }).then(function (j) { S.products = null; return j.product.id; });
        ensure.then(function (pid) {
          return api('POST', '/landings', { product_id: pid, title: (G.name || r.product_name) + ' — ' + G.angle + ' ' + G.lang.toUpperCase(), lang: G.lang, ai: true, live: true, content: Object.assign({}, r, { hero_img: G.imageUrl }) });
        }).then(function (j) { toast('Landing page created'); location.hash = '#/landings/' + j.landing.id; }).catch(fail);
      }
      render();
    }).catch(fail);
  };

  // ---------- AI landing generator (Algerian image-stack pages) ----------
  var PANEL_LABELS = { hook: 'Hook (first image)', problem: 'Problem', before_after: 'Before / after', 'case': 'Situation / occasions', features: 'Benefits / ingredients', how_to: 'How to use', trust: 'Trust (COD, delivery)', offer: 'Final offer', look: 'Full photo (look)', details: 'Details collage', sizes: 'Sizes / colours' };
  var PALETTES = {
    health: { primary: '#0F5C46', accent: '#F2A93B', dark: '#0B2A20' }, beauty: { primary: '#9F1239', accent: '#F9A8D4', dark: '#2A0E17' },
    home: { primary: '#1D4ED8', accent: '#FACC15', dark: '#0F1B3D' }, kids: { primary: '#EA580C', accent: '#FDE047', dark: '#3A1604' },
    men: { primary: '#1F2937', accent: '#D4A017', dark: '#0B0F14' }, fashion: { primary: '#111111', accent: '#E8C9A0', dark: '#000000' },
    tech: { primary: '#0E7490', accent: '#A3E635', dark: '#06232B' }, food: { primary: '#7C2D12', accent: '#F59E0B', dark: '#2B1006' }
  };
  function refDataUrl(url) {
    return new Promise(function (res) {
      var img = new Image(); img.onload = function () { var s = Math.min(1, 500 / Math.max(img.width, img.height)), cv = document.createElement('canvas'); cv.width = Math.round(img.width * s); cv.height = Math.round(img.height * s); var x = cv.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, cv.width, cv.height); x.drawImage(img, 0, 0, cv.width, cv.height); res(cv.toDataURL('image/jpeg', 0.88)); }; img.onerror = function () { res(null); }; img.src = url;
    });
  }
  function dataUrlFromUrl(url, maxW) {
    return new Promise(function (res) {
      if (!url) return res(null);
      var img = new Image(); img.onload = function () { var s = Math.min(1, (maxW || 768) / img.width), cv = document.createElement('canvas'); cv.width = img.width * s; cv.height = img.height * s; cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height); res(cv.toDataURL('image/jpeg', 0.82)); }; img.onerror = function () { res(null); }; img.src = url;
    });
  }
  // Generate AI scene(s) for one panel. Returns warning text or ''.
  // Small (<=512px) copy of the product photo: FLUX.2 uses it as a reference so the real product appears in the scene.
  var REF = {};
  function refFor(productUrl) {
    if (!productUrl || !S.ai || !S.ai.refImages) return Promise.resolve('');
    if (REF[productUrl]) return REF[productUrl];
    REF[productUrl] = refDataUrl(productUrl).then(function (d) { return d ? api('POST', '/upload', { data: d }).then(function (j) { return j.url || ''; }) : ''; }).catch(function () { delete REF[productUrl]; return ''; });
    return REF[productUrl];
  }
  function panelScenes(panel, productUrl) {
    if (!window.Panels.needsScene(panel.type)) return Promise.resolve('');
    return refFor(productUrl).then(function (ref) {
      var jobs = [];
      panel.sceneHasProduct = false;
      if (panel.type === 'before_after') {
        jobs.push(api('POST', '/ai/scene', { prompt: panel.before_scene || panel.scene_prompt, productUrl: '' }).then(function (r) { useQuota(r); if (r.url) panel.scene = r.url; return r.warning || ''; }));
        jobs.push(api('POST', '/ai/scene', { prompt: panel.after_scene || panel.scene_prompt, productUrl: productUrl, refUrl: ref }).then(function (r) { useQuota(r); if (r.url) { panel.scene2 = r.url; panel.sceneHasProduct = !!r.withProduct; } return r.warning || ''; }));
      } else {
        jobs.push(api('POST', '/ai/scene', { prompt: panel.scene_prompt, productUrl: productUrl, refUrl: ref, aspect: panel.type === 'hook' || panel.type === 'offer' ? '4:5' : '1:1' }).then(function (r) { useQuota(r); if (r.url) { panel.scene = r.url; panel.sceneHasProduct = !!r.withProduct; } return r.warning || ''; }));
      }
      return Promise.all(jobs).then(function (w) { return w.filter(Boolean)[0] || ''; });
    });
  }
  function panelRender(panel, o) {
    return window.Panels.render(panel, o).then(function (dataUrl) { return api('POST', '/upload', { data: dataUrl }); }).then(function (j) { panel.image = j.url; return panel; });
  }
  function splitLines(v) { return String(v || '').split('\n').map(function (s) { return s.trim(); }).filter(Boolean); }
  function panelFields(p, i) {
    var f = '<label class="f">Title<input type="text" data-pf="' + i + '.title" value="' + esc(p.title) + '" dir="auto"></label>';
    if (['hook', 'problem', 'case', 'features', 'how_to', 'trust', 'offer', 'before_after'].indexOf(p.type) >= 0) f += '<label class="f">Word to color (from the title)<input type="text" data-pf="' + i + '.highlight" value="' + esc(p.highlight) + '" dir="auto"></label>';
    if (p.type === 'hook' || p.type === 'offer') f += '<label class="f">Sub-title<input type="text" data-pf="' + i + '.subtitle" value="' + esc(p.subtitle) + '" dir="auto"></label>';
    if (p.type === 'hook') f += '<label class="f">Badge<input type="text" data-pf="' + i + '.badge" value="' + esc(p.badge) + '" dir="auto"></label>';
    if (p.type === 'look') f += '<label class="f">Sub-title<input type="text" data-pf="' + i + '.subtitle" value="' + esc(p.subtitle) + '" dir="auto"></label>';
    if (['problem', 'case', 'features', 'details', 'sizes'].indexOf(p.type) >= 0) f += '<label class="f">Points (one per line)<textarea data-pl="' + i + '.bullets" dir="auto" style="min-height:70px">' + esc((p.bullets || []).join('\n')) + '</textarea></label>';
    if (p.type === 'before_after') f += '<div class="grid g3"><label class="f">Before (one per line)<textarea data-pl="' + i + '.before_points" dir="auto">' + esc((p.before_points || []).join('\n')) + '</textarea></label><label class="f">After (one per line)<textarea data-pl="' + i + '.after_points" dir="auto">' + esc((p.after_points || []).join('\n')) + '</textarea></label></div>';
    if (p.type === 'how_to') f += '<label class="f">Steps (one per line)<textarea data-pl="' + i + '.steps" dir="auto">' + esc((p.steps || []).join('\n')) + '</textarea></label>';
    if (window.Panels.needsScene(p.type) && !p._photoMode) f += '<details><summary class="small" style="cursor:pointer">Image AI prompt</summary>' + (p.type === 'before_after' ? '<label class="f">Before scene<textarea data-pf="' + i + '.before_scene">' + esc(p.before_scene) + '</textarea></label><label class="f">After scene<textarea data-pf="' + i + '.after_scene">' + esc(p.after_scene) + '</textarea></label>' : '<textarea data-pf="' + i + '.scene_prompt">' + esc(p.scene_prompt) + '</textarea>') + '</details>';
    return f;
  }
  function bindPanelFields(root, panels) {
    root.querySelectorAll('[data-pf]').forEach(function (inp) { inp.oninput = function () { var a = inp.getAttribute('data-pf').split('.'); panels[+a[0]][a[1]] = inp.value; }; });
    root.querySelectorAll('[data-pl]').forEach(function (inp) { inp.oninput = function () { var a = inp.getAttribute('data-pl').split('.'); panels[+a[0]][a[1]] = splitLines(inp.value); }; });
  }

  PAGES.generate = function (el) {
    var G = { step: 1, productId: '', name: '', price: 3900, b2: 6900, b3: 9400, cost: 0, desc: '', lang: 'dz', photo: '', photos: [], photoData: null, useAI: true, usePhotos: false, plan: null, panels: [], palette: null, font: 'Cairo', busy: false, log: [], cut: '', fx: { glow: true, reflect: false, podium: false, rays: false } };
    Promise.all([loadProducts(), loadSettings()]).then(function (res) {
      var ps = res[0], st = res[1];
      G.font = st.theme.font || 'Cairo';
      G.lang = S.ai.defaultLang || 'dz';
      var imgOn = !!S.ai.images;
      G.useAI = imgOn;
      function prod() { return G.productId ? ps.filter(function (p) { return String(p.id) === String(G.productId); })[0] : null; }
      function priceInfo() { var p = prod(); return p ? { price: (p.offers && p.offers[0] ? p.offers[0].price : p.price), oldPrice: p.old_price, offers: p.offers } : { price: G.price, oldPrice: 0, offers: [{ qty: 1, price: G.price }, { qty: 2, price: G.b2 }, { qty: 3, price: G.b3 }] }; }
      function renderOpts() { var pi = priceInfo(); return { palette: G.palette, font: G.font, lang: G.lang, productImage: G.photo || (prod() && prod().images[0]) || '', price: pi.price, oldPrice: pi.oldPrice, offers: pi.offers, composite: !G.usePhotos && S.ai.imageProvider === 'cloudflare', productCutout: G.cut || '', fx: G.fx }; }
      var rrT = null;
      function rerenderPanels() { clearTimeout(rrT); rrT = setTimeout(function () { var ps = G.panels.filter(function (x) { return x.image; }); if (!ps.length) return; Promise.all(ps.map(function (x) { return panelRender(x, renderOpts()); })).then(function () { render(); }).catch(fail); }, 300); }
      function allPhotos() { var p = prod(); var list = [G.photo].concat(G.photos, p ? p.images : []).filter(Boolean); return list.filter(function (x, i) { return list.indexOf(x) === i; }); }
      // Photo mode (clothes, shoes, bags…): every panel uses one of the seller's photos instead of an AI scene.
      function assignPhotos() {
        var ph = allPhotos(); if (!ph.length) return;
        G.panels.forEach(function (x, i) { x._photoMode = true; x.scene = ph[i % ph.length]; x.scene2 = ph[(i + 1) % ph.length]; });
      }

      function render() {
        var p = prod();
        el.innerHTML = '<div class="ph"><div><h1>AI landing page generator</h1><p>Just upload the product photos — the AI recognises the product and niche, picks the panels that convert for it, writes the Darija copy and creates the images. No keys needed. Result: designed images with Darija text, the COD form after the first image, offers and sticky order button.</p></div><div class="row"><span class="chip ' + (S.ai.text ? 'st-delivered' : 'st-cancelled') + '">Text AI: ' + esc(S.ai.text ? 'built-in, free' : 'ready structure') + '</span><span class="chip ' + (imgOn ? 'st-delivered' : 'st-cancelled') + '">Image AI: ' + esc(imgOn ? (S.ai.refImages ? 'built-in, your product in every scene' : 'built-in, free') : 'off') + '</span><span class="chip st-new" id="gQuota">' + quotaText() + '</span><a class="btn sm" href="#/generate_classic">Classic text page</a></div></div>' +
          '<div class="cols"><div class="card stack">' +
          '<h2>1 · Product</h2><label class="f">Product<select id="gP"><option value="">+ New product</option>' + ps.map(function (x) { return '<option value="' + x.id + '"' + (String(x.id) === String(G.productId) ? ' selected' : '') + '>' + esc(x.name) + '</option>'; }).join('') + '</select></label>' +
          (G.productId ? '' : '<div class="grid g3"><label class="f">Product name<input type="text" id="gN" value="' + esc(G.name) + '" dir="auto"></label><label class="f">Price (DA)<input type="number" id="gPr" value="' + G.price + '"></label><label class="f">2 pieces (DA)<input type="number" id="gB2" value="' + G.b2 + '"></label><label class="f">3 pieces (DA)<input type="number" id="gB3" value="' + G.b3 + '"></label><label class="f">Landed cost (DA)<input type="number" id="gC" value="' + G.cost + '"></label></div>') +
          '<div class="f"><span class="small" style="font-weight:600">Product photo (clear, plain background is best)</span><div class="one-img"><div class="th" style="width:96px;height:96px;flex-basis:96px">' + ((G.photo || (p && p.images[0])) ? '<img src="' + esc(G.photo || p.images[0]) + '" alt="">' : '') + '</div><label class="btn" style="position:relative">' + (G.photo ? 'Change photo' : 'Upload photo') + '<input type="file" accept="image/*" id="gImg" style="position:absolute;inset:0;opacity:0"></label>' + ((G.photo || (p && p.images[0])) ? '<button class="btn" id="gCut" type="button">' + (G.cut ? '✂ Cut-out ready — redo' : '✂ Remove background') + '</button>' : '') + '</div>' +
          '<div class="f"><span class="small" style="font-weight:600">More photos (optional, up to 6 — models wearing it, details, colours)</span><div class="row">' + G.photos.map(function (u, i) { return '<span class="th" style="width:64px;height:64px;position:relative;display:inline-block;border-radius:10px;overflow:hidden"><img src="' + esc(u) + '" alt="" style="width:100%;height:100%;object-fit:cover"><button class="btn sm danger" data-gpx="' + i + '" style="position:absolute;top:2px;inset-inline-end:2px;min-height:0;padding:0 6px">✕</button></span>'; }).join('') + (G.photos.length < 6 ? '<label class="btn sm" style="position:relative">+ Add photos<input type="file" accept="image/*" multiple id="gImgs" style="position:absolute;inset:0;opacity:0"></label>' : '') + '</div></div>' +
          '<label class="f">Notes for the AI (optional — the AI reads your photos: product, niche, buyer)<textarea id="gD" dir="auto" placeholder="Optional: price angle, what makes it special, target…">' + esc(G.desc) + '</textarea></label>' +
          '<div class="grid g3"><label class="f">Text language<select id="gL"><option value="dz">الدارجة الجزائرية</option><option value="ar">العربية الفصحى</option><option value="fr">Français</option></select></label><label class="f inline" style="margin-top:18px"><input type="checkbox" id="gAI"' + (G.useAI ? ' checked' : '') + (imgOn ? '' : ' disabled') + '> Generate AI scenes (people, before/after)</label></div>' +
          '<label class="f inline"><input type="checkbox" id="gUP"' + (G.usePhotos ? ' checked' : '') + '> Use my photos instead of AI scenes (best for clothes, shoes, bags, jewellery)</label>' +
          (imgOn ? '<p class="small muted">About 8–9 AI images per page. Your store can make ' + S.ai.usage.imagesLimit + ' AI images per day. Without AI scenes, panels use your product photo.</p>' : '<div class="notice small">Image AI is not set up on the platform yet. Panels will use your product photo.' + (S.me.is_super ? ' Add the free keys in <a href="#/platform/ai">Platform → AI keys</a>.' : '') + '</div>') +
          '<button class="btn pri" id="gAnalyze" style="min-height:46px"' + (G.busy ? ' disabled' : '') + '>' + (G.plan ? 'Analyze again' : 'Analyze product') + '</button></div>' +
          '<div class="card stack" id="gRight">' + rightHtml() + '</div></div>' +
          (G.plan ? planHtml() : '');
        bind();
      }
      function rightHtml() {
        if (G.panels.some(function (x) { return x.image; })) {
          return '<div class="row" style="justify-content:space-between"><h2 style="margin:0">Preview</h2><span class="small muted">' + G.panels.filter(function (x) { return x.image; }).length + ' / ' + G.panels.length + ' images</span></div>' +
            '<div class="phone-frame" style="height:640px"><div style="height:100%;overflow-y:auto;background:#fff">' + G.panels.map(function (x, i) { return (x.image ? '<img src="' + esc(x.image) + '" alt="" style="width:100%;display:block">' : '<div class="empty small">Panel ' + (i + 1) + ' …</div>') + (i === 0 ? '<div style="margin:10px;border:2px solid ' + (G.palette ? G.palette.primary : '#0F5C46') + ';border-radius:14px;padding:14px;text-align:center" class="ar small"><b>استمارة الطلب هنا</b><br>الاسم · الهاتف · الولاية · البلدية</div>' : ''); }).join('') + '</div></div>' +
            '<div class="row"><button class="btn pri" id="gCreate"' + (G.busy || !G.panels.every(function (x) { return x.image; }) ? ' disabled' : '') + '>Create landing page</button></div>';
        }
        if (G.plan) return '<h2>2 · What the AI understood</h2><div class="line"><span class="muted">Niche</span><b>' + esc(G.plan.niche) + '</b></div><div class="line"><span class="muted">Audience</span><b class="ar" dir="auto">' + esc([G.plan.audience.who, G.plan.audience.gender, G.plan.audience.age].filter(Boolean).join(' · ')) + '</b></div><div class="line"><span class="muted">Pain / desire</span><b dir="auto">' + esc(G.plan.pain_or_desire) + '</b></div><div class="line"><span class="muted">Angle</span><b dir="auto">' + esc(G.plan.angle) + '</b></div>' +
          (G.plan.brief ? (function (b) { var row = function (k, v) { return v && v.length ? '<div class="line"><span class="muted">' + k + '</span><b dir="auto">' + esc(Array.isArray(v) ? v.join(' · ') : v) + '</b></div>' : ''; };
            return '<details class="brief"><summary>Creative brief (stage 1 · photos → ' + esc(G.plan.pipeline || '') + ')</summary>' + row('Product', b.product_type) + row('Features', b.features) + row('Benefits', b.benefits) + row('Buyers', b.avatars) + row('Pains', b.pains) + row('Desires', b.desires) + row('Objections', b.objections) + row('Angles', b.angles) + row('Moments', b.usage_moments) + row('Looks like', b.visual_description) + '</details>'; })(G.plan.brief) : '') +
          (G.warning ? '<div class="notice small">AI text not reachable (' + esc(G.warning) + '). A ready structure was used — edit the texts below.</div>' : '') +
          '<div class="small muted">Edit the texts and image prompts below, then generate.</div><button class="btn pri" id="gMake"' + (G.busy ? ' disabled' : '') + '>Generate ' + G.panels.length + ' images</button>' + (G.log.length ? '<div class="hist">' + G.log.map(esc).join('<br>') + '</div>' : '');
        return '<div class="empty">Upload a photo, write two lines, then Analyze. The AI finds the niche, the audience and the best panel structure for conversion.</div>';
      }
      function planHtml() {
        var pal = G.palette || PALETTES.health;
        return '<div class="card stack" style="margin-top:16px"><div class="row" style="justify-content:space-between"><h2 style="margin:0">3 · Panels (' + G.panels.length + ')</h2><div class="row"><span class="small muted">Colors</span><input type="color" id="gc1" value="' + pal.primary + '"><input type="color" id="gc2" value="' + pal.accent + '"><input type="color" id="gc3" value="' + pal.dark + '"><select id="gPal" style="width:auto"><option value="">Niche preset…</option>' + Object.keys(PALETTES).map(function (k) { return '<option>' + k + '</option>'; }).join('') + '</select></div></div>' +
          G.panels.map(function (x, i) {
            return '<div class="lcard" style="align-items:flex-start"><div class="thumb" style="width:90px;height:110px;flex-basis:90px">' + (x.image ? '<img src="' + esc(x.image) + '" alt="">' : '') + '</div><div class="info stack" style="gap:8px"><div class="row"><b>' + (i + 1) + '. ' + esc(PANEL_LABELS[x.type] || x.type) + '</b>' + (i === 0 ? '<span class="chip st-new">form goes after this</span>' : '') + '</div>' + panelFields(x, i) + '</div><div class="acts" style="flex-direction:column;align-items:stretch;flex:0 0 150px">' +
              '<button class="btn sm" data-rr="' + i + '"' + (G.busy ? ' disabled' : '') + '>Re-draw text</button>' + (imgOn && window.Panels.needsScene(x.type) ? '<button class="btn sm" data-rs="' + i + '"' + (G.busy ? ' disabled' : '') + '>New AI scene</button>' : '') +
              '<button class="btn sm" data-up="' + i + '"' + (i < 2 ? ' disabled' : '') + '>↑</button><button class="btn sm" data-dn="' + i + '"' + (i === 0 || i >= G.panels.length - 1 ? ' disabled' : '') + '>↓</button>' + (i > 0 && i < G.panels.length - 1 ? '<button class="btn sm danger" data-rm="' + i + '">Remove</button>' : '') + '</div></div>';
          }).join('') +
          '<div class="row"><select id="gAddT" style="width:auto">' + ['problem', 'before_after', 'case', 'features', 'how_to', 'trust', 'look', 'details', 'sizes'].map(function (t) { return '<option value="' + t + '">' + PANEL_LABELS[t] + '</option>'; }).join('') + '</select><button class="btn sm" id="gAdd">+ Add panel</button></div></div>';
      }
      function bind() {
        el.querySelector('#gL').value = G.lang;
        el.querySelector('#gP').onchange = function (e) { G.productId = e.target.value; var p = prod(); G.cut = p && p.images[0] && p.cutouts ? (p.cutouts[p.images[0]] || '') : ''; if (p && p.images[0]) { G.photo = p.images[0]; dataUrlFromUrl(G.photo).then(function (d) { G.photoData = d; }); } render(); };
        ['gN', 'gPr', 'gB2', 'gB3', 'gC'].forEach(function (k) { var i = el.querySelector('#' + k); if (i) i.oninput = function () { var map = { gN: 'name', gPr: 'price', gB2: 'b2', gB3: 'b3', gC: 'cost' }; G[map[k]] = k === 'gN' ? i.value : num(i.value); }; });
        el.querySelector('#gD').oninput = function (e) { G.desc = e.target.value; };
        el.querySelector('#gL').onchange = function (e) { G.lang = e.target.value; };
        var ai = el.querySelector('#gAI'); if (ai) ai.onchange = function () { G.useAI = ai.checked; };
        el.querySelector('#gUP').onchange = function (e) { G.usePhotos = e.target.checked; if (G.usePhotos) { G.useAI = false; assignPhotos(); } else G.panels.forEach(function (x) { x._photoMode = false; x.scene = ''; x.scene2 = ''; }); render(); };
        var gi = el.querySelector('#gImgs');
        if (gi) gi.onchange = function (e) { var fs = Array.prototype.slice.call(e.target.files || [], 0, 6 - G.photos.length); if (!fs.length) return; toast('Uploading ' + fs.length + ' photo(s)…'); Promise.all(fs.map(function (f) { return fileToUpload(f, 1400); })).then(function (urls) { G.photos = G.photos.concat(urls).slice(0, 6); if (G.usePhotos) assignPhotos(); toast('Photos added'); render(); }).catch(fail); };
        var gCut = el.querySelector('#gCut'); if (gCut) gCut.onclick = function () { var p = prod(), src = G.photo || (p && p.images[0]); cutoutDialog(src, function (url) { G.cut = url; if (url && p && p.images.indexOf(src) >= 0) { var cm = Object.assign({}, p.cutouts || {}); cm[src] = url; api('PUT', '/products/' + p.id, Object.assign({}, p, { cutouts: cm })).then(function (j) { if (j.product) p.cutouts = j.product.cutouts; }).catch(function () {}); } rerenderPanels(); render(); }, G.cut); };
        el.querySelectorAll('[data-gfx]').forEach(function (b) { b.onchange = function () { G.fx[b.getAttribute('data-gfx')] = b.checked; rerenderPanels(); }; });
        el.querySelectorAll('[data-gpx]').forEach(function (b) { b.onclick = function () { G.photos.splice(+b.getAttribute('data-gpx'), 1); if (G.usePhotos) assignPhotos(); render(); }; });
        el.querySelector('#gImg').onchange = function (e) { var f = e.target.files[0]; if (!f) return; toast('Uploading…'); fileToUpload(f, 1400).then(function (u) { G.photo = u; G.cut = ''; return dataUrlFromUrl(u); }).then(function (d) { G.photoData = d; toast('Photo ready'); render(); }).catch(fail); };
        el.querySelector('#gAnalyze').onclick = analyze;
        var mk = el.querySelector('#gMake'); if (mk) mk.onclick = generateAll;
        var cr = el.querySelector('#gCreate'); if (cr) cr.onclick = create;
        if (!G.plan) return;
        bindPanelFields(el, G.panels);
        var setPal = function () { G.palette = { primary: el.querySelector('#gc1').value, accent: el.querySelector('#gc2').value, dark: el.querySelector('#gc3').value }; };
        ['gc1', 'gc2', 'gc3'].forEach(function (k) { el.querySelector('#' + k).oninput = setPal; });
        el.querySelector('#gPal').onchange = function (e) { if (PALETTES[e.target.value]) { G.palette = Object.assign({}, PALETTES[e.target.value]); render(); } };
        el.querySelectorAll('[data-rr]').forEach(function (b) { b.onclick = function () { var i = +b.getAttribute('data-rr'); G.busy = true; render(); panelRender(G.panels[i], renderOpts()).then(function () { G.busy = false; render(); }).catch(function (e) { G.busy = false; render(); fail(e); }); }; });
        el.querySelectorAll('[data-rs]').forEach(function (b) { b.onclick = function () { var i = +b.getAttribute('data-rs'); G.busy = true; render(); toast('Generating scene…'); panelScenes(G.panels[i], G.photo).then(function (w) { if (w) toast(w, true); return panelRender(G.panels[i], renderOpts()); }).then(function () { G.busy = false; render(); }).catch(function (e) { G.busy = false; render(); fail(e); }); }; });
        el.querySelectorAll('[data-up]').forEach(function (b) { b.onclick = function () { var i = +b.getAttribute('data-up'); var t = G.panels[i]; G.panels[i] = G.panels[i - 1]; G.panels[i - 1] = t; render(); }; });
        el.querySelectorAll('[data-dn]').forEach(function (b) { b.onclick = function () { var i = +b.getAttribute('data-dn'); var t = G.panels[i]; G.panels[i] = G.panels[i + 1]; G.panels[i + 1] = t; render(); }; });
        el.querySelectorAll('[data-rm]').forEach(function (b) { b.onclick = function () { G.panels.splice(+b.getAttribute('data-rm'), 1); render(); }; });
        el.querySelector('#gAdd').onclick = function () { var t = el.querySelector('#gAddT').value; G.panels.splice(G.panels.length - 1, 0, { type: t, title: '', highlight: '', subtitle: '', badge: '', bullets: t === 'sizes' ? ['S', 'M', 'L', 'XL'] : [], before_points: [], after_points: [], steps: [], scene_prompt: G.usePhotos ? '' : G.panels[0] ? G.panels[0].scene_prompt : '' }); if (G.usePhotos) assignPhotos(); render(); };
      }
      function analyze() {
        if (!G.photo && !G.productId) return toast('Upload a product photo first', true);
        G.busy = true; render();
        var p = prod();
        var extra = allPhotos().slice(1, 3);
        Promise.all([G.photoData ? Promise.resolve(G.photoData) : dataUrlFromUrl(G.photo || (p && p.images[0]))].concat(extra.map(function (u) { return dataUrlFromUrl(u, 640); }))).then(function (ds) {
          var d = ds[0]; G.photoData = d;
          return api('POST', '/ai/analyze', { image: d, images: ds.filter(Boolean), description: G.desc, productName: p ? p.name : G.name, price: p ? p.price : G.price, lang: G.lang });
        }).then(function (r) {
          useQuota(r); G.plan = r.plan; G.warning = r.warning || ''; G.panels = r.plan.panels.map(function (x) { return Object.assign({}, x, { image: '', scene: '', scene2: '' }); });
          if (r.plan.use_photos) { G.usePhotos = true; G.useAI = false; assignPhotos(); }
          G.palette = Object.assign({}, r.plan.palette); if (!G.name && r.plan.product_name) G.name = r.plan.product_name; G.log = [];
          G.busy = false; render(); toast('Analysis ready — check the texts, then generate');
        }).catch(function (e) { G.busy = false; render(); fail(e); });
      }
      // Phase 2 "compose" strategy: FLUX paints EMPTY backdrops, the canvas places the real cut-out on them.
      // Max 4 AI images per page (hook bg, features bg, one lifestyle "in use" shot, offer bg) + 2 for a real before/after.
      function ensureCut() {
        if (G.cut || G.usePhotos || !G.useAI) return Promise.resolve(G.cut);
        var p = prod(), src = G.photo || (p && p.images[0]); if (!src) return Promise.resolve('');
        if (p && p.cutouts && p.cutouts[src]) { G.cut = p.cutouts[src]; return Promise.resolve(G.cut); }
        G.log.push('Cutting out the product (free, in your browser)…'); render();
        return needCutout().then(function (C) { return C.remove(src, { feather: 1, onProgress: function (pc) { G.log[G.log.length - 1] = 'Downloading cut-out model, one time only… ' + pc + '%'; render(); } }); })
          .then(function (r) { return blobToData(r.blob).then(function (d) { return api('POST', '/upload', { data: d }); }).then(function (j) { G.cut = j.url; G.log.push('  cut-out ready (' + r.method + ')'); if (p && p.images.indexOf(src) >= 0) { var cm = Object.assign({}, p.cutouts || {}); cm[src] = j.url; api('PUT', '/products/' + p.id, Object.assign({}, p, { cutouts: cm })).then(function (x) { if (x.product) p.cutouts = x.product.cutouts; }).catch(function () {}); } return G.cut; }); })
          .catch(function (e) { G.log.push('  cut-out failed (' + e.message + ') — AI will draw the product instead'); return ''; });
      }
      function scenePlan() {
        var jobs = {}, seen = {}, compose = !!G.cut;
        G.panels.forEach(function (pn, i) {
          var t = pn.type;
          if (t === 'hook' && !seen.hook) { seen.hook = 1; jobs[i] = { mode: compose ? 'bg' : 'ref', aspect: '4:5' }; }
          else if (/^(features|inside|details|look|problem)$/.test(t) && !seen.feat) { seen.feat = 1; jobs[i] = { mode: compose ? 'bg' : 'ref', aspect: '1:1' }; }
          else if (/^(case|how_to)$/.test(t) && !seen.life) { seen.life = 1; jobs[i] = { mode: 'ref', aspect: '1:1', life: true }; }
          else if (t === 'before_after' && !seen.ba) { seen.ba = 1; jobs[i] = { ba: true }; }
          else if (t === 'offer' && !seen.offer) { seen.offer = 1; jobs[i] = { mode: compose ? 'bg' : 'ref', aspect: '4:5', offer: true }; }
        });
        return jobs;
      }
      function oneScene(panel, job, ref) {
        var seed = G.plan && G.plan.style_seed ? ' ' + G.plan.style_seed : '';
        var prompt = job.mode === 'bg' ? (panel.bg_prompt || panel.scene_prompt) + '.' + seed : panel.scene_prompt + seed;
        return api('POST', '/ai/scene', { prompt: prompt, productUrl: G.photo, refUrl: job.mode === 'ref' ? ref : '', aspect: job.aspect, mode: job.mode }).then(function (r) {
          useQuota(r); if (r.url) { panel.scene = r.url; panel.sceneHasProduct = !!r.withProduct; } return r;
        });
      }
      function generateAll() {
        G.busy = true; G.log = []; render();
        var stop = false, hookScene = '', t0 = Date.now(), n0 = S.ai && S.ai.usage ? S.ai.usage.neuronsToday || 0 : 0;
        ensureCut().then(function () { return refFor(G.photo); }).then(function (ref) {
          var jobs = (G.useAI && !G.usePhotos) ? scenePlan() : {}, i = 0;
          G.log.push('AI images planned: ' + Object.keys(jobs).length + (G.cut ? ' (empty backdrops + your real cut-out)' : ' (AI draws the product)')); render();
          function next() {
            if (i >= G.panels.length) {
              var used = S.ai && S.ai.usage ? (S.ai.usage.neuronsToday || 0) - n0 : 0;
              G.log.push('Done in ' + Math.round((Date.now() - t0) / 1000) + ' s · ≈ ' + used + ' Neurons used'); G.busy = false; render(); toast('Landing page images ready'); return;
            }
            var panel = G.panels[i], n = i + 1, job = jobs[i];
            G.log.push('Panel ' + n + ': ' + (PANEL_LABELS[panel.type] || panel.type) + (job ? (job.ba ? ' · before/after scenes' : ' · AI ' + (job.mode === 'bg' ? 'backdrop' : 'lifestyle scene')) : ' · design only') + '…'); render();
            var work = Promise.resolve('');
            if (!job) { if (panel.type !== 'before_after') { panel.scene = ''; panel.sceneHasProduct = false; } }
            else if (stop) { if (job.offer && hookScene) { panel.scene = hookScene; panel.sceneHasProduct = false; } }
            else if (job.ba) work = panelScenes(panel, G.photo);
            else if (job.offer && hookScene && S.ai && S.ai.usage && S.ai.usage.pagesLeft < 3) { panel.scene = hookScene; panel.sceneHasProduct = false; G.log.push('  reusing the hook backdrop (saves free quota)'); }
            else work = oneScene(panel, job, ref).then(function (r) { if (r.budget) stop = true; if (job.mode === 'bg' && panel.type === 'hook' && r.url) hookScene = r.url; return r.warning || ''; });
            work.then(function (w) {
              if (w) G.log.push('  scene: ' + w);
              return panelRender(panel, renderOpts());
            }).then(function () { i++; next(); }).catch(function (e) { G.log.push('  error: ' + e.message); i++; next(); });
          }
          next();
        });
      }
      function create() {
        var plan = G.plan;
        var ensure = G.productId ? Promise.resolve(+G.productId) : api('POST', '/products', {
          name: G.name || plan.product_name || 'New product', price: G.price, cost: G.cost, short_desc: plan.headline, description: G.desc, images: allPhotos().slice(0, 8), live: true, seo_title: plan.seo_title,
          offers: [{ qty: 1, price: G.price }, { qty: 2, price: G.b2 }, { qty: 3, price: G.b3 }].filter(function (o) { return o.price > 0; }), variants: []
        }).then(function (j) { S.products = null; return j.product.id; });
        G.busy = true; render();
        ensure.then(function (pid) {
          var hook = G.panels[0] || {};
          return api('POST', '/landings', { product_id: pid, title: (G.name || plan.product_name) + ' — ' + plan.niche + ' ' + G.lang.toUpperCase(), lang: G.lang, ai: true, live: true,
            content: { layout: 'panels', use_photos: G.usePhotos, panels: G.panels, palette: G.palette, cutouts: G.cut ? [{ src: G.photo || '', cutout: G.cut }] : [], fx: G.fx, plan: { niche: plan.niche, audience: [plan.audience.who, plan.audience.age].filter(Boolean).join(' · '), angle: plan.angle }, headline: hook.title || plan.headline, subheadline: plan.headline, hero_img: hook.image, sections: {} } });
        }).then(function (j) { toast('Landing page created'); location.hash = '#/landings/' + j.landing.id; }).catch(function (e) { G.busy = false; render(); fail(e); });
      }
      render();
    }).catch(fail);
  };

  // ---------- Ads ----------
  PAGES.ads = function (el) {
    function load() {
      Promise.all([api('GET', '/ads?' + qs({ from: RANGE.from, to: RANGE.to })), loadSettings()]).then(function (res) {
        var d = res[0], s = res[1], rb = rangeBar(load);
        var T = { spend: 0, orders: 0, conf: 0, del: 0, profit: 0 };
        d.campaigns.forEach(function (c) { T.spend += c.spendDa; T.orders += c.orders; T.conf += c.confirmed; T.del += c.delivered; T.profit += c.profit; });
        var connected = !!(s.integrations.metaAdsToken && s.integrations.metaAdAccount);
        el.innerHTML = '<div class="ph"><div><h1>Ads &amp; profit</h1><p>Ads Manager numbers + real orders from your store, per campaign.</p></div><div class="row">' + rb.html + '<select id="aDays" style="width:auto" title="How far back to read from Meta"><option value="30">Last 30 days</option><option value="90" selected>Last 90 days</option><option value="180">Last 180 days</option><option value="365">Last 12 months</option></select>' + '<button class="btn pri" id="aSync"' + (connected ? '' : ' disabled title="Connect Meta in Settings → Integrations"') + '>Sync Meta now</button><button class="btn" id="aMan">+ Add spend manually</button></div></div>' +
          (connected ? '' : '<div class="notice" style="margin-bottom:12px">Meta Ads not connected. Add your access token and ad account ID in <a href="#/settings/integrations">Settings → Integrations</a> (free). Until then you can type daily spend manually.</div>') +
          '<div class="cards"><div class="kpi"><span>Ad spend</span><b>' + da(T.spend) + '</b><small>1 USD = ' + d.rate + ' DA</small></div><div class="kpi"><span>Orders from ads</span><b>' + T.orders + '</b><small>' + d.unmatched + ' orders without campaign tag</small></div><div class="kpi"><span>Confirmation</span><b>' + pct(T.orders ? T.conf / T.orders : null) + '</b></div><div class="kpi"><span>Delivered</span><b>' + T.del + '</b></div><div class="kpi"><span>Real cost / delivered</span><b>' + da(T.del ? T.spend / T.del : null) + '</b></div><div class="kpi"><span>Net profit from ads</span><b style="color:' + (T.profit >= 0 ? '#0B5132' : '#9A1C12') + '">' + da(T.profit) + '</b></div></div>' +
          '<div class="card scroll" style="padding:0">' + (d.campaigns.length ? '<table class="tbl"><tr><th>Campaign</th><th>Spend</th><th>CPM</th><th>CTR</th><th>CPC</th><th>Results</th><th>CPL</th><th>Orders</th><th>Confirm</th><th>Deliver</th><th>Delivered</th><th>Cost / deliv.</th><th>Break-even</th><th>Profit</th></tr>' + d.campaigns.map(function (c) {
            return '<tr><td><b>' + esc(c.name || c.id) + '</b><br><span class="verdict v-' + c.verdict + '">' + c.verdict + '</span> <span class="muted small">' + esc(c.id) + '</span></td><td>' + usd(c.spend) + '</td><td>' + usd(c.cpm) + '</td><td>' + (c.ctr * 100).toFixed(2) + '%</td><td>' + usd(c.cpc) + '</td><td>' + c.results + '</td><td>' + usd(c.cpl) + '</td><td>' + c.orders + '</td><td>' + pct(c.cr) + '</td><td>' + pct(c.dr) + '</td><td>' + c.delivered + '</td><td><b>' + da(c.cpd) + '</b></td><td>' + da(c.breakeven) + '</td><td><b style="color:' + (c.profit >= 0 ? '#0B5132' : '#9A1C12') + '">' + da(c.profit) + '</b></td></tr>';
          }).join('') + '</table>' : '<div class="empty">No ad spend in this period. Sync Meta or add spend manually.</div>') + '</div>' +
          '<div class="cols" style="margin-top:16px"><div class="card"><h2>How it is calculated</h2><div class="small stack" style="gap:6px"><span><b>Cost / delivered</b> = spend ÷ delivered orders of that campaign.</span><span><b>Break-even</b> = average (price − product cost − courier − confirmation) per delivered order.</span><span><b>Profit</b> = delivered revenue − product − courier − confirmation − returns − spend.</span><span><b>Verdict</b>: Scale under 70% of break-even, Watch up to 100%, Cut above. Needs 3+ delivered orders.</span><span>Orders are matched by <code>utm_campaign</code> = campaign ID (or name). Use the “Copy ad link” button in Landing pages.</span></div></div></div>';
        rb.bind(el);
        var sy = el.querySelector('#aSync'); if (sy) sy.onclick = function () { sy.disabled = true; sy.textContent = 'Syncing…'; api('POST', '/ads/sync', { days: +((el.querySelector('#aDays') || {}).value || 90) }).then(function (r) { toast(r.rows + ' rows synced. Pick 30 or 90 days above to see older campaigns.'); load(); }).catch(function (e) { fail(e); sy.disabled = false; sy.textContent = 'Sync Meta now'; }); };
        el.querySelector('#aMan').onclick = function () {
          var m = modal('<h2>Add ad spend</h2><div class="stack"><div class="grid g3"><label class="f">Date<input type="date" id="mD" value="' + today(0) + '"></label><label class="f">Platform<select id="mPl"><option value="meta">Meta</option><option value="tiktok">TikTok</option><option value="other">Other</option></select></label></div><label class="f">Campaign ID (the value in utm_campaign)<input type="text" id="mI"></label><label class="f">Campaign name<input type="text" id="mN"></label><div class="grid g3"><label class="f">Spend (USD)<input type="number" step="0.01" id="mS"></label><label class="f">Impressions<input type="number" id="mIm"></label><label class="f">Clicks<input type="number" id="mC"></label><label class="f">Results (purchases/leads)<input type="number" id="mR"></label></div><div class="row"><button class="btn pri" id="mGo">Save</button><button class="btn" data-close>Cancel</button></div></div>');
          m.el.querySelector('#mGo').onclick = function () { api('POST', '/ads/manual', { date: m.el.querySelector('#mD').value, platform: m.el.querySelector('#mPl').value, campaign_id: m.el.querySelector('#mI').value, campaign_name: m.el.querySelector('#mN').value, spend_usd: m.el.querySelector('#mS').value, impressions: m.el.querySelector('#mIm').value, clicks: m.el.querySelector('#mC').value, results: m.el.querySelector('#mR').value }).then(function () { m.close(); toast('Saved'); load(); }).catch(fail); };
        };
      }).catch(fail);
    }
    load();
  };

  // ---------- Simulator ----------
  PAGES.simulator = function (el) {
    Promise.all([loadProducts().catch(function () { return []; }), loadSettings().catch(function () { return null; }), api('GET', '/overview?' + qs({ from: today(29), to: today(0) })).catch(function () { return null; })]).then(function (res) {
      var ps = res[0], s = res[1], ov = res[2];
      var c = s ? s.costs : { courierPerDelivered: 400, confirmPerDelivered: 100, returnFee: 0, usdRate: 255, packaging: 0 };
      var cr = ov && ov.total >= 20 ? Math.round(ov.confirmationRate * 100) : 60, dr = ov && (ov.by.delivered + ov.by.returned) >= 20 ? Math.round(ov.deliveryRate * 100) : 55;
      var presets = ps.map(function (p) {
        var o2 = (p.offers || []).filter(function (o) { return o.qty === 2; })[0], o3 = (p.offers || []).filter(function (o) { return o.qty === 3; })[0];
        return { name: p.name + ' — store data', values: { name: p.name, price: String(p.price), cost: String(p.cost), pack: String(c.packaging || 0), call: '0', courier: String(c.courierPerDelivered + c.confirmPerDelivered), ret: String(c.returnFee || 0), cod: '0', lost: '0', rate: String(c.usdRate), cr: String(cr), dr: String(dr), b2: o2 ? String(o2.price) : '', b3: o3 ? String(o3.price) : '' } };
      });
      window.Sim.mount(el, { presets: presets, toast: toast });
    });
  };

  // ---------- Design ----------
  // Store themes: each one changes the layout of the store pages, not only the colors.
  var PRESETS = [
    { id: 'emerald', layout: 'classic', name: 'Classic Trust', desc: 'Clear and reassuring. Works for every product.', primary: '#0F5C46', accent: '#F2A93B', ink: '#15201B', bg: '#F7F6F2', font: 'Cairo', radius: 16 },
    { id: 'black', layout: 'bold', name: 'Bold Black', desc: 'Big full-screen photo, strong contrast. Gadgets, men, sport.', primary: '#111111', accent: '#F97316', ink: '#111111', bg: '#FFFFFF', font: 'Changa', radius: 6 },
    { id: 'minimal', layout: 'minimal', name: 'Clean Minimal', desc: 'White space, thin lines. Premium, tech, home.', primary: '#1F2937', accent: '#10B981', ink: '#111827', bg: '#FFFFFF', font: 'Readex Pro', radius: 10 },
    { id: 'boutique', layout: 'boutique', name: 'Boutique Mode', desc: 'Editorial photos 3:4, elegant font. Clothes, abayas, shoes.', primary: '#3B2F2F', accent: '#C8A97E', ink: '#2B2222', bg: '#FBF8F4', font: 'El Messiri', radius: 0 },
    { id: 'rose', layout: 'boutique', name: 'Rose Beauty', desc: 'Soft and feminine. Cosmetics, care, jewellery.', primary: '#9F1239', accent: '#F9A8D4', ink: '#2A1520', bg: '#FFF7F8', font: 'Almarai', radius: 18 },
    { id: 'market', layout: 'market', name: 'Souk Market', desc: 'Many products, promos and discount badges.', primary: '#1D4ED8', accent: '#FACC15', ink: '#0F172A', bg: '#F1F5F9', font: 'Cairo', radius: 12 },
    { id: 'fresh', layout: 'fresh', name: 'Fresh Health', desc: 'Rounded and friendly. Health, kids, food.', primary: '#0E7490', accent: '#A3E635', ink: '#0B2530', bg: '#F2FAFB', font: 'Almarai', radius: 22 }
  ];
  function themePreview(p) {
    var hero = { classic: '<div style="margin:8px;background:' + p.primary + ';border-radius:8px;height:46px"></div>', bold: '<div style="background:#111;height:62px;position:relative"><i style="position:absolute;bottom:8px;inset-inline-start:8px;width:50%;height:8px;background:' + p.accent + '"></i></div>', minimal: '<div style="text-align:center;padding:8px"><i style="display:inline-block;width:60%;height:6px;background:' + p.ink + '"></i><div style="margin:6px 8px;height:30px;background:#eee;border-radius:6px"></div></div>', boutique: '<div style="background:' + p.ink + ';height:64px;opacity:.85"></div>', market: '<div style="margin:6px;background:linear-gradient(120deg,' + p.primary + ',#000);height:34px;border-radius:6px"></div><div style="display:flex;gap:4px;margin:0 6px"><i style="flex:1;height:8px;border-radius:9px;background:' + p.accent + '"></i><i style="flex:1;height:8px;border-radius:9px;background:#ddd"></i><i style="flex:1;height:8px;border-radius:9px;background:#ddd"></i></div>', fresh: '<div style="margin:8px;background:' + p.primary + '22;border-radius:16px;height:46px"></div>' }[p.layout];
    var cardH = p.layout === 'boutique' ? 44 : 30, cols = p.layout === 'market' ? 4 : 3;
    var cards = ''; for (var i = 0; i < cols; i++) cards += '<i style="flex:1;height:' + cardH + 'px;background:' + (p.layout === 'minimal' ? '#f3f3f3' : '#fff') + ';border-radius:' + Math.min(p.radius, 8) + 'px;box-shadow:0 1px 3px rgba(0,0,0,.12)"></i>';
    return '<div class="tc-prev" style="background:' + p.bg + '"><div style="height:8px;background:' + (p.layout === 'bold' ? p.accent : p.ink) + '"></div>' + hero + '<div style="display:flex;gap:6px;margin:8px">' + cards + '</div></div>';
  }
  function lum(hex) { var h = String(hex).replace('#', ''); if (h.length !== 6) return 0; var c = [0, 2, 4].map(function (i) { var v = parseInt(h.slice(i, i + 2), 16) / 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; }
  PAGES.design = function (el) {
    Promise.all([loadSettings(true), api('GET', '/landings').catch(function () { return { rows: [] }; })]).then(function (res) {
      var th = Object.assign({}, res[0].theme), lp = res[1].rows.filter(function (l) { return l.live && (!l.content || l.content.layout !== 'panels'); })[0] || res[1].rows[0];
      var mode = 'store', saved = JSON.stringify(th);
      function b64(o) { return btoa(unescape(encodeURIComponent(JSON.stringify(o)))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
      function pvUrl() {
        var base = mode === 'landing' && lp ? storeLink('/l/' + lp.slug) : storeLink('/');
        return base + '?preview=1&th=' + b64({ primary: th.primary, accent: th.accent, ink: th.ink, bg: th.bg, layout: th.layout, font: th.font, radius: th.radius, template: th.template, cols: th.cols });
      }
      var pvT;
      function refresh() { clearTimeout(pvT); pvT = setTimeout(function () { var f = el.querySelector('#dFrame'); if (f) f.src = pvUrl(); }, 250); var d = el.querySelector('#dDirty'); if (d) d.hidden = JSON.stringify(th) === saved; }
      function warnHtml() {
        var contrast = 1.05 / (lum(th.primary) + 0.05);
        return contrast < 4.5 ? '<div class="notice" style="background:#FEF3F2;border-color:#F3C1BC;color:#9A1C12">White text on this main color is hard to read (' + contrast.toFixed(1) + ':1). Choose a darker main color.</div>' : '';
      }
      function render() {
        el.innerHTML = '<div class="ph"><div><h1>Store design</h1><p>Pick a theme, adjust colors and font, see it live, then publish.</p></div><div class="row"><span class="chip st-callback" id="dDirty" hidden>Not published yet</span><button class="btn pri" id="dSave">Publish theme</button></div></div>' +
          '<h2 style="margin:4px 0 10px">Themes</h2><div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(190px,1fr));margin-bottom:18px">' + PRESETS.map(function (p) { return '<button type="button" class="theme-card' + (th.preset === p.id ? ' on' : '') + '" data-pre="' + p.id + '">' + themePreview(p) + '<span class="tc-body"><b>' + p.name + '</b><small>' + p.desc + '</small></span></button>'; }).join('') + '</div>' +
          '<div class="cols"><div class="card stack"><h2>Customize</h2><div class="grid g3">' + [['primary', 'Main color (buttons)'], ['accent', 'Accent (badges, offers)'], ['ink', 'Text color'], ['bg', 'Background']].map(function (c) { return '<label class="f">' + c[1] + '<span class="row"><input type="color" data-col="' + c[0] + '" value="' + th[c[0]] + '"><input type="text" data-hex="' + c[0] + '" value="' + th[c[0]] + '" style="width:100px"></span></label>'; }).join('') + '</div>' +
          '<div id="dWarn">' + warnHtml() + '</div>' +
          '<label class="f">Store layout<select id="dLay">' + [['classic', 'Classic'], ['bold', 'Bold (full-screen photo)'], ['minimal', 'Minimal'], ['boutique', 'Boutique (fashion)'], ['market', 'Market (many products)'], ['fresh', 'Fresh (soft, rounded)']].map(function (o) { return '<option value="' + o[0] + '"' + ((th.layout || 'classic') === o[0] ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select></label>' +
          '<label class="f">Arabic font<select id="dFont">' + ['Cairo', 'Tajawal', 'Almarai', 'IBM Plex Sans Arabic', 'Readex Pro', 'El Messiri', 'Noto Kufi Arabic', 'Changa'].map(function (f) { return '<option' + (th.font === f ? ' selected' : '') + '>' + f + '</option>'; }).join('') + '</select></label>' +
          '<label class="f">Corner roundness: <span id="dRadV">' + th.radius + '</span> px<input type="range" min="0" max="28" step="2" id="dRad" value="' + th.radius + '" style="accent-color:#0F5C46"></label>' +
          '<label class="f">Text landing page layout<select id="dTpl"><option value="story"' + (th.template === 'story' ? ' selected' : '') + '>Story — problem → solution → proof → form</option><option value="bold"' + (th.template === 'bold' ? ' selected' : '') + '>Bold — offers and form right after the photo</option><option value="minimal"' + (th.template === 'minimal' ? ' selected' : '') + '>Minimal — photo, price, form first</option></select></label>' +
          '<label class="f">Products per row (desktop)<select id="dCols">' + [3, 4, 5].map(function (n) { return '<option' + (Number(th.cols) === n ? ' selected' : '') + '>' + n + '</option>'; }).join('') + '</select></label>' +
          oneImage('logo', th.logo, 'Logo (PNG or SVG, transparent)') + '<p class="small muted">AI image landing pages keep the colors chosen in the generator (their text is drawn inside the images). Change them in Landing pages → Edit → Re-draw all.</p></div>' +
          '<div class="card stack"><div class="row" style="justify-content:space-between"><h2 style="margin:0">Live preview</h2><div class="seg"><button type="button" data-pv="store" class="' + (mode === 'store' ? 'on' : '') + '">Store</button>' + (lp ? '<button type="button" data-pv="landing" class="' + (mode === 'landing' ? 'on' : '') + '">Landing</button>' : '') + '</div></div><div class="phone-frame"><iframe id="dFrame" title="Preview" src="' + esc(pvUrl()) + '"></iframe></div><p class="small muted">Changes show here instantly. Customers see them after “Publish theme”.</p></div></div>';
        bind(); refresh();
      }
      function bind() {
        el.querySelectorAll('[data-pre]').forEach(function (b) { b.onclick = function () { var p = PRESETS.filter(function (x) { return x.id === b.getAttribute('data-pre'); })[0]; Object.assign(th, { preset: p.id, layout: p.layout, primary: p.primary, accent: p.accent, ink: p.ink, bg: p.bg, font: p.font, radius: p.radius }); render(); }; });
        var unpick = function () { th.preset = 'custom'; el.querySelectorAll('[data-pre]').forEach(function (x) { x.classList.remove('on'); }); };
        el.querySelectorAll('[data-col]').forEach(function (i) { i.oninput = function () { th[i.getAttribute('data-col')] = i.value; unpick(); el.querySelector('[data-hex=' + i.getAttribute('data-col') + ']').value = i.value; el.querySelector('#dWarn').innerHTML = warnHtml(); refresh(); }; });
        el.querySelectorAll('[data-hex]').forEach(function (i) { i.oninput = function () { if (/^#[0-9a-fA-F]{6}$/.test(i.value)) { th[i.getAttribute('data-hex')] = i.value; unpick(); el.querySelector('[data-col=' + i.getAttribute('data-hex') + ']').value = i.value; el.querySelector('#dWarn').innerHTML = warnHtml(); refresh(); } }; });
        el.querySelector('#dLay').onchange = function (e) { th.layout = e.target.value; refresh(); };
        el.querySelector('#dFont').onchange = function (e) { th.font = e.target.value; refresh(); };
        el.querySelector('#dRad').oninput = function (e) { th.radius = +e.target.value; el.querySelector('#dRadV').textContent = th.radius; refresh(); };
        el.querySelector('#dTpl').onchange = function (e) { th.template = e.target.value; refresh(); };
        el.querySelector('#dCols').onchange = function (e) { th.cols = +e.target.value; refresh(); };
        el.querySelectorAll('[data-one]').forEach(function (i) { i.onchange = function () { if (!i.files[0]) return; fileToUpload(i.files[0], 600).then(function (u) { th.logo = u; render(); }).catch(fail); }; });
        el.querySelectorAll('[data-clear]').forEach(function (b) { b.onclick = function () { th.logo = ''; render(); }; });
        el.querySelectorAll('[data-pv]').forEach(function (b) { b.onclick = function () { mode = b.getAttribute('data-pv'); el.querySelectorAll('[data-pv]').forEach(function (x) { x.classList.toggle('on', x === b); }); refresh(); }; });
        el.querySelector('#dSave').onclick = function () { api('PUT', '/settings/theme', th).then(function (r) { S.settings = r.settings; th = Object.assign({}, r.settings.theme); saved = JSON.stringify(th); toast('Theme published — your store is updated'); refresh(); }).catch(fail); };
      }
      render();
    }).catch(fail);
  };

  // ---------- Settings ----------
  PAGES.settings = function (el, tab) {
    tab = tab || 'store';
    var TABS = [['store', 'Store info'], ['form', 'Order form'], ['delivery', 'Delivery prices'], ['couriers', 'Delivery company'], ['costs', 'Costs'], ['fraud', 'Fake orders'], ['tracking', 'Pixels & tracking'], ['integrations', 'Meta Ads & Sheets'], ['team', 'Team'], ['account', 'Account & backup']];
    loadSettings(true).then(function (s) {
      el.innerHTML = '<div class="ph"><h1>Settings</h1></div><div class="utabs">' + TABS.filter(function (t) { return t[0] !== 'team' || can('team'); }).map(function (t) { return '<button class="' + (tab === t[0] ? 'on' : '') + '" onclick="location.hash=\'#/settings/' + t[0] + '\'">' + t[1] + '</button>'; }).join('') + '</div><div id="sb"></div>';
      var b = el.querySelector('#sb');
      function F(key, path, label, type, extra) { var v = s[key][path]; return '<label class="f">' + esc(label) + (type === 'area' ? '<textarea data-s="' + path + '" dir="auto">' + esc(v) + '</textarea>' : '<input type="' + (type === 'password' ? 'text" class="secret" autocomplete="off" data-lpignore="true" data-1p-ignore="true" data-form-type="other" spellcheck="false' : (type || 'text')) + '" data-s="' + path + '" value="' + esc(v) + '"' + (extra || '') + '>') + '</label>'; }
      function CB(key, path, label) { return '<label class="f inline"><input type="checkbox" data-s="' + path + '"' + (s[key][path] ? ' checked' : '') + '> ' + esc(label) + '</label>'; }
      function saveBtn() { return '<div><button class="btn pri" id="sSave">Save</button></div>'; }
      function bindSave(key, extraCollect) {
        b.querySelector('#sSave').onclick = function () {
          var body = Object.assign({}, s[key]);
          b.querySelectorAll('[data-s]').forEach(function (i) { var k = i.getAttribute('data-s'); body[k] = i.type === 'checkbox' ? i.checked : i.type === 'number' ? num(i.value) : i.value; });
          if (extraCollect) extraCollect(body);
          api('PUT', '/settings/' + key, body).then(function (r) { S.settings = r.settings; s = r.settings; toast('Saved'); }).catch(fail);
        };
      }
      if (tab === 'store') {
        b.innerHTML = '<div class="card stack">' + '<div class="grid">' + F('store', 'name', 'Store name') + F('store', 'tagline', 'Tagline') + F('store', 'phone', 'Phone shown to customers', 'tel') + F('store', 'whatsapp', 'WhatsApp number', 'tel') + F('store', 'facebook', 'Facebook page URL', 'url') + F('store', 'instagram', 'Instagram URL', 'url') + F('store', 'tiktok', 'TikTok URL', 'url') + F('store', 'hours', 'Call hours') + F('store', 'deliveryTime', 'Delivery time text') + '</div>' +
          F('store', 'announcement', 'Top announcement bar') + F('store', 'heroTitle', 'Home page title') + F('store', 'heroSub', 'Home page subtitle') + F('store', 'returnPolicy', 'Return / exchange policy (one line)', 'area') +
          oneImage('heroImage', s.store.heroImage, 'Home banner image') + saveBtn() + '</div>';
        b.querySelectorAll('[data-one]').forEach(function (i) { i.onchange = function () { fileToUpload(i.files[0]).then(function (u) { s.store.heroImage = u; api('PUT', '/settings/store', s.store).then(function (r) { S.settings = r.settings; route(); }); }).catch(fail); }; });
        b.querySelectorAll('[data-clear]').forEach(function (x) { x.onclick = function () { s.store.heroImage = ''; api('PUT', '/settings/store', s.store).then(function () { route(); }); }; });
        bindSave('store');
      }
      if (tab === 'delivery') {
        api('GET', '/geo').then(function (g) {
          S.geo = g;
          var d = s.delivery, fees = d.fees || {};
          var rows = g.wilayas.filter(function (w) { return Number(d.wilayaMode) === 69 || Number(w.code) <= 58; });
          b.innerHTML = '<div class="card stack"><div class="grid g3"><label class="f">Wilaya list<select data-s="wilayaMode"><option value="58"' + (Number(d.wilayaMode) === 58 ? ' selected' : '') + '>58 wilayas (courier codes)</option><option value="69"' + (Number(d.wilayaMode) === 69 ? ' selected' : '') + '>69 wilayas (2026 reform)</option></select></label>' + F('delivery', 'defaultDesk', 'Default stop-desk fee (DA)', 'number') + F('delivery', 'defaultHome', 'Default home fee (DA)', 'number') + F('delivery', 'courier', 'Courier company name') + '</div>' +
            '<div class="row">' + CB('delivery', 'deskEnabled', 'Offer stop-desk delivery') + CB('delivery', 'homeEnabled', 'Offer home delivery') + '</div>' +
            '<p class="small muted">Fees are what the customer pays on top of the price. The 69-wilaya list adds 11 new wilayas — check your courier supports them before switching.</p>' +
            '<div class="row"><span>Communes list: <b>' + g.communes + '</b> communes loaded</span>' + (S.me.is_super ? '<button class="btn sm" id="dlCom">' + (g.communes ? 'Refresh' : 'Download now') + '</button>' : '') + '</div>' +
            '<div class="scroll"><table class="tbl"><tr><th>Wilaya</th><th>Desk (DA)</th><th>Home (DA)</th><th>Deliver here</th></tr>' + rows.map(function (w) { var f = fees[w.code] || {}; return '<tr><td>' + w.code + ' ' + esc(w.fr) + ' · <span class="ar">' + esc(w.ar) + '</span></td><td><input type="number" data-fee="' + w.code + '" data-k="desk" value="' + (f.desk != null ? f.desk : '') + '" placeholder="' + d.defaultDesk + '" style="width:100px"></td><td><input type="number" data-fee="' + w.code + '" data-k="home" value="' + (f.home != null ? f.home : '') + '" placeholder="' + d.defaultHome + '" style="width:100px"></td><td><input type="checkbox" data-fee="' + w.code + '" data-k="active"' + (f.active === false ? '' : ' checked') + '></td></tr>'; }).join('') + '</table></div>' + saveBtn() + '</div>';
          if (b.querySelector('#dlCom')) b.querySelector('#dlCom').onclick = function () { toast('Downloading communes…'); api('POST', '/geo/communes').then(function (r) { toast(r.communes + ' communes loaded'); route(); }).catch(fail); };
          bindSave('delivery', function (body) {
            var nf = {};
            b.querySelectorAll('[data-fee]').forEach(function (i) { var c = i.getAttribute('data-fee'), k = i.getAttribute('data-k'); nf[c] = nf[c] || {}; if (k === 'active') { if (!i.checked) nf[c].active = false; } else if (i.value !== '') nf[c][k] = num(i.value); });
            Object.keys(nf).forEach(function (c) { if (!Object.keys(nf[c]).length) delete nf[c]; });
            body.fees = nf; body.wilayaMode = num(body.wilayaMode);
          });
        }).catch(fail);
      }
      if (tab === 'costs') {
        b.innerHTML = '<div class="card stack"><p class="muted">Used for profit on Overview, Products and Ads.</p><div class="grid g3">' + F('costs', 'courierPerDelivered', 'Courier cost you pay per delivered order (DA)', 'number') + F('costs', 'confirmPerDelivered', 'Confirmation cost per delivered order (DA)', 'number') + F('costs', 'returnFee', 'Return fee per returned parcel (DA)', 'number') + F('costs', 'packaging', 'Packaging per parcel (DA)', 'number') + F('costs', 'usdRate', '1 USD = DA (ad spend)', 'number') + '</div>' + saveBtn() + '</div>';
        bindSave('costs');
      }
      if (tab === 'fraud') {
        b.innerHTML = '<div class="card stack"><h2>Phone protection</h2><div class="grid g3">' + F('fraud', 'mergeHours', 'Merge repeat orders from same phone within (hours)', 'number') + F('fraud', 'maxPerDay', 'Flag after this many orders per phone per day', 'number') + F('fraud', 'autoBlacklistReturns', 'Auto-blacklist after N refused deliveries (0 = off)', 'number') + F('fraud', 'flagScore', 'Flag customers with delivery score under (%)', 'number') + '</div>' +
          '<h2 style="margin-top:8px">IP protection (fake-order attacks)</h2><div class="grid g3">' + F('fraud', 'maxPerIpDay', 'Max orders from one IP in 24 h (0 = off)', 'number') + '</div><div class="row">' + CB('fraud', 'autoBlockIp', 'Block the IP automatically when it goes over the limit') + CB('fraud', 'blockIpv6Range', 'For IPv6 (4G) block the whole /64 network') + '</div>' +
          '<p class="small muted">Attackers change phone numbers, not their connection. A blocked IP still sees a thank-you message, but nothing is saved. Manage the list in Customers → Blocked IPs, or block from an order. Bots are also stopped by an invisible field and 8 orders / 10 min per connection.</p>' + saveBtn() + '</div>';
        bindSave('fraud');
      }
      if (tab === 'tracking') {
        var tr = s.tracking;
        tr.meta = tr.meta || []; tr.tiktok = tr.tiktok || []; tr.events = Object.assign({ PageView: true, ViewContent: true, InitiateCheckout: true, AddPaymentInfo: false, Lead: false }, tr.events || {});
        if (tr.metaPixel && !tr.meta.some(function (x) { return x.id === tr.metaPixel; })) tr.meta.unshift({ id: tr.metaPixel, token: tr.metaCapiToken || '', test: tr.metaTestCode || '', on: true, name: 'Main pixel' });
        if (tr.tiktokPixel && !tr.tiktok.some(function (x) { return x.id === tr.tiktokPixel; })) tr.tiktok.unshift({ id: tr.tiktokPixel, token: '', on: true, name: 'Main pixel' });
        var pxRow = function (list, i, kind) {
          var x = list[i];
          return '<div class="pxrow"><label class="sw-t"><input type="checkbox" data-pon="' + kind + ':' + i + '"' + (x.on !== false ? ' checked' : '') + '><span></span></label>' +
            '<input type="text" data-pf="' + kind + ':' + i + ':name" value="' + esc(x.name || '') + '" placeholder="Name (e.g. Store pixel)">' +
            '<input type="text" data-pf="' + kind + ':' + i + ':id" value="' + esc(x.id || '') + '" placeholder="Pixel ID" dir="ltr">' +
            '<input type="text" class="secret" autocomplete="off" data-lpignore="true" data-1p-ignore="true" data-pf="' + kind + ':' + i + ':token" value="' + esc(x.token || '') + '" placeholder="' + (kind === 'meta' ? 'Conversions API token (optional)' : 'Events API access token (optional)') + '" dir="ltr">' +
            '<input type="text" data-pf="' + kind + ':' + i + ':test" value="' + esc(x.test || '') + '" placeholder="Test code" dir="ltr" style="max-width:120px">' +
            '<button class="btn sm danger" data-prm="' + kind + ':' + i + '" title="Remove">✕</button></div>';
        };
        var renderPx = function () {
          b.innerHTML = '<div class="cols"><div class="stack">' +
            '<div class="card stack"><div class="row" style="justify-content:space-between"><h2 style="margin:0"><span class="pxlogo meta">f</span> Meta pixels</h2><button class="btn sm" data-padd="meta">+ Add pixel</button></div>' +
              (tr.meta.length ? tr.meta.map(function (x, i) { return pxRow(tr.meta, i, 'meta'); }).join('') : '<p class="muted small">No Meta pixel yet. Events Manager → Data sources → your pixel → copy the ID.</p>') +
              '<p class="small muted">Add the Conversions API token (Events Manager → Settings → Generate access token) so orders are also sent from the server: better tracking on iPhone and with ad blockers. Browser and server events are de-duplicated.</p></div>' +
            '<div class="card stack"><div class="row" style="justify-content:space-between"><h2 style="margin:0"><span class="pxlogo tt">♪</span> TikTok pixels</h2><button class="btn sm" data-padd="tiktok">+ Add pixel</button></div>' +
              (tr.tiktok.length ? tr.tiktok.map(function (x, i) { return pxRow(tr.tiktok, i, 'tiktok'); }).join('') : '<p class="muted small">No TikTok pixel yet.</p>') + '</div>' +
            '<div class="card stack"><h2 style="margin:0">Other platforms</h2><div class="grid">' + F('tracking', 'snapPixel', 'Snapchat Pixel ID') + F('tracking', 'googleTag', 'Google tag ID (G-… or AW-…)') + '</div></div>' +
          '</div><div class="stack">' +
            '<div class="card stack"><h2 style="margin:0">When is a sale reported?</h2>' +
              [['placed', 'When the order is placed', 'Fast learning, but counts fake and refused orders.'], ['confirmed', 'When you confirm the order by phone', 'Recommended for COD: the browser sends “Lead”, the server sends “Purchase” only for confirmed orders.'], ['delivered', 'When the order is delivered', 'Most accurate (real cash). Needs the Conversions API token and status updates.']].map(function (o) {
                return '<label class="opt-card' + (tr.purchaseOn === o[0] ? ' on' : '') + '"><input type="radio" name="pOn" value="' + o[0] + '"' + (tr.purchaseOn === o[0] ? ' checked' : '') + '><b>' + o[1] + '</b><small>' + o[2] + '</small></label>';
              }).join('') +
              '<label class="f">Event name when placed<select id="pEv"><option' + (tr.purchaseEvent === 'Purchase' ? ' selected' : '') + '>Purchase</option><option' + (tr.purchaseEvent === 'Lead' ? ' selected' : '') + '>Lead</option></select></label></div>' +
            '<div class="card stack"><h2 style="margin:0">Browser events</h2>' + ['PageView', 'ViewContent', 'InitiateCheckout'].map(function (e) { return '<label class="f inline"><input type="checkbox" data-ev="' + e + '"' + (tr.events[e] !== false ? ' checked' : '') + '> ' + e + '</label>'; }).join('') +
              '<p class="small muted">ViewContent = page opened, InitiateCheckout = customer starts the form, then Purchase/Lead on order.</p></div>' +
            '<div class="card stack"><h2 style="margin:0">Check it works</h2><p class="small muted">Save first. Then send a test “Purchase” from the server to every pixel that has a token (use the test code from Events Manager → Test events).</p><div><button class="btn" id="pTest">Send test event</button></div><div id="pOut"></div></div>' +
            '<div><button class="btn pri" id="pSave">Save pixels</button></div>' +
          '</div></div>';
          b.querySelectorAll('[data-padd]').forEach(function (x) { x.onclick = function () { collect(); tr[x.getAttribute('data-padd')].push({ id: '', token: '', test: '', on: true, name: '' }); renderPx(); }; });
          b.querySelectorAll('[data-prm]').forEach(function (x) { x.onclick = function () { collect(); var k = x.getAttribute('data-prm').split(':'); tr[k[0]].splice(+k[1], 1); renderPx(); }; });
          b.querySelectorAll('[name=pOn]').forEach(function (r) { r.onchange = function () { collect(); tr.purchaseOn = r.value; renderPx(); }; });
          b.querySelector('#pSave').onclick = function () { collect(); var body = Object.assign({}, tr, { metaPixel: '', metaCapiToken: '', metaTestCode: '', tiktokPixel: '' }); api('PUT', '/settings/tracking', body).then(function (r) { S.settings = r.settings; s = r.settings; tr = s.tracking; toast('Pixels saved'); renderPx(); }).catch(fail); };
          b.querySelector('#pTest').onclick = function () { api('POST', '/tracking/test').then(function (r) { b.querySelector('#pOut').innerHTML = r.results.length ? r.results.map(function (x) { return '<div class="notice small">' + (x.ok ? '✓ ' : '✗ ') + esc(x.platform + ' ' + x.id + ': ' + x.detail) + '</div>'; }).join('') : '<div class="notice small">No pixel with a server token yet.</div>'; }).catch(fail); };
        };
        var collect = function () {
          b.querySelectorAll('[data-pf]').forEach(function (i) { var k = i.getAttribute('data-pf').split(':'); tr[k[0]][+k[1]][k[2]] = i.value.trim(); });
          b.querySelectorAll('[data-pon]').forEach(function (i) { var k = i.getAttribute('data-pon').split(':'); tr[k[0]][+k[1]].on = i.checked; });
          b.querySelectorAll('[data-ev]').forEach(function (i) { tr.events[i.getAttribute('data-ev')] = i.checked; });
          var pe = b.querySelector('#pEv'); if (pe) tr.purchaseEvent = pe.value;
          b.querySelectorAll('[data-s]').forEach(function (i) { tr[i.getAttribute('data-s')] = i.value.trim(); });
        };
        renderPx();
      }
      if (tab === 'form') {
        var fc = JSON.parse(JSON.stringify(s.form));
        var NAMES = { name: 'Full name', phone: 'Phone', phone2: 'Second phone', wilaya: 'Wilaya', commune: 'Commune', address: 'Address', note: 'Note' };
        var CORE = ['name', 'phone', 'wilaya', 'commune'];
        var renderF = function () {
          b.innerHTML = '<div class="cols"><div class="card stack"><h2 style="margin:0">Fields</h2><p class="small muted">Name, phone, wilaya and commune are always required (the delivery company needs them). Turn other fields on, make them required, rename them, change the order, or add your own.</p>' +
            fc.fields.map(function (f, i) {
              var core = CORE.indexOf(f.key) >= 0, custom = f.key.indexOf('c_') === 0;
              return '<div class="ffield' + (f.on ? '' : ' off') + '"><div class="row" style="gap:6px;flex-wrap:nowrap"><button class="btn sm" data-fu="' + i + '"' + (i ? '' : ' disabled') + '>↑</button><button class="btn sm" data-fd="' + i + '"' + (i < fc.fields.length - 1 ? '' : ' disabled') + '>↓</button><b style="flex:1">' + esc(custom ? (f.label || 'Custom field') : NAMES[f.key]) + (core ? ' <span class="chip st-new">required</span>' : '') + '</b>' +
                (core ? '' : '<label class="f inline"><input type="checkbox" data-fon="' + i + '"' + (f.on ? ' checked' : '') + '> Show</label><label class="f inline"><input type="checkbox" data-freq="' + i + '"' + (f.req ? ' checked' : '') + '> Required</label>') + (custom ? '<button class="btn sm danger" data-fdel="' + i + '">✕</button>' : '') + '</div>' +
                '<div class="grid g3"><label class="f">Label (empty = default)<input type="text" data-fl="' + i + '" value="' + esc(f.label || '') + '" dir="auto"></label>' + (f.key === 'wilaya' || f.key === 'commune' ? '' : '<label class="f">Placeholder<input type="text" data-fp="' + i + '" value="' + esc(f.ph || '') + '" dir="auto"></label>') +
                (custom ? '<label class="f">Type<select data-ft="' + i + '">' + [['text', 'Text'], ['textarea', 'Long text'], ['number', 'Number'], ['select', 'Choice list']].map(function (t) { return '<option value="' + t[0] + '"' + (f.type === t[0] ? ' selected' : '') + '>' + t[1] + '</option>'; }).join('') + '</select></label>' + (f.type === 'select' ? '<label class="f">Choices (comma separated)<input type="text" data-fo="' + i + '" value="' + esc((f.options || []).join(', ')) + '" dir="auto"></label>' : '') : '') + '</div></div>';
            }).join('') + '<div><button class="btn" id="fAdd">+ Add custom field</button></div></div>' +
            '<div class="card stack"><h2 style="margin:0">Texts & blocks</h2><label class="f">Form title (empty = default)<input type="text" id="fT" value="' + esc(fc.title) + '" dir="auto"></label><label class="f">Sub-title<input type="text" id="fS" value="' + esc(fc.subtitle) + '" dir="auto"></label><label class="f">Button text<input type="text" id="fB" value="' + esc(fc.button) + '" dir="auto" placeholder="تأكيد الطلب"></label>' +
              '<label class="f inline"><input type="checkbox" id="fO"' + (fc.showOffers !== false ? ' checked' : '') + '> Show quantity offers (1 / 2 / 3 pieces)</label><label class="f inline"><input type="checkbox" id="fSum"' + (fc.showSummary !== false ? ' checked' : '') + '> Show order summary (product, delivery, total)</label><label class="f inline"><input type="checkbox" id="fTr"' + (fc.showTrust !== false ? ' checked' : '') + '> Show trust line under the button</label>' +
              '<div><button class="btn pri" id="fSave">Save form</button></div><p class="small muted">The phone field accepts digits only (10 max) and converts Arabic digits automatically.</p></div></div>';
          var upd = function () {
            b.querySelectorAll('[data-fl]').forEach(function (x) { fc.fields[+x.getAttribute('data-fl')].label = x.value; });
            b.querySelectorAll('[data-fp]').forEach(function (x) { fc.fields[+x.getAttribute('data-fp')].ph = x.value; });
            b.querySelectorAll('[data-fon]').forEach(function (x) { fc.fields[+x.getAttribute('data-fon')].on = x.checked; });
            b.querySelectorAll('[data-freq]').forEach(function (x) { fc.fields[+x.getAttribute('data-freq')].req = x.checked; });
            b.querySelectorAll('[data-ft]').forEach(function (x) { fc.fields[+x.getAttribute('data-ft')].type = x.value; });
            b.querySelectorAll('[data-fo]').forEach(function (x) { fc.fields[+x.getAttribute('data-fo')].options = x.value.split(',').map(function (v) { return v.trim(); }).filter(Boolean); });
            fc.title = b.querySelector('#fT').value; fc.subtitle = b.querySelector('#fS').value; fc.button = b.querySelector('#fB').value;
            fc.showOffers = b.querySelector('#fO').checked; fc.showSummary = b.querySelector('#fSum').checked; fc.showTrust = b.querySelector('#fTr').checked;
          };
          var mv = function (i, d) { upd(); var x = fc.fields.splice(i, 1)[0]; fc.fields.splice(i + d, 0, x); renderF(); };
          b.querySelectorAll('[data-fu]').forEach(function (x) { x.onclick = function () { mv(+x.getAttribute('data-fu'), -1); }; });
          b.querySelectorAll('[data-fd]').forEach(function (x) { x.onclick = function () { mv(+x.getAttribute('data-fd'), 1); }; });
          b.querySelectorAll('[data-fdel]').forEach(function (x) { x.onclick = function () { upd(); fc.fields.splice(+x.getAttribute('data-fdel'), 1); renderF(); }; });
          b.querySelectorAll('[data-ft],[data-fon]').forEach(function (x) { x.onchange = function () { upd(); renderF(); }; });
          b.querySelector('#fAdd').onclick = function () { upd(); fc.fields.push({ key: 'c_' + Math.random().toString(36).slice(2, 8), on: true, req: false, label: '', ph: '', type: 'text', options: [] }); renderF(); };
          b.querySelector('#fSave').onclick = function () { upd(); api('PUT', '/settings/form', fc).then(function (r) { S.settings = r.settings; fc = JSON.parse(JSON.stringify(r.settings.form)); toast('Order form saved'); renderF(); }).catch(fail); };
        };
        renderF();
      }
      if (tab === 'couriers') {
        api('GET', '/couriers').then(function (cj) {
          var c = s.couriers;
          var prov = cj.providers.filter(function (p) { return p.id === c.provider; })[0] || cj.providers[0];
          var LBL = { apiId: 'API ID', apiToken: 'API token', apiKey: 'API key', userGuid: 'User GUID', host: 'Your EcoTrack address (e.g. https://dhd.ecotrack.dz)' };
          b.innerHTML = '<div class="cols"><div class="card stack"><h2 style="margin:0">Delivery company</h2><label class="f">Company<select data-s="provider" id="cvP">' + cj.providers.map(function (p) { return '<option value="' + p.id + '"' + (p.id === c.provider ? ' selected' : '') + '>' + esc(p.name) + '</option>'; }).join('') + '</select></label>' +
            '<div class="grid">' + prov.fields.map(function (f) { return F('couriers', f, LBL[f], f === 'apiToken' || f === 'apiKey' ? 'password' : 'text', ' dir="ltr"'); }).join('') + '</div>' +
            (c.provider !== 'none' ? '<div class="grid g3"><label class="f">Ship from wilaya<select data-s="fromWilaya">' + wilayaOptions(c.fromWilaya || '16', true) + '</select></label>' + F('couriers', 'weight', 'Default weight (kg)', 'number') + '</div>' + CB('couriers', 'autoPush', 'Send the order automatically when I set it to Confirmed') : '') +
            '<div class="row"><button class="btn pri" id="sSave">Save</button>' + (c.provider !== 'none' ? '<button class="btn" id="cvTest">Test connection</button>' : '') + '</div><div id="cvOut"></div></div>' +
            '<div class="card stack"><h2 style="margin:0">How it works</h2><ol class="small"><li>Ask your delivery company for your API keys (in their merchant dashboard or from your account manager).</li><li>Choose the company, paste the keys, Save, then Test connection.</li><li>In Orders, open an order → <b>Send to delivery company</b>, or select many orders → <b>Send to delivery company</b>. The tracking number comes back automatically.</li><li>Press <b>Sync courier status</b> in Orders to update Shipped / Delivered / Returned from the company.</li></ol><p class="small muted">Keys are saved only for your store and are never shown again in full. Companies without an API: use “Export confirmed for courier” (CSV).</p></div></div>';
          b.querySelector('#cvP').onchange = function (e) { s.couriers.provider = e.target.value; api('PUT', '/settings/couriers', { provider: e.target.value }).then(function (r) { S.settings = r.settings; s = r.settings; route(); }).catch(fail); };
          bindSave('couriers');
          var t = b.querySelector('#cvTest');
          if (t) t.onclick = function () { b.querySelector('#cvOut').innerHTML = '<div class="small muted">Testing…</div>'; api('POST', '/couriers/test').then(function (r) { b.querySelector('#cvOut').innerHTML = '<div class="notice small">✓ ' + esc(r.message) + '</div>'; }).catch(function (e) { b.querySelector('#cvOut').innerHTML = '<div class="notice small" style="background:#FEF3F2;border-color:#F3C1BC;color:#9A1C12">✗ ' + esc(e.message) + '</div>'; }); };
        }).catch(fail);
      }
      if (tab === 'integrations') {
        var script = "function doPost(e){var d=JSON.parse(e.postData.contents),o=d.order,ss=SpreadsheetApp.getActiveSpreadsheet(),sh=ss.getSheetByName('Orders')||ss.insertSheet('Orders');\nvar k=['id','created_at','status','name','phone','wilaya','commune','address','delivery','product','variant','quantity','total','upsell','note','tracking','campaign'];\nif(sh.getLastRow()===0)sh.appendRow(k);var row=k.map(function(x){return o[x]});\nvar ids=sh.getRange(1,1,sh.getLastRow(),1).getValues().map(function(r){return String(r[0])}),i=ids.indexOf(String(o.id));\nif(i>0)sh.getRange(i+1,1,1,k.length).setValues([row]);else sh.appendRow(row);\nreturn ContentService.createTextOutput('ok');}";
        b.innerHTML = '<div class="card stack"><h2>Meta Ads (campaign KPIs)</h2><div class="grid">' + F('integrations', 'metaAdAccount', 'Ad account ID (act_… or numbers)') + F('integrations', 'metaAdsToken', 'Access token with ads_read', 'password', ' autocomplete="off"') + F('integrations', 'graphVersion', 'Graph API version') + '</div><p class="small muted">Free. Create a System User token in Meta Business Settings → Users → System users → Generate token (permission ads_read). Then Ads &amp; profit → Sync.</p>' +
          '<h2 style="margin-top:8px">Google Sheets (copy of every order, free)</h2>' + F('integrations', 'sheetsUrl', 'Apps Script web app URL (https://script.google.com/…)', 'url') + '<details><summary class="small" style="cursor:pointer">How to set it up (2 minutes)</summary><ol class="small"><li>Create a Google Sheet → Extensions → Apps Script.</li><li>Paste this code, Save.</li><li>Deploy → New deployment → Web app → Execute as: Me, Who has access: Anyone → Deploy → copy the URL here.</li></ol><pre>' + esc(script) + '</pre></details>' + saveBtn() + '</div>';
        bindSave('integrations');
      }
      if (tab === 'team') {
        api('GET', '/users').then(function (u) {
          b.innerHTML = '<div class="card stack"><h2>Team</h2><table class="tbl"><tr><th>Name</th><th>Email</th><th>Role</th><th>Active</th><th></th></tr>' + u.rows.map(function (x) { return '<tr><td>' + esc(x.name) + '</td><td>' + esc(x.email) + '</td><td><select data-role="' + x.id + '">' + u.roles.map(function (r) { return '<option' + (x.role === r ? ' selected' : '') + '>' + r + '</option>'; }).join('') + '</select></td><td><input type="checkbox" data-act="' + x.id + '"' + (x.active ? ' checked' : '') + '></td><td class="row"><button class="btn sm" data-pw="' + x.id + '">Set password</button>' + (x.id !== S.me.id ? '<button class="btn sm danger" data-rmu="' + x.id + '">Remove</button>' : '') + '</td></tr>'; }).join('') + '</table>' +
            '<div class="small muted">owner: everything · agent: orders + customers · stock: orders + products · ads: products, landing pages, ads, design</div>' +
            '<h2 style="margin-top:8px">Add member</h2><div class="grid g3"><label class="f">Name<input type="text" id="nN"></label><label class="f">Email (login)<input type="email" id="nE"></label><label class="f">Password (8+)<input type="text" id="nP"></label><label class="f">Role<select id="nR">' + u.roles.map(function (r) { return '<option' + (r === 'agent' ? ' selected' : '') + '>' + r + '</option>'; }).join('') + '</select></label></div><div><button class="btn pri" id="nAdd">Add member</button></div></div>';
          b.querySelector('#nAdd').onclick = function () { api('POST', '/users', { name: b.querySelector('#nN').value, email: b.querySelector('#nE').value, password: b.querySelector('#nP').value, role: b.querySelector('#nR').value }).then(function () { toast('Member added — share the email and password with them'); route(); }).catch(fail); };
          b.querySelectorAll('[data-role]').forEach(function (s2) { s2.onchange = function () { api('PATCH', '/users/' + s2.getAttribute('data-role'), { role: s2.value }).then(function () { toast('Role updated'); }).catch(fail); }; });
          b.querySelectorAll('[data-act]').forEach(function (c) { c.onchange = function () { api('PATCH', '/users/' + c.getAttribute('data-act'), { active: c.checked }).then(function () { toast('Updated'); }).catch(fail); }; });
          b.querySelectorAll('[data-pw]').forEach(function (x) { x.onclick = function () { var p = prompt('New password (8+ characters)'); if (p) api('PATCH', '/users/' + x.getAttribute('data-pw'), { password: p }).then(function () { toast('Password changed'); }).catch(fail); }; });
          b.querySelectorAll('[data-rmu]').forEach(function (x) { x.onclick = function () { if (confirm('Remove this member?')) api('DELETE', '/users/' + x.getAttribute('data-rmu')).then(function () { route(); }).catch(fail); }; });
        }).catch(fail);
      }
      if (tab === 'account') {
        b.innerHTML = '<div class="cols"><div class="card stack"><h2>Change my password</h2><label class="f">Current password<input type="password" id="pc" autocomplete="current-password"></label><label class="f">New password (8+)<input type="password" id="pn" autocomplete="new-password"></label><div><button class="btn pri" id="pGo">Change password</button></div></div>' +
          '<div class="card stack"><h2>Your store data</h2><p class="muted">Download all your products, landing pages, orders and customers (JSON file). The platform also keeps a daily backup of everything.</p><div class="row"><a class="btn" href="/api/admin/backup">Download my store data</a>' + (S.me.is_super ? '<a class="btn" href="/api/admin/backup?full=1">Full platform database</a>' : '') + '</div></div></div>';
        b.querySelector('#pGo').onclick = function () { api('POST', '/password', { current: b.querySelector('#pc').value, next: b.querySelector('#pn').value }).then(function () { toast('Password changed'); }).catch(fail); };
      }
    }).catch(fail);
  };

  // ---------- Platform (super admin) ----------
  PAGES.platform = function (el, tab) {
    tab = tab || 'stores';
    var TABS = [['stores', 'Stores'], ['settings', 'Platform settings'], ['ai', 'AI keys (free)']];
    el.innerHTML = '<div class="ph"><div><h1>Platform</h1><p>Your stores, sign-up rules and the shared AI keys.</p></div></div><div class="utabs">' + TABS.map(function (t) { return '<button class="' + (tab === t[0] ? 'on' : '') + '" onclick="location.hash=\'#/platform/' + t[0] + '\'">' + t[1] + '</button>'; }).join('') + '</div><div id="pb"><div class="empty">Loading…</div></div>';
    var b = el.querySelector('#pb');
    if (tab === 'stores') {
      api('GET', '/super/stores').then(function (j) {
        var P = j.platform;
        b.innerHTML = '<div class="cards"><div class="kpi"><span>Stores</span><b>' + j.rows.length + ' / ' + P.maxStores + '</b></div><div class="kpi"><span>Active</span><b>' + j.rows.filter(function (r) { return r.status === 'active'; }).length + '</b></div><div class="kpi"><span>Orders (7 days)</span><b>' + j.rows.reduce(function (a, r) { return a + r.orders7; }, 0) + '</b></div><div class="kpi"><span>AI images today</span><b>' + j.aiToday + '</b><small>Cloudflare free ≈ 90/day</small></div></div>' +
          '<div class="card"><div class="scroll"><table class="tbl"><tr><th>Store</th><th>Owner</th><th>Products</th><th>Pages</th><th>Orders</th><th>AI images / day</th><th>Status</th><th></th></tr>' + j.rows.map(function (r) {
            return '<tr><td><b>' + esc(r.name) + '</b><br><a class="small" href="' + esc(r.url) + '" target="_blank" rel="noopener">' + esc(r.url) + '</a></td><td>' + esc(r.owner_name || '') + '<br><span class="small muted">' + esc(r.owner_email || '') + '</span></td><td>' + r.products + '</td><td>' + r.landings + '</td><td>' + r.orders + '<br><span class="small muted">' + r.orders7 + ' in 7 d</span></td>' +
              '<td><input type="number" min="0" max="2000" value="' + r.ai_daily_images + '" data-ai="' + r.id + '" style="width:80px"><br><span class="small muted">used today ' + (r.ai_today || 0) + '</span></td>' +
              '<td><select data-st="' + r.id + '"' + (r.id === S.me.store_id ? ' disabled' : '') + '><option value="active"' + (r.status === 'active' ? ' selected' : '') + '>Active</option><option value="suspended"' + (r.status === 'suspended' ? ' selected' : '') + '>Suspended</option></select></td>' +
              '<td class="row"><button class="btn sm" data-rp="' + r.id + '">Reset owner password</button>' + (r.status === 'suspended' && r.id !== S.me.store_id ? '<button class="btn sm danger" data-del="' + r.id + '" data-slug="' + esc(r.slug) + '">Delete</button>' : '') + '</td></tr>';
          }).join('') + '</table></div></div>' +
          '<div class="card stack" style="margin-top:16px"><h2>Add a store for someone</h2><div class="grid g3"><label class="f">Store name<input type="text" id="ns1" dir="auto"></label><label class="f">Store link<input type="text" id="ns2" dir="ltr" placeholder="mystore"></label><label class="f">Owner name<input type="text" id="ns3"></label><label class="f">Owner email<input type="email" id="ns4"></label><label class="f">Password (8+)<input type="text" id="ns5"></label><label class="f">Phone<input type="tel" id="ns6" dir="ltr"></label></div><div><button class="btn pri" id="nsGo">Create store</button></div>' +
          '<p class="small muted">Or share the sign-up link <code>' + esc(location.origin) + '/admin/#signup</code>' + (P.signupMode === 'invite' ? ' with the invite code <b>' + esc(P.inviteCode) + '</b>' : '') + '.</p></div>';
        b.querySelector('#ns1').oninput = function (e) { b.querySelector('#ns2').value = slugify(e.target.value); };
        b.querySelector('#nsGo').onclick = function () { api('POST', '/super/stores', { storeName: b.querySelector('#ns1').value, slug: b.querySelector('#ns2').value, name: b.querySelector('#ns3').value, email: b.querySelector('#ns4').value, password: b.querySelector('#ns5').value, phone: b.querySelector('#ns6').value }).then(function () { toast('Store created — send the owner the email + password'); route(); }).catch(fail); };
        b.querySelectorAll('[data-ai]').forEach(function (i) { i.onchange = function () { api('PATCH', '/super/stores/' + i.getAttribute('data-ai'), { ai_daily_images: num(i.value) }).then(function () { toast('AI limit saved'); }).catch(fail); }; });
        b.querySelectorAll('[data-st]').forEach(function (i) { i.onchange = function () { api('PATCH', '/super/stores/' + i.getAttribute('data-st'), { status: i.value }).then(function () { toast(i.value === 'active' ? 'Store active' : 'Store suspended — its pages and logins are off'); route(); }).catch(fail); }; });
        b.querySelectorAll('[data-rp]').forEach(function (x) { x.onclick = function () { var pw = prompt('New password for the store owner (8+ characters)'); if (pw) api('POST', '/super/stores/' + x.getAttribute('data-rp') + '/password', { password: pw }).then(function (r) { toast('Password changed for ' + r.email); }).catch(fail); }; });
        b.querySelectorAll('[data-del]').forEach(function (x) { x.onclick = function () { var sl = x.getAttribute('data-slug'); var c = prompt('This deletes the store, its products, pages and orders forever. Type the store link “' + sl + '” to confirm:'); if (c === sl) api('DELETE', '/super/stores/' + x.getAttribute('data-del') + '?confirm=' + encodeURIComponent(c)).then(function () { toast('Store deleted'); route(); }).catch(fail); }; });
      }).catch(fail);
      return;
    }
    api('GET', '/super/settings').then(function (s) {
      function F(key, path, label, type, extra) { var v = s[key][path]; return '<label class="f">' + esc(label) + '<input type="' + (type === 'password' ? 'text" class="secret" autocomplete="off" data-lpignore="true" data-1p-ignore="true" data-form-type="other" spellcheck="false' : (type || 'text')) + '" data-s="' + path + '" value="' + esc(v) + '"' + (extra || '') + '></label>'; }
      if (s.ai && s.ai.modelV !== 2 && /flux-1-schnell/.test(s.ai.cfImageModel || '')) s.ai.cfImageModel = '@cf/black-forest-labs/flux-2-klein-4b';
      var sel = function (key, path, opts) { return '<select data-s="' + path + '">' + opts.map(function (o) { return '<option value="' + o[0] + '"' + (String(s[key][path]) === String(o[0]) ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select>'; };
      function bindSave(key) {
        b.querySelector('#sSave').onclick = function () {
          var body = Object.assign({}, s[key]);
          b.querySelectorAll('[data-s]').forEach(function (i) { body[i.getAttribute('data-s')] = i.type === 'number' ? num(i.value) : i.value; });
          api('PUT', '/super/settings/' + key, body).then(function (r) { s = r; toast('Saved'); if (key === 'ai') api('GET', '/me').then(function (j) { S.ai = j.ai; }); }).catch(fail);
        };
      }
      if (tab === 'settings') {
        b.innerHTML = '<div class="card stack"><div class="grid">' + F('platform', 'name', 'Platform name') + F('platform', 'tagline', 'Tagline (home page)') +
          '<label class="f">Sign-up' + sel('platform', 'signupMode', [['invite', 'Invite code only (recommended for the test period)'], ['open', 'Open to everyone'], ['closed', 'Closed']]) + '</label>' + F('platform', 'inviteCode', 'Invite code') +
          F('platform', 'maxStores', 'Maximum number of stores', 'number') + F('platform', 'baseDomain', 'Base domain for store sub-domains (optional, e.g. myplatform.eu.org)') + F('platform', 'supportPhone', 'Support WhatsApp (shown on the home page)', 'tel') + F('platform', 'supportEmail', 'Support email', 'email') + '</div>' +
          '<div class="notice info small">Without a base domain, stores live at <code>' + esc(location.origin) + '/s/&lt;link&gt;</code>. With one (and a wildcard <code>*.domain</code> in your Cloudflare tunnel), each store gets <code>link.domain</code>.</div><div><button class="btn pri" id="sSave">Save</button></div></div>';
        bindSave('platform');
        return;
      }
      b.innerHTML = '<div class="card stack"><h2>Text AI (understands the product, writes the copy)</h2><div class="grid"><label class="f">Provider' + sel('ai', 'provider', [['auto', 'Auto — Gemini key if set, else Cloudflare Llama 4 vision (free, no key)'], ['workers', 'Cloudflare Workers AI only (Llama 4 Scout vision, free)'], ['gemini', 'Google Gemini — free tier key'], ['ollama', 'Ollama — free, on this server'], ['none', 'None — ready-made structure only']]) + '</label><label class="f">Default page language' + sel('ai', 'defaultLang', [['dz', 'الدارجة الجزائرية'], ['ar', 'العربية الفصحى'], ['fr', 'Français']]) + '</label></div>' +
        '<div class="grid">' + F('ai', 'geminiKey', 'Gemini API key (aistudio.google.com)', 'password', ' autocomplete="off"') + F('ai', 'geminiModel', 'Gemini text model (gemini-flash-latest = current free Flash)') + F('ai', 'ollamaUrl', 'Ollama URL') + F('ai', 'ollamaModel', 'Ollama vision model (e.g. gemma3:4b)') + '</div>' +
        '<h2 style="margin-top:8px">Image AI (scenes without text — the platform writes the Arabic on top)</h2><div class="grid"><label class="f">Provider' + sel('ai', 'imageProvider', [['cloudflare', 'Cloudflare Workers AI — FREE (~90 images/day)'], ['openai', 'OpenAI gpt-image (paid)'], ['none', 'Off — use the product photo']]) + '</label>' +
        F('ai', 'cfAccountId', 'Cloudflare Account ID') + F('ai', 'cfApiToken', 'Cloudflare API token (Workers AI)', 'password', ' autocomplete="off"') + '<label class="f">Cloudflare image model' + sel('ai', 'cfImageModel', [['@cf/black-forest-labs/flux-2-klein-4b', 'FLUX.2 klein 4B — puts YOUR product in the scene (recommended, ~90/day free)'], ['@cf/black-forest-labs/flux-2-klein-9b', 'FLUX.2 klein 9B — better quality, fewer per day'], ['@cf/black-forest-labs/flux-1-schnell', 'FLUX.1 schnell — fast, product pasted on top']]) + '</label>' + F('ai', 'cfSteps', 'Quality steps (1–8, higher = better, uses more free quota)', 'number') +
        F('ai', 'openaiKey', 'OpenAI API key', 'password', ' autocomplete="off"') + F('ai', 'openaiImageModel', 'OpenAI image model') + '</div>' +
        '<div class="notice info small"><b>On Cloudflare it already works with no keys:</b> text = Llama 4 Scout (reads your product photos), images = FLUX.2 klein (puts your real product in the scene). Leave the Cloudflare fields empty.<br><b>Optional:</b> a free Gemini key (aistudio.google.com → Get API key) gives better Darija copy — with provider “Auto” it is used first.<br>Free quota ≈ 90 FLUX.2 images per day for the whole platform (≈ 10 landing pages), resets at 01:00 Algeria time. Split it between stores with the “AI images / day” limit in Stores. When the quota is used up, pages still get designed with the product photo.</div>' +
        '<div class="row"><button class="btn pri" id="sSave">Save</button><button class="btn" id="aiTest">Test text AI</button><button class="btn" id="aiTest2">Test text + 1 image</button></div><div id="aiOut"></div></div>';
      bindSave('ai');
      var test = function (img) {
        var o = b.querySelector('#aiOut'); o.innerHTML = '<div class="empty small">Testing… (save first if you changed keys)</div>';
        api('POST', '/super/ai-test', { image: img }).then(function (r) {
          var pv = r.providers || {}; var pr = Object.keys(pv).map(function (k) { var x = pv[k]; return '<div class="small">' + (x.ok ? '✓ ' : '✗ ') + '<b>' + esc(k) + '</b> <code>' + esc(x.model || '') + '</code> — ' + esc(x.detail || '') + '</div>'; }).join('');
          o.innerHTML = (pr ? '<div class="notice small">' + pr + '</div>' : '') + '<div class="notice small">' + (r.text.ok ? '✓ Text AI works: ' : '✗ Text AI: ') + esc(r.text.detail) + '</div>' + (r.image ? (r.image.ok ? '<div class="notice small">✓ Image AI works</div><img src="' + esc(r.image.url) + '" alt="" style="max-width:220px;border-radius:12px">' : '<div class="notice small">✗ Image AI: ' + esc(r.image.detail || 'no image') + '</div>') : '');
        }).catch(fail);
      };
      b.querySelector('#aiTest').onclick = function () { test(false); };
      b.querySelector('#aiTest2').onclick = function () { test(true); };
    }).catch(fail);
  };

  // ---------- boot ----------
  function boot() {
    api('GET', '/me').then(function (j) {
      S.me = j.user; S.store = j.store; S.statuses = j.statuses; S.labels = j.labels; S.storeUrl = j.storeUrl; S.ai = j.ai; S.platform = j.platform;
      return api('GET', '/geo').then(function (g) { S.geo = g; });
    }).then(function () {
      renderShell(); route();
    }).catch(function (e) { if (e.message !== 'Login required') { app.innerHTML = '<div class="empty">Cannot reach the server: ' + esc(e.message) + '</div>'; } });
  }
  window.addEventListener('hashchange', route);
  boot();
})();
