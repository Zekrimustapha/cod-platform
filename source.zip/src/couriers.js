'use strict';
// Push orders to Algerian delivery companies and read back the tracking status.
// Each store adds its own credentials in Settings → Delivery company. Nothing is shared between stores.
const { D, getSetting, orderRow, parseJson } = require('./db');
const geo = require('./geo');
const { nowIso, httpError } = require('./util');

const YALIDINE_HOSTS = {
  yalidine: 'https://api.yalidine.app', guepex: 'https://api.guepex.app', yalitec: 'https://api.yalitec.me',
  easyandspeed: 'https://api.easyandspeed.app', economiqua: 'https://api.economiqua.app', wecan: 'https://api.wecanservices.me'
};
const PROVIDERS = {
  none: { name: 'Manual (CSV export)', fields: [] },
  yalidine: { name: 'Yalidine', fields: ['apiId', 'apiToken'], family: 'yalidine' },
  guepex: { name: 'Guepex', fields: ['apiId', 'apiToken'], family: 'yalidine' },
  yalitec: { name: 'Yalitec', fields: ['apiId', 'apiToken'], family: 'yalidine' },
  easyandspeed: { name: 'Easy & Speed', fields: ['apiId', 'apiToken'], family: 'yalidine' },
  economiqua: { name: 'Economiqua', fields: ['apiId', 'apiToken'], family: 'yalidine' },
  wecan: { name: 'We Can Services', fields: ['apiId', 'apiToken'], family: 'yalidine' },
  zr: { name: 'ZR Express (Procolis)', fields: ['apiToken', 'apiKey'], family: 'procolis' },
  procolis: { name: 'Other Procolis courier', fields: ['apiToken', 'apiKey'], family: 'procolis' },
  ecotrack: { name: 'EcoTrack couriers (DHD, Conexlog, Anderson, World Express…)', fields: ['host', 'apiToken'], family: 'ecotrack' },
  noest: { name: 'Noest Express', fields: ['apiToken', 'userGuid'], family: 'noest' }
};

const fail = (msg) => Object.assign(new Error(msg), { status: 400 });

async function call(url, opts = {}) {
  let r;
  try {
    r = await fetch(url, { ...opts, signal: AbortSignal.timeout(20000) });
  } catch (e) {
    throw fail('Cannot reach the delivery company (' + e.message + ').');
  }
  const txt = await r.text();
  let j = null;
  try { j = JSON.parse(txt); } catch {}
  if (r.status === 401 || r.status === 403) throw fail('The delivery company refused the credentials (HTTP ' + r.status + '). Check the API keys in Settings → Delivery company.');
  if (!r.ok) throw fail('Delivery company error HTTP ' + r.status + ': ' + String((j && (j.message || j.error)) || txt).slice(0, 200));
  return j !== null ? j : txt;
}

function cfg(sid) {
  const c = getSetting('couriers', sid);
  const p = PROVIDERS[c.provider];
  if (!p || c.provider === 'none') throw fail('Choose your delivery company in Settings → Delivery company.');
  for (const f of p.fields) if (!String(c[f] || '').trim()) throw fail('Missing ' + f + ' for ' + p.name + ' (Settings → Delivery company).');
  return { ...c, family: p.family, pname: p.name };
}
function ecoBase(c) {
  let h = String(c.host || '').trim().replace(/\/+$/, '');
  if (!/^https?:\/\//.test(h)) h = 'https://' + h;
  return h.replace(/\/api\/v1$/, '');
}

function parcelOf(o) {
  const w = geo.wilayaByCode(o.wilaya_code, 69) || {};
  const parent = geo.wilayaByCode(w.parent || o.wilaya_code, 58) || w;
  const parts = String(o.name || '').trim().split(/\s+/);
  return {
    ref: String(o.id), first: parts[0] || o.name, last: parts.slice(1).join(' ') || parts[0] || '-', name: o.name, phone: o.phone, phone2: o.phone2 || '',
    address: o.address || o.commune, wilayaCode: String(w.parent || o.wilaya_code).padStart(2, '0'), wilayaFr: parent.fr || '', commune: o.commune,
    product: (o.product_name + (o.variant ? ' - ' + o.variant : '') + (o.quantity > 1 ? ' x' + o.quantity : '') + (o.upsell ? ' + ' + o.upsell : '')).slice(0, 240),
    total: o.total, desk: o.delivery !== 'home', note: String(o.note || '').replace(/^Client:\s*/, '').slice(0, 200), qty: o.quantity
  };
}

// ---- providers ----
const ADAPTERS = {
  yalidine: {
    headers: (c) => ({ 'X-API-ID': c.apiId.trim(), 'X-API-TOKEN': c.apiToken.trim(), 'Content-Type': 'application/json' }),
    base: (c) => YALIDINE_HOSTS[c.provider] || YALIDINE_HOSTS.yalidine,
    async test(c) { await call(this.base(c) + '/v1/wilayas/?page_size=1', { headers: this.headers(c) }); return 'Connected to ' + c.pname; },
    async create(c, p) {
      const from = geo.wilayaByCode(String(c.fromWilaya || '16').padStart(2, '0'), 58) || { fr: 'Alger' };
      const body = [{
        order_id: 'O' + p.ref, from_wilaya_name: from.fr, firstname: p.first, familyname: p.last, contact_phone: p.phone + (p.phone2 ? ',' + p.phone2 : ''),
        address: p.address, to_commune_name: p.commune, to_wilaya_name: p.wilayaFr, product_list: p.product, price: Math.round(p.total), do_insurance: false,
        declared_value: Math.round(p.total), length: 20, width: 20, height: 10, weight: Number(c.weight) || 1, freeshipping: false, is_stopdesk: p.desk, has_exchange: false
      }];
      if (p.desk) {
        const centers = await call(this.base(c) + '/v1/centers/?wilaya_id=' + Number(p.wilayaCode), { headers: this.headers(c) });
        const list = (centers && centers.data) || [];
        const same = list.find((x) => String(x.commune_name || '').toLowerCase() === String(p.commune).toLowerCase()) || list[0];
        if (!same) throw fail('No stop-desk office found for this wilaya. Switch the order to home delivery.');
        body[0].stopdesk_id = same.center_id;
      }
      const j = await call(this.base(c) + '/v1/parcels/', { method: 'POST', headers: this.headers(c), body: JSON.stringify(body) });
      const r = j && (j['O' + p.ref] || Object.values(j)[0]);
      if (!r || r.success === false || !r.tracking) throw fail('Yalidine: ' + ((r && r.message) || 'parcel not created'));
      return { tracking: r.tracking, label: r.label || '' };
    },
    async status(c, tracking) {
      const j = await call(this.base(c) + '/v1/parcels/' + encodeURIComponent(tracking), { headers: this.headers(c) });
      const d = (j && j.data && j.data[0]) || j || {};
      return d.last_status || d.status || '';
    }
  },
  procolis: {
    headers: (c) => ({ token: c.apiToken.trim(), key: c.apiKey.trim(), 'Content-Type': 'application/json' }),
    async test(c) { const j = await call('https://procolis.com/api_v1/token', { headers: this.headers(c) }); if (j && /refus|invalid/i.test(JSON.stringify(j))) throw fail('ZR Express refused the token / key.'); return 'Connected to ' + c.pname; },
    async create(c, p) {
      const body = { Colis: [{
        Tracking: '', TypeLivraison: p.desk ? '1' : '0', TypeColis: '0', Confrimee: '', Client: p.name, MobileA: p.phone, MobileB: p.phone2, Adresse: p.address,
        IDWilaya: p.wilayaCode, Commune: p.commune, Total: String(Math.round(p.total)), Note: p.note, TProduit: p.product.slice(0, 240).replace(/\|/g, '-'), id_Externe: p.ref, Source: ''
      }] };
      const j = await call('https://procolis.com/api_v1/add_colis', { method: 'POST', headers: this.headers(c), body: JSON.stringify(body) });
      const r = j && j.Colis && j.Colis[0];
      if (!r || !r.Tracking) throw fail('ZR Express: ' + ((r && r.MessageRetour) || JSON.stringify(j).slice(0, 160)));
      return { tracking: r.Tracking };
    },
    async status(c, tracking) {
      const j = await call('https://procolis.com/api_v1/lire', { method: 'POST', headers: this.headers(c), body: JSON.stringify({ Colis: [{ Tracking: tracking }] }) });
      const r = j && j.Colis && j.Colis[0];
      return (r && (r.Situation || r.Statut)) || '';
    }
  },
  ecotrack: {
    headers: (c) => ({ Authorization: 'Bearer ' + c.apiToken.trim(), Accept: 'application/json', 'Content-Type': 'application/json' }),
    async test(c) { await call(ecoBase(c) + '/api/v1/get/wilayas', { headers: this.headers(c) }); return 'Connected to ' + ecoBase(c); },
    async create(c, p) {
      const body = {
        reference: p.ref, nom_client: p.name, telephone: p.phone, telephone_2: p.phone2, adresse: p.address, code_postal: '', commune: p.commune, code_wilaya: Number(p.wilayaCode),
        montant: Math.round(p.total), remarque: p.note, produit: p.product, type: 1, stop_desk: p.desk ? 1 : 0, quantite: p.qty, weight: Number(c.weight) || 1
      };
      const j = await call(ecoBase(c) + '/api/v1/create/order', { method: 'POST', headers: this.headers(c), body: JSON.stringify(body) });
      if (!j || j.success === false || !j.tracking) throw fail('EcoTrack: ' + ((j && (j.message || JSON.stringify(j.errors || ''))) || 'order not created'));
      return { tracking: j.tracking };
    },
    async status(c, tracking) {
      const j = await call(ecoBase(c) + '/api/v1/get/tracking/info?tracking=' + encodeURIComponent(tracking), { headers: this.headers(c) });
      const act = (j && (j.activity || j.activities)) || [];
      const last = Array.isArray(act) ? act[act.length - 1] : null;
      return (last && (last.status || last.event)) || (j && (j.status || (j.OrderInfo && j.OrderInfo.status))) || '';
    }
  },
  noest: {
    base: 'https://app.noest-dz.com/api/public',
    auth: (c) => ({ api_token: c.apiToken.trim(), user_guid: c.userGuid.trim() }),
    async test(c) { await call(this.base + '/get/trackings/info', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...this.auth(c), trackings: [] }) }); return 'Connected to Noest'; },
    async create(c, p) {
      const body = { ...this.auth(c), reference: p.ref, client: p.name, phone: p.phone, phone_2: p.phone2, adresse: p.address, wilaya_id: Number(p.wilayaCode), commune: p.commune,
        montant: Math.round(p.total), remarque: p.note, produit: p.product, type_id: 1, poids: Number(c.weight) || 1, stop_desk: p.desk ? 1 : 0, stock: 0, quantite: String(p.qty), can_open: 0 };
      const j = await call(this.base + '/create/order', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      if (!j || j.success === false || !j.tracking) throw fail('Noest: ' + ((j && (j.message || JSON.stringify(j.errors || ''))) || 'order not created'));
      return { tracking: j.tracking };
    },
    async status(c, tracking) {
      const j = await call(this.base + '/get/trackings/info', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...this.auth(c), trackings: [tracking] }) });
      const r = j && (j[tracking] || Object.values(j)[0]);
      const act = (r && r.activity) || [];
      return (act.length && (act[act.length - 1].event || act[act.length - 1].status)) || (r && r.OrderInfo && r.OrderInfo.status) || '';
    }
  }
};

async function test(sid) {
  const c = cfg(sid);
  return ADAPTERS[c.family].test(c);
}

async function pushOrder(sid, id) {
  const c = cfg(sid);
  const o = orderRow(await D.get('SELECT * FROM orders WHERE id = ? AND store_id = ?', id, sid));
  if (!o) throw httpError(404, 'Order not found');
  if (o.tracking) return { tracking: o.tracking, already: true };
  if (!['confirmed', 'new', 'callback', 'noanswer'].includes(o.status)) throw fail('Only orders not yet shipped can be sent (order #' + o.id + ' is ' + o.status + ').');
  const r = await ADAPTERS[c.family].create(c, parcelOf(o));
  const h = parseJson(o.history, []);
  h.push({ at: nowIso(), by: 'system', action: 'sent to courier', detail: c.pname + ' · ' + r.tracking });
  await D.run("UPDATE orders SET tracking = ?, courier = ?, courier_status = ?, status = CASE WHEN status IN ('new','callback','noanswer') THEN 'confirmed' ELSE status END, history = ?, updated_at = ? WHERE id = ?",
    r.tracking, c.pname, 'created', JSON.stringify(h), nowIso(), o.id);
  return { tracking: r.tracking, label: r.label || '' };
}

// Map courier wording to our statuses (only clear cases).
function mapStatus(s) {
  const x = String(s || '').toLowerCase();
  if (/livr[ée]e?\b|delivered|encaiss/.test(x) && !/non livr|retour/.test(x)) return 'delivered';
  if (/retour|return|refus|annul/.test(x)) return 'returned';
  if (/exp[ée]di|transit|ramass|picked|en cours|sorti|centre|hub|vers/.test(x)) return 'shipped';
  return null;
}

async function refreshStatus(sid, id) {
  const c = cfg(sid);
  const o = await D.get('SELECT * FROM orders WHERE id = ? AND store_id = ?', id, sid);
  if (!o || !o.tracking) throw fail('This order has no tracking number yet.');
  const raw = String(await ADAPTERS[c.family].status(c, o.tracking) || '').slice(0, 120);
  const mapped = mapStatus(raw);
  await D.run('UPDATE orders SET courier_status = ?, updated_at = ? WHERE id = ?', raw, nowIso(), o.id);
  return { courier_status: raw, suggested: mapped && mapped !== o.status ? mapped : null };
}

function providerList() {
  return Object.entries(PROVIDERS).map(([id, p]) => ({ id, name: p.name, fields: p.fields }));
}

module.exports = { PROVIDERS, providerList, test, pushOrder, refreshStatus, mapStatus };
