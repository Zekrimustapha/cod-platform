'use strict';
const { D, getSetting } = require('./db');
const { sha256hex } = require('./crypto');

const sha = (s) => sha256hex(String(s).trim().toLowerCase());

function log(...a) {
  console.log('[integrations]', ...a);
}

// ---------- Google Sheets (free: Apps Script web app) ----------
async function pushToSheets(event, order) {
  const { sheetsUrl } = getSetting('integrations', order.store_id);
  if (!sheetsUrl || !/^https:\/\/script\.google\.com\//.test(sheetsUrl)) return;
  try {
    await fetch(sheetsUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ event, order: {
        id: order.id, created_at: order.created_at, status: order.status, name: order.name, phone: order.phone,
        wilaya: order.wilaya_code + ' ' + order.wilaya_name, commune: order.commune, address: order.address, delivery: order.delivery,
        product: order.product_name, variant: order.variant, quantity: order.quantity, total: order.total, upsell: order.upsell,
        note: order.note, tracking: order.tracking, campaign: order.utm_campaign
      } }),
      signal: AbortSignal.timeout(10000)
    });
  } catch (e) {
    log('sheets failed', e.message);
  }
}

// ---------- Meta Conversions API (free) ----------
async function metaCapi({ pixelId, eventName, eventId, order, req, extra = {} }) {
  const t = getSetting('tracking', order.store_id);
  const ver = getSetting('integrations', order.store_id).graphVersion || 'v21.0';
  const pixel = pixelId || t.metaPixel;
  if (!pixel || !t.metaCapiToken) return;
  const phoneIntl = order.phone ? '213' + order.phone.replace(/^0/, '') : '';
  const body = {
    data: [{
      event_name: eventName,
      event_time: Math.floor(Date.now() / 1000),
      event_id: eventId,
      action_source: 'website',
      event_source_url: extra.url || '',
      user_data: {
        ph: phoneIntl ? [await sha(phoneIntl)] : undefined,
        fn: order.name ? [await sha(order.name.split(' ')[0])] : undefined,
        ct: order.commune ? [await sha(order.commune)] : undefined,
        country: [await sha('dz')],
        client_ip_address: extra.ip || undefined,
        client_user_agent: extra.ua || undefined,
        fbc: extra.fbc || undefined,
        fbp: extra.fbp || undefined
      },
      custom_data: { currency: 'DZD', value: order.total, content_ids: order.product_id ? [String(order.product_id)] : [], content_type: 'product', num_items: order.quantity }
    }]
  };
  if (t.metaTestCode) body.test_event_code = t.metaTestCode;
  try {
    const r = await fetch(`https://graph.facebook.com/${ver}/${encodeURIComponent(pixel)}/events?access_token=${encodeURIComponent(t.metaCapiToken)}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(10000)
    });
    if (!r.ok) log('capi', r.status, (await r.text()).slice(0, 300));
  } catch (e) {
    log('capi failed', e.message);
  }
}

// ---------- Meta Ads insights (free Marketing API, needs ads_read token) ----------
const RESULT_ACTIONS = ['offsite_conversion.fb_pixel_purchase', 'purchase', 'onsite_web_purchase', 'offsite_conversion.fb_pixel_lead', 'lead'];

async function syncMetaAds(sid, days = 30) {
  const i = getSetting('integrations', sid);
  const costs = getSetting('costs', sid);
  if (!i.metaAdsToken || !i.metaAdAccount) throw new Error('Add the Meta access token and ad account ID in Settings → Integrations');
  const acct = String(i.metaAdAccount).replace(/^act_/, '');
  const until = new Date();
  const since = new Date(Date.now() - (days - 1) * 864e5);
  const fmt = (d) => d.toISOString().slice(0, 10);
  const params = new URLSearchParams({
    level: 'campaign', fields: 'campaign_id,campaign_name,spend,impressions,clicks,actions,account_currency',
    time_increment: '1', time_range: JSON.stringify({ since: fmt(since), until: fmt(until) }), limit: '500', access_token: i.metaAdsToken
  });
  let url = `https://graph.facebook.com/${i.graphVersion || 'v21.0'}/act_${acct}/insights?${params}`;
  const upSql = `INSERT INTO ad_spend(store_id, date, campaign_id, campaign_name, platform, spend_usd, impressions, clicks, results) VALUES(?,?,?,?,?,?,?,?,?)
    ON CONFLICT(store_id, date, campaign_id) DO UPDATE SET campaign_name=excluded.campaign_name, spend_usd=excluded.spend_usd, impressions=excluded.impressions, clicks=excluded.clicks, results=excluded.results`;
  let rows = 0;
  for (let page = 0; page < 20 && url; page++) {
    const r = await fetch(url, { signal: AbortSignal.timeout(20000) });
    const j = await r.json();
    if (j.error) throw new Error('Meta: ' + j.error.message);
    for (const x of j.data || []) {
      let spend = Number(x.spend || 0);
      if (x.account_currency && x.account_currency !== 'USD') {
        if (x.account_currency === 'DZD') spend = spend / (costs.usdRate || 255);
      }
      let results = 0;
      for (const a of x.actions || []) if (RESULT_ACTIONS.includes(a.action_type)) results = Math.max(results, Number(a.value || 0));
      await D.run(upSql, sid, x.date_start, String(x.campaign_id), x.campaign_name || '', 'meta', spend, Number(x.impressions || 0), Number(x.clicks || 0), results);
      rows++;
    }
    url = j.paging && j.paging.next;
  }
  return rows;
}

// ---------- Courier export ----------
function courierCsv(orders) {
  const head = ['reference', 'name', 'phone', 'wilaya_code', 'wilaya', 'commune', 'address', 'delivery_type', 'product', 'quantity', 'cod_amount', 'note'];
  const q = (v) => '"' + String(v ?? '').replace(/"/g, '""') + '"';
  const lines = [head.join(',')];
  for (const o of orders) {
    lines.push([o.id, o.name, o.phone, o.wilaya_code, o.wilaya_name, o.commune, o.address, o.delivery === 'home' ? 'home' : 'stopdesk',
      o.product_name + (o.variant ? ' - ' + o.variant : '') + (o.upsell ? ' + ' + o.upsell : ''), o.quantity, o.total, o.note].map(q).join(','));
  }
  return '﻿' + lines.join('\r\n');
}

module.exports = { pushToSheets, metaCapi, syncMetaAds, courierCsv, sha };
