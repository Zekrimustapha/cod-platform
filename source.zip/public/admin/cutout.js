/* Free in-browser background removal via Transformers.js, run in a Web Worker (page never freezes).
   Cutout.remove(src, {onProgress, feather}) -> Promise<{blob, url, method, width, height}>.
   Chain (each one is test-run; first that works is remembered):
     BiRefNet lite (MIT) WebGPU fp16  — only on GPUs with shader-f16, best edges
     ORMBG (Apache-2.0) WebGPU fp16 / fp32
     ORMBG WASM fp16                   — no GPU (slow, ~84 MB)
     flood-fill                        — plain light backgrounds only
   Model files: huggingface.co, or our same-origin mirror /hf/ when huggingface.co is blocked. */
(function () {
  var LIB = 'https://cdn.jsdelivr.net/npm/@huggingface/transformers@4.3.2/+esm';
  var WORKER_SRC = [
    'let T, cur = null, idx = 0, tries = null;',
    'const BIREF = "onnx-community/BiRefNet_lite-ONNX", ORM = "d30social/ormbg-ortweb";',
    'async function init(origin) {',
    '  if (tries) return;',
    '  T = await import("' + LIB + '");',
    '  T.env.allowLocalModels = false;',
    '  try { const r = await fetch("https://huggingface.co/" + ORM + "/resolve/main/config.json"); if (!r.ok) throw 0; } catch (e) { T.env.remoteHost = origin + "/hf/"; }',
    '  let f16 = false, gpu = false; try { const a = navigator.gpu && await navigator.gpu.requestAdapter(); gpu = !!a; f16 = !!(a && a.features.has("shader-f16")); } catch (e) {}',
    '  tries = [];',
    '  if (f16) tries.push({ id: BIREF, kind: "biref", device: "webgpu", dtype: "fp16" }, { id: ORM, kind: "orm", device: "webgpu", dtype: "fp16" });',
    '  if (gpu) tries.push({ id: ORM, kind: "orm", device: "webgpu", dtype: "fp32" });',
    '  tries.push({ id: ORM, kind: "orm", device: "wasm", dtype: "fp16" });',
    '}',
    'async function load(t, post) {',
    '  const model = await T.AutoModel.from_pretrained(t.id, { device: t.device, dtype: t.dtype, progress_callback: (p) => { if (p.status === "progress" && /onnx/.test(p.file || "")) post({ type: "progress", pct: Math.round(p.progress || 0) }); } });',
    '  const proc = await T.AutoProcessor.from_pretrained(t.id);',
    '  return { t, model, proc };',
    '}',
    'async function run(c, blob) {',
    '  const img = await T.RawImage.fromBlob(blob);',
    '  const inp = await c.proc(img);',
    '  let a;',
    '  if (c.t.kind === "biref") { const o = await c.model({ input_image: inp.pixel_values }); a = o.output_image[0].sigmoid(); }',
    '  else { const o = await c.model({ input: inp.pixel_values, pixel_values: inp.pixel_values }); a = (o.alphas || o[Object.keys(o)[0]])[0]; }',
    '  const m = await T.RawImage.fromTensor(a.mul(255).to("uint8")).resize(img.width, img.height);',
    '  return { w: m.width, h: m.height, ch: m.channels, data: m.data };',
    '}',
    'self.onmessage = async (ev) => {',
    '  const { id, blob, origin } = ev.data; const post = (o) => self.postMessage({ id, ...o });',
    '  try {',
    '    await init(origin);',
    '    let last;',
    '    for (; idx < tries.length; idx++) {',
    '      try {',
    '        if (!cur) cur = await load(tries[idx], post);',
    '        const r = await run(cur, blob);',
    '        return post({ type: "done", mask: r, method: cur.t.kind + "-" + cur.t.device + "-" + cur.t.dtype });',
    '      } catch (e) { last = e; try { cur && cur.model && cur.model.dispose && await cur.model.dispose(); } catch (_) {} cur = null; }',
    '    }',
    '    idx = Math.max(0, tries.length - 1);',
    '    throw last || new Error("no model");',
    '  } catch (e) { post({ type: "error", error: String(e && e.message || e).slice(0, 300) }); }',
    '};'
  ].join('\n');

  var worker = null, seq = 0, pending = {};
  function getWorker() {
    if (worker) return worker;
    var url = URL.createObjectURL(new Blob([WORKER_SRC], { type: 'text/javascript' }));
    worker = new Worker(url, { type: 'module' });
    worker.onmessage = function (ev) { var d = ev.data, p = pending[d.id]; if (!p) return; if (d.type === 'progress') { if (p.onProgress) p.onProgress(d.pct); return; } delete pending[d.id]; if (d.type === 'done') p.res(d); else p.rej(new Error(d.error)); };
    worker.onerror = function (e) { Object.keys(pending).forEach(function (k) { pending[k].rej(new Error(e.message || 'worker')); delete pending[k]; }); worker = null; };
    return worker;
  }
  function aiMask(blob, onProgress) {
    return new Promise(function (res, rej) {
      var id = ++seq; pending[id] = { res: res, rej: rej, onProgress: onProgress };
      try { getWorker().postMessage({ id: id, blob: blob, origin: location.origin }); } catch (e) { delete pending[id]; rej(e); }
      setTimeout(function () { if (pending[id]) { delete pending[id]; rej(new Error('timeout')); } }, 600000);
    });
  }
  function loadImg(src) { return new Promise(function (res, rej) { var i = new Image(); i.crossOrigin = 'anonymous'; i.onload = function () { res(i); }; i.onerror = function () { rej(new Error('image')); }; i.src = src; }); }
  function toBlob(cv, type, q) { return new Promise(function (res) { cv.toBlob(res, type || 'image/png', q); }); }

  // Apply alpha mask, feather, trim to bbox + 4% padding, longest side <= 1200.
  function compose(img, mask, feather) {
    var w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
    var mc = document.createElement('canvas'); mc.width = mask.w; mc.height = mask.h;
    var mx = mc.getContext('2d'), md = mx.createImageData(mask.w, mask.h);
    for (var i = 0, j = 0; i < mask.w * mask.h; i++, j += mask.ch) { md.data[i * 4 + 3] = mask.data[j]; }
    mx.putImageData(md, 0, 0);
    var cv = document.createElement('canvas'); cv.width = w; cv.height = h; var c = cv.getContext('2d');
    c.drawImage(img, 0, 0, w, h);
    c.globalCompositeOperation = 'destination-in';
    if (feather > 0) c.filter = 'blur(' + feather + 'px)';
    c.drawImage(mc, 0, 0, w, h);
    c.filter = 'none'; c.globalCompositeOperation = 'source-over';
    return trim(cv);
  }
  function trim(cv) {
    var w = cv.width, h = cv.height, d = cv.getContext('2d').getImageData(0, 0, w, h).data;
    var x0 = w, y0 = h, x1 = -1, y1 = -1, n = 0;
    for (var y = 0; y < h; y += 2) for (var x = 0; x < w; x += 2) { if (d[(y * w + x) * 4 + 3] > 24) { n++; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; } }
    var frac = n / ((w / 2) * (h / 2));
    if (x1 < 0) return { canvas: cv, frac: 0 };
    var pad = Math.round(Math.max(x1 - x0, y1 - y0) * 0.04);
    x0 = Math.max(0, x0 - pad); y0 = Math.max(0, y0 - pad); x1 = Math.min(w - 1, x1 + pad); y1 = Math.min(h - 1, y1 + pad);
    var bw = x1 - x0 + 1, bh = y1 - y0 + 1, s = Math.min(1, 1200 / Math.max(bw, bh));
    var out = document.createElement('canvas'); out.width = Math.round(bw * s); out.height = Math.round(bh * s);
    out.getContext('2d').drawImage(cv, x0, y0, bw, bh, 0, 0, out.width, out.height);
    return { canvas: out, frac: frac };
  }
  // Old method: flood-fill a plain light background from the borders.
  function flood(img) {
    var s = Math.min(1, 1200 / Math.max(img.width, img.height)), w = Math.round(img.width * s), h = Math.round(img.height * s);
    var cv = document.createElement('canvas'); cv.width = w; cv.height = h; var x = cv.getContext('2d'); x.drawImage(img, 0, 0, w, h);
    var d = x.getImageData(0, 0, w, h), px = d.data;
    var pts = [[2, 2], [w - 3, 2], [2, h - 3], [w - 3, h - 3], [w >> 1, 2], [w >> 1, h - 3], [2, h >> 1], [w - 3, h >> 1]];
    var cs = pts.map(function (p) { var i = (p[1] * w + p[0]) * 4; return [px[i], px[i + 1], px[i + 2]]; });
    var avg = [0, 1, 2].map(function (k) { return cs.reduce(function (a, c) { return a + c[k]; }, 0) / cs.length; });
    var spread = Math.max.apply(null, cs.map(function (c) { return Math.abs(c[0] - avg[0]) + Math.abs(c[1] - avg[1]) + Math.abs(c[2] - avg[2]); }));
    if (!(spread < 60 && (avg[0] + avg[1] + avg[2]) / 3 > 150)) return null;
    var tol = 48, seen = new Uint8Array(w * h), stack = [];
    for (var i = 0; i < w; i++) stack.push(i, (h - 1) * w + i);
    for (var j = 0; j < h; j++) stack.push(j * w, j * w + w - 1);
    while (stack.length) {
      var p = stack.pop(); if (seen[p]) continue; seen[p] = 1;
      var o = p * 4; if (Math.abs(px[o] - avg[0]) + Math.abs(px[o + 1] - avg[1]) + Math.abs(px[o + 2] - avg[2]) > tol) continue;
      px[o + 3] = 0; var xx = p % w, yy = (p / w) | 0;
      if (xx > 0) stack.push(p - 1); if (xx < w - 1) stack.push(p + 1); if (yy > 0) stack.push(p - w); if (yy < h - 1) stack.push(p + w);
    }
    x.putImageData(d, 0, 0);
    return trim(cv);
  }

  var maskCache = {};
  function remove(src, opts) {
    opts = opts || {};
    var feather = Math.max(0, Math.min(4, +opts.feather || 0));
    return loadImg(src).then(function (img) {
      var getMask = maskCache[src] ? Promise.resolve(maskCache[src]) : fetch(src).then(function (r) { return r.blob(); }).then(function (b) { return aiMask(b, opts.onProgress); }).then(function (d) { maskCache[src] = d; return d; });
      return getMask.then(function (d) {
        var r = compose(img, d.mask, feather);
        if (r.frac < 0.02 || r.frac > 0.985) throw new Error('mask empty');
        return { canvas: r.canvas, method: d.method };
      }).catch(function (e) {
        var r = flood(img);
        if (!r) throw new Error('Background removal failed (' + e.message + '). Use a photo on a plain light background.');
        return { canvas: r.canvas, method: 'flood-fill', warning: e.message };
      });
    }).then(function (r) {
      return toBlob(r.canvas, 'image/webp', 0.9).then(function (b) { return b && b.type === 'image/webp' ? b : toBlob(r.canvas, 'image/png'); }).then(function (blob) { return { blob: blob, url: URL.createObjectURL(blob), method: r.method, warning: r.warning, width: r.canvas.width, height: r.canvas.height }; });
    });
  }
  window.Cutout = { remove: remove };
})();
