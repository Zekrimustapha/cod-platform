'use strict';
const { D } = require('./db');
const { hashPassword, verifyPassword } = require('./crypto');
const { parseCookies, token, nowIso, httpError } = require('./util');

const SESSION_DAYS = 30;

const ROLES = {
  owner: ['overview', 'orders', 'customers', 'products', 'landings', 'ads', 'simulator', 'design', 'settings', 'team'],
  agent: ['overview', 'orders', 'customers', 'simulator'],
  stock: ['overview', 'orders', 'products', 'simulator'],
  ads: ['overview', 'products', 'landings', 'ads', 'simulator', 'design']
};

async function userCount() {
  return (await D.get('SELECT COUNT(*) AS n FROM users')).n;
}

async function createUser({ name, email, password, role = 'agent', storeId = null, isSuper = false }) {
  if (!ROLES[role]) throw httpError(400, 'Unknown role');
  if (!email || !/^[^@\s]+@[^@\s]+$/.test(email)) throw httpError(400, 'Valid email required');
  if (!password || String(password).length < 8) throw httpError(400, 'Password must be at least 8 characters');
  const exists = (await D.get('SELECT id FROM users WHERE email = ?', String(email).toLowerCase()));
  if (exists) throw httpError(409, 'Email already used');
  const r = (await D.run('INSERT INTO users(store_id, name, email, pass_hash, role, is_super, created_at) VALUES(?,?,?,?,?,?,?)', storeId, String(name || email).slice(0, 80), String(email).toLowerCase(), await hashPassword(password), role, isSuper ? 1 : 0, nowIso()));
  return Number(r.lastInsertRowid);
}

function isSecure(req) {
  return req.headers['x-forwarded-proto'] === 'https' || /"scheme":"https"/.test(String(req.headers['cf-visitor'] || '')) || !!(req.socket && req.socket.encrypted);
}

function sessionCookie(req, value, maxAgeSec) {
  return `sid=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSec}${isSecure(req) ? '; Secure' : ''}`;
}

async function login(req, email, password) {
  const u = (await D.get('SELECT * FROM users WHERE email = ? AND active = 1', String(email || '').toLowerCase()));
  if (!u || !(await verifyPassword(password, u.pass_hash))) return null;
  const st = u.store_id ? (await D.get('SELECT slug, name, status FROM stores WHERE id = ?', u.store_id)) : null;
  if (!u.is_super && (!st || st.status !== 'active')) return { suspended: true };
  if (st) Object.assign(u, { store_slug: st.slug, store_name: st.name });
  const t = token(32);
  (await D.run('INSERT INTO sessions(token, user_id, expires_at) VALUES(?,?,?)', t, u.id, Date.now() + SESSION_DAYS * 864e5));
  (await D.run('DELETE FROM sessions WHERE expires_at < ?', Date.now()));
  return { cookie: sessionCookie(req, t, SESSION_DAYS * 86400), user: publicUser(u) };
}

async function logout(req) {
  const sid = parseCookies(req).sid;
  if (sid) (await D.run('DELETE FROM sessions WHERE token = ?', sid));
  return sessionCookie(req, '', 0);
}

async function currentUser(req) {
  const sid = parseCookies(req).sid;
  if (!sid) return null;
  const row = (await D.get(`SELECT u.*, st.slug AS store_slug, st.name AS store_name, st.status AS store_status FROM sessions s JOIN users u ON u.id = s.user_id
    LEFT JOIN stores st ON st.id = u.store_id WHERE s.token = ? AND s.expires_at > ? AND u.active = 1`, sid, Date.now()));
  if (!row) return null;
  if (!row.is_super && row.store_status !== 'active') return null;
  return publicUser(row);
}

function publicUser(u) {
  return { id: u.id, name: u.name, email: u.email, role: u.role, sections: ROLES[u.role] || [], store_id: u.store_id, is_super: !!u.is_super,
    store_slug: u.store_slug || null, store_name: u.store_name || null };
}

function can(user, section) {
  return !!user && (ROLES[user.role] || []).includes(section);
}

module.exports = { ROLES, publicUser, sessionCookie, SESSION_DAYS, hashPassword, verifyPassword, userCount, createUser, login, logout, currentUser, can };
