'use strict';
// Cloudflare D1 driver (serverless SQLite).
const clean = (p) => p.map((v) => (v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : v));
function makeD1Driver(DB) {
  return {
    kind: 'd1',
    async get(sql, p) { return (await DB.prepare(sql).bind(...clean(p)).first()) || undefined; },
    async all(sql, p) { return (await DB.prepare(sql).bind(...clean(p)).all()).results || []; },
    async run(sql, p) { const r = await DB.prepare(sql).bind(...clean(p)).run(); return { changes: r.meta.changes, lastInsertRowid: r.meta.last_row_id }; },
    async exec(sql) { await DB.exec(sql); }
  };
}
module.exports = { makeD1Driver };
