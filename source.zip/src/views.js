'use strict';
const { esc } = require('./util');
const geo = require('./geo');
const { getSetting } = require('./db');
// Render context (rendering is synchronous, so a module-level context is safe).
const CTX = { sid: 0, base: '' };
function setCtx(sid, base) { CTX.sid = sid; CTX.base = base || ''; }
const B = () => CTX.base;
const { deliveryFee, priceFor } = require('./orders');

const T = {
  ar: {
    dir: 'rtl', lang: 'ar', cod: 'الدفع عند الاستلام', delivery58: 'توصيل لكل الولايات', freeDesk: 'التوصيل للمكتب مجاني', order: 'اطلب الآن',
    orderTitle: 'اطلب الآن — ادفع عند الاستلام', orderSub: '4 معلومات فقط. لن تدفع شيئاً الآن.', name: 'الاسم الكامل', namePh: 'مثال: محمد بن علي',
    phone: 'رقم الهاتف', wilaya: 'الولاية', chooseWilaya: 'اختر الولاية', commune: 'البلدية', chooseCommune: 'اختر البلدية', typeCommune: 'اكتب اسم بلديتك',
    search: 'ابحث بالاسم أو الرقم…', desk: 'مكتب التوصيل', home: 'إلى المنزل', free: 'مجاني', total: 'المجموع عند الاستلام', confirm: 'تأكيد الطلب',
    trust: ['الدفع عند الاستلام', 'مكالمة تأكيد', 'استبدال مضمون'], errName: 'اكتب اسمك الكامل', errPhone: '10 أرقام تبدأ بـ 05 أو 06 أو 07',
    errWilaya: 'اختر ولايتك', errCommune: 'اختر بلديتك', errVariant: 'اختر الخيار المناسب', thanks: 'شكراً! طلبك وصلنا', thanksSub: 'سنتصل بك على {phone} لتأكيد الطلب. أبقِ هاتفك مفتوحاً.',
    upTitle: 'عرض خاص لك فقط قبل التأكيد', upSub: 'يُضاف لنفس الطرد، بدون توصيل إضافي', upYes: 'نعم، أضفه', upNo: 'لا، شكراً', newOrder: 'طلب جديد',
    piece: 'قطعة', pieces: 'قطع', two: 'قطعتان', save: 'وفّر', mostOrdered: 'الأكثر طلباً', bestValue: 'أفضل قيمة', why: 'لماذا', seeDiff: 'شاهد الفرق',
    before: 'قبل', after: 'بعد', drag: 'اسحب للمقارنة', vsTitle: 'الفرق بيننا وبين الآخرين', us: 'نحن', others: 'غيرنا', reviews: 'زبائننا يقولون',
    swipe: 'اسحب لرؤية المزيد', how: 'طريقة الاستعمال', after1: 'ماذا يحدث بعد طلبك؟', faq: 'أسئلة شائعة', s1: 'تملأ الاستمارة', s1t: 'في أقل من دقيقة',
    s2: 'نتصل بك للتأكيد', s3: 'يصلك الطرد', s4: 'تدفع عند الاستلام', s4t: 'بعد أن ترى المنتج', currency: 'دج', error: 'حدث خطأ، حاول مرة أخرى',
    home_: 'الرئيسية', cats: 'الأقسام', best: 'الأكثر مبيعاً', shop: 'تسوّق الآن', view: 'عرض المنتج', all: 'الكل', buyNow: 'اشترِ الآن — الدفع عند الاستلام',
    qty: 'الكمية', descTab: 'الوصف', specTab: 'المواصفات', shipTab: 'التوصيل والاستبدال', related: 'منتجات قد تعجبك', howOrder: 'كيف تطلب؟', policy: 'سياسة الاستبدال',
    chooseOption: 'اختر', sending: 'جاري الإرسال…', outOfStock: 'غير متوفر', call: 'اتصل بنا'
  },
  fr: {
    dir: 'ltr', lang: 'fr', cod: 'Paiement à la livraison', delivery58: 'Livraison dans toutes les wilayas', freeDesk: 'Livraison au bureau gratuite', order: 'Commander',
    orderTitle: 'Commandez — payez à la livraison', orderSub: '4 informations. Vous ne payez rien maintenant.', name: 'Nom complet', namePh: 'Ex. : Mohamed Benali',
    phone: 'Téléphone', wilaya: 'Wilaya', chooseWilaya: 'Choisir la wilaya', commune: 'Commune', chooseCommune: 'Choisir la commune', typeCommune: 'Écrivez votre commune',
    search: 'Rechercher…', desk: 'Bureau de livraison', home: 'À domicile', free: 'Gratuit', total: 'Total à la livraison', confirm: 'Confirmer la commande',
    trust: ['Paiement à la livraison', 'Appel de confirmation', 'Échange garanti'], errName: 'Écrivez votre nom complet', errPhone: '10 chiffres commençant par 05, 06 ou 07',
    errWilaya: 'Choisissez votre wilaya', errCommune: 'Choisissez votre commune', errVariant: 'Choisissez une option', thanks: 'Merci ! Commande reçue', thanksSub: 'Nous vous appelons au {phone} pour confirmer. Gardez votre téléphone allumé.',
    upTitle: 'Offre spéciale avant confirmation', upSub: 'Ajouté au même colis, sans frais de livraison', upYes: 'Oui, ajouter', upNo: 'Non merci', newOrder: 'Nouvelle commande',
    piece: 'pièce', pieces: 'pièces', two: '2 pièces', save: 'Économisez', mostOrdered: 'Le plus commandé', bestValue: 'Meilleur prix', why: 'Pourquoi', seeDiff: 'Voyez la différence',
    before: 'Avant', after: 'Après', drag: 'Glissez pour comparer', vsTitle: 'Nous vs les autres', us: 'Nous', others: 'Autres', reviews: 'Nos clients',
    swipe: 'Glissez pour voir plus', how: 'Utilisation', after1: 'Après votre commande', faq: 'Questions fréquentes', s1: 'Vous remplissez le formulaire', s1t: 'Moins d’une minute',
    s2: 'Nous vous appelons', s3: 'Vous recevez le colis', s4: 'Vous payez à la réception', s4t: 'Après avoir vu le produit', currency: 'DA', error: 'Erreur, réessayez',
    home_: 'Accueil', cats: 'Catégories', best: 'Meilleures ventes', shop: 'Voir les produits', view: 'Voir le produit', all: 'Tout', buyNow: 'Acheter — paiement à la livraison',
    qty: 'Quantité', descTab: 'Description', specTab: 'Caractéristiques', shipTab: 'Livraison et échange', related: 'Vous aimerez aussi', howOrder: 'Comment commander ?', policy: 'Politique d’échange',
    chooseOption: 'Choisir', sending: 'Envoi…', outOfStock: 'Épuisé', call: 'Appelez-nous'
  }
};
T.dz = { ...T.ar };

const money = (n, t) => String(Math.round(n || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' ' + t.currency;
const safeId = (s) => String(s || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 40);
const FONT_URLS = {
  Cairo: 'Cairo:wght@400;600;700;800;900', Tajawal: 'Tajawal:wght@400;500;700;800', Almarai: 'Almarai:wght@400;700;800', 'IBM Plex Sans Arabic': 'IBM+Plex+Sans+Arabic:wght@400;600;700'
};

function hexA(hex, a) {
  const h = String(hex).replace('#', '');
  if (h.length !== 6) return `rgba(15,92,70,${a})`;
  return `rgba(${parseInt(h.slice(0, 2), 16)},${parseInt(h.slice(2, 4), 16)},${parseInt(h.slice(4, 6), 16)},${a})`;
}

function themeCss(th) {
  const r = Math.max(0, Math.min(28, Number(th.radius) || 0));
  return `:root{--p:${th.primary};--a:${th.accent};--ink:${th.ink};--bg:${th.bg};--r:${r}px;--rs:${Math.round(r * 0.65)}px;--p-soft:${hexA(th.primary, 0.12)};--p-faint:${hexA(th.primary, 0.06)};--a-soft:${hexA(th.accent, 0.16)};--font:'${th.font}',system-ui,sans-serif}`;
}

function pixelHead(metaId, tiktokId) {
  let s = '';
  const m = safeId(metaId);
  const t = safeId(tiktokId);
  if (m) s += `<script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','${m}');fbq('track','PageView');</script>`;
  if (t) s += `<script>!function(w,d,t){w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var i="https://analytics.tiktok.com/i18n/pixel/events.js";ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=i,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};var o=d.createElement("script");o.type="text/javascript",o.async=!0,o.src=i+"?sdkid="+e+"&lib="+t;var a=d.getElementsByTagName("script")[0];a.parentNode.insertBefore(o,a)};ttq.load('${t}');ttq.page();}(window,document,'ttq');</script>`;
  return s;
}

function layout({ title, description = '', body, t, theme, store, pixels = {}, image = '', bodyClass = '' }) {
  const fontQ = FONT_URLS[theme.font] || FONT_URLS.Cairo;
  return `<!doctype html>
<html lang="${t.lang}" dir="${t.dir}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(title)}</title>
<meta name="description" content="${esc(description)}">
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(description)}">
${image ? `<meta property="og:image" content="${esc(image)}">` : ''}
<meta name="theme-color" content="${esc(theme.primary)}">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=${fontQ}&display=swap" rel="stylesheet" media="print" onload="this.media='all'">
<link rel="stylesheet" href="/assets/store.css?v=4">
<style>${themeCss(theme)}</style>
${pixelHead(pixels.meta, pixels.tiktok)}
</head>
<body class="${bodyClass}">
${body}
</body>
</html>`;
}

function img(src, alt, cls = '', eager = false) {
  if (!src) return `<div class="ph ${cls}"><span>${esc(alt)}</span></div>`;
  return `<img class="${cls}" src="${esc(src)}" alt="${esc(alt)}" ${eager ? 'fetchpriority="high"' : 'loading="lazy"'} decoding="async">`;
}

const ICON = {
  check: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  x: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  chev: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>',
  phone: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a1 1 0 01-1 1A16 16 0 014 5a1 1 0 011-1z"/></svg>',
  truck: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 7h11v9H3z"/><path d="M14 10h4l3 3v3h-7"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/></svg>',
  cash: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2.5" y="6" width="19" height="12" rx="2"/><circle cx="12" cy="12" r="2.6"/></svg>',
  shield: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/></svg>'
};

// Data the order form script needs (wilayas with fees, offers…)
function formData({ product, landing, t, lang }) {
  const d = getSetting('delivery', CTX.sid);
  const tr = getSetting('tracking', CTX.sid);
  const wilayas = geo.wilayas(d.wilayaMode).map((w) => ({ code: w.code, ar: w.ar, fr: w.fr, desk: deliveryFee(CTX.sid, w.code, 'desk'), home: deliveryFee(CTX.sid, w.code, 'home') })).filter((w) => w.desk !== null || w.home !== null);
  const offers = offersFor(product, t);
  return {
    base: CTX.base, lang, t: pick(t, ['chooseWilaya', 'chooseCommune', 'typeCommune', 'free', 'errName', 'errPhone', 'errWilaya', 'errCommune', 'errVariant', 'thanks', 'thanksSub', 'currency', 'error', 'sending', 'confirm', 'upYes', 'upNo', 'newOrder']),
    productId: product.id, landingId: landing ? landing.id : null, offers, variants: product.variants || [],
    wilayas, deskEnabled: d.deskEnabled !== false, homeEnabled: d.homeEnabled !== false,
    purchaseEvent: tr.purchaseEvent || 'Purchase', upsell: landing && landing.content.upsell ? landing.content.upsell : null, contentName: product.name
  };
}
function pick(o, keys) { const r = {}; keys.forEach((k) => (r[k] = o[k])); return r; }

function offersFor(product, t) {
  let offers = (product.offers || []).filter((o) => o.qty > 0 && o.price > 0).sort((a, b) => a.qty - b.qty);
  if (!offers.length) offers = [{ qty: 1, price: product.price, label: '' }];
  const base = product.price || offers[0].price / offers[0].qty;
  return offers.map((o, i) => {
    const saving = Math.max(0, Math.round(base * o.qty - o.price));
    const label = o.label || (o.qty === 1 ? '1 ' + t.piece : o.qty === 2 && t.lang === 'ar' ? t.two : o.qty + ' ' + t.pieces);
    const ribbon = offers.length > 1 ? (i === 1 ? t.mostOrdered : i === offers.length - 1 && i > 1 ? t.bestValue : '') : '';
    return { qty: o.qty, price: o.price, label, saving, ribbon };
  });
}

function orderForm({ product, landing, t, lang, compact = false }) {
  const data = formData({ product, landing, t, lang });
  const variants = product.variants || [];
  const offers = data.offers;
  const defaultOffer = offers.length > 1 ? offers[1] : offers[0];
  return `
<form class="cod" id="order" novalidate data-cod>
  <div class="cod-step" data-step="form">
    ${compact ? '' : `<div class="cod-head"><h2>${esc(t.orderTitle)}</h2><p>${esc(t.orderSub)}</p></div>`}
    <fieldset class="offers" aria-label="${esc(t.qty)}">
      ${offers.map((o) => `
      <label class="offer${o.qty === defaultOffer.qty ? ' on' : ''}">
        <input type="radio" name="quantity" value="${o.qty}" ${o.qty === defaultOffer.qty ? 'checked' : ''}>
        <span class="dot"></span>
        <span class="offer-txt"><b>${esc(o.label)}</b>${o.saving ? `<small>${esc(t.save)} ${money(o.saving, t)}</small>` : ''}</span>
        <b class="offer-price">${money(o.price, t)}</b>
        ${o.ribbon ? `<span class="ribbon">${esc(o.ribbon)}</span>` : ''}
      </label>`).join('')}
    </fieldset>
    ${variants.length > 1 ? `
    <div class="field"><span class="lbl">${esc(t.chooseOption)}</span>
      <div class="variants" role="radiogroup">
        ${variants.map((v) => `<label class="variant${v.stock <= 0 ? ' off' : ''}"><input type="radio" name="variant" value="${esc(v.name)}" ${v.stock <= 0 ? 'disabled' : ''}>${v.color ? `<span class="sw" style="background:${esc(v.color)}"></span>` : ''}<span>${esc(v.name)}</span></label>`).join('')}
      </div>
      <small class="err" data-err="variant"></small>
    </div>` : ''}
    <label class="field"><span class="lbl">${esc(t.name)}</span>
      <input name="name" autocomplete="name" placeholder="${esc(t.namePh)}" maxlength="80" required>
      <small class="err" data-err="name"></small></label>
    <label class="field"><span class="lbl">${esc(t.phone)}</span>
      <input name="phone" type="tel" inputmode="numeric" dir="ltr" autocomplete="tel" placeholder="05 / 06 / 07 XX XX XX XX" maxlength="14" required>
      <small class="err" data-err="phone"></small></label>
    <div class="field"><span class="lbl">${esc(t.wilaya)}</span>
      <div class="pick" data-pick="wilaya">
        <button type="button" class="pick-btn" aria-haspopup="listbox" aria-expanded="false"><span>${esc(t.chooseWilaya)}</span>${ICON.chev}</button>
        <div class="pick-pop" hidden><input type="search" class="pick-search" placeholder="${esc(t.search)}" aria-label="${esc(t.search)}"><div class="pick-list" role="listbox"></div></div>
      </div>
      <input type="hidden" name="wilaya">
      <small class="err" data-err="wilaya"></small></div>
    <div class="field"><span class="lbl">${esc(t.commune)}</span>
      <div class="pick" data-pick="commune" hidden>
        <button type="button" class="pick-btn" aria-haspopup="listbox" aria-expanded="false"><span>${esc(t.chooseCommune)}</span>${ICON.chev}</button>
        <div class="pick-pop" hidden><input type="search" class="pick-search" placeholder="${esc(t.search)}" aria-label="${esc(t.search)}"><div class="pick-list" role="listbox"></div></div>
      </div>
      <input name="commune" class="commune-input" placeholder="${esc(t.chooseWilaya)}" maxlength="80" autocomplete="address-level2">
      <small class="err" data-err="commune"></small></div>
    <div class="deliv">
      ${data.deskEnabled ? `<label class="dv on"><input type="radio" name="delivery" value="desk" checked><b>${esc(t.desk)}</b><small data-fee="desk">${esc(t.free)}</small></label>` : ''}
      ${data.homeEnabled ? `<label class="dv${data.deskEnabled ? '' : ' on'}"><input type="radio" name="delivery" value="home" ${data.deskEnabled ? '' : 'checked'}><b>${esc(t.home)}</b><small data-fee="home"></small></label>` : ''}
    </div>
    <div class="sum"><b>${esc(t.total)}</b><b class="sum-v" data-total>${money(defaultOffer.price, t)}</b></div>
    <input type="text" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">
    <button type="submit" class="btn btn-xl">${esc(t.confirm)}</button>
    <div class="trust-line">${t.trust.map((x) => `<span>✓ ${esc(x)}</span>`).join('')}</div>
    <p class="form-err" role="alert" hidden></p>
  </div>
  <div class="cod-step done" data-step="done" hidden>
    <div class="done-ic">${ICON.check}</div>
    <h2 data-done-title></h2>
    <p data-done-sub></p>
    ${data.upsell ? `
    <div class="upsell" data-upsell>
      <b>${esc(t.upTitle)}</b>
      <div class="up-row">${data.upsell.image ? img(data.upsell.image, data.upsell.title, 'up-img') : ''}<span><b>${esc(data.upsell.title)}</b><small>${esc(t.upSub)}</small><b class="up-price">+ ${money(data.upsell.price, t)}</b></span></div>
      <div class="up-btns"><button type="button" class="btn" data-up="yes">${esc(t.upYes)}</button><button type="button" class="btn btn-ghost" data-up="no">${esc(t.upNo)}</button></div>
    </div>` : ''}
    <div class="sum"><b>${esc(t.total)}</b><b class="sum-v" data-done-total></b></div>
  </div>
  <script type="application/json" class="cod-data">${JSON.stringify(data).replace(/</g, '\\u003c')}</script>
</form>`;
}

// ---------------- Landing page ----------------
// Algerian image-stack layout: panel 1 → form → remaining panels → reviews → CTA.
function panelLandingPage({ landing, product, theme, store, url }) {
  const t = T[landing.lang] || T.ar;
  const c = landing.content || {};
  const p = (s) => esc(s);
  const price = (offersFor(product, t)[0] || { price: product.price }).price;
  const tall = (type) => type === 'hook' || type === 'offer';
  const panelImg = (x, i) => `<img class="panel" src="${p(x.image)}" alt="${p(x.title || product.name)}" width="1080" height="${tall(x.type) ? 1350 : 1080}" ${i === 0 ? 'fetchpriority="high"' : 'loading="lazy"'} decoding="async">`;
  const panels = c.panels || [];
  const body = `
<div class="lp lp-panels">
  <header class="lp-top"><b class="brand">${theme.logo ? `<img src="${p(theme.logo)}" alt="${p(store.name)}">` : p(store.name)}</b><span class="pill">${p(t.cod)}</span></header>
  ${panels[0] ? panelImg(panels[0], 0) : ''}
  <section class="sec form-wrap" style="padding-top:14px">${orderForm({ product, landing, t, lang: landing.lang })}</section>
  <div class="panels">${panels.slice(1).map((x, i) => panelImg(x, i + 1)).join('')}</div>
  ${(c.review_imgs || []).length ? `<section class="sec"><h2 class="c">${p(t.reviews)}</h2><div class="reviews">${c.review_imgs.map((r) => img(r, t.reviews, 'rev')).join('')}</div></section>` : ''}
  ${(c.faq || []).length ? `<section class="sec"><h2 class="c">${p(t.faq)}</h2>${c.faq.map((f) => `<details class="faq"><summary>${p(f.q)}</summary><p>${p(f.a)}</p></details>`).join('')}</section>` : ''}
  <section class="sec final"><h2>${p(c.final_cta || t.orderTitle)}</h2><a href="#order" class="btn btn-inv">${p(t.order)} · ${money(price, t)}</a></section>
  <footer class="lp-foot"><span>${p(store.name)}${store.phone ? ' · ' + p(store.phone) : ''}</span><span>${p(store.returnPolicy)}</span></footer>
  <div class="sticky"><span><small>${p(t.cod)}</small><b>${money(price, t)}</b></span><a href="#order" class="btn">${p(t.order)}</a></div>
</div>
<script src="/assets/cod.js?v=6" defer></script>`;
  const tr = getSetting('tracking', CTX.sid);
  return layout({
    title: c.headline || product.name, description: c.subheadline || product.short_desc, t, theme, store, body, bodyClass: 'is-lp',
    pixels: { meta: landing.pixel_meta || tr.metaPixel, tiktok: landing.pixel_tiktok || tr.tiktokPixel }, image: panels[0] ? url.origin + panels[0].image : ''
  });
}

function landingPage({ landing, product, theme, store, url }) {
  if (landing.content && landing.content.layout === 'panels' && (landing.content.panels || []).length) return panelLandingPage({ landing, product, theme, store, url });
  const t = T[landing.lang] || T.ar;
  const c = landing.content || {};
  const S = c.sections || {};
  const hero = c.hero_img || product.images[0] || '';
  const price = (offersFor(product, t)[0] || { price: product.price }).price;
  const p = (s) => esc(s);
  const sections = {
    problem: S.problem !== false && c.problem && (c.problem.title || (c.problem.pains || []).length) ? `
<section class="sec dark">
  <h2>${p(c.problem.title)}</h2>
  ${(c.problem.pains || []).map((x) => `<p class="pain">${ICON.x}<span>${p(x)}</span></p>`).join('')}
  ${c.problem.bridge ? `<b class="bridge">${p(c.problem.bridge)}</b>` : ''}
</section>` : '',
    beforeafter: S.beforeafter !== false && c.before_img && c.after_img ? `
<section class="sec">
  <h2 class="c">${p(t.seeDiff)}</h2>
  <div class="ba" dir="ltr" data-ba>
    <img src="${p(c.before_img)}" alt="${p(t.before)}" loading="lazy">
    <div class="ba-after" style="width:50%"><img src="${p(c.after_img)}" alt="${p(t.after)}" loading="lazy"></div>
    <span class="ba-tag l">${p(t.before)}</span><span class="ba-tag r">${p(t.after)}</span>
  </div>
  <input type="range" min="5" max="95" value="50" class="ba-range" aria-label="${p(t.drag)}">
</section>` : '',
    benefits: S.benefits !== false && (c.benefits || []).length ? `
<section class="sec">
  <h2 class="c">${p(t.why)} ${p(product.name)}${t.lang === 'fr' ? ' ?' : '؟'}</h2>
  <div class="grid2">${c.benefits.map((b, i) => `<div class="card"><span class="num">${i + 1}</span><b>${p(b.title)}</b><small>${p(b.text)}</small></div>`).join('')}</div>
  ${c.video ? `<video class="media" src="${p(c.video)}" controls playsinline preload="metadata"></video>` : ''}
  ${(c.gallery || []).length ? `<div class="gal">${c.gallery.map((g) => img(g, product.name, 'media')).join('')}</div>` : ''}
</section>` : '',
    comparison: S.comparison !== false && (c.comparison || []).length ? `
<section class="sec">
  <h2 class="c">${p(t.vsTitle)}</h2>
  <div class="vs"><div class="vs-h"><span></span><span class="us">${p(t.us)}</span><span>${p(t.others)}</span></div>
  ${c.comparison.map((x) => `<div class="vs-r"><span>${p(x)}</span><span class="ok">${ICON.check}</span><span class="no">${ICON.x}</span></div>`).join('')}</div>
</section>` : '',
    reviews: S.reviews !== false && (c.review_imgs || []).length ? `
<section class="sec">
  <h2 class="c">${p(t.reviews)}</h2>
  <div class="reviews">${c.review_imgs.map((r) => img(r, t.reviews, 'rev')).join('')}</div>
  ${c.review_imgs.length > 1 ? `<small class="c muted">${p(t.swipe)}</small>` : ''}
</section>` : '',
    steps: S.steps !== false && (c.steps || []).length ? `
<section class="sec">
  <h2 class="c">${p(t.how)}</h2>
  <div class="steps">${c.steps.map((s, i) => `<div class="step"><span class="num">${i + 1}</span><span><b>${p(s.title)}</b><small>${p(s.text)}</small></span></div>`).join('')}</div>
</section>` : '',
    faq: S.faq !== false && (c.faq || []).length ? `
<section class="sec">
  <h2 class="c">${p(t.faq)}</h2>
  ${c.faq.map((f) => `<details class="faq"><summary>${p(f.q)}</summary><p>${p(f.a)}</p></details>`).join('')}
</section>` : ''
  };
  const form = `<section class="sec form-wrap">${orderForm({ product, landing, t, lang: landing.lang })}</section>`;
  const timeline = `
<section class="sec">
  <h2 class="c">${p(t.after1)}</h2>
  <div class="tl">
    <div><span class="num">1</span><span><b>${p(t.s1)}</b><small>${p(t.s1t)}</small></span></div>
    <div><span class="num">2</span><span><b>${p(t.s2)}</b><small>${p(store.hours)}</small></span></div>
    <div><span class="num">3</span><span><b>${p(t.s3)}</b><small>${p(store.deliveryTime)}</small></span></div>
    <div><span class="num acc">4</span><span><b>${p(t.s4)}</b><small>${p(t.s4t)}</small></span></div>
  </div>
</section>`;
  const order = theme.template === 'minimal'
    ? ['FORM', 'benefits', 'beforeafter', 'reviews', 'comparison', 'steps', 'TIMELINE', 'faq']
    : theme.template === 'bold'
      ? ['FORM', 'benefits', 'beforeafter', 'reviews', 'problem', 'comparison', 'steps', 'TIMELINE', 'faq']
      : ['problem', 'beforeafter', 'benefits', 'comparison', 'reviews', 'FORM', 'TIMELINE', 'steps', 'faq'];
  const bodyParts = order.map((k) => (k === 'FORM' ? form : k === 'TIMELINE' ? timeline : sections[k] || '')).join('');
  const body = `
<div class="lp">
  <header class="lp-top"><b class="brand">${theme.logo ? `<img src="${p(theme.logo)}" alt="${p(store.name)}">` : p(store.name)}</b><span class="pill">${p(t.cod)}</span></header>
  <section class="hero">
    <div class="hero-img">${img(hero, product.name, '', true)}${c.badge ? `<span class="badge">${p(c.badge)}</span>` : ''}
      <div class="chips"><span>${p(t.delivery58)}</span><span>${p(t.freeDesk)}</span></div></div>
  </section>
  <section class="sec intro">
    ${c.hook ? `<span class="hook">${p(c.hook)}</span>` : ''}
    <h1>${p(c.headline || product.name)}</h1>
    ${c.subheadline ? `<p class="sub">${p(c.subheadline)}</p>` : ''}
    ${(c.bullets || []).length ? `<ul class="bul">${c.bullets.map((b) => `<li>${ICON.check}<span>${p(b)}</span></li>`).join('')}</ul>` : ''}
    <div class="price-row"><span>${product.old_price > price ? `<s>${money(product.old_price, t)}</s>` : ''}<b>${money(price, t)}</b></span><a href="#order" class="btn">${p(t.order)}</a></div>
  </section>
  ${bodyParts}
  <section class="sec final"><h2>${p(c.final_cta || t.orderTitle)}</h2><a href="#order" class="btn btn-inv">${p(t.order)} · ${money(price, t)}</a></section>
  <footer class="lp-foot"><span>${p(store.name)}${store.phone ? ' · ' + p(store.phone) : ''}</span><span>${p(store.returnPolicy)}</span></footer>
  <div class="sticky"><span><small>${p(t.cod)}</small><b>${money(price, t)}</b></span><a href="#order" class="btn">${p(t.order)}</a></div>
</div>
<script src="/assets/cod.js?v=6" defer></script>`;
  const tr = getSetting('tracking', CTX.sid);
  return layout({
    title: c.headline || product.name, description: c.subheadline || product.short_desc, t, theme, store, body, bodyClass: 'is-lp',
    pixels: { meta: landing.pixel_meta || tr.metaPixel, tiktok: landing.pixel_tiktok || tr.tiktokPixel }, image: hero ? url.origin + hero : ''
  });
}

// ---------------- Store pages ----------------
function storeHeader(store, theme, t) {
  return `
<div class="ann">${esc(store.announcement)}</div>
<header class="st-head"><div class="wrap st-head-in">
  <a href="${B()}/" class="brand">${theme.logo ? `<img src="${esc(theme.logo)}" alt="${esc(store.name)}">` : esc(store.name)}</a>
  <nav class="st-nav"><a href="${B()}/">${esc(t.home_)}</a><a href="${B()}/#cats">${esc(t.cats)}</a><a href="${B()}/#best">${esc(t.best)}</a></nav>
  <form class="st-search" action="${B()}/" method="get"><input type="search" name="q" placeholder="${esc(t.search)}" aria-label="${esc(t.search)}"></form>
  ${store.phone ? `<a class="btn btn-sm" href="tel:${esc(store.phone)}">${ICON.phone}<span>${esc(t.call)}</span></a>` : ''}
</div></header>`;
}
function storeFooter(store, t) {
  return `<footer class="st-foot"><div class="wrap st-foot-in">
  <div><b>${esc(store.name)}</b><small>${esc(store.tagline)}</small></div>
  <div><b>${esc(t.call)}</b>${store.phone ? `<a href="tel:${esc(store.phone)}">${esc(store.phone)}</a>` : ''}${store.facebook ? `<a href="${esc(store.facebook)}" rel="noopener">Facebook</a>` : ''}${store.instagram ? `<a href="${esc(store.instagram)}" rel="noopener">Instagram</a>` : ''}${store.tiktok ? `<a href="${esc(store.tiktok)}" rel="noopener">TikTok</a>` : ''}</div>
  <div><b>${esc(t.policy)}</b><small>${esc(store.returnPolicy)}</small></div>
</div></footer>`;
}

function productCard(p, t) {
  const price = (offersFor(p, t)[0] || {}).price || p.price;
  return `<a class="pcard" href="${B()}/p/${esc(p.slug)}">${img(p.images[0], p.name, 'pimg')}<b>${esc(p.name)}</b>${p.category ? `<small>${esc(p.category)}</small>` : ''}<span class="pprice"><b>${money(price, t)}</b>${p.old_price > price ? `<s>${money(p.old_price, t)}</s>` : ''}</span><span class="btn btn-sm">${esc(t.view)}</span></a>`;
}

function homePage({ products, theme, store, q, cat }) {
  const t = T.ar;
  const cats = [...new Set(products.map((p) => p.category).filter(Boolean))];
  let list = products;
  if (cat) list = list.filter((p) => p.category === cat);
  if (q) list = list.filter((p) => (p.name + ' ' + p.short_desc).toLowerCase().includes(q.toLowerCase()));
  const body = `
${storeHeader(store, theme, t)}
<main>
<section class="wrap"><div class="st-hero">
  <div class="st-hero-txt"><h1>${esc(store.heroTitle)}</h1><p>${esc(store.heroSub)}</p><a class="btn btn-inv" href="#best">${esc(t.shop)}</a></div>
  <div class="st-hero-img">${img(store.heroImage || (products[0] && products[0].images[0]), store.name, '', true)}</div>
</div></section>
<section class="wrap trust4">
  <div>${ICON.cash}<span><b>${esc(t.cod)}</b></span></div><div>${ICON.truck}<span><b>${esc(t.delivery58)}</b></span></div>
  <div>${ICON.shield}<span><b>${esc(T.ar.trust[2])}</b></span></div><div>${ICON.phone}<span><b>${esc(T.ar.trust[1])}</b></span></div>
</section>
${cats.length ? `<section class="wrap" id="cats"><h2>${esc(t.cats)}</h2><div class="chips-row"><a class="chip${!cat ? ' on' : ''}" href="${B()}/#best">${esc(t.all)}</a>${cats.map((c) => `<a class="chip${cat === c ? ' on' : ''}" href="${B()}/?cat=${encodeURIComponent(c)}#best">${esc(c)}</a>`).join('')}</div></section>` : ''}
<section class="wrap" id="best"><h2>${esc(q ? '"' + q + '"' : t.best)}</h2>
  <div class="pgrid" style="--cols:${Math.max(2, Math.min(5, Number(theme.cols) || 4))}">${list.map((p) => productCard(p, t)).join('') || '<p class="muted">—</p>'}</div>
</section>
<section class="wrap"><h2>${esc(t.howOrder)}</h2><div class="steps3">
  <div><span class="num">1</span><b>${esc(t.s1)}</b><small>${esc(t.s1t)}</small></div><div><span class="num">2</span><b>${esc(t.s2)}</b><small>${esc(store.hours)}</small></div><div><span class="num">3</span><b>${esc(t.s4)}</b><small>${esc(t.s4t)}</small></div>
</div></section>
</main>
${storeFooter(store, t)}`;
  const tr = getSetting('tracking', CTX.sid);
  return layout({ title: store.name + ' — ' + store.tagline, description: store.heroSub, t, theme, store, body, pixels: { meta: tr.metaPixel, tiktok: tr.tiktokPixel } });
}

function productPage({ product, related, theme, store }) {
  const t = T.ar;
  const imgs = product.images.length ? product.images : [''];
  const price = (offersFor(product, t)[0] || {}).price || product.price;
  const body = `
${storeHeader(store, theme, t)}
<main class="wrap">
<nav class="crumbs"><a href="${B()}/">${esc(t.home_)}</a>${product.category ? ` / <a href="${B()}/?cat=${encodeURIComponent(product.category)}#best">${esc(product.category)}</a>` : ''} / <span>${esc(product.name)}</span></nav>
<section class="pp">
  <div class="pp-gal" data-gal>
    <div class="pp-main">${img(imgs[0], product.name, '', true)}</div>
    ${imgs.length > 1 ? `<div class="pp-thumbs">${imgs.map((src, i) => `<button type="button" class="${i === 0 ? 'on' : ''}" data-src="${esc(src)}" aria-label="${i + 1}">${img(src, product.name)}</button>`).join('')}</div>` : ''}
  </div>
  <div class="pp-info">
    <h1>${esc(product.name)}</h1>
    <div class="pprice big"><b>${money(price, t)}</b>${product.old_price > price ? `<s>${money(product.old_price, t)}</s>` : ''}</div>
    ${product.short_desc ? `<p class="sub">${esc(product.short_desc)}</p>` : ''}
    ${orderForm({ product, landing: null, t, lang: 'ar', compact: true })}
  </div>
</section>
<section class="tabs" data-tabs>
  <div class="tab-btns" role="tablist">
    <button type="button" role="tab" aria-selected="true" data-tab="d">${esc(t.descTab)}</button>
    ${product.specs ? `<button type="button" role="tab" aria-selected="false" data-tab="s">${esc(t.specTab)}</button>` : ''}
    <button type="button" role="tab" aria-selected="false" data-tab="x">${esc(t.shipTab)}</button>
  </div>
  <div class="tab-body" data-panel="d">${esc(product.description || product.short_desc || '')}</div>
  ${product.specs ? `<div class="tab-body" data-panel="s" hidden>${esc(product.specs)}</div>` : ''}
  <div class="tab-body" data-panel="x" hidden>${esc(t.delivery58)} · ${esc(store.deliveryTime)}\n${esc(t.freeDesk)}\n${esc(t.cod)}\n${esc(store.returnPolicy)}</div>
</section>
${related.length ? `<section><h2>${esc(t.related)}</h2><div class="pgrid" style="--cols:4">${related.map((p) => productCard(p, t)).join('')}</div></section>` : ''}
</main>
${storeFooter(store, t)}
<script src="/assets/cod.js?v=6" defer></script>`;
  const tr = getSetting('tracking', CTX.sid);
  return layout({ title: product.seo_title || product.name + ' — ' + store.name, description: product.short_desc, t, theme, store, body, pixels: { meta: tr.metaPixel, tiktok: tr.tiktokPixel }, image: product.images[0] || '' });
}

function notFound(theme, store) {
  const t = T.ar;
  return layout({ title: '404', t, theme, store, body: `${storeHeader(store, theme, t)}<main class="wrap" style="padding:64px 16px;text-align:center"><h1>404</h1><p><a href="${B()}/">${esc(t.home_)}</a></p></main>` });
}

module.exports = { setCtx, CTX, layout, esc, T, landingPage, homePage, productPage, notFound, themeCss };
