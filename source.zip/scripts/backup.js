'use strict';
// Usage: npm run backup  → data/backups/store-manual-<date-time>.db
const fs = require('node:fs');
const path = require('node:path');
const { db, DATA_DIR } = require('../src/driver-node');
const dir = path.join(DATA_DIR, 'backups');
fs.mkdirSync(dir, { recursive: true });
const file = path.join(dir, 'store-manual-' + new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.db');
db.exec(`VACUUM INTO '${file.replace(/'/g, "''")}'`);
console.log('Backup saved:', file);
console.log('Photos are inside the database file (older photos: data/uploads).');
