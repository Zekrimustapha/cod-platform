'use strict';
// AI landing page generator: understand the product → plan Algerian-style image panels → generate scene images.
const { getSetting } = require('./db');
const files = require('./files');

// On Cloudflare Workers the platform gets Workers AI as a binding (no token needed).
let AI_BINDING = null;
function setAiBinding(b) { AI_BINDING = b || null; }

const PANEL_TYPES = ['hook', 'problem', 'before_after', 'case', 'features', 'how_to', 'trust', 'offer'];
const PALETTES = {
  health: { primary: '#0F5C46', accent: '#F2A93B', dark: '#0B2A20' },
  beauty: { primary: '#9F1239', accent: '#F9A8D4', dark: '#2A0E17' },
  home: { primary: '#1D4ED8', accent: '#FACC15', dark: '#0F1B3D' },
  kids: { primary: '#EA580C', accent: '#FDE047', dark: '#3A1604' },
  men: { primary: '#1F2937', accent: '#D4A017', dark: '#0B0F14' },
  fashion: { primary: '#111111', accent: '#E8C9A0', dark: '#000000' },
  tech: { primary: '#0E7490', accent: '#A3E635', dark: '#06232B' },
  food: { primary: '#7C2D12', accent: '#F59E0B', dark: '#2B1006' }
};

const LANG_RULE = {
  dz: 'Algerian Darija written in Arabic script, warm and natural like Algerian Facebook sellers (examples of tone: "حاب ترتاح من…؟", "واش كاين داخل…", "جربها وشوف الفرق"). Short punchy lines.',
  ar: 'simple Modern Standard Arabic, warm, short lines, understood by Algerians.',
  fr: 'simple direct French for Algerian buyers, short lines.'
};

function planPrompt({ description, productName, price, lang }) {
  return `You are the best cash-on-delivery landing page strategist in Algeria. Algerian COD landing pages are a vertical stack of 6-9 designed image panels with big Arabic text, viewed on phones from Facebook/TikTok ads. The order form comes right after the first panel.

Product name: ${productName || '(infer from the photo)'}
Price: ${price || '?'} DZD
Seller notes: ${description}

STEP 1 — understand: niche, who buys it (gender, age range, situation), the main pain or desire, the strongest selling angle for Algeria.
STEP 2 — choose the panel sequence that converts best for THIS niche. Allowed panel types: ${PANEL_TYPES.join(', ')}.
- Always start with "hook" and end with "offer". Use 6 to 9 panels.
- Pain / health / restore products: hook, problem, before_after, case (1-3 specific situations), features, how_to, trust, offer.
- Gadgets / home / tools: hook, problem, features, how_to, before_after (optional), trust, offer.
- Beauty: hook, problem, before_after, features (ingredients), how_to, trust, offer.
- Fashion / gifts: hook, features, case (occasions), trust, offer.
STEP 3 — write the text for each panel in ${LANG_RULE[lang] || LANG_RULE.dz}

Hard rules:
- Never invent statistics, numbers of customers, doctors, certifications, medical cure claims, or testimonials/reviews. No customer names.
- No emojis inside titles. Titles max 7 words. Bullets max 6 words each.
- scene_prompt is in ENGLISH for an image AI: describe a realistic photo scene with Algerian / North African people and homes when people appear (modest clothing), the product clearly visible when relevant, natural light, vertical-friendly composition, and ALWAYS end with "no text, no letters, no words, no logos in the image".

Return ONLY JSON:
{
 "product_name": string,
 "niche": one of ${Object.keys(PALETTES).join('|')},
 "audience": {"who": string, "gender": "women|men|all", "age": string},
 "pain_or_desire": string,
 "angle": string,
 "headline": string,
 "seo_title": string,
 "panels": [
   {"type": "hook", "title": string, "highlight": string (one word from title to color), "subtitle": string, "badge": string (2-3 words), "scene_prompt": string},
   {"type": "problem", "title": string, "bullets": [3 strings], "scene_prompt": string},
   {"type": "before_after", "title": string, "before_points": [3], "after_points": [3], "before_scene": string, "after_scene": string},
   {"type": "case", "title": string, "bullets": [3], "scene_prompt": string},
   {"type": "features", "title": string, "bullets": [4-6], "scene_prompt": string},
   {"type": "how_to", "title": string, "steps": [3 short strings]},
   {"type": "trust", "title": string},
   {"type": "offer", "title": string, "subtitle": string, "scene_prompt": string}
 ]
}`;
}

const clean = (v, n = 120) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, n);
const list = (v, n, m = 60) => (Array.isArray(v) ? v : []).slice(0, n).map((x) => clean(typeof x === 'string' ? x : x && (x.title || x.text || x.label), m)).filter(Boolean);

function normalizePlan(j, fallbackName, lang) {
  const niche = PALETTES[j.niche] ? j.niche : 'health';
  let panels = (Array.isArray(j.panels) ? j.panels : []).filter((p) => p && PANEL_TYPES.includes(p.type)).slice(0, 9).map((p) => ({
    type: p.type,
    title: clean(p.title, 70), highlight: clean(p.highlight, 30), subtitle: clean(p.subtitle, 110), badge: clean(p.badge, 30),
    bullets: list(p.bullets, 6), before_points: list(p.before_points, 3), after_points: list(p.after_points, 3), steps: list(p.steps, 3, 70),
    scene_prompt: clean(p.scene_prompt, 600), before_scene: clean(p.before_scene, 600), after_scene: clean(p.after_scene, 600)
  }));
  if (!panels.length || panels[0].type !== 'hook') panels = fallbackPlan({ productName: fallbackName, lang }).panels;
  if (panels[panels.length - 1].type !== 'offer') panels.push(fallbackPlan({ productName: fallbackName, lang }).panels.slice(-1)[0]);
  return {
    product_name: clean(j.product_name || fallbackName, 100), niche, palette: PALETTES[niche],
    audience: { who: clean(j.audience?.who, 120), gender: clean(j.audience?.gender, 10), age: clean(j.audience?.age, 20) },
    pain_or_desire: clean(j.pain_or_desire, 200), angle: clean(j.angle, 200), headline: clean(j.headline, 120), seo_title: clean(j.seo_title, 90), lang, panels
  };
}

function fallbackPlan({ productName, lang, description }) {
  const n = productName || (lang === 'fr' ? 'Le produit' : 'المنتج');
  const fr = lang === 'fr';
  const dz = lang !== 'ar' && !fr;
  const P = (o) => ({ title: '', highlight: '', subtitle: '', badge: '', bullets: [], before_points: [], after_points: [], steps: [], scene_prompt: '', before_scene: '', after_scene: '', ...o });
  const scene = (s) => s + ', realistic photo, natural light, Algerian home, no text, no letters, no words, no logos in the image';
  return {
    product_name: n, niche: 'health', palette: PALETTES.health, audience: { who: '', gender: 'all', age: '' }, pain_or_desire: clean(description, 200), angle: '', headline: n, seo_title: n, lang,
    panels: [
      P({ type: 'hook', title: fr ? 'Enfin une vraie solution' : dz ? 'حاب ترتاح نهائياً؟' : 'هل تبحث عن حل حقيقي؟', highlight: fr ? 'solution' : dz ? 'ترتاح' : 'حل', subtitle: n, badge: fr ? 'Offre limitée' : 'عرض محدود', scene_prompt: scene('a happy relieved person holding the product') }),
      P({ type: 'problem', title: fr ? 'Vous en avez assez ?' : dz ? 'تعبت من هاد المشكل؟' : 'هل تعبت من المشكلة؟', bullets: fr ? ['Ça revient chaque jour', 'Rien ne marche', 'Ça gâche vos journées'] : dz ? ['كل يوم نفس المشكل', 'جربت بزاف وما نفعش', 'راهو مخسرلك راحتك'] : ['المشكلة تتكرر كل يوم', 'جربت حلولاً بلا فائدة', 'تؤثر على راحتك'], scene_prompt: scene('a tired worried person at home') }),
      P({ type: 'before_after', title: fr ? 'Avant / Après' : dz ? 'شوف الفرق' : 'شاهد الفرق', before_points: fr ? ['Gêne', 'Fatigue', 'Stress'] : dz ? ['تعب', 'قلق', 'إزعاج'] : ['تعب', 'قلق', 'إزعاج'], after_points: fr ? ['Confort', 'Énergie', 'Sérénité'] : dz ? ['راحة', 'نشاط', 'ثقة'] : ['راحة', 'نشاط', 'ثقة'], before_scene: scene('a person looking uncomfortable, dim light'), after_scene: scene('the same kind of person smiling, bright light, using the product') }),
      P({ type: 'features', title: fr ? 'Pourquoi ' + n + ' ?' : dz ? 'علاش ' + n + '؟' : 'لماذا ' + n + '؟', bullets: fr ? ['Qualité contrôlée', 'Facile à utiliser', 'Résultat visible', 'Garanti'] : dz ? ['جودة مضمونة', 'ساهل في الاستعمال', 'نتيجة باينة', 'مضمون'] : ['جودة مضمونة', 'سهل الاستعمال', 'نتيجة واضحة', 'مضمون'], scene_prompt: scene('the product on a clean table, premium product photography') }),
      P({ type: 'how_to', title: fr ? 'Comment l’utiliser' : dz ? 'كيفاش تستعملو' : 'طريقة الاستعمال', steps: fr ? ['Ouvrez', 'Appliquez', 'Profitez'] : dz ? ['حلّو', 'استعملو', 'استمتع بالنتيجة'] : ['افتحه', 'استعمله', 'استمتع بالنتيجة'] }),
      P({ type: 'trust', title: fr ? 'Commandez sans risque' : dz ? 'اطلب وانت مرتاح' : 'اطلب بدون مخاطرة' }),
      P({ type: 'offer', title: fr ? 'Offre spéciale' : dz ? 'عرض خاص اليوم' : 'عرض خاص اليوم', subtitle: fr ? 'Paiement à la livraison' : 'الدفع عند الاستلام', scene_prompt: scene('the product hero shot on an elegant background') })
    ]
  };
}

function extractJson(text) {
  const s = String(text || '');
  const a = s.indexOf('{');
  const b = s.lastIndexOf('}');
  if (a < 0 || b < a) throw new Error('AI did not return JSON');
  return JSON.parse(s.slice(a, b + 1));
}

async function textAI(prompt, image) {
  const cfg = getSetting('ai');
  if (cfg.provider === 'gemini') {
    if (!cfg.geminiKey) throw new Error('Add a Gemini API key in Platform → AI keys (super admin)');
    const parts = [{ text: prompt }];
    if (image) parts.push({ inline_data: { mime_type: image.mime, data: image.data } });
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(cfg.geminiModel)}:generateContent?key=${encodeURIComponent(cfg.geminiKey)}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents: [{ parts }], generationConfig: { responseMimeType: 'application/json', temperature: 0.8 } }), signal: AbortSignal.timeout(120000)
    });
    const j = await r.json();
    if (j.error) throw new Error('Gemini: ' + j.error.message);
    return extractJson((j.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join(''));
  }
  if (cfg.provider === 'ollama') {
    const r = await fetch(cfg.ollamaUrl.replace(/\/$/, '') + '/api/chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: cfg.ollamaModel, stream: false, format: 'json', options: { temperature: 0.7 }, messages: [{ role: 'user', content: prompt, images: image ? [image.data] : undefined }] }),
      signal: AbortSignal.timeout(300000)
    });
    if (!r.ok) throw new Error('Ollama HTTP ' + r.status);
    return extractJson((await r.json()).message?.content);
  }
  throw new Error('no-ai');
}

async function analyze({ image, description, productName, price, lang }) {
  lang = ['dz', 'ar', 'fr'].includes(lang) ? lang : getSetting('ai').defaultLang || 'dz';
  try {
    const j = await textAI(planPrompt({ description, productName, price, lang }), image);
    return { plan: normalizePlan(j, productName, lang), provider: getSetting('ai').provider };
  } catch (e) {
    return { plan: fallbackPlan({ productName, lang, description }), provider: 'template', warning: e.message === 'no-ai' ? 'AI text provider is off' : e.message };
  }
}

// Scene image (no text) — the platform draws the Arabic text on top.
async function scene({ prompt, productUrl, aspect = '1:1', storeId = null }) {
  const cfg = getSetting('ai');
  const saveImage = (bytes, ext) => files.saveBytes(storeId, bytes, ext === 'png' ? 'image/png' : 'image/jpeg');
  const saveB64 = (b64, ext) => files.saveBase64(storeId, b64, ext === 'png' ? 'image/png' : 'image/jpeg');
  if (cfg.imageProvider === 'cloudflare') {
    // Free: Cloudflare Workers AI (FLUX schnell, ~10,000 free neurons/day ≈ 130 images). The model cannot see the product photo,
    // so we ask for a clean empty area and the platform composites the real product photo on top.
    const p = String(prompt || '').replace(/no text[^.]*$/i, '').slice(0, 1500) +
      (productUrl ? '. Do NOT show any bottle, jar, box or package; leave a clean empty area in the lower middle where a product will be placed later.' : '') +
      ' Photorealistic, natural light, high detail. No text, no letters, no words, no watermark, no logos.';
    const steps = Math.min(8, Math.max(1, Number(cfg.cfSteps) || 6));
    if (AI_BINDING && !(cfg.cfAccountId && cfg.cfApiToken)) {
      try {
        const out = await AI_BINDING.run(cfg.cfImageModel, { prompt: p, steps });
        const b64 = out && (out.image || out);
        if (!b64 || typeof b64 !== 'string') throw new Error('Workers AI returned no image');
        return saveB64(b64, 'jpg');
      } catch (e) {
        throw new Error(/neuron|limit|quota|429|exceeded/i.test(e.message) ? 'Free daily image limit reached (resets 01:00 Algeria time). Panels use the product photo for now.' : 'Workers AI: ' + e.message);
      }
    }
    if (!cfg.cfAccountId || !cfg.cfApiToken) throw new Error('Add your free Cloudflare Account ID and API token in Platform → AI keys (super admin)');
    const r = await fetch(`https://api.cloudflare.com/client/v4/accounts/${encodeURIComponent(cfg.cfAccountId)}/ai/run/${cfg.cfImageModel}`, {
      method: 'POST', headers: { Authorization: 'Bearer ' + cfg.cfApiToken, 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: p, steps }), signal: AbortSignal.timeout(120000)
    });
    const ct = r.headers.get('content-type') || '';
    if (ct.startsWith('image/')) return saveImage(new Uint8Array(await r.arrayBuffer()), ct.includes('png') ? 'png' : 'jpg');
    const j = await r.json().catch(() => ({}));
    if (!r.ok || j.success === false) {
      const msg = (j.errors && j.errors[0] && j.errors[0].message) || 'HTTP ' + r.status;
      throw new Error(/neuron|limit|quota|429/i.test(msg + r.status) ? 'Free daily image limit reached (resets 01:00 Algeria time). Panels use the product photo for now.' : 'Cloudflare: ' + msg);
    }
    const b64 = j.result && (j.result.image || j.result);
    if (!b64 || typeof b64 !== 'string') throw new Error('Cloudflare returned no image');
    return saveB64(b64, 'jpg');
  }
  const full = String(prompt || '').slice(0, 900) + (productUrl ? ' Use the product from the reference photo exactly as it looks (same packaging, colors and shape).' : '') + ' No text, no letters, no words, no watermark.';
  const prod = await files.read(productUrl);
  if (cfg.imageProvider === 'gemini') {
    if (!cfg.geminiKey) throw new Error('Add a Gemini API key in Platform → AI keys (super admin)');
    const parts = [{ text: full }];
    if (prod) parts.push({ inline_data: { mime_type: prod.mime, data: prod.b64 } });
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(cfg.geminiImageModel)}:generateContent?key=${encodeURIComponent(cfg.geminiKey)}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents: [{ parts }], generationConfig: { responseModalities: ['IMAGE'], imageConfig: { aspectRatio: aspect } } }), signal: AbortSignal.timeout(180000)
    });
    const j = await r.json();
    if (j.error) throw new Error('Gemini image: ' + j.error.message);
    const part = (j.candidates?.[0]?.content?.parts || []).find((p) => p.inlineData || p.inline_data);
    if (!part) throw new Error('Gemini returned no image (try again or change the prompt)');
    const d = part.inlineData || part.inline_data;
    return saveB64(d.data, (d.mimeType || d.mime_type || '').includes('png') ? 'png' : 'jpg');
  }
  if (cfg.imageProvider === 'openai') {
    if (!cfg.openaiKey) throw new Error('Add an OpenAI API key in Platform → AI keys (super admin)');
    let r;
    if (prod) {
      const fd = new FormData();
      fd.append('model', cfg.openaiImageModel);
      fd.append('prompt', full);
      fd.append('size', '1024x1024');
      fd.append('image', new Blob([prod.bytes], { type: prod.mime }), 'product.' + (prod.mime.split('/')[1] || 'jpg'));
      r = await fetch('https://api.openai.com/v1/images/edits', { method: 'POST', headers: { Authorization: 'Bearer ' + cfg.openaiKey }, body: fd, signal: AbortSignal.timeout(180000) });
    } else {
      r = await fetch('https://api.openai.com/v1/images/generations', { method: 'POST', headers: { Authorization: 'Bearer ' + cfg.openaiKey, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: cfg.openaiImageModel, prompt: full, size: '1024x1024' }), signal: AbortSignal.timeout(180000) });
    }
    const j = await r.json();
    if (j.error) throw new Error('OpenAI: ' + j.error.message);
    const b64 = j.data && j.data[0] && j.data[0].b64_json;
    if (!b64) throw new Error('OpenAI returned no image');
    return saveB64(b64, 'png');
  }
  throw new Error('Image AI is off — panels use your product photo');
}

module.exports = { setAiBinding, hasAiBinding: () => !!AI_BINDING, analyze, scene, textAI, PALETTES, PANEL_TYPES, fallbackPlan };
