# COD Platform — Algeria

Your own platform (like YouCan / Ayor) for cash-on-delivery sellers in Algeria: sign-up, one store per seller, product pages, **AI landing pages in Darija**, orders dashboard, Meta Ads profit, profit simulator.
**100% free to run**: no Supabase, no paid database, no npm packages. One SQLite file built into Node.js, in `data/`.

MVP sized for **5–10 stores** (default limit 10, change it in Platform settings).

---

## 0. LIVE NOW — Cloudflare (free, no server, no card)

The platform is deployed on **Cloudflare Workers** (free plan):
- Site: **https://cod-platform.zekrimustapha16.workers.dev** · Dashboard: `/admin`
- Database: **Cloudflare D1** `cod-platform` (Western Europe). All users, stores, orders, settings and photos are stored there.
- Free AI, no keys: **Workers AI** binding — text/vision **Llama 4 Scout** (reads the product photos) + images **FLUX.2 klein 4B** (draws YOUR real product inside the scene). Optional free Gemini key for better Darija.
- Code: private GitHub repo `Zekrimustapha/cod-platform` → every push redeploys automatically (Workers Builds).

Free limits: 100,000 requests/day, D1 5 GB + 5M row reads + 100k row writes/day, ~10,000 AI neurons/day (≈90 FLUX.2 images).
Backups: D1 → Time Travel (restore any minute of the last days) + Platform → Stores → Account & backup → *Full platform database* (JSON).

Update the live site: change the code in `src/` or `public/`, run `node tools/build-worker.js`, upload `dist/worker.js` to the GitHub repo as `worker.js`.
The same code still runs on a PC/VPS with `npm start` (SQLite file in `data/`).

### New in this version
- **Order form builder** (Settings → Order form): show/hide/rename fields, required or not, custom fields (text, list, number), order summary, digits-only phone.
- **Delivery companies** (Settings → Delivery company): Yalidine family (Yalidine, Guepex, Yalitec…), ZR Express (Procolis), EcoTrack couriers (DHD, Conexlog…), Noest. Send orders in one click, tracking number back, “Sync courier status”. Test with your real keys — each company's API can differ slightly.
- **IP blocker**: automatic block after N orders/24 h from one connection (IPv6 /64 range), manual block from an order, Customers → Blocked IPs. Blocked visitors see a normal thank-you page, nothing is saved.
- **Pixels & tracking**: several Meta + TikTok pixels, Snapchat, Google tag, Conversions API / Events API per pixel, test button, and **report Purchase only when confirmed or delivered**.
- **Store themes**: Classic, Bold, Minimal, Boutique (fashion), Market, Fresh — live preview before publishing.
- **AI generator**: niche-aware structures; clothes/shoes/bags use your own photos (up to 7) with fashion panels (look, details collage, sizes).
- Meta Ads sync: clear error messages and 30/90/180/365-day range.
- **Photo-driven AI generator**: upload photos only (notes optional). Llama 4 Scout vision reads up to 3 photos → niche, buyer, angle, panel order, Darija copy. FLUX.2 klein receives your product photo as a reference and puts the real product in every scene (no cut-out pasting). Arabic text is still drawn by the platform (never broken AI letters).

---

## 1. Try it on your computer (5 minutes)

1. Install **Node.js 22 LTS or newer** from https://nodejs.org.
2. Double-click **`start-store.bat`** (Mac/Linux: `npm start`). Keep the window open.
3. Open **http://localhost:3000/admin** → *Create your platform*: platform name, your store name + link, your email + password.
   This first account is the **platform owner (super admin)** and also gets the first store.
4. Home page of the platform: http://localhost:3000 · your store: http://localhost:3000/s/your-link

Updating from the old single-store version: just replace the files and keep `data/`. Your store, orders and settings are migrated automatically into store #1 (link `store`), and old `/l/…` ad links keep working.

---

## 2. How the platform works

| Who | Where | What |
|---|---|---|
| Visitors | `/` | Platform home page (Arabic, mobile-first) with “Create your store” |
| Sellers | `/admin/#signup` | Sign up: store name, store link, name, phone, email, password (+ invite code) |
| Sellers | `/admin` | Their own dashboard — they only ever see their own products, pages, orders, customers, team |
| Customers | `/s/<link>/l/<page>` | Landing page with the COD form (or `<link>.yourdomain` with sub-domains) |
| You | `/admin/#/platform` | All stores, suspend/activate, AI quota per store, reset an owner's password, add a store, platform settings, AI keys, full backup |

**Sign-up modes** (Platform → Platform settings): *Invite code only* (default — give the code to the sellers you choose), *Open*, *Closed*.
A suspended store: its pages show “unavailable” and its team cannot log in; data is kept.

---

## 3. AI landing page generator — free

Seller: AI landing generator → product photo + 2 lines → **Analyze** (niche, audience, pain, best panel order) → edit texts → **Generate images** → **Create landing page**.
Result: 6–9 designed images with Darija text (hook, problem, before/after, situations, benefits, how to use, trust, offer), COD form after the first image, offer cards, sticky button.

The AI keys are **yours** (platform owner), shared by all stores. Setup in **Platform → AI keys (free)**:
1. **Text — Google Gemini free key:** https://aistudio.google.com → *Get API key* → paste.
2. **Images — Cloudflare Workers AI (free):** free account on https://dash.cloudflare.com → *Workers AI* → copy **Account ID**; *My Profile → API Tokens → Create Token → “Workers AI” template* → paste the token.
3. Click **Test text + 1 image**.

Free quota ≈ **130 images/day for the whole platform ≈ 15 landing pages/day**. Each store has an “AI images / day” limit (default 30 ≈ 3–4 pages; yours 300) — set it in Platform → Stores so 10 sellers share fairly. When the quota is used up, pages are still designed with the product photo. Arabic text is always drawn by the platform (never broken AI text).

No keys at all still works: a ready Darija structure + your product photo.
Reviews are never invented: the reviews section only shows real screenshots the seller uploads.

---

## 4. Free 24/7 server (Oracle Cloud Always Free) + Cloudflare

Your PC can host it for tests; for real ads use a free always-on server.

**A. Server (once, ~30 min)**
1. Create an account on https://cloud.oracle.com (card only for identity, Always Free is not charged). Region: Europe (Paris/Marseille/Madrid) for low latency to Algeria.
2. *Compute → Instances → Create*: image **Ubuntu 24.04**, shape **VM.Standard.A1.Flex (ARM) 1 OCPU / 6 GB** (or E2.1.Micro if ARM is unavailable). Download the SSH key.
3. Copy the project to the server (from your PC):
   `scp -r -i key.pem cod-store ubuntu@SERVER_IP:~/`
4. On the server: `ssh -i key.pem ubuntu@SERVER_IP` then
   `cd cod-store && sudo bash deploy/setup-oracle.sh`
   It installs Node 22 + cloudflared and starts the platform as a service (auto-restart, starts on boot). No ports need to be opened.

**B. Public address with Cloudflare Tunnel (free)**
1. A domain on Cloudflare: free one from https://nic.eu.org (approval can take time) or a cheap `.com` (only optional cost).
2. Cloudflare → *Zero Trust → Networks → Tunnels → Create tunnel* → Cloudflared → copy the **Debian** install command → run it on the server.
3. Public hostnames → add `yourdomain` → `http://localhost:3000`, and (for store sub-domains) `*.yourdomain` → `http://localhost:3000`.
   For the wildcard also add a DNS record: `CNAME * → <tunnel-id>.cfargotunnel.com` (proxied).
4. In the dashboard: Platform → Platform settings → **Base domain** = `yourdomain`. Stores become `link.yourdomain` (the `/s/link` addresses keep working).

**Updating the code later:** copy the new files over (never delete `data/`), then `sudo systemctl restart platform`.
Logs: `journalctl -u platform -f`. Off-server backups: see `deploy/backup-to-drive.md`.

---

## 5. Ads & tracking (per store)

- **Pixel:** Settings → Pixels (Meta / TikTok). Each landing page can have its own pixel. Conversions API token for better iOS tracking (deduplicated).
- **Campaign KPIs:** Settings → Integrations → ad account + System User token (`ads_read`) → Ads & profit → Sync.
- **Copy ad link** in Landing pages adds `utm_campaign={{campaign.id}}` → every order is matched to its campaign (cost per delivered order, break-even, profit, Scale / Watch / Cut).

## 6. Daily use

- Orders: status dropdown (New → No answer / Call back → Confirmed → Shipped → Delivered / Returned / Cancelled), bulk, call/WhatsApp, notes, history, CSV for the courier.
- Fake orders: merge same phone within 24 h, blacklist, auto-blacklist after 2 refusals, bot trap, delivery score.
- Abandoned forms → Customers → Abandoned. Team roles: owner, agent, stock, ads (max 15 per store).
- Sellers can download all their data (JSON). You can download the full database.

### Backups
- Automatic: full database copy every day in `data/backups` (last 14).
- **The `data/` folder is the whole business — never delete it.**

Forgot a password: Platform → Stores → *Reset owner password*, or on the server `npm run reset-password -- you@email.com NewPassword123`.

---

## Technical notes

- Node.js ≥ 22.13, zero dependencies (`node:sqlite`, `http`, `crypto`). Env: `PORT` (3000), `HOST`, `DATA_DIR`.
- Multi-store: every table is scoped by `store_id`; every admin query is filtered by the logged-in user's store; tested for cross-store access.
- Store resolution: `<link>.<baseDomain>` → `/s/<link>/…` → legacy root `/l/…` = first store.
- Limits per store: 500 products, 300 landing pages, 15 team members, AI images/day (configurable), 400 uploads/hour.
- Passwords: scrypt; sessions: HttpOnly cookies; admin API only accepts JSON (CSRF-safe); rate limits on login, sign-up (5/h/IP) and order form; prices always recalculated on the server.
- Wilayas: 58 or 69 (2026 reform) per store. Communes (1,541) download automatically on first start.
