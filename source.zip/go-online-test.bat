@echo off
title Store public link (test) - keep this window open
where cloudflared >nul 2>nul
if errorlevel 1 (
  echo.
  echo  cloudflared is not installed. In a terminal run:
  echo      winget install --id Cloudflare.cloudflared
  echo  then run this file again.
  echo.
  pause
  exit /b
)
echo.
echo  Creating a free public https link to your store (for testing).
echo  Look below for a line ending in .trycloudflare.com
echo  This link CHANGES every time you restart. For ads use the permanent setup in README.md.
echo.
cloudflared tunnel --url http://localhost:3000
pause
