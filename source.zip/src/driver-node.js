'use strict';
// Node.js driver: one SQLite file in DATA_DIR (built into Node 22, no install).
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads'); // legacy files from the first version
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(path.join(DATA_DIR, 'store.db'));
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');

const PLATFORM_KEYS = ['ai', 'platform'];
let SCHEMA = '';
const clean = (p) => p.map((v) => (v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : v));

function cols(table) {
  try { return db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name); } catch { return []; }
}

// Migrate a v1 single-store database (no store_id) into store #1 of the platform.
function migrateV1() {
  const old = cols('products');
  if (!old.length || old.includes('store_id')) return false;
  console.log('Migrating database to the multi-store platform format…');
  db.exec('PRAGMA foreign_keys = OFF');
  db.exec('BEGIN');
  try {
    const tables = ['settings', 'users', 'sessions', 'products', 'landings', 'orders', 'abandoned', 'blacklist', 'ad_spend', 'landing_stats'];
    for (const t of tables) if (cols(t).length) db.exec(`ALTER TABLE ${t} RENAME TO ${t}_v1`);
    db.exec(SCHEMA);
    let storeName = 'متجري';
    const st = db.prepare("SELECT value FROM settings_v1 WHERE key = 'store'").get();
    try { if (st) storeName = JSON.parse(st.value).name || storeName; } catch {}
    db.prepare("INSERT INTO stores(id, slug, name, status, ai_daily_images, created_at) VALUES(1, 'store', ?, 'active', 300, ?)").run(storeName, new Date().toISOString());
    for (const r of db.prepare('SELECT key, value FROM settings_v1').all()) {
      if (PLATFORM_KEYS.includes(r.key)) db.prepare('INSERT OR REPLACE INTO settings(key, value) VALUES(?, ?)').run(r.key, r.value);
      else db.prepare('INSERT OR REPLACE INTO store_settings(store_id, key, value) VALUES(1, ?, ?)').run(r.key, r.value);
    }
    const copy = (t, extra = 'store_id', val = '1') => {
      const oc = cols(t + '_v1');
      if (!oc.length) return;
      const nc = cols(t).filter((c) => oc.includes(c));
      db.exec(`INSERT INTO ${t}(${extra ? extra + ',' : ''}${nc.join(',')}) SELECT ${extra ? val + ',' : ''}${nc.join(',')} FROM ${t}_v1`);
    };
    copy('users');
    db.exec("UPDATE users SET is_super = 1 WHERE id = (SELECT MIN(id) FROM users WHERE role = 'owner')");
    copy('products'); copy('landings'); copy('orders'); copy('abandoned'); copy('blacklist'); copy('ad_spend');
    copy('landing_stats', '', '');
    for (const t of tables) if (cols(t + '_v1').length) db.exec(`DROP TABLE ${t}_v1`);
    db.exec('COMMIT');
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  } finally {
    db.exec('PRAGMA foreign_keys = ON');
  }
  return true;
}


const driver = {
  kind: 'node',
  raw: db,
  async get(sql, p) { return db.prepare(sql).get(...clean(p)); },
  async all(sql, p) { return db.prepare(sql).all(...clean(p)); },
  async run(sql, p) { const r = db.prepare(sql).run(...clean(p)); return { changes: Number(r.changes), lastInsertRowid: Number(r.lastInsertRowid) }; },
  async exec(sql) { db.exec(sql); },
  async migrate(schema) { SCHEMA = schema; migrateV1(); }
};

module.exports = { driver, db, DATA_DIR, UPLOAD_DIR };
