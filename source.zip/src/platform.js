'use strict';
// Platform-level public pages (marketing home, store unavailable).
const { getSetting } = require('./db');
const { esc } = require('./util');

const CSS = `
:root{--p:#0F5C46;--a:#F2A93B;--ink:#15201B;--bg:#F7F6F2;--card:#fff;--line:#e6e3da;--mut:#5b665f}
*{box-sizing:border-box}html,body{margin:0;overflow-x:hidden}body{font-family:Cairo,system-ui,sans-serif;background:var(--bg);color:var(--ink);line-height:1.6}
a{color:inherit}.wrap{max-width:1080px;margin:0 auto;padding:0 16px}
.top{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 0}
.logo{font-weight:800;font-size:20px;text-decoration:none;display:flex;align-items:center;gap:8px}
.logo i{width:30px;height:30px;border-radius:9px;background:var(--p);display:inline-grid;place-items:center;color:#fff;font-style:normal;font-size:16px}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:46px;padding:0 20px;border-radius:12px;background:var(--p);color:#fff;text-decoration:none;font-weight:700;border:0;font-family:inherit;font-size:15px}
.btn.ghost{background:transparent;color:var(--ink);border:1.5px solid var(--line)}.btn.acc{background:var(--a);color:#1d1400}
.hero{padding:34px 0 26px;text-align:center}.hero h1{font-size:clamp(28px,7vw,48px);line-height:1.25;margin:0 0 12px}
.hero h1 em{font-style:normal;color:var(--p)}.hero p{font-size:clamp(16px,4.2vw,19px);color:var(--mut);margin:0 auto 22px;max-width:620px}
.cta{display:flex;gap:10px;justify-content:center;flex-wrap:wrap}
.chips{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:18px}.chips span{background:#fff;border:1px solid var(--line);border-radius:99px;padding:4px 12px;font-size:13px;color:var(--mut)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px;margin:26px 0}
.card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:18px}.card b{display:block;font-size:17px;margin-bottom:4px}.card small{color:var(--mut);font-size:14px}
.card .ic{width:40px;height:40px;border-radius:12px;background:#e7f1ec;color:var(--p);display:grid;place-items:center;font-size:20px;margin-bottom:10px}
h2{font-size:clamp(22px,5.4vw,30px);text-align:center;margin:40px 0 6px}.sub{text-align:center;color:var(--mut);margin:0 0 10px}
.steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin:20px 0}
.steps div{background:#fff;border:1px solid var(--line);border-radius:16px;padding:16px;position:relative}.steps .n{width:30px;height:30px;border-radius:50%;background:var(--a);display:grid;place-items:center;font-weight:800;margin-bottom:6px}
.band{background:var(--p);color:#fff;border-radius:22px;padding:28px 18px;text-align:center;margin:40px 0}.band h2{margin:0 0 8px;color:#fff}.band p{opacity:.85;margin:0 0 18px}
footer{color:var(--mut);font-size:13px;text-align:center;padding:24px 0 40px}
.mid{min-height:70vh;display:grid;place-items:center;text-align:center;padding:30px 16px}
`;

function shell(title, body, desc = '') {
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>${esc(title)}</title><meta name="description" content="${esc(desc)}"><meta name="theme-color" content="#0F5C46">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet" media="print" onload="this.media='all'">
<style>${CSS}</style></head><body>${body}</body></html>`;
}

function homePage() {
  const P = getSetting('platform');
  const name = esc(P.name);
  const signup = P.signupMode !== 'closed';
  const feats = [
    ['✨', 'مولّد صفحات الهبوط بالذكاء الاصطناعي', 'ارفع صورة المنتج وسطرين وصف، يخرج لك صفحة بالدارجة: صور مصممة، عرض، فورم الطلب.'],
    ['📝', 'فورم الدفع عند الاستلام', 'الاسم، الهاتف، الولاية والبلدية (58 أو 69 ولاية)، مكتب أو منزل، عروض الكمية.'],
    ['📦', 'إدارة الطلبيات', 'حالة كل طلب بقائمة واحدة، اتصال وواتساب، كشف الطلبات المزيفة، تصدير لشركة التوصيل.'],
    ['📊', 'أرباح الإعلانات', 'ربط Meta Ads: تكلفة الطلب المسلّم، نقطة التعادل، الربح الصافي لكل حملة.'],
    ['🧮', 'حاسبة الأرباح', 'محاكي أرباح COD الجزائري مدمج في لوحة التحكم.'],
    ['🎨', 'تصميم متجرك', 'ألوان، خط، شعار، قوالب صفحات — بدون برمجة.']
  ];
  const body = `<div class="wrap">
<header class="top"><a class="logo" href="/"><i>◆</i>${name}</a><nav style="display:flex;gap:8px"><a class="btn ghost" href="/admin/">دخول</a>${signup ? '<a class="btn" href="/admin/#signup">أنشئ متجرك</a>' : ''}</nav></header>
<section class="hero">
  <h1>متجرك للدفع عند الاستلام<br><em>وصفحات هبوط تبيع</em> في دقائق</h1>
  <p>${esc(P.tagline)}. منصة جزائرية: متجر، صفحات هبوط بالذكاء الاصطناعي، طلبيات، وأرباح إعلاناتك في مكان واحد.</p>
  <div class="cta">${signup ? '<a class="btn acc" href="/admin/#signup">ابدأ مجاناً</a>' : ''}<a class="btn ghost" href="/admin/">لديّ حساب</a></div>
  <div class="chips"><span>مجاني في الفترة التجريبية</span><span>58 / 69 ولاية</span><span>بالدارجة والعربية والفرنسية</span></div>
</section>
<div class="grid">${feats.map((f) => `<div class="card"><div class="ic">${f[0]}</div><b>${esc(f[1])}</b><small>${esc(f[2])}</small></div>`).join('')}</div>
<h2>كيف تبدأ؟</h2><p class="sub">ثلاث خطوات وتكون صفحتك جاهزة للإعلان</p>
<div class="steps"><div><span class="n">1</span><b>أنشئ حسابك</b><br><small>اسم المتجر ورابطه.</small></div><div><span class="n">2</span><b>أضف منتجك</b><br><small>صورة، سعر، عروض.</small></div><div><span class="n">3</span><b>ولّد صفحة الهبوط</b><br><small>وانسخ رابط الإعلان.</small></div></div>
<section class="band"><h2>جاهز تبيع؟</h2><p>${P.signupMode === 'invite' ? 'التسجيل حالياً بكود دعوة — اطلبه منا.' : 'أنشئ متجرك الآن.'}</p>${signup ? '<a class="btn acc" href="/admin/#signup">أنشئ متجرك</a>' : ''}
${P.supportPhone ? `<p style="margin-top:14px">واتساب: <a href="https://wa.me/${esc(String(P.supportPhone).replace(/\D/g, '').replace(/^0/, '213'))}" style="color:#fff">${esc(P.supportPhone)}</a></p>` : ''}</section>
<footer>© ${new Date().getFullYear()} ${name}</footer></div>`;
  return shell(P.name + ' — ' + P.tagline, body, P.tagline);
}

function unavailable() {
  const P = getSetting('platform');
  return shell('غير متاح', `<div class="mid"><div><h1 style="margin:0 0 8px">هذا المتجر غير متاح حالياً</h1><p style="color:var(--mut)">Cette boutique est momentanément indisponible.</p><a class="btn ghost" href="/">${esc(P.name)}</a></div></div>`);
}

function notFound() {
  const P = getSetting('platform');
  return shell('404', `<div class="mid"><div><h1 style="margin:0 0 8px">404</h1><a class="btn ghost" href="/">${esc(P.name)}</a></div></div>`);
}

module.exports = { homePage, unavailable, notFound };
