'use strict';
const { D } = require('./db');

// 58 historic wilayas (codes still used by most couriers).
const W58 = [
  ['01', 'أدرار', 'Adrar'], ['02', 'الشلف', 'Chlef'], ['03', 'الأغواط', 'Laghouat'], ['04', 'أم البواقي', 'Oum El Bouaghi'], ['05', 'باتنة', 'Batna'],
  ['06', 'بجاية', 'Béjaïa'], ['07', 'بسكرة', 'Biskra'], ['08', 'بشار', 'Béchar'], ['09', 'البليدة', 'Blida'], ['10', 'البويرة', 'Bouira'],
  ['11', 'تمنراست', 'Tamanrasset'], ['12', 'تبسة', 'Tébessa'], ['13', 'تلمسان', 'Tlemcen'], ['14', 'تيارت', 'Tiaret'], ['15', 'تيزي وزو', 'Tizi Ouzou'],
  ['16', 'الجزائر', 'Alger'], ['17', 'الجلفة', 'Djelfa'], ['18', 'جيجل', 'Jijel'], ['19', 'سطيف', 'Sétif'], ['20', 'سعيدة', 'Saïda'],
  ['21', 'سكيكدة', 'Skikda'], ['22', 'سيدي بلعباس', 'Sidi Bel Abbès'], ['23', 'عنابة', 'Annaba'], ['24', 'قالمة', 'Guelma'], ['25', 'قسنطينة', 'Constantine'],
  ['26', 'المدية', 'Médéa'], ['27', 'مستغانم', 'Mostaganem'], ['28', 'المسيلة', "M'Sila"], ['29', 'معسكر', 'Mascara'], ['30', 'ورقلة', 'Ouargla'],
  ['31', 'وهران', 'Oran'], ['32', 'البيض', 'El Bayadh'], ['33', 'إليزي', 'Illizi'], ['34', 'برج بوعريريج', 'Bordj Bou Arréridj'], ['35', 'بومرداس', 'Boumerdès'],
  ['36', 'الطارف', 'El Tarf'], ['37', 'تندوف', 'Tindouf'], ['38', 'تيسمسيلت', 'Tissemsilt'], ['39', 'الوادي', 'El Oued'], ['40', 'خنشلة', 'Khenchela'],
  ['41', 'سوق أهراس', 'Souk Ahras'], ['42', 'تيبازة', 'Tipaza'], ['43', 'ميلة', 'Mila'], ['44', 'عين الدفلى', 'Aïn Defla'], ['45', 'النعامة', 'Naâma'],
  ['46', 'عين تموشنت', 'Aïn Témouchent'], ['47', 'غرداية', 'Ghardaïa'], ['48', 'غليزان', 'Relizane'], ['49', 'تيميمون', 'Timimoun'], ['50', 'برج باجي مختار', 'Bordj Badji Mokhtar'],
  ['51', 'أولاد جلال', 'Ouled Djellal'], ['52', 'بني عباس', 'Béni Abbès'], ['53', 'عين صالح', 'In Salah'], ['54', 'عين قزام', 'In Guezzam'], ['55', 'تقرت', 'Touggourt'],
  ['56', 'جانت', 'Djanet'], ['57', 'المغير', "El M'Ghair"], ['58', 'المنيعة', 'El Meniaa']
];

// 11 wilayas created in the 69-wilaya reform (Journal officiel 2026). Parent = wilaya they were split from.
// Verify names/numbers against your courier before switching the store to 69 mode.
const W_NEW = [
  ['59', 'أفلو', 'Aflou', '03'], ['60', 'بريكة', 'Barika', '05'], ['61', 'القنطرة', 'El Kantara', '07'], ['62', 'بئر العاتر', 'Bir El Ater', '12'],
  ['63', 'العريشة', 'El Aricha', '13'], ['64', 'قصر الشلالة', 'Ksar Chellala', '14'], ['65', 'عين وسارة', 'Aïn Oussera', '17'], ['66', 'مسعد', 'Messaad', '17'],
  ['67', 'قصر البخاري', 'Ksar El Boukhari', '26'], ['68', 'بوسعادة', 'Bou Saâda', '28'], ['69', 'الأبيض سيدي الشيخ', 'El Abiodh Sidi Cheikh', '32']
];

function wilayas(mode = 58) {
  const list = W58.map(([code, ar, fr]) => ({ code, ar, fr, parent: code }));
  if (Number(mode) === 69) W_NEW.forEach(([code, ar, fr, parent]) => list.push({ code, ar, fr, parent }));
  return list;
}

function wilayaByCode(code, mode = 69) {
  return wilayas(mode).find((w) => w.code === String(code).padStart(2, '0')) || null;
}

const COMMUNES_URL = 'https://raw.githubusercontent.com/othmanus/algeria-cities/master/json/algeria_cities.json';
let communes = null;
let lastTry = 0;

// Communes are downloaded once and kept in the database (meta table).
async function loadCommunes() {
  if (communes && Object.keys(communes).length) return communes;
  const row = await D.get("SELECT value FROM meta WHERE key = 'communes'");
  try { communes = row ? JSON.parse(row.value) : {}; } catch { communes = {}; }
  if (!Object.keys(communes).length && Date.now() - lastTry > 10 * 60e3) { lastTry = Date.now(); try { await downloadCommunes(); } catch (e) { console.log('Communes download failed:', e.message); } }
  return communes;
}

async function downloadCommunes() {
  const r = await fetch(COMMUNES_URL, { signal: AbortSignal.timeout(20000) });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  const rows = await r.json();
  const out = {};
  for (const x of rows) {
    const code = String(x.wilaya_code).padStart(2, '0');
    (out[code] = out[code] || []).push({ ar: String(x.commune_name || '').trim(), fr: String(x.commune_name_ascii || '').trim() });
  }
  for (const k of Object.keys(out)) out[k].sort((a, b) => a.ar.localeCompare(b.ar, 'ar'));
  await D.run("INSERT INTO meta(key, value) VALUES('communes', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", JSON.stringify(out));
  communes = out;
  return Object.values(out).reduce((a, b) => a + b.length, 0);
}

async function communesFor(code) {
  const all = await loadCommunes();
  const w = wilayaByCode(code);
  if (!w) return [];
  return all[w.parent] || [];
}

async function communesCount() {
  return Object.values(await loadCommunes()).reduce((a, b) => a + b.length, 0);
}

module.exports = { wilayas, wilayaByCode, communesFor, loadCommunes, downloadCommunes, communesCount };
