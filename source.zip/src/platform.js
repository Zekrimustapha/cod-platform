'use strict';
// Platform-level public pages (marketing home, store unavailable).
const { getSetting } = require('./db');
const { esc } = require('./util');

const CSS = `
:root{--p:#047857;--p2:#065F46;--p3:#D1FAE5;--pf:#ECFDF5;--a:#F59E0B;--a2:#FBBF24;--ink:#0B1411;--ink2:#1F2A25;--mut:#56635C;--line:#E3E8E4;--bg:#F6F8F6;--card:#fff;--dark:#07110D;--r:20px}
*{box-sizing:border-box}html{scroll-behavior:smooth;-webkit-text-size-adjust:100%}html,body{margin:0;overflow-x:hidden}
body{font-family:'IBM Plex Sans Arabic',Rubik,system-ui,sans-serif;background:var(--bg);color:var(--ink);line-height:1.65;font-size:16px}
h1,h2,h3,.disp{font-family:Rubik,'IBM Plex Sans Arabic',system-ui,sans-serif;letter-spacing:-.2px}
a{color:inherit}img{max-width:100%}
.wrap{max-width:1160px;margin:0 auto;padding:0 20px}
:focus-visible{outline:3px solid var(--a);outline-offset:3px;border-radius:10px}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:48px;padding:0 22px;border-radius:14px;background:var(--p);color:#fff;text-decoration:none;font-weight:700;border:0;font-family:inherit;font-size:16px;cursor:pointer;transition:background .2s,transform .15s,box-shadow .2s}
.btn:hover{background:var(--p2)}.btn:active{transform:scale(.98)}
.btn.acc{background:var(--a);color:#1B1300;box-shadow:0 10px 30px -8px rgba(245,158,11,.55)}.btn.acc:hover{background:var(--a2)}
.btn.ghost{background:transparent;color:inherit;border:1.5px solid currentColor;border-color:rgba(127,140,133,.45)}.btn.ghost:hover{background:rgba(127,140,133,.12)}
.btn.big{min-height:56px;padding:0 28px;font-size:17px;border-radius:16px}
.btn svg{width:18px;height:18px}
/* nav */
.top{position:sticky;top:0;z-index:30;background:rgba(7,17,13,.78);backdrop-filter:saturate(1.6) blur(14px);-webkit-backdrop-filter:saturate(1.6) blur(14px);border-bottom:1px solid rgba(255,255,255,.08);color:#fff}
.top .wrap{display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:68px}
.logo{font-weight:800;font-size:20px;text-decoration:none;display:flex;align-items:center;gap:10px;font-family:Rubik,sans-serif}
.logo i{width:34px;height:34px;border-radius:11px;background:linear-gradient(135deg,#10B981,#047857);display:inline-grid;place-items:center;color:#fff;font-style:normal;box-shadow:inset 0 1px 0 rgba(255,255,255,.3)}
.logo i svg{width:18px;height:18px}
.nav{display:none;gap:28px;font-weight:500;font-size:15px}.nav a{text-decoration:none;color:rgba(255,255,255,.72);transition:color .2s}.nav a:hover{color:#fff}
.row{display:flex;gap:10px;align-items:center}
.top .btn{min-height:42px;padding:0 16px;font-size:15px;border-radius:12px}
.top .btn.ghost{color:#fff;border-color:rgba(255,255,255,.22)}
/* hero */
.hero{position:relative;background:var(--dark);color:#fff;overflow:hidden;margin-top:-69px;padding-top:69px}
.hero:before{content:"";position:absolute;inset:0;background:radial-gradient(60% 55% at 85% 10%,rgba(16,185,129,.35),transparent 70%),radial-gradient(45% 45% at 5% 90%,rgba(245,158,11,.18),transparent 70%)}
.hero:after{content:"";position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.05) 1px,transparent 1px);background-size:44px 44px;mask-image:radial-gradient(70% 60% at 50% 30%,#000,transparent 80%);-webkit-mask-image:radial-gradient(70% 60% at 50% 30%,#000,transparent 80%)}
.hero .wrap{position:relative;z-index:1;display:grid;gap:44px;align-items:center;padding-top:44px;padding-bottom:64px}
.kicker{display:inline-flex;align-items:center;gap:8px;background:rgba(16,185,129,.14);border:1px solid rgba(16,185,129,.35);color:#6EE7B7;font-weight:600;font-size:13px;padding:6px 14px;border-radius:99px;margin-bottom:18px}
.kicker b{width:7px;height:7px;border-radius:50%;background:#34D399;box-shadow:0 0 0 4px rgba(52,211,153,.2)}
.hero h1{font-size:clamp(34px,8.4vw,62px);line-height:1.15;margin:0 0 18px;font-weight:800}
.hero h1 em{font-style:normal;background:linear-gradient(90deg,#34D399,#FBBF24);-webkit-background-clip:text;background-clip:text;color:transparent}
.hero p.lead{font-size:clamp(16px,4.2vw,19px);color:rgba(255,255,255,.72);margin:0 0 28px;max-width:560px}
.cta{display:flex;gap:12px;flex-wrap:wrap}
.ticks{list-style:none;padding:0;margin:26px 0 0;display:flex;gap:10px 20px;flex-wrap:wrap;color:rgba(255,255,255,.66);font-size:14px}
.ticks li{display:flex;align-items:center;gap:6px}.ticks svg{width:16px;height:16px;color:#34D399}
.hero-vis{position:relative;display:grid;place-items:center;padding:10px 0}
.phone{width:272px;height:556px;border-radius:44px;background:#0d0f0e;padding:11px;box-shadow:0 0 0 1px rgba(255,255,255,.12),0 40px 80px -20px rgba(0,0,0,.7),0 0 120px -20px rgba(16,185,129,.45);position:relative}
.phone:before{content:"";position:absolute;top:18px;left:50%;transform:translateX(-50%);width:84px;height:22px;border-radius:20px;background:#0d0f0e;z-index:2}
.scr{width:100%;height:100%;border-radius:34px;background:#fff;overflow:hidden;display:flex;flex-direction:column;color:var(--ink)}
.m-top{display:flex;justify-content:space-between;align-items:center;padding:38px 14px 10px;font-size:11px}.m-top b{font-size:13px}.m-top span{border:1px solid var(--p);color:var(--p);border-radius:99px;padding:1px 8px;font-weight:600}
.m-hero{height:206px;margin:0 10px;border-radius:18px;background:linear-gradient(160deg,#0b2a20,#047857 60%,#10B981);color:#fff;padding:14px;position:relative;display:flex;flex-direction:column;justify-content:flex-end;overflow:hidden}
.m-hero:after{content:"";position:absolute;width:150px;height:150px;border-radius:50%;background:rgba(255,255,255,.12);top:-40px;left:-30px}
.m-hero b{font-size:22px;line-height:1.3;font-family:Rubik,sans-serif;position:relative;z-index:1}
.m-badge{position:absolute;top:12px;inset-inline-start:12px;background:var(--a);color:#1B1300;font-size:10px;font-weight:800;padding:3px 9px;border-radius:99px;z-index:1}
.m-form{padding:12px 10px;display:grid;gap:7px}.m-offer{display:flex;justify-content:space-between;align-items:center;border:1.5px solid var(--line);border-radius:12px;padding:8px 10px;font-size:12px}.m-offer.on{border-color:var(--p);background:var(--pf)}
.m-offer b{color:var(--p)}.m-form i{height:30px;border:1px solid var(--line);border-radius:10px;background:#FAFBFA}
.m-btn{background:var(--p);color:#fff;text-align:center;border-radius:12px;padding:10px;font-weight:800;font-size:13px;margin-top:2px}
.float{position:absolute;background:rgba(255,255,255,.96);color:var(--ink);border-radius:16px;padding:10px 14px;font-size:13px;font-weight:600;box-shadow:0 20px 40px -10px rgba(0,0,0,.45);display:flex;gap:10px;align-items:center;animation:bob 6s ease-in-out infinite}
.float i{width:30px;height:30px;border-radius:10px;display:grid;place-items:center;flex:0 0 30px}.float i svg{width:16px;height:16px}
.float small{display:block;color:var(--mut);font-weight:500;font-size:11px}
.f1{top:54px;inset-inline-end:-6px}.f1 i{background:var(--p3);color:var(--p)}
.f2{bottom:96px;inset-inline-start:-10px;animation-delay:-2s}.f2 i{background:#FEE2E2;color:#B91C1C}
.f3{bottom:12px;inset-inline-end:4px;animation-delay:-4s}.f3 i{background:#FEF3C7;color:#B45309}
@keyframes bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
/* logos */
.logos{display:flex;gap:12px 34px;flex-wrap:wrap;justify-content:center;align-items:center;padding:26px 0;color:var(--mut);font-size:14px;border-bottom:1px solid var(--line)}
.logos b{color:var(--ink2);font-size:17px;font-weight:700;opacity:.55;font-family:Rubik,sans-serif;letter-spacing:.2px;direction:ltr}
/* sections */
.sec{padding:76px 0 0}
.eyebrow{display:inline-block;color:var(--p);font-weight:700;font-size:14px;margin-bottom:10px}
.sh{max-width:680px;margin:0 auto 36px;text-align:center}
.sh h2{font-size:clamp(26px,6vw,40px);line-height:1.25;margin:0 0 12px;font-weight:800}
.sh p{color:var(--mut);margin:0;font-size:17px}
/* bento */
.bento{display:grid;gap:16px;grid-template-columns:1fr}
.tile{background:var(--card);border:1px solid var(--line);border-radius:var(--r);padding:24px;position:relative;overflow:hidden;transition:border-color .2s,box-shadow .25s,transform .25s}
.tile:hover{border-color:#C9D6CF;box-shadow:0 24px 50px -28px rgba(4,120,87,.35);transform:translateY(-2px)}
.tile h3{font-size:19px;margin:14px 0 6px;font-weight:700}.tile p{margin:0;color:var(--mut);font-size:15px}
.ic{width:46px;height:46px;border-radius:14px;background:var(--pf);color:var(--p);display:grid;place-items:center;border:1px solid var(--p3)}.ic svg{width:22px;height:22px}
.tile.big{background:linear-gradient(160deg,#052e22,#047857);color:#fff;border:0}.tile.big p{color:rgba(255,255,255,.75)}.tile.big .ic{background:rgba(255,255,255,.12);color:#fff;border-color:rgba(255,255,255,.2)}
.panels-demo{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:20px}
.pd{border-radius:14px;padding:12px 10px;aspect-ratio:4/5;display:flex;flex-direction:column;justify-content:flex-end;gap:2px;font-size:12px;box-shadow:0 10px 24px -10px rgba(0,0,0,.5)}.pd b{font-size:14px;line-height:1.3;font-family:Rubik,sans-serif}
.p1{background:linear-gradient(170deg,#3b3b3b,#111);color:#fff}.p2{background:linear-gradient(170deg,#fde68a,#f59e0b);color:#1B1300}.p3{background:#fff;color:var(--ink);border:2px solid var(--a)}
.p3 em{font-style:normal;color:var(--p);font-weight:800;font-size:15px}
.chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:16px}.chips span{font-size:12px;font-weight:600;padding:5px 10px;border-radius:99px;background:var(--bg);border:1px solid var(--line);direction:ltr}
.log{margin-top:16px;display:grid;gap:6px;font-size:12px;font-family:ui-monospace,Menlo,monospace;direction:ltr}
.log span{display:flex;justify-content:space-between;gap:8px;background:var(--bg);border-radius:10px;padding:7px 10px}.log em{font-style:normal;font-weight:700}.log .no{color:#B91C1C}.log .ok{color:var(--p)}
.minibars{display:flex;align-items:flex-end;gap:6px;height:74px;margin-top:18px}.minibars i{flex:1;border-radius:6px 6px 2px 2px;background:var(--p3)}.minibars i.on{background:var(--p)}
.statrow{display:flex;justify-content:space-between;margin-top:12px;font-size:13px;color:var(--mut)}.statrow b{display:block;color:var(--ink);font-size:20px;font-family:Rubik,sans-serif}
/* stats */
.stats{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-top:16px}
.stat{background:var(--card);border:1px solid var(--line);border-radius:var(--r);padding:20px;text-align:center}
.stat b{display:block;font-size:clamp(28px,7vw,40px);font-family:Rubik,sans-serif;color:var(--p);line-height:1.1;direction:ltr}
.stat span{color:var(--mut);font-size:14px}
/* steps */
.steps{display:grid;gap:14px;counter-reset:s}
.step{background:var(--card);border:1px solid var(--line);border-radius:var(--r);padding:24px;position:relative}
.step .n{width:40px;height:40px;border-radius:12px;background:var(--ink);color:#fff;display:grid;place-items:center;font-weight:800;font-family:Rubik,sans-serif;margin-bottom:14px}
.step h3{margin:0 0 4px;font-size:18px}.step p{margin:0;color:var(--mut);font-size:15px}
/* compare */
.cmp{background:var(--card);border:1px solid var(--line);border-radius:var(--r);overflow:hidden}
.cmp-h,.cmp-r{display:grid;grid-template-columns:1fr 88px 104px;gap:8px;padding:14px 18px;align-items:center}
.cmp-h{background:var(--ink);color:#fff;font-weight:700;font-size:14px}.cmp-h .us{color:#6EE7B7}
.cmp-r{border-top:1px solid var(--line);font-size:15px}.cmp-r>span:not(:first-child){text-align:center}
.yes,.no2{width:28px;height:28px;border-radius:50%;display:inline-grid;place-items:center}.yes{background:var(--p3);color:var(--p)}.no2{background:#FEE2E2;color:#B91C1C}.yes svg,.no2 svg{width:15px;height:15px}
.meh{color:var(--mut);font-size:12px}
/* faq */
.faq{display:grid;gap:10px;max-width:820px;margin:0 auto}
.faq details{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:0 20px;transition:border-color .2s}
.faq details[open]{border-color:#B7D8C9}
.faq summary{font-weight:700;cursor:pointer;min-height:60px;display:flex;align-items:center;justify-content:space-between;gap:12px;list-style:none}
.faq summary::-webkit-details-marker{display:none}
.faq summary:after{content:"";width:10px;height:10px;border-inline-end:2px solid var(--mut);border-bottom:2px solid var(--mut);transform:rotate(45deg);transition:transform .2s;flex:0 0 10px;margin-top:-4px}
.faq details[open] summary:after{transform:rotate(-135deg);margin-top:4px}
.faq p{color:var(--mut);margin:0 0 18px}
/* band */
.band{position:relative;overflow:hidden;background:var(--dark);color:#fff;border-radius:28px;padding:56px 24px;text-align:center;margin:80px 0 0}
.band:before{content:"";position:absolute;inset:0;background:radial-gradient(50% 80% at 50% 0%,rgba(16,185,129,.35),transparent 70%)}
.band>*{position:relative}.band h2{margin:0 0 10px;font-size:clamp(28px,6vw,44px);font-weight:800}.band p{color:rgba(255,255,255,.72);margin:0 0 26px;font-size:17px}
.band a.wa{color:#6EE7B7}
footer{color:var(--mut);font-size:14px;padding:40px 0 48px;display:flex;flex-wrap:wrap;gap:16px;justify-content:space-between;align-items:center;border-top:1px solid var(--line);margin-top:64px}
footer .logo{color:var(--ink);font-size:18px}footer nav{display:flex;gap:18px;flex-wrap:wrap}footer a{text-decoration:none}footer a:hover{color:var(--p)}
.mid{min-height:100vh;display:grid;place-items:center;text-align:center;padding:30px 16px;background:var(--dark);color:#fff}.mid p{color:rgba(255,255,255,.7)}
@media(max-width:600px){.cta .btn{flex:1 1 100%}.f3{display:none}.f2{bottom:150px;inset-inline-start:-4px}.f1{top:40px}.hero .wrap{padding-bottom:48px}}
@media(min-width:720px){.bento{grid-template-columns:repeat(2,1fr)}.stats{grid-template-columns:repeat(4,1fr)}.steps{grid-template-columns:repeat(3,1fr)}}
@media(min-width:960px){.nav{display:flex}.hero .wrap{grid-template-columns:1.1fr .9fr;padding-top:72px;padding-bottom:96px}
.bento{grid-template-columns:repeat(3,1fr)}.tile.big{grid-column:span 2;grid-row:span 2;padding:32px}.tile.big h3{font-size:26px}.tile.wide{grid-column:span 2}
.panels-demo{max-width:460px}.band{padding:72px 40px}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}.float{animation:none}.tile,.btn{transition:none}}
`;

function shell(title, body, desc = '') {
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>${esc(title)}</title><meta name="description" content="${esc(desc)}"><meta name="theme-color" content="#07110D">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Rubik:wght@500;600;700;800&display=swap" rel="stylesheet" media="print" onload="this.media='all'">
<style>${CSS}</style></head><body>${body}</body></html>`;
}

function homePage() {
  const P = getSetting('platform');
  const name = esc(P.name);
  const signup = P.signupMode !== 'closed';
  const cta = signup ? '<a class="btn acc big" href="/admin/#signup">أنشئ متجرك مجاناً</a>' : '';
  const ic = (d) => `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  const I = {
    ai: ic('<path d="M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>'),
    form: ic('<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>'),
    truck: ic('<path d="M3 7h11v9H3z"/><path d="M14 10h4l3 3v3h-7"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/>'),
    shield: ic('<path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>'),
    chart: ic('<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>'),
    phone: ic('<path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a1 1 0 01-1 1A16 16 0 014 5a1 1 0 011-1z"/>'),
    palette: ic('<circle cx="12" cy="12" r="9"/><circle cx="8" cy="10" r="1.2"/><circle cx="12" cy="7.5" r="1.2"/><circle cx="16" cy="10" r="1.2"/><path d="M12 21a3 3 0 010-6h2a3 3 0 003-3"/>'),
    target: ic('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>')
  };
  const feats = [
    [I.ai, 'صفحات هبوط بالذكاء الاصطناعي', 'صورة المنتج وسطرين وصف ← صفحة كاملة بالدارجة: صور مصممة، عروض، وفورم الطلب بعد أول صورة. ستايل خاص لكل نيش: ملابس، تجميل، صحة، دار…'],
    [I.form, 'فورم طلب تتحكم فيه', 'زيد، نحّي، سمّي الخانات كيما تحب، خلي واحدة إجبارية ولا لا. رقم الهاتف أرقام فقط، وملخص الطلب يبان للزبون قبل التأكيد.'],
    [I.truck, 'ربط مع شركات التوصيل', 'بعث الطلبيات بكليك واحد ورجع رقم التتبع والحالة أوتوماتيك: Yalidine، Guepex، ZR Express، Noest، وشركات EcoTrack.'],
    [I.shield, 'حماية من الطلبات المزيفة', 'حظر IP أوتوماتيكي، قائمة سوداء للأرقام، دمج الطلبات المكررة، نقطة ثقة لكل زبون، وفخ للروبوتات.'],
    [I.target, 'بيكسلات ذكية', 'عدة بيكسلات Meta وTikTok وSnap وGoogle، مع Conversions API. تقدر تبعث “Purchase” غير كي تأكد الطلب أو كي يتسلم — إعلانات تتعلم من الزبائن الحقيقيين.'],
    [I.chart, 'الربح الحقيقي للإعلانات', 'ربط Meta Ads: تكلفة الطلب المؤكد والمسلّم، نقطة التعادل، والربح الصافي لكل حملة: زيد، راقب، أوقف.'],
    [I.phone, 'تأكيد الطلبيات', 'حالة كل طلب بقائمة وحدة، اتصال وواتساب بكليك، تاريخ كل طلب، فريق بأدوار (مؤكد، مخزن، إعلانات).'],
    [I.palette, 'ثيمات حقيقية لمتجرك', 'Classic، Bold، Minimal، Boutique للملابس، Market، Fresh — كل ثيم بتصميم مختلف، باش متجرك ما يشبهش للآخرين.']
  ];
  const steps = [['أنشئ حسابك', 'اسم المتجر ورابطه، في دقيقة.'], ['زيد منتجك', 'صورة، سعر، عروض 1/2/3 قطع.'], ['ولّد الصفحة واعلن', 'انسخ رابط الإعلان وابدأ تستقبل الطلبيات.']];
  const rows = [
    ['صفحات هبوط بالدارجة بالذكاء الاصطناعي', true, false],
    ['ربط شركات التوصيل الجزائرية', true, 'غالباً مدفوع'],
    ['حظر IP ضد هجمات الطلبات المزيفة', true, false],
    ['Purchase للإعلانات عند التأكيد أو التسليم', true, false],
    ['حساب الربح الصافي لكل حملة', true, false],
    ['محاكي أرباح COD مدمج', true, false],
    ['بدون عمولة على الطلبيات', true, 'أحياناً']
  ];
  const faq = [
    ['هل المنصة مجانية؟', 'نعم، مجانية خلال الفترة التجريبية بدون عمولة على الطلبيات.'],
    ['هل نحتاج نعرف البرمجة؟', 'لا. كل شيء من لوحة التحكم: المنتجات، الصفحات، التصميم، الفورم والإعدادات.'],
    ['كيفاش نربط شركة التوصيل؟', 'من الإعدادات ← شركة التوصيل: تختار الشركة وتحط مفاتيح الـ API تاعك، وتبعث الطلبيات بكليك.'],
    ['واش نقدر نستعمل البيكسل تاعي؟', 'أكيد. تقدر تزيد عدة بيكسلات Meta وTikTok وSnap وGoogle، وكل صفحة هبوط تقدر يكون عندها بيكسل خاص.'],
    ['كيفاش نحمي روحي من الطلبات المزيفة؟', 'المنصة تحظر الـ IP اللي يبعث بزاف طلبيات، تحط الأرقام المشبوهة في القائمة السوداء، وتعطيك نقطة ثقة لكل زبون حسب تاريخ التسليم.'],
    ['وين تتخزن المعلومات؟', 'في قاعدة بيانات آمنة خاصة بالمنصة. كل متجر يشوف غير معلوماته، ومفاتيح الـ API ما تبانش كاملة.']
  ];
  const sv = (d, w = 2) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  const OK = sv('<path d="M5 12.5l4.5 4.5L19 7.5"/>', 2.6), NO = sv('<path d="M6 6l12 12M18 6L6 18"/>', 2.6);
  const ARR = sv('<path d="M19 12H5M11 6l-6 6 6 6"/>');
  const mark = sv('<path d="M4 7l8-4 8 4-8 4z"/><path d="M4 12l8 4 8-4"/><path d="M4 17l8 4 8-4"/>', 2.2);
  const mock = `<div class="phone" aria-hidden="true"><div class="scr">
      <div class="m-top"><b>متجري</b><span>الدفع عند الاستلام</span></div>
      <div class="m-hero"><span class="m-badge">عرض محدود</span><b>أناقة وراحة<br>في نفس الوقت</b></div>
      <div class="m-form"><div class="m-offer on"><span>قطعتان</span><b>⁦6 900⁩ دج</b></div><div class="m-offer"><span>قطعة</span><b>⁦3 900⁩ دج</b></div><i></i><i></i><i></i><div class="m-btn">تأكيد الطلب</div></div>
    </div></div>`;
  const tile = (f, cls = '', extra = '') => `<article class="tile ${cls}"><div class="ic">${f[0]}</div><h3>${esc(f[1])}</h3><p>${esc(f[2])}</p>${extra}</article>`;
  const body = `<header class="top"><div class="wrap"><a class="logo" href="/"><i>${mark}</i>${name}</a><nav class="nav" aria-label="الأقسام"><a href="#features">المميزات</a><a href="#how">كيف تبدأ</a><a href="#compare">المقارنة</a><a href="#faq">أسئلة</a></nav><div class="row"><a class="btn ghost" href="/admin/">دخول</a>${signup ? '<a class="btn acc" href="/admin/#signup">ابدأ مجاناً</a>' : ''}</div></div></header>
<section class="hero"><div class="wrap">
  <div class="hero-txt">
    <span class="kicker"><b></b>منصة جزائرية للبيع بالدفع عند الاستلام</span>
    <h1>متجرك وصفحات هبوط <em>تبيع</em> — في دقائق، بدون برمجة</h1>
    <p class="lead">${esc(P.tagline)}. ارفع صورة المنتج والذكاء الاصطناعي يبني صفحة بالدارجة، وأنت ركّز على التأكيد والتوصيل والأرباح — كلها في مكان واحد.</p>
    <div class="cta">${signup ? `<a class="btn acc big" href="/admin/#signup">أنشئ متجرك مجاناً ${ARR}</a>` : ''}<a class="btn ghost big" href="/admin/">لديّ حساب</a></div>
    <ul class="ticks"><li>${OK}مجاني في الفترة التجريبية</li><li>${OK}بدون عمولة على الطلبيات</li><li>${OK}دارجة · عربية · فرنسية</li></ul>
  </div>
  <div class="hero-vis">${mock}
    <div class="float f1"><i>${OK}</i><span>طلب جديد — ⁦6 900⁩ دج<small>وهران · مكتب التوصيل</small></span></div>
    <div class="float f2"><i>${I.shield}</i><span>IP مشبوه تم حظره<small>5 طلبيات في 10 دقائق</small></span></div>
    <div class="float f3"><i>${I.truck}</i><span>أُرسل لـ Yalidine<small>رقم التتبع وصل</small></span></div>
  </div>
</div></section>
<div class="wrap"><section class="logos" aria-label="مربوطة مع"><span>مربوطة مع</span><b>Yalidine</b><b>Guepex</b><b>ZR Express</b><b>Noest</b><b>EcoTrack</b><b>Meta</b><b>TikTok</b></section></div>
<section class="sec" id="features"><div class="wrap">
  <div class="sh"><span class="eyebrow">المميزات</span><h2>كل ما يحتاجه بائع COD في الجزائر</h2><p>مبنية على المشاكل الحقيقية للسوق: الطلبات المزيفة، الإرجاع، والإعلانات اللي تحرق الميزانية.</p></div>
  <div class="bento">
    ${tile([I.ai, 'من صورة واحدة إلى صفحة هبوط كاملة', 'الذكاء الاصطناعي يتعرّف على المنتج والنيش والزبون من الصورة، يختار ترتيب الصور اللي يقنع ويبيع، ويكتب النص بالدارجة. الملابس تاخذ صورك أنت، والمنتجات الأخرى تاخذ مشاهد فيها منتجك الحقيقي.'], 'big', '<div class="panels-demo"><div class="pd p1"><span>هل تعاني؟</span><b>تعبت من هاد المشكل؟</b></div><div class="pd p2"><span>الفايدة</span><b>نتيجة من أول استعمال</b></div><div class="pd p3"><span>عرض اليوم</span><b>قطعتان</b><em>⁦6 900⁩ دج</em></div></div>')}
    ${tile(feats[2], '', '<div class="chips"><span>Yalidine</span><span>ZR Express</span><span>Noest</span><span>EcoTrack</span></div>')}
    ${tile(feats[3], '', '<div class="log"><span>41.105.x.x <em class="no">blocked</em></span><span>0555 •• •• 12 <em class="ok">score 92%</em></span></div>')}
    ${tile(feats[5], 'wide', '<div class="minibars" aria-hidden="true"><i style="height:30%"></i><i style="height:45%"></i><i style="height:38%"></i><i style="height:62%"></i><i class="on" style="height:80%"></i><i style="height:55%"></i><i class="on" style="height:95%"></i></div><div class="statrow"><span><b>⁦1.8$⁩</b>تكلفة الطلب المسلّم</span><span><b>⁦+42 000⁩</b>ربح صافي (دج)</span><span><b>Scale</b>القرار</span></div>')}
    ${tile(feats[4])}
    ${tile(feats[1])}
    ${tile(feats[6])}
    ${tile(feats[7])}
  </div>
  <div class="stats"><div class="stat"><b>0%</b><span>عمولة على الطلبيات</span></div><div class="stat"><b>58/69</b><span>ولاية مع البلديات</span></div><div class="stat"><b>6</b><span>ثيمات للمتجر</span></div><div class="stat"><b>3</b><span>لغات للصفحات</span></div></div>
</div></section>
<section class="sec" id="how"><div class="wrap">
  <div class="sh"><span class="eyebrow">كيف تبدأ</span><h2>ثلاث خطوات وصفحتك جاهزة للإعلان</h2></div>
  <div class="steps">${steps.map((x, i) => `<div class="step"><span class="n">${i + 1}</span><h3>${esc(x[0])}</h3><p>${esc(x[1])}</p></div>`).join('')}</div>
</div></section>
<section class="sec" id="compare"><div class="wrap">
  <div class="sh"><span class="eyebrow">المقارنة</span><h2>علاش ${name}؟</h2></div>
  <div class="cmp" role="table"><div class="cmp-h" role="row"><span></span><span class="us">${name}</span><span>منصات أخرى</span></div>${rows.map((r) => `<div class="cmp-r" role="row"><span>${esc(r[0])}</span><span><i class="yes" aria-label="نعم">${OK}</i></span><span>${r[2] === false ? `<i class="no2" aria-label="لا">${NO}</i>` : `<span class="meh">${esc(r[2])}</span>`}</span></div>`).join('')}</div>
</div></section>
<section class="sec" id="faq"><div class="wrap">
  <div class="sh"><span class="eyebrow">أسئلة</span><h2>أسئلة شائعة</h2></div>
  <div class="faq">${faq.map((f) => `<details><summary>${esc(f[0])}</summary><p>${esc(f[1])}</p></details>`).join('')}</div>
</div></section>
<div class="wrap"><section class="band"><h2>جاهز تبيع؟</h2><p>${P.signupMode === 'invite' ? 'التسجيل حالياً بكود دعوة — اطلبه منا.' : 'أنشئ متجرك الآن، مجاناً.'}</p>${signup ? `<a class="btn acc big" href="/admin/#signup">أنشئ متجرك مجاناً ${ARR}</a>` : ''}
${P.supportPhone ? `<p style="margin:18px 0 0">واتساب: <a class="wa" href="https://wa.me/${esc(String(P.supportPhone).replace(/\D/g, '').replace(/^0/, '213'))}">${esc(P.supportPhone)}</a></p>` : ''}</section>
<footer><a class="logo" href="/"><i>${mark}</i>${name}</a><nav><a href="/admin/">دخول</a>${signup ? '<a href="/admin/#signup">إنشاء متجر</a>' : ''}${P.supportEmail ? '<a href="mailto:' + esc(P.supportEmail) + '">' + esc(P.supportEmail) + '</a>' : ''}</nav><small>© ${new Date().getFullYear()} ${name} · ${esc(P.tagline)}</small></footer></div>`;
  return shell(P.name + ' — ' + P.tagline, body, P.tagline);
}

function unavailable() {
  const P = getSetting('platform');
  return shell('غير متاح', `<div class="mid"><div><h1 style="margin:0 0 8px">هذا المتجر غير متاح حالياً</h1><p style="color:var(--mut)">Cette boutique est momentanément indisponible.</p><a class="btn ghost" href="/">${esc(P.name)}</a></div></div>`);
}

function notFound() {
  const P = getSetting('platform');
  return shell('404', `<div class="mid"><div><h1 style="margin:0 0 8px">404</h1><a class="btn ghost" href="/">${esc(P.name)}</a></div></div>`);
}

module.exports = { homePage, unavailable, notFound };
