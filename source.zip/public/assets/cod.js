(function () {
  'use strict';
  var ss = {
    get: function (k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { sessionStorage.setItem(k, v); } catch (e) {} }
  };
  function cookie(name) { var m = document.cookie.match(new RegExp('(?:^|; )' + name + '=([^;]*)')); return m ? decodeURIComponent(m[1]) : ''; }
  function money(n, cur) { return '\u2066' + String(Math.round(n || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, '\u202f') + '\u2069 ' + cur; }
  var EVENTS = {};
  function track(ev, data, id) {
    if (EVENTS[ev] === false) return;
    try { if (window.fbq) window.fbq('track', ev, data || {}, id ? { eventID: id } : undefined); } catch (e) {}
    try { if (window.ttq) window.ttq.track(ev === 'Purchase' ? 'CompletePayment' : ev === 'Lead' ? 'SubmitForm' : ev, data || {}, id ? { event_id: id } : undefined); } catch (e) {}
    try { if (window.snaptr) window.snaptr('track', ev === 'Purchase' ? 'PURCHASE' : ev === 'ViewContent' ? 'VIEW_CONTENT' : ev === 'InitiateCheckout' ? 'START_CHECKOUT' : ev === 'Lead' ? 'SIGN_UP' : ev.toUpperCase(), { price: data && data.value, currency: 'DZD', client_dedup_id: id }); } catch (e) {}
    try { if (window.gtag) window.gtag('event', ev === 'Purchase' ? 'purchase' : ev === 'ViewContent' ? 'view_item' : ev === 'InitiateCheckout' ? 'begin_checkout' : ev === 'Lead' ? 'generate_lead' : ev, { value: data && data.value, currency: 'DZD', transaction_id: id }); } catch (e) {}
  }

  // UTM / click ids: keep the first ones of this visit.
  var qs = new URLSearchParams(location.search);
  ['utm_source', 'utm_campaign', 'utm_content'].forEach(function (k) { if (qs.get(k) && !ss.get(k)) ss.set(k, qs.get(k)); });
  if (!ss.get('sid')) ss.set('sid', Math.random().toString(36).slice(2) + Date.now().toString(36));

  function normPhone(v) {
    var d = String(v || '').replace(/[^0-9+]/g, '').replace(/^\+/, '');
    if (d.indexOf('00213') === 0) d = '0' + d.slice(5); else if (d.indexOf('213') === 0) d = '0' + d.slice(3);
    if (/^[567][0-9]{8}$/.test(d)) d = '0' + d;
    return /^0[567][0-9]{8}$/.test(d) ? d : null;
  }

  function setupPick(root, opts) {
    var btn = root.querySelector('.pick-btn'), pop = root.querySelector('.pick-pop'), search = root.querySelector('.pick-search'), list = root.querySelector('.pick-list');
    var items = [], value = null;
    function render() {
      var q = (search.value || '').trim().toLowerCase();
      list.innerHTML = '';
      items.filter(function (it) { return !q || it.search.indexOf(q) >= 0; }).slice(0, 400).forEach(function (it) {
        var b = document.createElement('button');
        b.type = 'button'; b.className = 'pick-item' + (it.value === value ? ' on' : ''); b.setAttribute('role', 'option');
        b.textContent = it.label;
        if (it.sub) { var s = document.createElement('small'); s.textContent = it.sub; b.appendChild(s); }
        b.addEventListener('click', function () { choose(it); });
        list.appendChild(b);
      });
    }
    function open(v) {
      pop.hidden = !v; btn.setAttribute('aria-expanded', v ? 'true' : 'false');
      if (v) { search.value = ''; render(); setTimeout(function () { search.focus(); }, 30); }
    }
    function choose(it) {
      value = it.value; btn.querySelector('span').textContent = it.label; btn.classList.add('set'); open(false); opts.onChange(it);
    }
    btn.addEventListener('click', function () { open(pop.hidden); });
    search.addEventListener('input', render);
    search.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') open(false);
      if (e.key === 'Enter') { e.preventDefault(); var f = list.querySelector('.pick-item'); if (f) f.click(); }
    });
    document.addEventListener('click', function (e) { if (!root.contains(e.target)) open(false); });
    return {
      setItems: function (arr) { items = arr; value = null; btn.querySelector('span').textContent = opts.placeholder; btn.classList.remove('set'); },
      reset: function (ph) { value = null; btn.querySelector('span').textContent = ph || opts.placeholder; btn.classList.remove('set'); }
    };
  }

  function initForm(form) {
    var D = JSON.parse(form.querySelector('.cod-data').textContent);
    var T = D.t;
    EVENTS = D.events || {};
    var REQ = D.required || [];
    // Phone fields: digits only, 10 max (customers often type spaces or Arabic digits).
    form.querySelectorAll('[data-digits]').forEach(function (inp) {
      inp.addEventListener('input', function () {
        var v = inp.value.replace(/[٠-٩]/g, function (c) { return String(c.charCodeAt(0) - 1632); }).replace(/[۰-۹]/g, function (c) { return String(c.charCodeAt(0) - 1776); }).replace(/\D/g, '');
        if (v.indexOf('213') === 0 && v.length > 10) v = '0' + v.slice(3);
        if (inp.name === 'phone' || inp.name === 'phone2') v = v.slice(0, 10);
        if (inp.value !== v) inp.value = v;
      });
    });
    var $ = function (s) { return form.querySelector(s); };
    var nameEl = form.querySelector('input[name=name]');
    var wilayaInput = form.querySelector('input[name=wilaya]');
    var communeInput = form.querySelector('input[name=commune]');
    var communePick = form.querySelector('[data-pick=commune]');
    var current = { wilaya: null };
    var checkoutTracked = false;

    function selected(name) { var el = form.querySelector('input[name=' + name + ']:checked'); return el ? el.value : null; }
    function variantObj() { var n = selected('variant'); for (var i = 0; i < (D.variants || []).length; i++) if (D.variants[i].name === n) return D.variants[i]; return null; }
    function vDelta() { var v = variantObj(); return v && v.price > 0 && D.basePrice ? v.price - D.basePrice : 0; }
    function offer() {
      var q = Number(selected('quantity') || 1), o = D.offers[0];
      for (var i = 0; i < D.offers.length; i++) if (D.offers[i].qty === q) { o = D.offers[i]; break; }
      return { qty: o.qty, price: Math.max(0, o.price + vDelta() * o.qty) };
    }
    function fee() {
      if (!current.wilaya) return 0;
      var v = selected('delivery') === 'home' ? current.wilaya.home : current.wilaya.desk;
      return v == null ? 0 : v;
    }
    function updateTotal() {
      var o = offer(), dl = vDelta();
      $('[data-total]').textContent = money(o.price + fee(), T.currency);
      form.querySelectorAll('.offer').forEach(function (lb) {
        var inp = lb.querySelector('input'), pr = lb.querySelector('.offer-price'); if (!inp || !pr) return;
        for (var i = 0; i < D.offers.length; i++) if (String(D.offers[i].qty) === inp.value) pr.textContent = money(Math.max(0, D.offers[i].price + dl * D.offers[i].qty), T.currency);
      });
      var hp = document.querySelector('.pp-info .pprice b'); if (hp && D.basePrice) hp.textContent = money(D.basePrice + dl, T.currency);
      var vo = variantObj(), pn = form.querySelector('[data-prenote]');
      if (pn) pn.hidden = !(vo && vo.out);
      var sp = $('[data-s-prod]'), si = $('[data-s-items]'), ss2 = $('[data-s-ship]');
      if (sp) sp.textContent = D.productName + ' × ' + o.qty + (selected('variant') ? ' — ' + selected('variant') : '');
      if (si) si.textContent = money(o.price, T.currency);
      if (ss2) ss2.textContent = current.wilaya ? (fee() ? money(fee(), T.currency) : T.free) : T.chooseFirst;
      var dz = $('[data-fee=desk]'), hm = $('[data-fee=home]');
      if (current.wilaya) {
        if (dz) dz.textContent = current.wilaya.desk ? money(current.wilaya.desk, T.currency) : T.free;
        if (hm) hm.textContent = current.wilaya.home ? money(current.wilaya.home, T.currency) : T.free;
      } else {
        if (dz) dz.textContent = T.chooseFirst;
        if (hm) hm.textContent = '';
      }
    }
    function syncRadios(group, cls) {
      form.querySelectorAll('input[name=' + group + ']').forEach(function (inp) {
        inp.closest('.' + cls).classList.toggle('on', inp.checked);
      });
    }
    form.addEventListener('change', function (e) {
      var n = e.target.name;
      if (n === 'quantity') syncRadios('quantity', 'offer');
      if (n === 'delivery') syncRadios('delivery', 'dv');
      if (n === 'variant') {
        syncRadios('variant', 'variant'); setErr('variant', '');
        var vv = variantObj(), mi = document.querySelector('.pp-main img');
        if (vv && vv.image && mi) { mi.src = vv.image; mi.removeAttribute('srcset'); }
      }
      updateTotal();
    });

    function setErr(field, msg) {
      var el = form.querySelector('[data-err=' + field + ']');
      if (el) el.textContent = msg || '';
      var f = el && el.closest('.field');
      if (f) f.classList.toggle('bad', !!msg);
    }

    var wilayaPick = setupPick(form.querySelector('[data-pick=wilaya]'), {
      placeholder: T.chooseWilaya,
      onChange: function (it) {
        current.wilaya = it.w; wilayaInput.value = it.value; setErr('wilaya', '');
        loadCommunes(it.value); updateTotal(); saveAbandoned();
        if (!checkoutTracked) { checkoutTracked = true; track('InitiateCheckout', { content_name: D.contentName, currency: 'DZD', value: offer().price }); }
      }
    });
    wilayaPick.setItems(D.wilayas.map(function (w) {
      var label = w.code + ' - ' + (D.lang === 'fr' ? w.fr : w.ar);
      return { value: w.code, label: label, sub: D.lang === 'fr' ? w.ar : w.fr, search: (w.code + ' ' + w.ar + ' ' + w.fr).toLowerCase(), w: w };
    }));
    var cPick = setupPick(communePick, { placeholder: T.chooseCommune, onChange: function (it) { communeInput.value = it.value; setErr('commune', ''); saveAbandoned(); } });

    function loadCommunes(code) {
      communeInput.value = '';
      communeInput.placeholder = T.typeCommune;
      fetch('/api/communes/' + code).then(function (r) { return r.json(); }).then(function (j) {
        var list = (j.communes || []);
        if (list.length) {
          cPick.setItems(list.map(function (c) { var l = D.lang === 'fr' ? (c.fr || c.ar) : c.ar; return { value: l, label: l, sub: D.lang === 'fr' ? c.ar : c.fr, search: (c.ar + ' ' + c.fr).toLowerCase() }; }));
          communePick.hidden = false; communeInput.type = 'hidden';
        } else {
          communePick.hidden = true; communeInput.type = 'text';
        }
      }).catch(function () { communePick.hidden = true; communeInput.type = 'text'; });
    }

    var abTimer = null;
    function saveAbandoned() {
      clearTimeout(abTimer);
      abTimer = setTimeout(function () {
        var phone = normPhone(form.phone.value);
        if (!phone) return;
        fetch((D.base || '') + '/api/abandoned', { method: 'POST', headers: { 'Content-Type': 'application/json' }, keepalive: true, body: JSON.stringify({
          session: ss.get('sid'), name: nameEl.value, phone: phone, wilaya: wilayaInput.value, commune: communeInput.value, product_id: D.productId, landing_id: D.landingId
        }) }).catch(function () {});
      }, 900);
    }
    form.phone.addEventListener('input', function () { setErr('phone', ''); saveAbandoned(); });
    nameEl.addEventListener('input', function () { setErr('name', ''); });
    form.phone.addEventListener('focus', function () { if (!checkoutTracked) { checkoutTracked = true; track('InitiateCheckout', { content_name: D.contentName, currency: 'DZD', value: offer().price }); } });
    communeInput.addEventListener('input', function () { setErr('commune', ''); });
    form.addEventListener('input', function (e) { if (e.target.name && e.target.name.indexOf('c_') === 0 || ['address', 'note', 'phone2'].indexOf(e.target.name) >= 0) setErr(e.target.name, ''); });

    var lastOrder = null;
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var phone = normPhone(form.phone.value);
      var ok = true;
      if (nameEl.value.trim().length < 2) { setErr('name', T.errName); ok = false; }
      if (!phone) { setErr('phone', T.errPhone); ok = false; }
      if (!wilayaInput.value) { setErr('wilaya', T.errWilaya); ok = false; }
      if (!communeInput.value.trim()) { setErr('commune', T.errCommune); ok = false; }
      if (D.variants.length > 1 && !selected('variant')) { setErr('variant', T.errVariant); ok = false; }
      var extra = {};
      form.querySelectorAll('[name^="c_"], [name=address], [name=note], [name=phone2]').forEach(function (inp) {
        var v = String(inp.value || '').trim();
        if (inp.name.indexOf('c_') === 0) extra[inp.name] = v;
        if (REQ.indexOf(inp.name) >= 0 && !v) { setErr(inp.name, T.errReq); ok = false; }
      });
      var p2 = form.querySelector('[name=phone2]');
      if (p2 && p2.value && !normPhone(p2.value)) { setErr('phone2', T.errPhone); ok = false; }
      if (!ok) { var bad = form.querySelector('.field.bad'); if (bad) bad.scrollIntoView({ behavior: 'smooth', block: 'center' }); return; }
      var btn = form.querySelector('button[type=submit]');
      btn.disabled = true; btn.textContent = T.sending;
      var errBox = form.querySelector('.form-err'); errBox.hidden = true;
      fetch((D.base || '') + '/api/order', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
        name: nameEl.value.trim(), phone: phone, wilaya: wilayaInput.value, commune: communeInput.value.trim(), delivery: selected('delivery') || 'desk',
        quantity: Number(selected('quantity') || 1), variant: selected('variant') || '', product_id: D.productId, landing_id: D.landingId,
        utm_source: ss.get('utm_source') || '', utm_campaign: ss.get('utm_campaign') || '', utm_content: ss.get('utm_content') || '',
        session: ss.get('sid'), page_url: location.href, fbc: cookie('_fbc'), fbp: cookie('_fbp'), website: form.website.value,
        address: (form.querySelector('[name=address]') || {}).value || '', note: (form.querySelector('[name=note]') || {}).value || '',
        phone2: normPhone((form.querySelector('[name=phone2]') || {}).value || '') || '', extra: extra
      }) }).then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); }).then(function (res) {
        if (!res.ok || !res.j.ok) {
          var f = res.j && res.j.field;
          if (f && (f.indexOf('c_') === 0 || f === 'address' || f === 'note' || f === 'phone2')) setErr(f, T.errReq);
          else if (f === 'phone') setErr('phone', T.errPhone); else if (f === 'wilaya' || f === 'delivery') setErr('wilaya', T.errWilaya); else if (f === 'commune') setErr('commune', T.errCommune); else if (f === 'variant') setErr('variant', T.errVariant); else if (f === 'soldout') setErr('variant', T.errSoldout || T.error); else if (f === 'name') setErr('name', T.errName);
          else { errBox.textContent = (res.j && res.j.error) || T.error; errBox.hidden = false; }
          btn.disabled = false; btn.textContent = T.confirm; return;
        }
        lastOrder = res.j;
        if (res.j.id && !res.j.merged) track(D.purchaseEvent || 'Purchase', { content_name: D.contentName, content_ids: [String(D.productId)], content_type: 'product', currency: 'DZD', value: res.j.total }, 'order-' + res.j.id);
        form.querySelector('[data-step=form]').hidden = true;
        var done = form.querySelector('[data-step=done]');
        done.hidden = false;
        done.querySelector('[data-done-title]').textContent = T.thanks;
        done.querySelector('[data-done-sub]').textContent = T.thanksSub.replace('{phone}', phone);
        done.querySelector('[data-done-total]').textContent = money(res.j.total, T.currency);
        form.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }).catch(function () {
        errBox.textContent = T.error; errBox.hidden = false; btn.disabled = false; btn.textContent = T.confirm;
      });
    });

    form.querySelectorAll('[data-up]').forEach(function (b) {
      b.addEventListener('click', function () {
        var box = form.querySelector('[data-upsell]');
        if (b.getAttribute('data-up') === 'no' || !lastOrder || !lastOrder.id) { box.remove(); return; }
        b.disabled = true;
        fetch((D.base || '') + '/api/order/' + lastOrder.id + '/upsell', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token: lastOrder.token }) })
          .then(function (r) { return r.json(); }).then(function (j) {
            if (j.ok) { form.querySelector('[data-done-total]').textContent = money(j.total, T.currency); track('AddToCart', { currency: 'DZD', value: D.upsell.price }); }
            box.remove();
          }).catch(function () { box.remove(); });
      });
    });

    if (D.variants.length === 1) { var only = form.querySelector('input[name=variant]'); if (only) only.checked = true; }
    syncRadios('quantity', 'offer'); updateTotal();
    track('ViewContent', { content_name: D.contentName, content_ids: [String(D.productId)], content_type: 'product', currency: 'DZD', value: offer().price });
  }

  document.querySelectorAll('[data-cod]').forEach(initForm);

  // Sticky bar hides while the form is on screen.
  var sticky = document.querySelector('.sticky'), formEl = document.getElementById('order');
  if (sticky && formEl && 'IntersectionObserver' in window) {
    new IntersectionObserver(function (en) { sticky.classList.toggle('hide', en[0].isIntersecting); }, { threshold: 0.15 }).observe(formEl);
  }

  // Before / after slider
  document.querySelectorAll('[data-ba]').forEach(function (ba) {
    var after = ba.querySelector('.ba-after'), inner = after.querySelector('img'), range = ba.parentNode.querySelector('.ba-range');
    function size() { inner.style.width = ba.offsetWidth + 'px'; }
    size(); window.addEventListener('resize', size);
    if (range) range.addEventListener('input', function () { after.style.width = (100 - Number(range.value)) + '%'; });
  });

  // Product gallery
  document.querySelectorAll('[data-gal]').forEach(function (g) {
    var main = g.querySelector('.pp-main img');
    g.querySelectorAll('.pp-thumbs button').forEach(function (b) {
      b.addEventListener('click', function () {
        if (main) main.src = b.getAttribute('data-src');
        g.querySelectorAll('.pp-thumbs button').forEach(function (x) { x.classList.toggle('on', x === b); });
      });
    });
  });

  // Tabs
  document.querySelectorAll('[data-tabs]').forEach(function (t) {
    t.querySelectorAll('[data-tab]').forEach(function (b) {
      b.addEventListener('click', function () {
        var k = b.getAttribute('data-tab');
        t.querySelectorAll('[data-tab]').forEach(function (x) { x.setAttribute('aria-selected', x === b ? 'true' : 'false'); });
        t.querySelectorAll('[data-panel]').forEach(function (p) { p.hidden = p.getAttribute('data-panel') !== k; });
      });
    });
  });
})();
