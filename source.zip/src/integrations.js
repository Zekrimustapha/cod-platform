'use strict';
const { D, getSetting } = require('./db');
const { sha256hex } = require('./crypto');

const sha = (s) => sha256hex(String(s).trim().toLowerCase());

function log(...a) {
  console.log('[integrations]', ...a);
}

// ---------- Google Sheets (free: Apps Script web app) ----------
async function pushToSheets(event, order) {
  const { sheetsUrl } = getSetting('integrations', order.store_id);
  if (!sheetsUrl || !/^https:\/\/script\.google\.com\//.test(sheetsUrl)) return;
  try {
    await fetch(sheetsUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ event, order: {
        id: order.id, created_at: order.created_at, status: order.status, name: order.name, phone: order.phone,
        wilaya: order.wilaya_code + ' ' + order.wilaya_name, commune: order.commune, address: order.address, delivery: order.delivery,
        product: order.product_name, variant: order.variant, quantity: order.quantity, total: order.total, upsell: order.upsell,
        note: order.note, tracking: order.tracking, campaign: order.utm_campaign
      } }),
      signal: AbortSignal.timeout(10000)
    });
  } catch (e) {
    log('sheets failed', e.message);
  }
}

// ---------- Server-side conversion events (Meta Conversions API + TikTok Events API, free) ----------
// Every Meta / TikTok pixel that has an access token gets the event. Browser + server events share the same event id (deduplicated).
function serverPixels(t, landingPixel) {
  const meta = [];
  const add = (id, token, test) => { id = String(id || '').replace(/\D/g, ''); if (id && token && !meta.some((m) => m.id === id)) meta.push({ id, token, test: test || '' }); };
  for (const m of t.meta || []) if (m && m.on !== false) add(m.id, m.token, m.test);
  add(t.metaPixel, t.metaCapiToken, t.metaTestCode);
  if (landingPixel && !meta.some((m) => m.id === String(landingPixel))) add(landingPixel, (meta[0] && meta[0].token) || t.metaCapiToken, t.metaTestCode);
  const tiktok = (t.tiktok || []).filter((x) => x && x.on !== false && x.id && x.token);
  return { meta, tiktok };
}
async function metaCapi({ pixelId, eventName, eventId, order, extra = {} }) {
  const t = getSetting('tracking', order.store_id);
  const ver = getSetting('integrations', order.store_id).graphVersion || 'v21.0';
  const { meta, tiktok } = serverPixels(t, pixelId);
  if (!meta.length && !tiktok.length) return [];
  const phoneIntl = order.phone ? '213' + order.phone.replace(/^0/, '') : '';
  const hPh = phoneIntl ? await sha(phoneIntl) : undefined;
  const results = [];
  for (const px of meta) {
    const body = {
      data: [{
        event_name: eventName, event_time: Math.floor(Date.now() / 1000), event_id: eventId, action_source: 'website', event_source_url: extra.url || '',
        user_data: {
          ph: hPh ? [hPh] : undefined, fn: order.name ? [await sha(order.name.split(' ')[0])] : undefined, ct: order.commune ? [await sha(order.commune)] : undefined,
          country: [await sha('dz')], external_id: hPh ? [hPh] : undefined,
          client_ip_address: extra.ip && extra.ip !== 'admin' ? extra.ip : undefined, client_user_agent: extra.ua && extra.ua !== 'admin' ? extra.ua : undefined, fbc: extra.fbc || undefined, fbp: extra.fbp || undefined
        },
        custom_data: { currency: 'DZD', value: order.total, content_ids: order.product_id ? [String(order.product_id)] : [], content_type: 'product', num_items: order.quantity, order_id: String(order.id) }
      }]
    };
    if (px.test) body.test_event_code = px.test;
    try {
      const r = await fetch(`https://graph.facebook.com/${ver}/${encodeURIComponent(px.id)}/events?access_token=${encodeURIComponent(px.token)}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(10000)
      });
      const txt = await r.text();
      results.push({ platform: 'meta', id: px.id, ok: r.ok, detail: r.ok ? 'sent' : txt.slice(0, 200) });
      if (!r.ok) log('capi', r.status, txt.slice(0, 300));
    } catch (e) { results.push({ platform: 'meta', id: px.id, ok: false, detail: e.message }); }
  }
  for (const px of tiktok) {
    const ev = eventName === 'Purchase' ? 'CompletePayment' : eventName === 'Lead' ? 'SubmitForm' : eventName;
    const body = {
      event_source: 'web', event_source_id: px.id, test_event_code: px.test || undefined,
      data: [{ event: ev, event_time: Math.floor(Date.now() / 1000), event_id: eventId,
        user: { phone: hPh, external_id: hPh, ip: extra.ip && extra.ip !== 'admin' ? extra.ip : undefined, user_agent: extra.ua && extra.ua !== 'admin' ? extra.ua : undefined },
        page: { url: extra.url || undefined },
        properties: { currency: 'DZD', value: order.total, content_type: 'product', contents: [{ content_id: String(order.product_id || ''), quantity: order.quantity }] } }]
    };
    try {
      const r = await fetch('https://business-api.tiktok.com/open_api/v1.3/event/track/', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Access-Token': px.token }, body: JSON.stringify(body), signal: AbortSignal.timeout(10000) });
      const j = await r.json().catch(() => ({}));
      results.push({ platform: 'tiktok', id: px.id, ok: r.ok && j.code === 0, detail: j.message || ('HTTP ' + r.status) });
    } catch (e) { results.push({ platform: 'tiktok', id: px.id, ok: false, detail: e.message }); }
  }
  return results;
}

// ---------- Meta Ads insights (free Marketing API, needs ads_read token) ----------
const RESULT_ACTIONS = ['offsite_conversion.fb_pixel_purchase', 'purchase', 'onsite_web_purchase', 'offsite_conversion.fb_pixel_lead', 'lead'];

async function syncMetaAds(sid, days = 30) {
  const i = getSetting('integrations', sid);
  const costs = getSetting('costs', sid);
  const bad = (m) => Object.assign(new Error(m), { status: 400 });
  if (!i.metaAdsToken || !i.metaAdAccount) throw bad('Add the Meta access token and ad account ID in Settings → Integrations');
  if (!/^(act_)?\d{5,20}$/.test(String(i.metaAdAccount).trim())) throw bad('The ad account ID must be numbers only (example: act_1234567890). You can find it in Ads Manager, top left.');
  const acct = String(i.metaAdAccount).trim().replace(/^act_/, '');
  const until = new Date();
  const since = new Date(Date.now() - (days - 1) * 864e5);
  const fmt = (d) => d.toISOString().slice(0, 10);
  const params = new URLSearchParams({
    level: 'campaign', fields: 'campaign_id,campaign_name,spend,impressions,clicks,actions,account_currency',
    time_increment: '1', time_range: JSON.stringify({ since: fmt(since), until: fmt(until) }), limit: '500', access_token: i.metaAdsToken
  });
  let url = `https://graph.facebook.com/${i.graphVersion || 'v21.0'}/act_${acct}/insights?${params}`;
  const upSql = `INSERT INTO ad_spend(store_id, date, campaign_id, campaign_name, platform, spend_usd, impressions, clicks, results) VALUES(?,?,?,?,?,?,?,?,?)
    ON CONFLICT(store_id, date, campaign_id) DO UPDATE SET campaign_name=excluded.campaign_name, spend_usd=excluded.spend_usd, impressions=excluded.impressions, clicks=excluded.clicks, results=excluded.results`;
  let rows = 0;
  for (let page = 0; page < 20 && url; page++) {
    let j;
    try {
      const r = await fetch(url, { signal: AbortSignal.timeout(20000) });
      j = await r.json();
    } catch (e) { throw bad('Could not reach Meta: ' + e.message); }
    if (j.error) throw bad('Meta says: ' + j.error.message + (j.error.code === 190 ? ' → the access token is wrong or expired. Paste a new System User token.' : j.error.code === 100 ? ' → check the ad account ID.' : j.error.code === 200 || j.error.code === 10 ? ' → the token needs the ads_read permission and access to this ad account.' : ''));
    for (const x of j.data || []) {
      let spend = Number(x.spend || 0);
      if (x.account_currency && x.account_currency !== 'USD') {
        if (x.account_currency === 'DZD') spend = spend / (costs.usdRate || 255);
      }
      let results = 0;
      for (const a of x.actions || []) if (RESULT_ACTIONS.includes(a.action_type)) results = Math.max(results, Number(a.value || 0));
      await D.run(upSql, sid, x.date_start, String(x.campaign_id), x.campaign_name || '', 'meta', spend, Number(x.impressions || 0), Number(x.clicks || 0), results);
      rows++;
    }
    url = j.paging && j.paging.next;
  }
  return rows;
}

// ---------- Courier export ----------
function courierCsv(orders) {
  const head = ['reference', 'name', 'phone', 'wilaya_code', 'wilaya', 'commune', 'address', 'delivery_type', 'product', 'quantity', 'cod_amount', 'note'];
  const q = (v) => '"' + String(v ?? '').replace(/"/g, '""') + '"';
  const lines = [head.join(',')];
  for (const o of orders) {
    lines.push([o.id, o.name, o.phone, o.wilaya_code, o.wilaya_name, o.commune, o.address, o.delivery === 'home' ? 'home' : 'stopdesk',
      o.product_name + (o.variant ? ' - ' + o.variant : '') + (o.upsell ? ' + ' + o.upsell : ''), o.quantity, o.total, o.note].map(q).join(','));
  }
  return '﻿' + lines.join('\r\n');
}

module.exports = { serverPixels, pushToSheets, metaCapi, syncMetaAds, courierCsv, sha };
