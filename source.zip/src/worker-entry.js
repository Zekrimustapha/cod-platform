'use strict';
// Cloudflare Worker entry: same app as server.js, with D1 (database) and Workers AI (free images) bindings.
const { init, drainBg, D } = require('./db');
const { makeD1Driver } = require('./driver-d1');
const LAI = require('./landing-ai');
const app = require('./app');
const auth = require('./auth');

const SCHEMA_VERSION = '5';
let ready = null;
async function ensureReady(env) {
  if (!ready) {
    ready = (async () => {
      const drv = makeD1Driver(env.DB);
      let skip = false;
      try { const r = await drv.get("SELECT value FROM meta WHERE key = 'schema'", []); skip = r && r.value === SCHEMA_VERSION; } catch {}
      if (skip) {
        await init({ ...drv, migrate: null, skipSchema: true });
      } else {
        await init(drv);
        await D.run("INSERT INTO meta(key, value) VALUES('schema', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", SCHEMA_VERSION);
      }
    })().catch((e) => { ready = null; throw e; });
  }
  return ready;
}

function makeRes() {
  return {
    statusCode: 200, headers: {}, body: null, headersSent: false,
    writeHead(status, headers) { this.statusCode = status; Object.assign(this.headers, headers || {}); this.headersSent = true; },
    setHeader(k, v) { this.headers[k] = v; },
    end(body) { this.body = body == null ? null : body; this.headersSent = true; }
  };
}

// Same-origin mirror of the free background-removal model files (for networks that block huggingface.co).
// Locked down: logged-in admins only, exact file allowlist, stored once in the Cloudflare edge cache.
const HF_FILES = {
  'd30social/ormbg-ortweb': ['config.json', 'preprocessor_config.json', 'onnx/model.onnx', 'onnx/model_fp16.onnx'],
  'onnx-community/BiRefNet_lite-ONNX': ['config.json', 'preprocessor_config.json', 'onnx/model_fp16.onnx']
};
const HF_TTL = 2592000; // 30 days
function hfMatch(pathname) {
  const m = pathname.match(/^\/hf\/([\w-]+\/[\w.-]+)\/resolve\/main\/(.+)$/);
  return m && HF_FILES[m[1]] && HF_FILES[m[1]].includes(m[2]) ? { repo: m[1], file: m[2] } : null;
}
async function hfProxy(request, url, ctx) {
  const f = hfMatch(url.pathname);
  if (!f) return new Response('not found', { status: 404 });
  const headers = {}; request.headers.forEach((v, k) => { headers[k.toLowerCase()] = v; });
  const user = await auth.currentUser({ headers, socket: {} }).catch(() => null);
  if (!user || !(user.is_super || auth.can(user, 'products') || auth.can(user, 'landings'))) return new Response('not found', { status: 404 });
  const cache = caches.default, key = new Request(url.origin + '/hf/' + f.repo + '/resolve/main/' + f.file);
  let r = await cache.match(key), hit = !!r;
  if (!r) {
    const up = await fetch('https://huggingface.co/' + f.repo + '/resolve/main/' + f.file, { redirect: 'follow' });
    if (!up.ok || !up.body) return new Response('upstream ' + up.status, { status: 502 });
    const h = new Headers({ 'Content-Type': /\.json$/.test(f.file) ? 'application/json' : 'application/octet-stream', 'Cache-Control': 'public, max-age=' + HF_TTL + ', immutable' });
    const len = up.headers.get('content-length'); if (len) h.set('Content-Length', len);
    r = new Response(up.body, { status: 200, headers: h });
    ctx.waitUntil(cache.put(key, r.clone()).catch(() => {}));
  }
  const out = new Headers(r.headers);
  out.set('Cache-Control', 'private, max-age=' + HF_TTL + ', immutable');
  out.set('X-Content-Type-Options', 'nosniff');
  out.set('X-Mirror', hit ? 'HIT' : 'MISS');
  out.delete('Access-Control-Allow-Origin');
  return new Response(request.method === 'HEAD' ? null : r.body, { status: 200, headers: out });
}

async function fetchHandler(request, env, ctx) {
  const u0 = new URL(request.url);
  if (u0.pathname.startsWith('/hf/')) {
    if (!['GET', 'HEAD'].includes(request.method)) return new Response('not found', { status: 404 });
    await ensureReady(env);
    return hfProxy(request, u0, ctx);
  }
  await ensureReady(env);
  LAI.setAiBinding(env.AI);
  const url = new URL(request.url);
  const headers = {};
  request.headers.forEach((v, k) => { headers[k.toLowerCase()] = v; });
  headers['x-forwarded-proto'] = url.protocol.replace(':', '');
  const req = { method: request.method, url: url.pathname + url.search, headers, socket: {}, _text: '' };
  if (!['GET', 'HEAD'].includes(request.method)) req._text = await request.text();
  const res = makeRes();
  await app.handle(req, res, url, { assets: async (rel) => (Object.prototype.hasOwnProperty.call(ASSETS, rel) ? ASSETS[rel] : null) });
  ctx.waitUntil(drainBg());
  const h = new Headers();
  for (const [k, v] of Object.entries(res.headers)) if (v != null && k.toLowerCase() !== 'content-length') h.set(k, String(v));
  const body = request.method === 'HEAD' || [204, 304].includes(res.statusCode) ? null : res.body;
  return new Response(body, { status: res.statusCode, headers: h });
}

module.exports = { fetchHandler };
