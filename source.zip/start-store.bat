@echo off
title COD Store - keep this window open
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js is not installed.
  echo  Download the LTS version from https://nodejs.org then run this file again.
  echo.
  pause
  exit /b
)
node -e "const [a,b]=process.versions.node.split('.').map(Number);process.exit(a>22||(a===22&&b>=13)?0:1)"
if errorlevel 1 (
  echo.
  echo  Your Node.js is too old. Install Node.js 22 LTS or newer from https://nodejs.org
  echo.
  pause
  exit /b
)
echo.
echo  Starting the store...  Admin: http://localhost:3000/admin
echo  Close this window to stop the store.
echo.
start "" "http://localhost:3000/admin"
:loop
node --disable-warning=ExperimentalWarning server.js
echo.
echo  The server stopped. Restarting in 5 seconds...
timeout /t 5 >nul
goto loop
