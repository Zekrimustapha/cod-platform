'use strict';
// Landing generator v3 — the AI writes CONTENT only; code decides style, layout and background prompts.
const { getSetting } = require('./db');
const LAI = require('./landing-ai');

const STYLES = ['luxe_amber', 'luxe_dark', 'fresh_clean', 'bold_promo', 'soft_beauty', 'tech_neon', 'kids_fun', 'fashion_editorial'];
const NICHE_STYLE = { health: 'luxe_amber', men: 'luxe_amber', beauty: 'soft_beauty', home: 'fresh_clean', food: 'fresh_clean', kids: 'kids_fun', tech: 'tech_neon', fashion: 'fashion_editorial' };
const SETTINGS = {
  dark_studio: 'dark seamless studio backdrop with a matte stone pedestal surface',
  rustic_wood: 'dark rustic wooden table top',
  marble_kitchen: 'white marble kitchen counter in a bright modern kitchen',
  bathroom_vanity: 'light marble bathroom vanity with soft towels',
  nature_outdoor: 'natural flat stone surface outdoors with soft greenery behind',
  kids_room: 'light wooden floor of a cheerful pastel kids room',
  car_interior: 'clean dark car dashboard surface inside a modern car',
  boutique: 'cream boutique shelf surface with soft fabric drapes'
};
const NICHE_SETTING = { health: 'rustic_wood', men: 'dark_studio', beauty: 'bathroom_vanity', home: 'marble_kitchen', food: 'rustic_wood', kids: 'kids_room', tech: 'dark_studio', fashion: 'boutique' };
const PRESET_LIGHT = {
  luxe_amber: 'warm golden rim light, dark moody background, golden bokeh',
  luxe_dark: 'dramatic low-key lighting, deep black background, subtle gold reflections',
  fresh_clean: 'bright soft daylight, white and light green tones',
  bold_promo: 'bright punchy studio light, warm red and yellow tones',
  soft_beauty: 'soft diffused pink light, pastel blush tones, dreamy bokeh',
  tech_neon: 'dark navy background with cyan neon rim light, sleek reflections',
  kids_fun: 'bright cheerful daylight, warm pastel orange tones',
  fashion_editorial: 'soft editorial daylight, cream and beige tones'
};
const TYPES3 = ['hook', 'problem', 'before_after', 'case', 'features', 'inside', 'how_to', 'guarantee_strip', 'bundle', 'offer', 'look', 'details', 'sizes'];
const ORDERS = {
  'health / natural mixes / honey': 'hook, inside, case, guarantee_strip, offer',
  'visible beauty / cleaning': 'hook, problem (chips), before_after, inside or features, how_to, guarantee_strip, offer',
  'gadgets / tech / kitchen tools': 'hook, problem or case, features, how_to, guarantee_strip, bundle, offer',
  'fashion / clothes / bags / jewellery': 'hook, look, details, case, sizes, guarantee_strip, offer',
  'kids': 'hook, features, case, guarantee_strip, offer',
  'food': 'hook, inside, case, guarantee_strip, offer'
};
const TONE = {
  dz: 'Algerian Darija in Arabic script ONLY — never Modern Standard Arabic (say "علاش" not "لماذا", "واش" not "ماذا", "كيفاش" not "كيف", "بزاف" not "كثيراً", "درك" not "الآن", "حاب" not "تريد"). Tone examples (do NOT copy them): "حاب تسترجع طاقتك وحيويتك؟", "واش كاين داخل هاد الخلطة؟", "اطلب خلطتك درك!", "ريّح روحك من التعب".',
  ar: 'simple Modern Standard Arabic, warm, short lines.',
  fr: 'simple direct French for Algerian buyers, short lines.'
};

function styleFor(niche, text) {
  const t = String(text || '');
  if (/miel|honey|عسل|تمر|dattes|dates|زيت|huile|oil|خلطة|mélange|sidr|سدر|حبة البركة|ginseng/i.test(t)) return 'luxe_amber';
  if (/parfum|perfume|عطر|برفان|montre|watch|ساعة/i.test(t)) return 'luxe_dark';
  if (niche === 'home' && /promo|gadget|machine|électrique|كهربائي|آلة|مكينة|robot|روبو/i.test(t)) return 'bold_promo';
  return NICHE_STYLE[niche] || 'fresh_clean';
}

function prompt3({ brief, description, productName, price, lang }) {
  return `You write the CONTENT of an Algerian cash-on-delivery landing page (vertical stack of designed sections, viewed on phones). Design, colours and layout are done by code — you only choose the section list and write the texts.

Product: ${productName || brief.product_name}
Price: ${price || '?'} DZD
Seller notes: ${description || '(none)'}
Creative brief from a vision expert who studied the photos (trust it): ${JSON.stringify(brief)}

Choose "style" from: ${STYLES.join(', ')} (luxe_amber = honey, natural mixes, dates, oils, men's health; luxe_dark = perfume, watches, premium gadgets; fresh_clean = food, home, cleaning, natural cosmetics; bold_promo = gadgets, kitchen tools, deals; soft_beauty = skin, hair, makeup; tech_neon = tech, car accessories; kids_fun = kids, toys; fashion_editorial = clothes, bags, jewellery).
Choose "setting" from: ${Object.keys(SETTINGS).join(', ')}.
"props": 3-5 English nouns of real objects that belong next to this product in a photo (e.g. honey: "honey dipper", "honeycomb piece", "wildflowers"). Never the product itself.
Section types allowed: ${TYPES3.join(', ')}. Typical orders: ${Object.entries(ORDERS).map(([k, v]) => k + ' → ' + v).join('; ')}.
Rules:
- Start with "hook", end with "offer". 5 to 8 sections. "guarantee_strip" has no text (code draws it).
- "before_after" ONLY if the brief says visible_transformation true. "problem" only for a real pain the buyer feels; give it 3-4 short "chips" (pain words, 1-3 words each).
- "inside"/"features": 4-6 bullets, each max 6 words, benefits not specs. "case": 3 bullets (moments of use) + "lifestyle_prompt" in ENGLISH describing a person using the product in that moment. "how_to": 3 short steps. "sizes": bullets = the sizes only (e.g. "S","M","L","XL").
- Titles max 7 words with ONE "highlight" word that appears exactly in the title. Subtitle (hook only) max 8 words. Never repeat the same phrase in two sections.
- Do NOT write COD / delivery / payment lines or prices anywhere (code adds them once).
- Never invent statistics, customer numbers, ratings, reviews, doctors, certifications or medical cure claims.
- Language: ${TONE[lang] || TONE.dz}

Return ONLY JSON:
{"product_name": string, "niche": one of health|beauty|home|kids|men|fashion|tech|food, "style": string, "visible_transformation": bool, "is_wearable": bool, "props": [3-5 strings], "setting": string,
 "sections": [{"type": string, "title": string, "highlight": string, "subtitle"?: string, "bullets"?: [..], "steps"?: [..], "chips"?: [..], "lifestyle_prompt"?: string}]}`;
}

// sections → old panel shape → reuse the proven gating rules (before/after, fashion photos…) → v3 post-processing
function normalize3(j, { brief, lang, hint, productName }) {
  const old = { ...j, panels: (Array.isArray(j.sections) ? j.sections : j.panels || []).map((s) => ({ ...s, type: s.type === 'pain_chips' ? 'problem' : s.type === 'cta' ? 'offer' : s.type === 'trust' ? 'guarantee_strip' : s.type, scene_prompt: s.lifestyle_prompt || s.scene_prompt || '' })) };
  if (brief && brief.visible_transformation === false) old.visible_transformation = false;
  if (brief && brief.is_wearable) old.use_photos = true;
  if (!LAI.PALETTES[old.niche] && brief && brief.niche) old.niche = brief.niche;
  const plan = LAI.normalizePlan(old, productName || (brief && brief.product_name), lang, hint);
  let panels = plan.panels.map((p) => ({ ...p, type: p.type === 'trust' ? 'guarantee_strip' : p.type, badge: '', bg_prompt: '' }));
  // problem chips are edited as "bullets" in the editor
  panels.forEach((p) => { if (p.type === 'problem') { p.bullets = (p.chips.length ? p.chips : p.bullets.map((b) => b.split(/\s+/).slice(0, 3).join(' '))).slice(0, 4); p.chips = []; } });
  // exactly one guarantee strip, right before the offer
  panels = panels.filter((p, i) => p.type !== 'guarantee_strip' || panels.findIndex((x) => x.type === 'guarantee_strip') === i);
  if (!panels.some((p) => p.type === 'guarantee_strip')) panels.splice(Math.max(1, panels.length - 1), 0, { type: 'guarantee_strip', title: '', highlight: '', subtitle: '', bullets: [], steps: [], chips: [], before_points: [], after_points: [] });
  const gi = panels.findIndex((p) => p.type === 'guarantee_strip'), last = panels.length - 1;
  if (gi !== last - 1 && panels[last].type === 'offer') { const g = panels.splice(gi, 1)[0]; panels.splice(panels.length - 1, 0, g); }
  // highlight must be a word of the title
  panels.forEach((p) => { if (p.highlight && !p.title.split(/\s+/).some((w) => w.replace(/[؟?!.,،]/g, '') === p.highlight.replace(/[؟?!.,،]/g, ''))) p.highlight = ''; });
  const niche = plan.niche, text = hint + ' ' + (j.product_name || '') + ' ' + (brief ? brief.product_type : '');
  const forced = /miel|honey|عسل|تمر|dattes|dates|زيت|huile|oil|خلطة|mélange|parfum|perfume|عطر|برفان|montre|watch|ساعة/i.test(text) ? styleFor(niche, text) : '';
  let style = forced || (STYLES.includes(j.style) ? j.style : styleFor(niche, text));
  if (plan.use_photos || niche === 'fashion') style = 'fashion_editorial';
  if (style === 'fashion_editorial' && !plan.use_photos && niche !== 'fashion') style = styleFor(niche, text);
  const props = (Array.isArray(j.props) ? j.props : []).map((x) => String(x || '').replace(/[^\w\s\-]/g, '').trim().slice(0, 40)).filter(Boolean).slice(0, 5);
  const setting = SETTINGS[j.setting] ? j.setting : NICHE_SETTING[niche] || 'dark_studio';
  return { ...plan, v: 3, style, props, setting, panels };
}

// Copy chief: one short extra call that polishes the texts (Darija only, short titles, highlight in title, no MSA, no duplicates).
async function copyChief(plan, lang, meter) {
  const items = plan.panels.map((p, i) => ({ i, type: p.type, title: p.title, highlight: p.highlight, subtitle: p.subtitle || undefined, bullets: p.bullets.length ? p.bullets : undefined, steps: p.steps.length ? p.steps : undefined, chips: p.chips && p.chips.length ? p.chips : undefined })).filter((x) => x.type !== 'guarantee_strip');
  const prompt = `You are the copy chief of an Algerian e-commerce agency. Fix these landing page texts and return the SAME JSON array (same items, same "i", same number of bullets/steps/chips).
Rules: language = ${TONE[lang] || TONE.dz}
${lang === 'dz' ? 'Rewrite ANY Modern Standard Arabic phrasing into natural spoken Algerian Darija, the way sellers write Facebook ads (e.g. "لماذا تختار" → "علاش تختار", "الآن" → "درك", "كيف" → "كيفاش", "فوائد" → "واش يديرلك", "مميز" → "هايل", "تجربة" → "جرّب", "استمتع" → "تمتّع"). Titles should be a question or a direct benefit that talks to the buyer ("حاب ...؟", "واش ...؟", "علاش ...؟", "ريّح روحك ..."), never a dry noun phrase like "فوائد عسل صحي".' : ''}
Titles max 7 words. "highlight" must be ONE word that appears exactly in the title. Bullets max 6 words. No repeated phrases across items. Remove any COD / delivery / payment wording and any price or number of dinars from titles. Never add numbers, ratings, reviews or medical claims. Keep the meaning.
Return ONLY JSON: {"items": [...]}
${JSON.stringify(items)}`;
  try {
    const w = await LAI.writerAI(prompt, meter, (r) => Array.isArray(r.items) && r.items.length);
    const arr = w && w.j && Array.isArray(w.j.items) ? w.j.items : null;
    if (!arr) return { plan, ok: false };
    const s = (v, n) => String(v || '').replace(/\s+/g, ' ').trim().slice(0, n);
    arr.forEach((x) => {
      const p = plan.panels[x && x.i]; if (!p) return;
      if (x.title) p.title = s(x.title, 70);
      if (typeof x.highlight === 'string') p.highlight = s(x.highlight, 30);
      if (x.subtitle && p.subtitle) p.subtitle = s(x.subtitle, 110);
      ['bullets', 'steps', 'chips'].forEach((k) => { if (Array.isArray(x[k]) && p[k] && x[k].length === p[k].length) p[k] = x[k].map((b) => s(b, 70)).filter(Boolean); });
      if (p.highlight && !p.title.includes(p.highlight)) p.highlight = '';
    });
    return { plan, ok: true };
  } catch (e) { return { plan, ok: false }; }
}

async function analyze3({ image, images, description, productName, price, lang }) {
  lang = ['dz', 'ar', 'fr'].includes(lang) ? lang : getSetting('ai').defaultLang || 'dz';
  const imgs = (Array.isArray(images) && images.length ? images : image ? [image] : []).filter((x) => x && x.data).slice(0, 3);
  const hint = (productName || '') + ' ' + (description || ''), meter = { n: 0 };
  let brief = null;
  try { if (imgs.length || description) brief = LAI.cleanBrief(await LAI.textAI(LAI.briefPrompt({ description, productName, price }), imgs, meter)); } catch (e) { /* template below */ }
  if (brief) {
    const w = await LAI.writerAI(prompt3({ brief, description, productName, price, lang }), meter, (r) => Array.isArray(r.sections) && r.sections.length >= 3).catch(() => null);
    const j = w && w.j && Array.isArray(w.j.sections) ? w.j : null;
    if (j) {
      let plan = normalize3(j, { brief, lang, hint: hint + ' ' + brief.product_type, productName });
      const cc = await copyChief(plan, lang, meter);
      plan = cc.plan;
      return { plan: { ...plan, brief, pipeline: 'brief→' + w.model + (cc.ok ? ' + copy chief' : '') }, provider: 'workers-ai', neurons: meter.n };
    }
  }
  const fb = LAI.fallbackPlan({ productName, lang, description });
  const plan = normalize3({ ...fb, sections: fb.panels }, { brief, lang, hint, productName });
  return { plan: brief ? { ...plan, brief, pipeline: 'brief→template' } : plan, provider: 'template', neurons: meter.n, warning: 'AI writer not reachable — a ready structure was used' };
}

// ---- backgrounds: code assembles the prompt; the AI only gave props + setting ----
function bgPrompt({ setting, props, style }) {
  const st = SETTINGS[setting] || SETTINGS.dark_studio;
  const pr = (Array.isArray(props) ? props : []).map((x) => String(x).replace(/[^\w\s\-]/g, '').trim()).filter(Boolean).slice(0, 5).join(', ');
  return `${st}${pr ? ', ' + pr : ''}, arranged at the left and right edges, an empty clean surface in the lower third with free space in the centre for a product, ${PRESET_LIGHT[style] || PRESET_LIGHT.fresh_clean}, shallow depth of field, professional product photography backdrop, 4:5 vertical. No product, no jar, no bottle, no box, no people, no hands, no text, no letters, no logos.`;
}
function lifePrompt(text) {
  return `${String(text || 'a person using the product at home').slice(0, 400)}, North African family in a modern Algerian home, modest clothing, natural light, the product from image 0 clearly visible and unchanged, faces fully inside the frame, no text.`;
}

// Quality check of a generated image with the vision model (small JSON answer).
async function bgCheck({ image, kind, product, style, props, setting }, meter) {
  let prompt, j, r, pass;
  if (kind === 'life') {
    prompt = `This is a lifestyle photo for a "${String(product || 'product').slice(0, 60)}" landing page. Answer JSON only: {"has_text_or_letters": bool (any written words, letters or logos added on the image), "shows_person_using_product": bool, "face_cut_off": bool (a face is cut by the image border), "fits": "<what the person is doing>"}`;
    j = await LAI.workersText(prompt, [image], meter);
    r = { has_text_or_letters: j.has_text_or_letters === true, shows_person_using_product: j.shows_person_using_product !== false, face_cut_off: j.face_cut_off === true, fits: String(j.fits || '').slice(0, 60) };
    pass = !r.has_text_or_letters && r.shows_person_using_product && !r.face_cut_off;
  } else {
    const allowed = (Array.isArray(props) ? props : []).slice(0, 5).join(', ');
    prompt = `This should be an EMPTY product-photography background (${SETTINGS[setting] || 'a surface'}, ${PRESET_LIGHT[style] || ''}) for a "${String(product || 'product').slice(0, 60)}". Decorative props at the left/right edges are allowed${allowed ? ' (' + allowed + ')' : ''}. Answer JSON only: {"matches_theme": bool (it looks like that kind of backdrop and lighting), "has_text_or_letters": bool, "product_in_centre": bool (a jar, bottle, box, package or the product itself stands in the CENTRE third), "has_people": bool, "centre_is_empty": bool (the centre of the lower third is free for a product), "fits": "<product type it suits>"}`;
    j = await LAI.workersText(prompt, [image], meter);
    r = { matches_theme: j.matches_theme !== false, has_text_or_letters: j.has_text_or_letters === true, has_product_or_container: j.product_in_centre === true, has_people: j.has_people === true, centre_is_empty: j.centre_is_empty !== false, fits: String(j.fits || '').slice(0, 60) };
    pass = r.matches_theme && !r.has_text_or_letters && !r.has_product_or_container && !r.has_people;
  }
  return { ...r, pass };
}

// Shorter line when a text cannot fit its zone even at the minimum size.
async function shorten({ text, maxWords, lang }, meter) {
  const p = `Rewrite this landing page line shorter (max ${maxWords || 5} words), same meaning, same language (${TONE[lang] || TONE.dz}). Return ONLY JSON: {"text": string}\nLine: ${String(text).slice(0, 200)}`;
  const w = await LAI.writerAI(p, meter, (r) => typeof r.text === 'string' && r.text.length > 0);
  return w && w.j && w.j.text ? String(w.j.text).replace(/\s+/g, ' ').trim().slice(0, 90) : '';
}

module.exports = { STYLES, SETTINGS, PRESET_LIGHT, styleFor, prompt3, normalize3, copyChief, analyze3, bgPrompt, lifePrompt, bgCheck, shorten };
