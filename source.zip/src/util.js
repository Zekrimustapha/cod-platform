'use strict';
const { randomHex, randomB64url } = require('./crypto');

const MAX_BODY = 20 * 1024 * 1024; // 20 MB (images are compressed in the browser first)

// Works with Node's http request and with the Workers request shim (req._text).
function readBody(req, limit = MAX_BODY) {
  if (req._text !== undefined) {
    if (req._text.length > limit) return Promise.reject(Object.assign(new Error('Body too large'), { status: 413 }));
    return Promise.resolve(req._text);
  }
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        reject(Object.assign(new Error('Body too large'), { status: 413 }));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

async function readJson(req, limit) {
  const buf = await readBody(req, limit);
  if (!buf.length) return {};
  try {
    return JSON.parse(buf);
  } catch {
    throw Object.assign(new Error('Invalid JSON'), { status: 400 });
  }
}

async function readForm(req) {
  const buf = await readBody(req, 64 * 1024);
  return Object.fromEntries(new URLSearchParams(buf));
}

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'X-Frame-Options': 'SAMEORIGIN',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()'
};

function send(res, status, body, headers = {}) {
  res.writeHead(status, { ...SECURITY_HEADERS, ...headers });
  res.end(body);
}

function json(res, status, data, headers = {}) {
  send(res, status, JSON.stringify(data), { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
}

function html(res, status, body, headers = {}) {
  send(res, status, body, { 'Content-Type': 'text/html; charset=utf-8', ...headers });
}

function redirect(res, location, status = 302) {
  send(res, status, '', { Location: location });
}

function parseCookies(req) {
  const out = {};
  const raw = req.headers.cookie || '';
  raw.split(';').forEach((p) => {
    const i = p.indexOf('=');
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function slugify(s) {
  const base = String(s || '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
  return base || 'p-' + randomHex(3);
}

// Algerian mobile: 05 / 06 / 07 + 8 digits. Accepts +213 / 00213 / 213 prefixes.
function normalizePhone(raw) {
  let d = String(raw || '').replace(/[^0-9+]/g, '');
  d = d.replace(/^\+/, '');
  if (d.startsWith('00213')) d = '0' + d.slice(5);
  else if (d.startsWith('213')) d = '0' + d.slice(3);
  if (/^[567][0-9]{8}$/.test(d)) d = '0' + d;
  return /^0[567][0-9]{8}$/.test(d) ? d : null;
}

function token(bytes = 24) {
  return randomB64url(bytes);
}

function nowIso() {
  return new Date().toISOString();
}

// Simple in-memory sliding-window rate limiter.
const buckets = new Map();
function rateLimit(key, max, windowMs) {
  const now = Date.now();
  const arr = (buckets.get(key) || []).filter((t) => now - t < windowMs);
  if (arr.length >= max) {
    buckets.set(key, arr);
    return false;
  }
  arr.push(now);
  buckets.set(key, arr);
  return true;
}
setInterval(() => {
  const now = Date.now();
  for (const [k, arr] of buckets) if (!arr.some((t) => now - t < 3600e3)) buckets.delete(k);
}, 600e3).unref();

function clientIp(req) {
  const cf = req.headers['cf-connecting-ip'];
  if (cf) return String(cf);
  const xf = req.headers['x-forwarded-for'];
  if (xf) return String(xf).split(',')[0].trim();
  return req.socket.remoteAddress || '';
}

function int(v, def = 0) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : def;
}
function num(v, def = 0) {
  const n = parseFloat(v);
  return Number.isFinite(n) ? n : def;
}
function str(v, max = 500) {
  return String(v ?? '').trim().slice(0, max);
}

function httpError(status, message) {
  return Object.assign(new Error(message), { status });
}

module.exports = { readBody, readJson, readForm, send, json, html, redirect, parseCookies, esc, slugify, normalizePhone, token, nowIso, rateLimit, clientIp, int, num, str, httpError };
