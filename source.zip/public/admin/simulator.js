/* COD profit simulator — same formulas as the DZ COD Profit Simulator. */
(function () {
  'use strict';
  var DEF = {
    name: 'Example product', price: '6900', cost: '2900', pack: '300', call: '150', courier: '0', ret: '200', cod: '1', lost: '10', other: '0',
    cpo: '2', rate: '240', cr: '65', dr: '70', budget: '50', target: '100', minp: '800',
    lc_cny: '28', lc_units: '200', lc_kg: '0.4', lc_cnyusd: '0.14', lc_freight: '6', lc_agent: '5', lc_customs: '20', lc_clear: '20000', lc_local: '5000',
    af_cpm: '1.5', af_ctr: '2', af_conv: '5',
    z1s: '50', z1d: '82', z1f: '200', z2s: '35', z2d: '72', z2f: '300', z3s: '15', z3d: '55', z3f: '500',
    pl_k: '1.5', pl_drop: '3', b2: '11900', b3: '16900',
    rk_cr: '12', rk_dr: '12', rk_lo: '0.8', rk_hi: '1.6',
    cf_delay: '7', cf_stock: '10', cf_fixed: '30000',
    mp_fixed: '30000', mp_re: '0', mp_reorders: '1', mp_rise: '10', tp_budget: '30'
  };
  var TABS = [['overview', 'Overview'], ['landed', 'Landed cost'], ['funnel', 'Ad funnel'], ['regions', 'Regions'], ['price', 'Price lab'], ['bundles', 'Bundles'], ['scen', 'Scenarios'], ['sens', 'Sensitivity'], ['risk', 'Risk'], ['cash', 'Cash flow'], ['monthly', 'Monthly P&L'], ['test', 'Test plan'], ['saved', 'Saved']];
  function N(x) { var n = parseFloat(x); return isFinite(n) ? n : 0; }
  function da(n) { if (!isFinite(n)) return '—'; var r = Math.round(n); return (r < 0 ? '−' : '') + String(Math.abs(r)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' DA'; }
  function usd(n) { return isFinite(n) ? '$' + n.toFixed(2) : '—'; }
  function pct(n) { return isFinite(n) ? Math.round(n * 100) + '%' : '—'; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function num(v) { return { price: N(v.price), cost: N(v.cost), pack: N(v.pack), call: N(v.call), courier: N(v.courier), ret: N(v.ret), cod: N(v.cod), lost: N(v.lost), other: N(v.other), cpo: N(v.cpo), rate: N(v.rate) || 1, cr: N(v.cr), dr: N(v.dr), target: N(v.target) || 1, units: 1 }; }
  function calc(base, o) {
    var i = Object.assign({}, base, o || {});
    var cr = i.cr / 100, dr = i.dr / 100, D = i.target, unit = (i.cost + i.pack) * i.units;
    var L = cr > 0 && dr > 0 ? D / (cr * dr) : 0, C = L * cr, R = Math.max(0, C - D);
    var revenue = D * i.price, ads = L * i.cpo * i.rate, product = D * unit, call = C * i.call;
    var returns = R * i.ret + R * (i.lost / 100) * unit, courier = D * i.courier + revenue * i.cod / 100, other = revenue * i.other / 100;
    var costs = ads + product + call + returns + courier + other, profit = revenue - costs;
    return { L: L, C: C, D: D, R: R, revenue: revenue, ads: ads, product: product, call: call, returns: returns, courier: courier, other: other, costs: costs, profit: profit,
      per: D ? profit / D : 0, roi: costs ? profit / costs : 0, margin: revenue ? profit / revenue : 0, cash: ads + call + C * unit,
      maxCpo: L ? (profit + ads) / L / i.rate : 0, perPlaced: L ? profit / L : 0, beRoas: (profit + ads) > 0 ? revenue / (profit + ads) : Infinity, roas: ads ? revenue / ads : 0 };
  }
  function solveMin(base, key) {
    var f = function (x) { var o = {}; o[key] = x; return calc(base, o).profit; };
    if (f(100) <= 0) return null; if (f(1) > 0) return 1;
    var lo = 1, hi = 100; for (var k = 0; k < 40; k++) { var m = (lo + hi) / 2; if (f(m) > 0) hi = m; else lo = m; } return hi;
  }
  function verdictOf(r, minp) { if (r.profit <= 0) return 'NO GO'; if (r.roi >= 0.3 && r.per >= minp) return 'GO'; return 'TEST'; }
  function vcls(v) { return 'v-' + v.replace(' ', ''); }
  function rng(seed) { return function () { seed |= 0; seed = seed + 0x6D2B79F5 | 0; var t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

  function field(v, key, label, step, type) {
    return '<label class="f">' + esc(label) + '<input data-k="' + key + '" type="' + (type || 'number') + '" step="' + (step || 'any') + '" value="' + esc(v[key]) + '"></label>';
  }
  function kpi(label, value, note, color) { return '<div class="kpi"><span>' + esc(label) + '</span><b' + (color ? ' style="color:' + color + '"' : '') + '>' + value + '</b>' + (note ? '<small>' + note + '</small>' : '') + '</div>'; }
  function lines(arr) { return arr.map(function (x) { return '<div class="line"><span>' + x[0] + '</span><b' + (x[2] ? ' style="color:' + x[2] + '"' : '') + '>' + x[1] + '</b></div>'; }).join(''); }

  function mount(el, opts) {
    opts = opts || {};
    var st = { v: Object.assign({}, DEF), tab: 'overview', saved: [] };
    try { var sv = JSON.parse(localStorage.getItem('sim_saved') || '[]'); if (Array.isArray(sv)) st.saved = sv; } catch (e) {}
    var presets = opts.presets || [];

    el.innerHTML = '<div class="ph"><div><h1>Profit simulator</h1><p>Same engine as your DZ COD Profit Simulator.</p></div><div class="row"><label class="f inline">Load numbers <select data-preset><option value="">Example product</option>' +
      presets.map(function (p, i) { return '<option value="' + i + '">' + esc(p.name) + '</option>'; }).join('') + '</select></label><button class="btn" data-reset>Reset</button></div></div>' +
      '<div class="tabs" data-tabs>' + TABS.map(function (t) { return '<button data-tab="' + t[0] + '">' + t[1] + '</button>'; }).join('') + '</div>' +
      '<div class="split"><div class="r" style="position:static"><div class="card stack" data-core></div></div><div class="l stack"><div data-tabin></div><div data-out></div></div></div>';
    var core = el.querySelector('[data-core]'), tabin = el.querySelector('[data-tabin]'), out = el.querySelector('[data-out]');

    function renderCore() {
      var v = st.v;
      core.innerHTML = '<b>Product &amp; costs</b><div class="grid g3">' + field(v, 'name', 'Product name', '', 'text') + field(v, 'price', 'Selling price (DZD)') + field(v, 'cost', 'Product cost, landed (DZD)') + field(v, 'pack', 'Packaging (DZD)') +
        field(v, 'call', 'Call center fee / confirmed (DZD)') + field(v, 'courier', 'Courier fee you pay / delivered') + field(v, 'ret', 'Return fee / returned (DZD)') + field(v, 'cod', 'COD collection fee (%)') + field(v, 'lost', 'Returns lost or damaged (%)') + field(v, 'other', 'Other deductions (% revenue)') + '</div>' +
        '<b>Ads &amp; funnel</b><div class="grid g3">' + field(v, 'cpo', 'Cost per order placed (USD)', '0.1') + field(v, 'rate', '1 USD = DZD') + field(v, 'cr', 'Confirmation rate (%)') + field(v, 'dr', 'Delivery rate of confirmed (%)') + field(v, 'budget', 'Daily ad budget (USD)') + '</div>' +
        '<b>Goal</b><div class="grid g3">' + field(v, 'target', 'Target delivered orders') + field(v, 'minp', 'Minimum profit / order (DZD)') + '</div>';
    }
    function renderTabInputs() {
      var v = st.v, t = st.tab, h = '';
      if (t === 'landed') h = field(v, 'lc_cny', 'Supplier price / unit (CNY)') + field(v, 'lc_units', 'Units in the shipment') + field(v, 'lc_kg', 'Weight per unit (kg)') + field(v, 'lc_cnyusd', '1 CNY = USD') + field(v, 'lc_freight', 'Freight (USD/kg)') + field(v, 'lc_agent', 'Agent / inspection fee (%)') + field(v, 'lc_customs', 'Customs and taxes (%)') + field(v, 'lc_clear', 'Clearance and misc. (DZD)') + field(v, 'lc_local', 'Local transport (DZD)');
      if (t === 'funnel') h = field(v, 'af_cpm', 'CPM (USD)') + field(v, 'af_ctr', 'Click-through rate (%)') + field(v, 'af_conv', 'Visitor-to-order rate (%)');
      if (t === 'regions') h = [['z1', 'Major cities'], ['z2', 'Other northern wilayas'], ['z3', 'South and remote']].map(function (z) { return field(v, z[0] + 's', z[1] + ' — share %') + field(v, z[0] + 'd', 'delivery %') + field(v, z[0] + 'f', 'return fee (DZD)'); }).join('');
      if (t === 'price') h = field(v, 'pl_k', 'Ad cost rise per +1% price (0 none, 1 proportional)') + field(v, 'pl_drop', 'Confirmation drop per +10% price (pts)');
      if (t === 'bundles') h = field(v, 'b2', 'Price for 2 pieces (DZD)') + field(v, 'b3', 'Price for 3 pieces (DZD)');
      if (t === 'risk') h = field(v, 'rk_cr', 'Confirmation swing (± pts)') + field(v, 'rk_dr', 'Delivery swing (± pts)') + field(v, 'rk_lo', 'Lowest cost per order (× input)', '0.1') + field(v, 'rk_hi', 'Highest cost per order (× input)', '0.1');
      if (t === 'cash') h = field(v, 'cf_delay', 'Days until courier pays you') + field(v, 'cf_stock', 'Days of stock bought upfront') + field(v, 'cf_fixed', 'Monthly fixed costs (DZD)');
      if (t === 'monthly') h = field(v, 'mp_fixed', 'Monthly fixed costs (DZD)') + field(v, 'mp_re', 'Customers who reorder (%)') + field(v, 'mp_reorders', 'Reorders per returning customer') + field(v, 'mp_rise', 'Ad cost rise per budget doubling (%)');
      if (t === 'test') h = field(v, 'tp_budget', 'Test budget (USD)');
      tabin.innerHTML = h ? '<div class="card"><div class="grid g3">' + h + '</div></div>' : '';
      el.querySelectorAll('[data-tab]').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-tab') === t); });
    }

    function compute() {
      var v = st.v, base = num(v), r = calc(base), minp = N(v.minp);
      var pess = calc(base, { cr: base.cr - 10, dr: base.dr - 10, cpo: base.cpo * 1.3 }), opt = calc(base, { cr: base.cr + 5, dr: base.dr + 5, cpo: base.cpo * 0.85 });
      var R = rng(42), runs = [], rcr = N(v.rk_cr), rdr = N(v.rk_dr), lo = N(v.rk_lo), hi = N(v.rk_hi);
      for (var k = 0; k < 3000; k++) runs.push(calc(base, { cr: Math.min(100, Math.max(5, base.cr + (R() * 2 - 1) * rcr)), dr: Math.min(100, Math.max(5, base.dr + (R() * 2 - 1) * rdr)), cpo: base.cpo * (lo + R() * (hi - lo)), cost: base.cost * (0.9 + R() * 0.2) }).per);
      runs.sort(function (a, b) { return a - b; });
      return { v: v, base: base, r: r, minp: minp, pess: pess, opt: opt, runs: runs, chance: runs.filter(function (x) { return x > 0; }).length / runs.length };
    }

    function renderOut() {
      var M = compute(), v = M.v, base = M.base, r = M.r, minp = M.minp, h = '', t = st.tab;
      var verdict = verdictOf(r, minp);
      if (t === 'overview') {
        var unit = base.cost + base.pack, minDr = solveMin(base, 'dr'), minCr = solveMin(base, 'cr'), od = base.cpo ? N(v.budget) / base.cpo : 0;
        var vc = verdict === 'GO' ? '#0F5C46' : verdict === 'TEST' ? '#B45309' : '#9A1C12';
        h += '<div class="card" style="background:' + vc + ';color:#fff;border:0"><div class="row"><span class="chip" style="background:#fff;color:' + vc + '">' + verdict + '</span><b style="font-size:16px">' +
          (verdict === 'GO' ? 'Strong numbers. Test it now with a small budget.' : verdict === 'TEST' ? 'Profitable but thin. Test carefully and watch the kill line.' : 'These numbers lose money. Change price, cost or cost per order.') + '</b></div><div style="margin-top:8px;display:flex;flex-direction:column;gap:2px">' +
          ['' + (r.maxCpo > base.cpo ? 'Ad cost can rise ' + Math.round((r.maxCpo / base.cpo - 1) * 100) + '% before you lose money' : 'Your cost per order is already above break-even'),
            M.pess.profit > 0 ? 'Still profitable in the pessimistic scenario' : 'Loses money in the pessimistic scenario',
            'Product cost is ' + Math.round(unit / (base.price || 1) * 100) + '% of the price (aim under 40%)',
            Math.round(M.chance * 100) + '% chance of profit across 3,000 random runs'].map(function (x) { return '<span>• ' + esc(x) + '</span>'; }).join('') + '</div></div>';
        h += '<div class="cards" style="margin-top:12px">' + kpi('Net profit', da(r.profit), 'From ' + Math.round(r.D) + ' delivered orders', r.profit > 0 ? '#0B5132' : '#9A1C12') + kpi('Profit per delivered order', da(r.per)) + kpi('ROI', pct(r.roi), 'Net margin ' + pct(r.margin)) + kpi('Chance of profit', pct(M.chance), '3,000 random runs') + kpi('Cash tied up', da(r.cash), 'Ads + call center + stock shipped') + '</div>';
        h += '<div class="card"><h2>Break-even points</h2><div class="cards" style="margin:0">' + kpi('Max cost per order', usd(r.maxCpo), 'Now ' + usd(base.cpo)) + kpi('Min delivery rate', minDr === null ? '>100%' : Math.round(minDr) + '%', 'Now ' + base.dr + '%') + kpi('Min confirmation rate', minCr === null ? '>100%' : Math.round(minCr) + '%', 'Now ' + base.cr + '%') + kpi('Break-even ROAS', isFinite(r.beRoas) ? r.beRoas.toFixed(2) + 'x' : '—', 'Now ' + r.roas.toFixed(2) + 'x') + '</div></div>';
        var split = [['Ads', r.ads, '#B45309'], ['Product + packaging', r.product, '#57625C'], ['Call center', r.call, '#4B2A86'], ['Returns (fees + losses)', r.returns, '#B42318'], ['Courier + COD fee', r.courier + r.other, '#1D3F8F'], ['Profit', Math.max(0, r.profit), '#0F5C46']];
        h += '<div class="cols" style="margin-top:12px"><div class="card"><h2>Where the sale price goes</h2>' + split.map(function (x) { var s = r.revenue ? x[1] / r.revenue : 0; return '<div style="margin-bottom:8px"><div class="row" style="justify-content:space-between"><span>' + x[0] + '</span><span><b>' + da(x[1]) + '</b> · ' + (s * 100).toFixed(1) + '%</span></div><div class="meter"><i style="width:' + Math.min(100, s * 100) + '%;background:' + x[2] + '"></i></div></div>'; }).join('') + '<div class="muted">Revenue <b style="color:#15201B">' + da(r.revenue) + '</b></div></div>' +
          '<div class="card"><h2>Order funnel</h2>' + lines([['Orders placed', Math.round(r.L)], ['Confirmed', Math.round(r.C)], ['Delivered', Math.round(r.D)], ['Returned', Math.round(r.R)]]) + '<h2 style="margin-top:12px">Per day at your ad budget</h2>' +
          lines([['Orders placed / day', od.toFixed(1)], ['Delivered / day', (od * base.cr / 100 * base.dr / 100).toFixed(1)], ['Profit / day', da(r.perPlaced * od)], ['Profit / 30 days', da(r.perPlaced * od * 30)]]) + '</div></div>';
      }
      if (t === 'landed') {
        var g = N(v.lc_cny) * N(v.lc_cnyusd) * base.rate, ag = g * N(v.lc_agent) / 100, fr = N(v.lc_kg) * N(v.lc_freight) * base.rate, cu = (g + fr) * N(v.lc_customs) / 100, fx = (N(v.lc_clear) + N(v.lc_local)) / (N(v.lc_units) || 1), tot = g + ag + fr + cu + fx;
        h = '<div class="card"><div class="row" style="justify-content:space-between"><div><div class="muted small">Landed cost per unit</div><b style="font-size:26px">' + da(tot) + '</b><div class="muted small">' + pct(tot / (base.price || 1)) + ' of the selling price</div></div><button class="btn pri" data-set="cost" data-val="' + Math.round(tot) + '">Use as product cost</button></div>' +
          lines([['Goods', da(g)], ['Agent fee', da(ag)], ['Freight', da(fr)], ['Customs and taxes', da(cu)], ['Fixed costs per unit', da(fx)]]) + '<p class="muted small">Estimates. Replace with your supplier and forwarder quotes.</p></div>';
      }
      if (t === 'funnel') {
        var cpc = N(v.af_ctr) ? N(v.af_cpm) / 1000 / (N(v.af_ctr) / 100) : 0, cpo = N(v.af_conv) ? cpc / (N(v.af_conv) / 100) : 0, be = r.maxCpo ? cpc / r.maxCpo : 0;
        h = '<div class="card"><div class="cards" style="margin:0">' + kpi('Cost per click', '$' + cpc.toFixed(3)) + kpi('Cost per order', usd(cpo)) + kpi('Visitors per order', N(v.af_conv) ? Math.round(100 / N(v.af_conv)) : '—') + kpi('Max cost per order', usd(r.maxCpo)) + '</div>' +
          '<p>Visitor-to-order rate needed to break even: <b>' + (be * 100).toFixed(2) + '%</b> (yours ' + N(v.af_conv).toFixed(2) + '%)</p><button class="btn pri" data-set="cpo" data-val="' + cpo.toFixed(2) + '">Use as cost per order</button></div>';
      }
      if (t === 'regions') {
        var wS = 0, wD = 0, rw = 0, fw = 0, rows = '';
        [['z1', 'Major cities'], ['z2', 'Other northern wilayas'], ['z3', 'South and remote']].forEach(function (z) {
          var sh = N(v[z[0] + 's']), zd = N(v[z[0] + 'd']), zf = N(v[z[0] + 'f']); wS += sh; wD += sh * zd; var rr = sh * (1 - zd / 100); rw += rr; fw += rr * zf;
          var zr = calc(base, { dr: zd, ret: zf }); var vd = zr.per >= minp ? ['Keep selling', '#0B5132'] : zr.per > 0 ? ['Thin — raise delivery fee', '#8A4B00'] : ['Stop selling here', '#9A1C12'];
          rows += '<tr><td>' + z[1] + '</td><td>' + sh + '%</td><td>' + zd + '%</td><td>' + da(zf) + '</td><td><b>' + da(zr.per) + '</b></td><td style="color:' + vd[1] + ';font-weight:700">' + vd[0] + '</td></tr>';
        });
        var wdr = wS ? wD / wS : 0, wf = rw ? fw / rw : 0;
        h = '<div class="card"><div class="scroll"><table class="tbl"><tr><th>Zone</th><th>Share</th><th>Delivery</th><th>Return fee</th><th>Profit / order</th><th></th></tr>' + rows + '</table></div><div class="row" style="margin-top:10px"><span>Weighted delivery rate <b>' + wdr.toFixed(1) + '%</b></span><span>Weighted return fee <b>' + da(wf) + '</b></span><button class="btn pri" data-apply-regions="' + wdr.toFixed(1) + '|' + Math.round(wf) + '">Apply to inputs</button></div></div>';
      }
      if (t === 'price') {
        var k2 = N(v.pl_k), drop = N(v.pl_drop), pr = [];
        for (var m = 6; m <= 16; m++) { var mult = m / 10, pp = Math.round(base.price * mult), pc = base.cpo * Math.pow(mult, k2); var x = calc(base, { price: pp, cpo: pc, cr: Math.min(100, Math.max(1, base.cr - drop * (mult - 1) * 10)), dr: Math.min(100, Math.max(1, base.dr - drop / 2 * (mult - 1) * 10)) }); pr.push({ p: pp, cpo: pc, per: x.per, day: pc ? x.perPlaced * N(v.budget) / pc : 0 }); }
        var best = Math.max.apply(null, pr.map(function (x) { return x.day; })), mx = Math.max(1, best);
        h = '<div class="card"><div class="hbars">' + pr.map(function (x) { return '<i style="height:' + Math.max(2, Math.round(Math.max(0, x.day) / mx * 110)) + 'px;background:' + (x.day === best ? '#0F5C46' : '#9FC9B8') + '"></i>'; }).join('') + '</div><div class="scroll"><table class="tbl"><tr><th>Price</th><th>Cost / order</th><th>Profit / delivered</th><th>Profit / day</th></tr>' +
          pr.map(function (x) { var b = x.day === best; return '<tr' + (b ? ' class="sel"' : '') + '><td>' + da(x.p) + (b ? ' <b>· Best</b>' : '') + '</td><td>' + usd(x.cpo) + '</td><td>' + da(x.per) + '</td><td>' + da(x.day) + '</td></tr>'; }).join('') + '</table></div></div>';
      }
      if (t === 'bundles') {
        var bs = [[1, base.price], [2, N(v.b2)], [3, N(v.b3)]].map(function (b) { var x = calc(base, { price: b[1], units: b[0] }); return { n: b[0], p: b[1], per: x.per, p100: x.per * 100 * base.cr / 100 * base.dr / 100 }; });
        var bb = Math.max.apply(null, bs.map(function (b) { return b.p100; }));
        h = '<div class="card"><table class="tbl"><tr><th>Pieces</th><th>Price</th><th>Profit / delivered</th><th>Per 100 orders placed</th><th></th></tr>' + bs.map(function (b) { return '<tr><td>' + b.n + '</td><td>' + da(b.p) + '</td><td>' + da(b.per) + '</td><td>' + da(b.p100) + '</td><td>' + (b.p100 === bb ? '<b style="color:#0B5132">Best</b>' : '') + '</td></tr>'; }).join('') + '</table><p class="muted small">Same funnel and ad cost for every offer.</p></div>';
      }
      if (t === 'scen') {
        h = '<div class="card scroll"><table class="tbl"><tr><th></th><th>Confirm</th><th>Deliver</th><th>Cost/order</th><th>Net profit</th><th>Per order</th><th>ROI</th><th>Verdict</th></tr>' +
          [['Pessimistic', M.pess, base.cr - 10, base.dr - 10, base.cpo * 1.3], ['Base', r, base.cr, base.dr, base.cpo], ['Optimistic', M.opt, base.cr + 5, base.dr + 5, base.cpo * 0.85]].map(function (s) { var vv = verdictOf(s[1], minp); return '<tr><td><b>' + s[0] + '</b></td><td>' + Math.round(s[2]) + '%</td><td>' + Math.round(s[3]) + '%</td><td>' + usd(s[4]) + '</td><td><b style="color:' + (s[1].profit > 0 ? '#0B5132' : '#9A1C12') + '">' + da(s[1].profit) + '</b></td><td>' + da(s[1].per) + '</td><td>' + pct(s[1].roi) + '</td><td><span class="verdict ' + vcls(vv) + '">' + vv + '</span></td></tr>'; }).join('') +
          '</table><p class="muted small">Pessimistic: confirmation −10 pts, delivery −10 pts, cost per order +30%. Optimistic: +5, +5, −15%.</p></div>';
      }
      if (t === 'sens') {
        var cs = [1, 1.5, 2, 2.5, 3, 4], rs = [40, 50, 60, 70, 80, 90];
        var nc = cs.reduce(function (a, b) { return Math.abs(b - base.cpo) < Math.abs(a - base.cpo) ? b : a; }), nr = rs.reduce(function (a, b) { return Math.abs(b - base.dr) < Math.abs(a - base.dr) ? b : a; });
        h = '<div class="card scroll"><table class="tbl sens"><tr><th>Delivery ↓ / CPO →</th>' + cs.map(function (c) { return '<th>$' + c.toFixed(2) + '</th>'; }).join('') + '</tr>' +
          rs.map(function (d) { return '<tr><th>' + d + '%</th>' + cs.map(function (c) { var x = calc(base, { dr: d, cpo: c }).per; var g = x >= minp, ok = x > 0; return '<td style="background:' + (g ? '#DDF0E6' : ok ? '#FFF3E0' : '#FDECEA') + ';color:' + (g ? '#0B5132' : ok ? '#8A4B00' : '#9A1C12') + (d === nr && c === nc ? ';outline:2px solid #15201B' : '') + '">' + Math.round(x) + '</td>'; }).join('') + '</tr>'; }).join('') +
          '</table><p class="muted small">Profit per delivered order (DA). Outlined cell is closest to your inputs.</p></div>';
      }
      if (t === 'risk') {
        var runs = M.runs, q = function (p) { return runs[Math.floor(p * (runs.length - 1))]; }, avg = runs.reduce(function (a, b) { return a + b; }, 0) / runs.length;
        var mn = runs[0], mxx = runs[runs.length - 1], sp = (mxx - mn) || 1, bins = []; for (var i = 0; i < 14; i++) bins.push(0);
        runs.forEach(function (x) { bins[Math.min(13, Math.floor((x - mn) / sp * 14))]++; }); var bm = Math.max.apply(null, bins);
        h = '<div class="card"><div class="cards" style="margin:0 0 12px">' + kpi('Chance of profit', pct(M.chance)) + kpi('Chance of your minimum', pct(runs.filter(function (x) { return x >= minp; }).length / runs.length)) + kpi('Average profit / order', da(avg)) + kpi('Average net for target', da(avg * base.target)) + kpi('Bad case (P10)', da(q(0.1))) + kpi('Typical', da(q(0.5))) + kpi('Good case (P90)', da(q(0.9))) + '</div>' +
          '<div class="hbars">' + bins.map(function (b, i) { var mid = mn + (i + 0.5) * sp / 14; return '<i style="height:' + Math.max(2, Math.round(b / bm * 110)) + 'px;background:' + (mid > 0 ? '#0F5C46' : '#B42318') + '"></i>'; }).join('') + '</div><div class="row muted small" style="justify-content:space-between"><span>' + da(mn) + '</span><span>Profit per delivered order across runs</span><span>' + da(mxx) + '</span></div></div>';
      }
      if (t === 'cash') {
        var cB = N(v.budget), cOD = base.cpo ? cB / base.cpo : 0, cC = cOD * base.cr / 100, cD = cC * base.dr / 100, cR = cC - cD, ucost = base.cost + base.pack;
        var daily = cB * base.rate + cC * base.call + N(v.cf_fixed) / 30, stockDay = (cD + cR * base.lost / 100) * ucost, inc = cD * base.price * (1 - base.cod / 100) - cD * base.courier - cR * base.ret;
        var cum = -stockDay * N(v.cf_stock), low = cum, pos = null, ser = [cum];
        for (var d = 1; d <= 60; d++) { cum -= daily; if (d > N(v.cf_stock)) cum -= stockDay; if (d > N(v.cf_delay)) cum += inc; ser.push(cum); if (cum < low) low = cum; if (pos === null && cum > 0) pos = d; }
        var cm = Math.max.apply(null, ser.map(Math.abs)) || 1;
        h = '<div class="card"><div class="cards" style="margin:0 0 12px">' + kpi('Cash you need at the lowest point', da(-low), '', '#9A1C12') + kpi('Cash turns positive on day', pos === null ? 'Not in 60 days' : pos) + kpi('Cash on day 60', da(ser[60]), '', ser[60] > 0 ? '#0B5132' : '#9A1C12') + '</div>' +
          '<div style="display:flex;gap:4px;height:180px">' + ser.filter(function (_, i) { return i % 5 === 0; }).map(function (x, i) { return '<div style="flex:1;display:flex;flex-direction:column" title="Day ' + i * 5 + ': ' + da(x) + '"><div style="height:90px;display:flex;align-items:flex-end"><i style="display:block;width:100%;height:' + (x > 0 ? Math.round(x / cm * 90) : 0) + 'px;background:#0F5C46;border-radius:3px 3px 0 0"></i></div><div style="height:90px;border-top:1px solid #C9C6BB"><i style="display:block;width:100%;height:' + (x < 0 ? Math.round(-x / cm * 90) : 0) + 'px;background:#B42318;border-radius:0 0 3px 3px"></i></div></div>'; }).join('') + '</div>' +
          '<div class="barlbl">' + ser.filter(function (_, i) { return i % 5 === 0; }).map(function (_, i) { return '<span>' + i * 5 + '</span>'; }).join('') + '</div><p class="muted small">Uses the daily ad budget from the left. Ads and calls paid daily, upfront stock on day 0, courier pays after the delay.</p></div>';
      }
      if (t === 'monthly') {
        var mB = N(v.budget), rise = N(v.mp_rise) / 100, mOD = base.cpo ? mB / base.cpo : 0, sc = r.L ? mOD * 30 / r.L : 0, mDel = r.D * sc, reC = mDel * N(v.mp_re) / 100 * N(v.mp_reorders), apd = r.D ? r.ads / r.D : 0;
        var bef = r.profit * sc, re = reC * (r.per + apd), net = bef - N(v.mp_fixed) + re;
        var cpoAt = function (b) { return base.cpo * Math.pow(1 + rise, Math.log(b / (mB || 1)) / Math.LN2); };
        var srows = [20, 50, 100, 200, 500, 1000].map(function (b) { var c = cpoAt(b), x = calc(base, { cpo: c }); return { b: b, c: c, pm: x.perPlaced * b / c * 30 }; }), bp = Math.max.apply(null, srows.map(function (x) { return x.pm; }));
        h = '<div class="cols"><div class="card">' + lines([['Revenue', da(r.revenue * sc)], ['Ads', da(-r.ads * sc)], ['Product + packaging', da(-r.product * sc)], ['Call center', da(-r.call * sc)], ['Returns', da(-r.returns * sc)], ['Courier + COD fee', da(-(r.courier + r.other) * sc)], ['<b>Profit before fixed costs</b>', da(bef)], ['Fixed costs', da(-N(v.mp_fixed))], ['Profit from reorders', da(re)], ['<b>Net monthly profit</b>', da(net), net > 0 ? '#0B5132' : '#9A1C12'], ['Delivered / month to cover fixed', r.per > 0 ? Math.ceil(N(v.mp_fixed) / r.per) : '—']]) + '</div>' +
          '<div class="card"><h2>Scaling the daily budget</h2><table class="tbl"><tr><th>Budget</th><th>Cost / order</th><th>Profit / month</th></tr>' + srows.map(function (x) { return '<tr' + (x.pm === bp ? ' class="sel"' : '') + '><td>$' + x.b + '/day</td><td>' + usd(x.c) + '</td><td><b>' + da(x.pm) + '</b></td></tr>'; }).join('') + '</table></div></div>';
      }
      if (t === 'test') {
        var tb = N(v.tp_budget), to = base.cpo ? tb / base.cpo : 0, td = to * base.cr / 100 * base.dr / 100;
        h = '<div class="card"><div class="cards" style="margin:0 0 12px">' + kpi('Orders placed', to.toFixed(1)) + kpi('Confirmed', (to * base.cr / 100).toFixed(1)) + kpi('Delivered', td.toFixed(1)) + kpi('Expected profit or loss', da(td * r.per), '', r.per > 0 ? '#0B5132' : '#9A1C12') + kpi('Cost to reach 10 delivered', base.cr && base.dr ? '$' + Math.round(10 / (base.cr / 100 * base.dr / 100) * base.cpo) : '—') + '</div>' +
          '<div class="notice" style="background:#FEF3F2;border-color:#F3C1BC;color:#9A1C12"><b>Kill line:</b> stop if your cost per order stays above ' + usd(r.maxCpo) + '</div><p class="muted">Judge only after at least 20 orders placed.</p></div>';
      }
      if (t === 'saved') {
        h = '<div class="card"><div class="row" style="margin-bottom:10px"><button class="btn pri" data-save>Save current</button><button class="btn" data-copy>Copy summary</button></div>' +
          (st.saved.length ? '<table class="tbl"><tr><th>Product</th><th>Price</th><th>Net profit</th><th>Per order</th><th>Verdict</th><th></th></tr>' + st.saved.map(function (s, i) { return '<tr><td><b>' + esc(s.name) + '</b></td><td>' + da(s.price) + '</td><td>' + da(s.profit) + '</td><td>' + da(s.per) + '</td><td><span class="verdict ' + vcls(s.v) + '">' + s.v + '</span></td><td><button class="btn sm" data-load="' + i + '">Load</button> <button class="btn sm danger" data-del="' + i + '">Delete</button></td></tr>'; }).join('') + '</table>' : '<p class="muted">Nothing saved yet. Saved on this computer.</p>') + '</div>';
      }
      out.innerHTML = h;
      st.last = { verdict: verdict, r: r };
    }

    function full() { renderCore(); renderTabInputs(); renderOut(); }
    el.addEventListener('input', function (e) { var k = e.target.getAttribute('data-k'); if (k) { st.v[k] = e.target.value; renderOut(); } });
    el.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      if (b.hasAttribute('data-tab')) { st.tab = b.getAttribute('data-tab'); renderTabInputs(); renderOut(); }
      if (b.hasAttribute('data-reset')) { st.v = Object.assign({}, DEF); el.querySelector('[data-preset]').value = ''; full(); }
      if (b.hasAttribute('data-set')) { st.v[b.getAttribute('data-set')] = b.getAttribute('data-val'); renderCore(); renderOut(); if (opts.toast) opts.toast('Updated'); }
      if (b.hasAttribute('data-apply-regions')) { var p = b.getAttribute('data-apply-regions').split('|'); st.v.dr = p[0]; st.v.ret = p[1]; renderCore(); renderOut(); if (opts.toast) opts.toast('Delivery rate and return fee updated'); }
      if (b.hasAttribute('data-save')) { var c = calc(num(st.v)); st.saved.push({ name: st.v.name, price: N(st.v.price), profit: c.profit, per: c.per, v: verdictOf(c, N(st.v.minp)), inputs: Object.assign({}, st.v) }); persist(); renderOut(); }
      if (b.hasAttribute('data-load')) { st.v = Object.assign({}, DEF, st.saved[+b.getAttribute('data-load')].inputs); st.tab = 'overview'; full(); }
      if (b.hasAttribute('data-del')) { st.saved.splice(+b.getAttribute('data-del'), 1); persist(); renderOut(); }
      if (b.hasAttribute('data-copy')) { var s = st.v.name + ': ' + st.last.verdict + ' · net ' + da(st.last.r.profit) + ' · ' + da(st.last.r.per) + '/order · max CPO ' + usd(st.last.r.maxCpo); try { navigator.clipboard.writeText(s); } catch (x) {} if (opts.toast) opts.toast('Summary copied'); }
    });
    el.querySelector('[data-preset]').addEventListener('change', function (e) {
      var p = presets[+e.target.value]; st.v = Object.assign({}, DEF, p ? p.values : {}); full();
    });
    function persist() { try { localStorage.setItem('sim_saved', JSON.stringify(st.saved)); } catch (e) {} }
    full();
  }
  window.Sim = { mount: mount, calc: calc, num: num, DEF: DEF };
})();
