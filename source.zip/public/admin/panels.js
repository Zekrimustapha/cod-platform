/* Panel renderer: draws Algerian-style landing banners (Arabic text over AI scenes / product photo) on a canvas. */
(function () {
  'use strict';
  var W = 1080;
  var L = {
    ar: { sizes: 'اختر مقاسك في الاستمارة', before: 'قبل', after: 'بعد', cod: 'الدفع عند الاستلام', deliv: 'التوصيل لكل الولايات', call: 'مكالمة تأكيد قبل الإرسال', exch: 'استبدال مضمون', order: 'اطلب الآن', special: 'عرض خاص', only: 'فقط', currency: 'دج', piece: 'قطعة', pieces: 'قطع', step: 'الخطوة' },
    dz: { sizes: 'اختاري المقاس في الاستمارة', before: 'قبل', after: 'بعد', cod: 'الخلاص عند الاستلام', deliv: 'توصيل لكل الولايات', call: 'نعيطولك قبل ما نبعثو', exch: 'استبدال مضمون', order: 'اطلب درك', special: 'عرض خاص', only: 'برك', currency: 'دج', piece: 'حبة', pieces: 'حبات', step: 'الخطوة' },
    fr: { sizes: 'Choisissez la taille dans le formulaire', before: 'Avant', after: 'Après', cod: 'Paiement à la livraison', deliv: 'Livraison toutes wilayas', call: 'Appel de confirmation', exch: 'Échange garanti', order: 'Commander', special: 'Offre spéciale', only: 'seulement', currency: 'DA', piece: 'pièce', pieces: 'pièces', step: 'Étape' }
  };
  var fontsReady = {};
  function ensureFont(font) {
    if (fontsReady[font]) return fontsReady[font];
    var q = { Cairo: 'Cairo:wght@600;700;800;900', Tajawal: 'Tajawal:wght@500;700;800', Almarai: 'Almarai:wght@400;700;800', 'IBM Plex Sans Arabic': 'IBM+Plex+Sans+Arabic:wght@500;600;700', 'El Messiri': 'El+Messiri:wght@500;600;700', 'Readex Pro': 'Readex+Pro:wght@400;600;700', Changa: 'Changa:wght@500;700;800', 'Noto Kufi Arabic': 'Noto+Kufi+Arabic:wght@500;700;800' }[font] || 'Cairo:wght@600;700;800;900';
    var link = document.createElement('link'); link.rel = 'stylesheet'; link.href = 'https://fonts.googleapis.com/css2?family=' + q + '&display=swap'; document.head.appendChild(link);
    fontsReady[font] = Promise.race([
      Promise.all(['700', '800', '900'].map(function (w) { return document.fonts.load(w + ' 60px "' + font + '"', 'ابت'); })),
      new Promise(function (r) { setTimeout(r, 5000); })
    ]).catch(function () {});
    return fontsReady[font];
  }
  var imgCache = {};
  function loadImg(url) {
    if (!url) return Promise.resolve(null);
    if (imgCache[url]) return imgCache[url];
    imgCache[url] = new Promise(function (res) { var i = new Image(); i.onload = function () { res(i); }; i.onerror = function () { res(null); }; i.src = url; });
    return imgCache[url];
  }
  // Remove a plain (light, uniform) background from the product photo so it can sit on AI scenes.
  // Busy backgrounds fall back to a clean white rounded card.
  var cutCache = {};
  function cutout(img) {
    if (!img) return null;
    if (cutCache[img.src]) return cutCache[img.src];
    var s = Math.min(1, 800 / Math.max(img.width, img.height)), w = Math.round(img.width * s), h = Math.round(img.height * s);
    var cv = document.createElement('canvas'); cv.width = w; cv.height = h; var x = cv.getContext('2d'); x.drawImage(img, 0, 0, w, h);
    var d = x.getImageData(0, 0, w, h), px = d.data;
    var pts = [[2, 2], [w - 3, 2], [2, h - 3], [w - 3, h - 3], [w >> 1, 2], [w >> 1, h - 3], [2, h >> 1], [w - 3, h >> 1]];
    var cs = pts.map(function (p) { var i = (p[1] * w + p[0]) * 4; return [px[i], px[i + 1], px[i + 2]]; });
    var avg = [0, 1, 2].map(function (k) { return cs.reduce(function (a, c) { return a + c[k]; }, 0) / cs.length; });
    var spread = Math.max.apply(null, cs.map(function (c) { return Math.abs(c[0] - avg[0]) + Math.abs(c[1] - avg[1]) + Math.abs(c[2] - avg[2]); }));
    var res;
    if (spread < 60 && (avg[0] + avg[1] + avg[2]) / 3 > 150) {
      var tol = 48, seen = new Uint8Array(w * h), stack = [];
      for (var i = 0; i < w; i++) { stack.push(i, (h - 1) * w + i); }
      for (var j = 0; j < h; j++) { stack.push(j * w, j * w + w - 1); }
      while (stack.length) {
        var p = stack.pop(); if (seen[p]) continue; seen[p] = 1;
        var o = p * 4; if (Math.abs(px[o] - avg[0]) + Math.abs(px[o + 1] - avg[1]) + Math.abs(px[o + 2] - avg[2]) > tol) continue;
        px[o + 3] = 0;
        var xx = p % w, yy = (p / w) | 0;
        if (xx > 0) stack.push(p - 1); if (xx < w - 1) stack.push(p + 1); if (yy > 0) stack.push(p - w); if (yy < h - 1) stack.push(p + w);
      }
      x.putImageData(d, 0, 0);
      res = { canvas: cv, card: false };
    } else {
      res = { canvas: cv, card: true };
    }
    cutCache[img.src] = res;
    return res;
  }
  // Real transparent cut-out (Cutout.js / product editor ✂) wins over the flood-fill guess.
  var CUR = { cut: null, fx: {}, accent: '#F2A93B', dark: '#0B2A20' };
  function placeProduct(c, img, cx, cy, size) {
    var cut = CUR.cut ? { canvas: CUR.cut, card: false } : cutout(img); if (!cut) return;
    var cv = cut.canvas, cw = cv.naturalWidth || cv.width, ch = cv.naturalHeight || cv.height;
    var s = size / Math.max(cw, ch), w = cw * s, h = ch * s, x = cx - w / 2, y = cy - h / 2, fx = CUR.fx || {};
    c.save();
    if (cut.card) {
      c.shadowColor = 'rgba(0,0,0,.45)'; c.shadowBlur = 40; c.shadowOffsetY = 12;
      rr(c, x - 18, y - 18, w + 36, h + 36, 30); c.fillStyle = '#fff'; c.fill();
      c.shadowColor = 'transparent'; rr(c, x, y, w, h, 18); c.clip();
      c.drawImage(cv, x, y, w, h); c.restore(); return;
    }
    var base = y + h;
    if (fx.glow !== false) { // soft back glow in the accent colour
      var R = Math.max(w, h) * 0.78, g = c.createRadialGradient(cx, cy, R * 0.05, cx, cy, R);
      g.addColorStop(0, hexA(CUR.accent, 0.55)); g.addColorStop(0.55, hexA(CUR.accent, 0.18)); g.addColorStop(1, hexA(CUR.accent, 0));
      c.fillStyle = g; c.fillRect(cx - R, cy - R, R * 2, R * 2);
      if (fx.rays) { c.save(); c.translate(cx, cy); c.globalAlpha = 0.16; c.fillStyle = CUR.accent; for (var i = 0; i < 14; i++) { c.rotate(Math.PI / 7); c.beginPath(); c.moveTo(0, 0); c.lineTo(R * 1.25, -R * 0.07); c.lineTo(R * 1.25, R * 0.07); c.closePath(); c.fill(); } c.restore(); }
    }
    if (fx.podium) { // simple plinth under the product
      var pw = w * 1.15, ph = Math.max(40, w * 0.12), py = base - ph * 0.35;
      grad(c, cx - pw / 2, py, pw, ph * 1.6, [[0, hexA(CUR.dark, 0.95)], [1, hexA(CUR.dark, 0.7)]], true);
      c.beginPath(); c.ellipse(cx, py, pw / 2, ph / 2, 0, 0, Math.PI * 2); c.fillStyle = hexA(CUR.accent, 0.9); c.fill();
      c.beginPath(); c.ellipse(cx, py, pw / 2 - 6, ph / 2 - 4, 0, 0, Math.PI * 2); c.fillStyle = '#ffffff22'; c.fill();
      base = py;
    }
    // contact shadow (ellipse on the floor)
    var cs = c.createRadialGradient(cx, base, 2, cx, base, w * 0.5);
    cs.addColorStop(0, 'rgba(0,0,0,.5)'); cs.addColorStop(1, 'rgba(0,0,0,0)');
    c.save(); c.translate(cx, base); c.scale(1, 0.14); c.translate(-cx, -base); c.fillStyle = cs; c.fillRect(cx - w * 0.55, base - w * 0.5, w * 1.1, w); c.restore();
    if (fx.reflect) { // faded floor reflection
      var rc = document.createElement('canvas'); rc.width = Math.ceil(w); rc.height = Math.ceil(h * 0.45); var rx = rc.getContext('2d');
      rx.save(); rx.translate(0, h); rx.scale(1, -1); rx.drawImage(cv, 0, 0, w, h); rx.restore();
      rx.globalCompositeOperation = 'destination-in'; var rg = rx.createLinearGradient(0, 0, 0, rc.height); rg.addColorStop(0, 'rgba(0,0,0,.28)'); rg.addColorStop(1, 'rgba(0,0,0,0)'); rx.fillStyle = rg; rx.fillRect(0, 0, rc.width, rc.height);
      c.drawImage(rc, x, base + 2);
    }
    c.shadowColor = 'rgba(0,0,0,.42)'; c.shadowBlur = 38; c.shadowOffsetY = 16;
    c.drawImage(cv, x, base - h, w, h);
    c.restore();
  }
  function rr(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function cover(c, img, x, y, w, h, filter) {
    if (!img) return false;
    var s = Math.max(w / img.width, h / img.height), iw = img.width * s, ih = img.height * s;
    c.save(); c.beginPath(); c.rect(x, y, w, h); c.clip(); if (filter) c.filter = filter;
    c.drawImage(img, x + (w - iw) / 2, y + (h - ih) / 2, iw, ih); c.restore(); return true;
  }
  function contain(c, img, x, y, w, h) {
    if (!img) return;
    var s = Math.min(w / img.width, h / img.height), iw = img.width * s, ih = img.height * s;
    c.drawImage(img, x + (w - iw) / 2, y + (h - ih) / 2, iw, ih);
  }
  function grad(c, x, y, w, h, stops, vertical) {
    var g = vertical === false ? c.createLinearGradient(x, y, x + w, y) : c.createLinearGradient(x, y, x, y + h);
    stops.forEach(function (s) { g.addColorStop(s[0], s[1]); }); c.fillStyle = g; c.fillRect(x, y, w, h);
  }
  function hexA(hex, a) { var h = String(hex || '#000000').replace('#', ''); return 'rgba(' + parseInt(h.slice(0, 2), 16) + ',' + parseInt(h.slice(2, 4), 16) + ',' + parseInt(h.slice(4, 6), 16) + ',' + a + ')'; }

  // Word-by-word text drawing (supports RTL, centering, wrapping and one highlighted word).
  function text(c, str, o) {
    str = String(str || '').trim(); if (!str) return 0;
    var size = o.size || 48, lh = o.lh || 1.3, rtl = o.rtl !== false, maxW = o.maxW || W - 120;
    c.font = (o.weight || 800) + ' ' + size + 'px "' + o.font + '", Cairo, Tahoma, sans-serif';
    c.direction = rtl ? 'rtl' : 'ltr';
    var words = str.split(/\s+/), lines = [], cur = [], space = c.measureText(' ').width;
    // RTL: keep runs of Latin words / numbers ("Robe Elina", "3 400", "S – XL") together and left-to-right.
    if (rtl) { var mw = []; words.forEach(function (w) { var prevL = mw.length && mw[mw.length - 1].ltr, ltr = !/[\u0600-\u06FF]/.test(w) && (/[A-Za-z0-9]/.test(w) || (prevL && /^[-–—\/+&×x.]+$/.test(w))); if (ltr && prevL) mw[mw.length - 1].t += ' ' + w; else mw.push({ t: w, ltr: ltr }); }); words = mw.map(function (m) { return m.ltr ? '\u2066' + m.t + '\u2069' : m.t; }); }
    function wid(arr) { return arr.reduce(function (a, w) { return a + c.measureText(w).width; }, 0) + space * Math.max(0, arr.length - 1); }
    words.forEach(function (w) { var t = cur.concat([w]); if (wid(t) > maxW && cur.length) { lines.push(cur); cur = [w]; } else cur = t; });
    if (cur.length) lines.push(cur);
    if (o.maxLines && lines.length > o.maxLines) lines = lines.slice(0, o.maxLines);
    var hl = (o.highlight || '').trim();
    lines.forEach(function (ln, i) {
      var y = o.y + i * size * lh, total = wid(ln), align = o.align || 'center', x;
      if (align === 'center') x = rtl ? o.x + total / 2 : o.x - total / 2;
      else if (align === 'right') x = rtl ? o.x : o.x - total;
      else x = rtl ? o.x + total : o.x;
      c.textBaseline = 'top';
      ln.forEach(function (w) {
        var ww = c.measureText(w).width;
        var wc = w.replace(/[\u2066\u2069]/g, ''), isHl = hl && (wc === hl || wc.replace(/[؟?!.,،]/g, '') === hl.replace(/[؟?!.,،]/g, '') || (wc.indexOf(' ') > 0 && wc.split(' ').indexOf(hl) >= 0));
        if (o.shadow) { c.shadowColor = 'rgba(0,0,0,.55)'; c.shadowBlur = 18; c.shadowOffsetY = 3; }
        c.fillStyle = isHl ? (o.hlColor || '#F2A93B') : (o.color || '#fff');
        c.direction = rtl ? 'rtl' : 'ltr';
        c.textAlign = rtl ? 'right' : 'left';
        c.fillText(w, x, y);
        c.shadowColor = 'transparent'; c.shadowBlur = 0; c.shadowOffsetY = 0;
        x = rtl ? x - ww - space : x + ww + space;
      });
    });
    return lines.length * size * lh;
  }
  function pill(c, str, cx, y, o) {
    c.font = (o.weight || 800) + ' ' + (o.size || 34) + 'px "' + o.font + '", Cairo, sans-serif';
    c.direction = o.rtl === false ? 'ltr' : 'rtl';
    var w = c.measureText(str).width + (o.padX || 36) * 2, h = (o.size || 34) * 1.75;
    var x = o.align === 'right' ? cx - w : o.align === 'left' ? cx : cx - w / 2;
    rr(c, x, y, w, h, h / 2); c.fillStyle = o.bg; c.fill();
    c.fillStyle = o.color; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(str, x + w / 2, y + h / 2 + 2);
    return { w: w, h: h, x: x };
  }
  function iconCircle(c, x, y, r, bg, kind) {
    c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fillStyle = bg; c.fill();
    c.strokeStyle = '#fff'; c.lineWidth = r * 0.22; c.lineCap = 'round'; c.lineJoin = 'round'; c.beginPath();
    if (kind === 'x') { c.moveTo(x - r * 0.38, y - r * 0.38); c.lineTo(x + r * 0.38, y + r * 0.38); c.moveTo(x + r * 0.38, y - r * 0.38); c.lineTo(x - r * 0.38, y + r * 0.38); }
    else { c.moveTo(x - r * 0.42, y + r * 0.02); c.lineTo(x - r * 0.1, y + r * 0.34); c.lineTo(x + r * 0.45, y - r * 0.3); }
    c.stroke();
  }
  function bulletList(c, items, o) {
    var y = o.y, rtl = o.rtl !== false;
    items.forEach(function (b) {
      var ix = rtl ? o.x - o.icon : o.x + o.icon;
      iconCircle(c, ix, y + o.size * 0.62, o.icon * 0.8, o.iconBg, o.kind);
      var h = text(c, b, { x: rtl ? o.x - o.icon * 2.2 : o.x + o.icon * 2.2, y: y, size: o.size, weight: 700, color: o.color, font: o.font, rtl: rtl, align: 'right', maxW: o.maxW, lh: 1.25 });
      y += Math.max(h, o.icon * 1.7) + o.gap;
    });
    return y - o.y;
  }
  function band(c, y, h, color) { c.fillStyle = color; c.fillRect(0, y, W, h); }

  // ---------- templates ----------
  var T = {};
  T.hook = function (c, p, k) {
    var H = 1350; c.canvas.height = H;
    grad(c, 0, 0, W, H, [[0, k.pal.dark], [1, k.pal.primary]]);
    if (cover(c, k.scene, 0, 0, W, H)) {
      if (k.composite) { grad(c, 0, 640, W, 560, [[0, 'rgba(0,0,0,0)'], [1, 'rgba(0,0,0,.35)']]); placeProduct(c, k.product, W / 2, 900, 560); }
    } else if (CUR.cut) { placeProduct(c, null, W / 2, 870, 660);
    } else {
      if (k.product) { c.save(); c.shadowColor = 'rgba(0,0,0,.4)'; c.shadowBlur = 50; rr(c, 140, 470, 800, 760, 48); c.fillStyle = '#fff'; c.fill(); c.restore(); c.save(); rr(c, 140, 470, 800, 760, 48); c.clip(); contain(c, k.product, 170, 500, 740, 700); c.restore(); }
    }
    grad(c, 0, 0, W, 560, [[0, 'rgba(0,0,0,.78)'], [0.7, 'rgba(0,0,0,.35)'], [1, 'rgba(0,0,0,0)']]);
    grad(c, 0, H - 300, W, 300, [[0, 'rgba(0,0,0,0)'], [1, 'rgba(0,0,0,.75)']]);
    if (p.badge) pill(c, p.badge, k.rtl ? 60 : W - 60, 52, { bg: k.pal.accent, color: '#111', size: 34, font: k.font, align: k.rtl ? 'left' : 'right', rtl: k.rtl });
    var y = 150;
    y += text(c, p.title, { x: W / 2, y: y, size: 92, weight: 900, color: '#fff', hlColor: k.pal.accent, highlight: p.highlight, font: k.font, rtl: k.rtl, maxW: W - 120, shadow: true, maxLines: 3 });
    if (p.subtitle) text(c, p.subtitle, { x: W / 2, y: y + 16, size: 46, weight: 700, color: '#fff', font: k.font, rtl: k.rtl, maxW: W - 160, shadow: true, maxLines: 2 });
    var chips = [k.t.cod, k.t.deliv], cx = W / 2, cy = H - 120;
    c.font = '800 34px "' + k.font + '", Cairo, sans-serif';
    var w0 = c.measureText(chips[0]).width + 72, w1 = c.measureText(chips[1]).width + 72, gap = 20, total = w0 + w1 + gap;
    pill(c, chips[0], cx + total / 2 - w0 / 2, cy, { bg: 'rgba(255,255,255,.95)', color: k.pal.dark, size: 34, font: k.font, rtl: k.rtl });
    pill(c, chips[1], cx - total / 2 + w1 / 2, cy, { bg: k.pal.accent, color: '#111', size: 34, font: k.font, rtl: k.rtl });
  };
  T.problem = function (c, p, k) {
    var H = 1080; c.canvas.height = H;
    grad(c, 0, 0, W, H, [[0, '#2a2a2a'], [1, '#111']]);
    cover(c, k.scene || k.product, 0, 0, W, H, k.scene ? '' : 'grayscale(1) brightness(.6)');
    c.fillStyle = 'rgba(10,10,10,.45)'; c.fillRect(0, 0, W, H);
    band(c, 0, 210, k.pal.dark);
    text(c, p.title, { x: W / 2, y: 50, size: 74, weight: 900, color: '#fff', font: k.font, rtl: k.rtl, maxLines: 2, highlight: p.highlight, hlColor: '#FF8A80' });
    var boxH = 70 + (p.bullets.length || 3) * 120;
    c.save(); rr(c, 60, H - boxH - 60, W - 120, boxH, 36); c.fillStyle = 'rgba(0,0,0,.72)'; c.fill(); c.restore();
    bulletList(c, p.bullets, { x: k.rtl ? W - 110 : 110, y: H - boxH - 20, size: 48, icon: 30, iconBg: '#D93025', kind: 'x', color: '#fff', font: k.font, rtl: k.rtl, maxW: W - 320, gap: 36 });
  };
  T.before_after = function (c, p, k) {
    var H = 1080; c.canvas.height = H; c.fillStyle = '#fff'; c.fillRect(0, 0, W, H);
    var top = 190, half = W / 2, imgH = 560;
    text(c, p.title, { x: W / 2, y: 40, size: 70, weight: 900, color: k.pal.dark, font: k.font, rtl: k.rtl, maxLines: 2, highlight: p.highlight, hlColor: k.pal.primary });
    var leftIsBefore = true;
    var bx = leftIsBefore ? 0 : half, ax = leftIsBefore ? half : 0;
    if (!cover(c, k.scene, bx, top, half, imgH, k.scene ? '' : 'grayscale(1) brightness(.85)')) cover(c, k.product, bx, top, half, imgH, 'grayscale(1) brightness(.85)');
    if (!cover(c, k.scene2, ax, top, half, imgH)) cover(c, k.product, ax, top, half, imgH);
    if (k.scene2 && k.composite) placeProduct(c, k.product, ax + half - 105, top + imgH - 100, 170);
    c.fillStyle = 'rgba(217,48,37,.18)'; c.fillRect(bx, top, half, imgH);
    c.fillStyle = '#fff'; c.fillRect(half - 4, top, 8, imgH);
    pill(c, k.t.before, bx + half / 2, top + 24, { bg: '#D93025', color: '#fff', size: 46, font: k.font, rtl: k.rtl });
    pill(c, k.t.after, ax + half / 2, top + 24, { bg: '#1E8E3E', color: '#fff', size: 46, font: k.font, rtl: k.rtl });
    var by = top + imgH + 30;
    c.save(); rr(c, bx + 24, by, half - 48, H - by - 30, 28); c.fillStyle = '#FDECEA'; c.fill(); c.restore();
    c.save(); rr(c, ax + 24, by, half - 48, H - by - 30, 28); c.fillStyle = '#E6F4EA'; c.fill(); c.restore();
    bulletList(c, p.before_points, { x: k.rtl ? bx + half - 60 : bx + 60, y: by + 30, size: 38, icon: 22, iconBg: '#D93025', kind: 'x', color: '#5f1712', font: k.font, rtl: k.rtl, maxW: half - 170, gap: 20 });
    bulletList(c, p.after_points, { x: k.rtl ? ax + half - 60 : ax + 60, y: by + 30, size: 38, icon: 22, iconBg: '#1E8E3E', kind: 'check', color: '#0d3d1c', font: k.font, rtl: k.rtl, maxW: half - 170, gap: 20 });
  };
  T['case'] = function (c, p, k) {
    var H = 1080; c.canvas.height = H; c.fillStyle = '#fff'; c.fillRect(0, 0, W, H);
    band(c, 0, 200, k.pal.primary);
    text(c, p.title, { x: W / 2, y: 46, size: 76, weight: 900, color: '#fff', font: k.font, rtl: k.rtl, maxLines: 2, highlight: p.highlight, hlColor: k.pal.accent });
    cover(c, k.scene || k.product, 0, 200, W, 520);
    if (k.scene && k.composite) placeProduct(c, k.product, k.rtl ? 190 : W - 190, 590, 250);
    var y = 750;
    bulletList(c, p.bullets, { x: k.rtl ? W - 90 : 90, y: y, size: 46, icon: 28, iconBg: k.pal.primary, kind: 'check', color: k.pal.dark, font: k.font, rtl: k.rtl, maxW: W - 260, gap: 26 });
  };
  T.features = function (c, p, k) {
    var H = 1080; c.canvas.height = H;
    grad(c, 0, 0, W, H, [[0, '#ffffff'], [1, hexA(k.pal.primary, 0.12)]]);
    text(c, p.title, { x: W / 2, y: 46, size: 72, weight: 900, color: k.pal.dark, font: k.font, rtl: k.rtl, maxLines: 2, highlight: p.highlight, hlColor: k.pal.primary });
    var img = k.scene || k.product;
    c.save(); c.beginPath(); c.arc(W / 2, 470, 260, 0, Math.PI * 2); c.closePath(); c.fillStyle = '#fff'; c.shadowColor = 'rgba(0,0,0,.18)'; c.shadowBlur = 40; c.fill(); c.restore();
    c.save(); c.beginPath(); c.arc(W / 2, 470, 250, 0, Math.PI * 2); c.clip(); cover(c, img, W / 2 - 250, 220, 500, 500); c.restore();
    if (k.scene && k.composite) placeProduct(c, k.product, W / 2, 500, 340);
    var items = p.bullets.slice(0, 6), colW = (W - 120) / 2, y0 = 770;
    items.forEach(function (b, i) {
      var col = i % 2, row = Math.floor(i / 2);
      var x = k.rtl ? (col === 0 ? W - 60 : W - 60 - colW) : (col === 0 ? 60 : 60 + colW);
      var y = y0 + row * 100;
      c.save(); rr(c, k.rtl ? x - colW + 10 : x, y, colW - 10, 84, 42); c.fillStyle = '#fff'; c.shadowColor = 'rgba(0,0,0,.08)'; c.shadowBlur = 12; c.fill(); c.restore();
      iconCircle(c, k.rtl ? x - 46 : x + 46, y + 42, 24, k.pal.primary, 'check');
      text(c, b, { x: k.rtl ? x - 86 : x + 86, y: y + 20, size: 36, weight: 800, color: k.pal.dark, font: k.font, rtl: k.rtl, align: 'right', maxW: colW - 120, maxLines: 1 });
    });
  };
  T.how_to = function (c, p, k) {
    var H = 1080; c.canvas.height = H;
    grad(c, 0, 0, W, H, [[0, k.pal.primary], [1, k.pal.dark]]);
    text(c, p.title, { x: W / 2, y: 60, size: 76, weight: 900, color: '#fff', font: k.font, rtl: k.rtl, maxLines: 2, highlight: p.highlight, hlColor: k.pal.accent });
    if (k.product) { c.save(); rr(c, W / 2 - 150, 230, 300, 300, 40); c.fillStyle = '#fff'; c.fill(); c.clip(); contain(c, k.product, W / 2 - 135, 245, 270, 270); c.restore(); }
    var steps = p.steps.slice(0, 3), y = 590;
    steps.forEach(function (s, i) {
      c.save(); rr(c, 70, y, W - 140, 132, 30); c.fillStyle = 'rgba(255,255,255,.96)'; c.fill(); c.restore();
      var nx = k.rtl ? W - 140 : 140;
      c.beginPath(); c.arc(nx, y + 66, 44, 0, Math.PI * 2); c.fillStyle = k.pal.accent; c.fill();
      c.fillStyle = '#111'; c.font = '900 50px "' + k.font + '", Cairo, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.direction = 'ltr'; c.fillText(String(i + 1), nx, y + 70);
      text(c, s, { x: k.rtl ? W - 220 : 220, y: y + 40, size: 44, weight: 800, color: k.pal.dark, font: k.font, rtl: k.rtl, align: 'right', maxW: W - 360, maxLines: 2, lh: 1.15 });
      y += 156;
    });
  };
  T.trust = function (c, p, k) {
    var H = 1080; c.canvas.height = H; c.fillStyle = '#fff'; c.fillRect(0, 0, W, H);
    text(c, p.title, { x: W / 2, y: 60, size: 74, weight: 900, color: k.pal.dark, font: k.font, rtl: k.rtl, maxLines: 2, highlight: p.highlight, hlColor: k.pal.primary });
    var tiles = [k.t.cod, k.t.deliv, k.t.call, k.t.exch], tw = (W - 180) / 2, th = 330;
    tiles.forEach(function (s, i) {
      var col = i % 2, row = Math.floor(i / 2), x = 60 + col * (tw + 60), y = 270 + row * (th + 50);
      c.save(); rr(c, x, y, tw, th, 36); c.fillStyle = hexA(k.pal.primary, 0.08); c.fill(); c.lineWidth = 4; c.strokeStyle = hexA(k.pal.primary, 0.35); c.stroke(); c.restore();
      iconCircle(c, x + tw / 2, y + 100, 56, i === 1 ? k.pal.accent : k.pal.primary, 'check');
      text(c, s, { x: x + tw / 2, y: y + 190, size: 42, weight: 800, color: k.pal.dark, font: k.font, rtl: k.rtl, maxW: tw - 50, maxLines: 2, lh: 1.2 });
    });
  };
  T.offer = function (c, p, k) {
    var H = 1350; c.canvas.height = H;
    grad(c, 0, 0, W, H, [[0, k.pal.dark], [1, '#000']]);
    if (k.scene) { cover(c, k.scene, 0, 0, W, H); c.fillStyle = 'rgba(0,0,0,.55)'; c.fillRect(0, 0, W, H); if (k.composite) placeProduct(c, k.product, W / 2, 540, 400); }
    pill(c, k.t.special, W / 2, 60, { bg: k.pal.accent, color: '#111', size: 44, font: k.font, rtl: k.rtl });
    var y = 170;
    y += text(c, p.title, { x: W / 2, y: y, size: 84, weight: 900, color: '#fff', font: k.font, rtl: k.rtl, maxLines: 2, shadow: true, highlight: p.highlight, hlColor: k.pal.accent });
    if (!k.scene && CUR.cut) { var top0 = y + 30, sz0 = Math.max(260, 760 - top0); placeProduct(c, null, W / 2, top0 + sz0 / 2, sz0); }
    else if (k.product && !k.scene) { c.save(); c.shadowColor = 'rgba(0,0,0,.5)'; c.shadowBlur = 50; rr(c, W / 2 - 280, y + 30, 560, 520, 44); c.fillStyle = '#fff'; c.fill(); c.restore(); c.save(); rr(c, W / 2 - 280, y + 30, 560, 520, 44); c.clip(); contain(c, k.product, W / 2 - 260, y + 50, 520, 480); c.restore(); }
    var py = 780;
    c.save(); rr(c, 90, py, W - 180, 300, 40); c.fillStyle = 'rgba(255,255,255,.97)'; c.fill(); c.restore();
    var cur = ' ' + k.t.currency;
    if (k.oldPrice > k.price) {
      c.font = '700 54px "' + k.font + '", Cairo, sans-serif'; c.fillStyle = '#9aa0a6'; c.textAlign = 'center'; c.textBaseline = 'top'; c.direction = 'rtl';
      var os = fmt(k.oldPrice) + cur; c.fillText(os, W / 2, py + 26); var ow = c.measureText(os).width; c.fillStyle = '#D93025'; c.fillRect(W / 2 - ow / 2 - 10, py + 56, ow + 20, 6);
    }
    c.font = '900 120px "' + k.font + '", Cairo, sans-serif'; c.fillStyle = k.pal.primary; c.textAlign = 'center'; c.textBaseline = 'top'; c.direction = 'rtl';
    c.fillText(fmt(k.price) + cur, W / 2, py + (k.oldPrice > k.price ? 92 : 70));
    var bundle = (k.offers || []).filter(function (o) { return o.qty === 2; })[0];
    if (bundle) text(c, (k.lang === 'fr' ? '2 ' + k.t.pieces + ' : ' : '2 ' + k.t.pieces + ' بـ ') + fmt(bundle.price) + cur, { x: W / 2, y: py + 228, size: 40, weight: 800, color: k.pal.dark, font: k.font, rtl: k.rtl, maxLines: 1 });
    var by = 1120;
    c.save(); rr(c, 140, by, W - 280, 120, 60); c.fillStyle = k.pal.accent; c.shadowColor = 'rgba(0,0,0,.35)'; c.shadowBlur = 24; c.fill(); c.restore();
    c.font = '900 56px "' + k.font + '", Cairo, sans-serif'; c.fillStyle = '#111'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.direction = k.rtl ? 'rtl' : 'ltr'; c.fillText(k.t.order, W / 2, by + 64);
    text(c, (p.subtitle || k.t.cod) + ' · ' + k.t.deliv, { x: W / 2, y: by + 150, size: 34, weight: 700, color: '#fff', font: k.font, rtl: k.rtl, maxLines: 1 });
  };
  // ---- fashion / photo templates (use the seller's own photos) ----
  T.look = function (c, p, k) {
    var H = 1350; c.canvas.height = H;
    grad(c, 0, 0, W, H, [[0, k.pal.dark], [1, '#000']]);
    if (!cover(c, k.scene || k.product, 0, 0, W, H)) { }
    grad(c, 0, H - 560, W, 560, [[0, 'rgba(0,0,0,0)'], [1, 'rgba(0,0,0,.82)']]);
    c.fillStyle = k.pal.accent; c.fillRect(W / 2 - 60, H - 380, 120, 6);
    var y = H - 350;
    y += text(c, p.title, { x: W / 2, y: y, size: 78, weight: 800, color: '#fff', font: k.font, rtl: k.rtl, maxLines: 2, shadow: true, highlight: p.highlight, hlColor: k.pal.accent });
    if (p.subtitle) text(c, p.subtitle, { x: W / 2, y: y + 14, size: 42, weight: 600, color: 'rgba(255,255,255,.9)', font: k.font, rtl: k.rtl, maxLines: 2 });
  };
  T.details = function (c, p, k) {
    var H = 1080; c.canvas.height = H; c.fillStyle = hexA(k.pal.accent, 0.18); c.fillRect(0, 0, W, H); c.fillStyle = '#fff'; c.fillRect(0, 0, W, 200);
    text(c, p.title, { x: W / 2, y: 50, size: 66, weight: 800, color: k.pal.dark, font: k.font, rtl: k.rtl, maxLines: 2, highlight: p.highlight, hlColor: k.pal.primary });
    var a = k.scene || k.product, b = k.scene2 || k.product;
    c.save(); rr(c, 50, 230, 600, 600, 28); c.clip(); cover(c, a, 50, 230, 600, 600); c.restore();
    c.save(); rr(c, 680, 230, 350, 288, 24); c.clip(); cover(c, b, 680, 230, 350, 288); c.restore();
    c.save(); rr(c, 680, 542, 350, 288, 24); c.clip(); cover(c, k.product || a, 680, 542, 350, 288); c.restore();
    var items = p.bullets.slice(0, 3), x = 60, w = (W - 120 - 40) / 3;
    items.forEach(function (it, i) {
      var bx = k.rtl ? W - 60 - (i + 1) * w - i * 20 : x + i * (w + 20);
      c.save(); rr(c, bx, 860, w, 170, 24); c.fillStyle = '#fff'; c.shadowColor = 'rgba(0,0,0,.08)'; c.shadowBlur = 16; c.fill(); c.restore();
      iconCircle(c, bx + w / 2, 900, 22, k.pal.primary, 'check');
      text(c, it, { x: bx + w / 2, y: 940, size: 32, weight: 700, color: k.pal.dark, font: k.font, rtl: k.rtl, maxW: w - 30, maxLines: 2, lh: 1.2 });
    });
  };
  T.sizes = function (c, p, k) {
    var H = 1080; c.canvas.height = H; c.fillStyle = '#fff'; c.fillRect(0, 0, W, H);
    var img = k.scene || k.product, px = k.rtl ? 0 : W / 2;
    cover(c, img, px, 0, W / 2, H);
    var cx = k.rtl ? W * 0.75 : W * 0.25;
    text(c, p.title, { x: cx, y: 120, size: 60, weight: 800, color: k.pal.dark, font: k.font, rtl: k.rtl, maxW: W / 2 - 80, maxLines: 2 });
    var items = (p.bullets.length ? p.bullets : ['S', 'M', 'L', 'XL']).slice(0, 6), y = 320;
    items.forEach(function (it, i) {
      var col = i % 2, row = Math.floor(i / 2), bw = 190, bx = cx - bw - 10 + col * (bw + 20), by = y + row * 130;
      c.save(); rr(c, bx, by, bw, 104, 52); c.fillStyle = i === 1 ? k.pal.primary : '#fff'; c.fill(); c.lineWidth = 4; c.strokeStyle = k.pal.primary; c.stroke(); c.restore();
      c.font = '800 44px "' + k.font + '", Cairo, sans-serif'; c.fillStyle = i === 1 ? '#fff' : k.pal.dark; c.textAlign = 'center'; c.textBaseline = 'middle'; c.direction = 'ltr'; c.fillText(it, bx + bw / 2, by + 54);
    });
    text(c, k.t.sizes, { x: cx, y: y + Math.ceil(items.length / 2) * 130 + 30, size: 34, weight: 700, color: '#5f6964', font: k.font, rtl: k.rtl, maxW: W / 2 - 80, maxLines: 2 });
  };
  function fmt(n) { return '\u2066' + String(Math.round(n || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, '\u202F') + '\u2069'; }

  // render(panel, opts) -> Promise<dataURL webp>
  function render(panel, o) {
    var font = o.font || 'Cairo', lang = o.lang || 'dz';
    return Promise.all([ensureFont(font), loadImg(panel.scene), loadImg(panel.scene2), loadImg(o.productImage), loadImg(panel.cutout || o.productCutout)]).then(function (r) {
      var pal0 = o.palette || {}; CUR = { cut: r[4] || null, fx: o.fx || {}, accent: pal0.accent || '#F2A93B', dark: pal0.dark || '#0B2A20' };
      var cv = document.createElement('canvas'); cv.width = W; cv.height = 1080;
      var c = cv.getContext('2d');
      var k = { pal: o.palette || { primary: '#0F5C46', accent: '#F2A93B', dark: '#0B2A20' }, font: font, lang: lang, rtl: lang !== 'fr', t: L[lang] || L.dz, scene: r[1], scene2: r[2], product: r[3], price: o.price || 0, oldPrice: o.oldPrice || 0, offers: o.offers || [], composite: !!o.composite && !panel.sceneHasProduct && !panel._photoMode };
      var p = { title: panel.title || '', highlight: panel.highlight || '', subtitle: panel.subtitle || '', badge: panel.badge || '', bullets: panel.bullets || [], before_points: panel.before_points || [], after_points: panel.after_points || [], steps: panel.steps || [] };
      (T[panel.type] || T.features)(c, p, k);
      var url = cv.toDataURL('image/webp', 0.86);
      if (url.indexOf('data:image/webp') !== 0) url = cv.toDataURL('image/jpeg', 0.88);
      return url;
    });
  }
  function needsScene(type) { return ['hook', 'problem', 'before_after', 'case', 'features', 'offer'].indexOf(type) >= 0; }
  function usesPhoto(type) { return ['hook', 'look', 'details', 'case', 'sizes', 'features', 'offer', 'problem'].indexOf(type) >= 0; }
  window.Panels = { render: render, needsScene: needsScene, usesPhoto: usesPhoto, types: Object.keys(T) };
})();
