'use strict';
// Node.js server (your PC or any VPS). On Cloudflare the same app runs from worker-entry.js.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const { driver, db, DATA_DIR, UPLOAD_DIR } = require('./src/driver-node');
const { init } = require('./src/db');
const app = require('./src/app');
const geo = require('./src/geo');

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const PUBLIC_DIR = path.join(__dirname, 'public');

async function assets(rel) {
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) return null;
  try { if (!fs.statSync(file).isFile()) return null; return fs.readFileSync(file); } catch { return null; }
}
// Photos uploaded with the first version were files in data/uploads.
async function legacyUpload(req, res, name) {
  const file = path.normalize(path.join(UPLOAD_DIR, name));
  if (!file.startsWith(UPLOAD_DIR + path.sep) || !fs.existsSync(file)) return false;
  const st = fs.statSync(file);
  const type = app.mimeOf(file);
  const headers = { 'Content-Type': type, 'Cache-Control': 'public, max-age=31536000, immutable', 'Content-Length': st.size, 'X-Content-Type-Options': 'nosniff', 'Accept-Ranges': 'bytes' };
  const range = req.headers.range;
  if (range && type.startsWith('video/')) {
    const mt = range.match(/bytes=(\d*)-(\d*)/);
    const start = mt && mt[1] ? Number(mt[1]) : 0;
    const end = mt && mt[2] ? Math.min(Number(mt[2]), st.size - 1) : st.size - 1;
    res.writeHead(206, { ...headers, 'Content-Range': `bytes ${start}-${end}/${st.size}`, 'Content-Length': end - start + 1 });
    fs.createReadStream(file, { start, end }).pipe(res);
    return true;
  }
  res.writeHead(200, headers);
  if (req.method === 'HEAD') res.end(); else fs.createReadStream(file).pipe(res);
  return true;
}

const server = http.createServer(async (req, res) => {
  let url;
  try {
    url = new URL(req.url, `${req.headers['x-forwarded-proto'] || 'http'}://${req.headers.host || 'localhost'}`);
  } catch {
    res.writeHead(400); return res.end('Bad request');
  }
  const started = Date.now();
  await app.handle(req, res, url, { assets, legacyUpload });
  if (process.env.LOG_REQUESTS) console.log(req.method, url.pathname, res.statusCode, Date.now() - started + 'ms');
});
server.requestTimeout = 120000;
server.headersTimeout = 30000;

// ---------- daily backup (keeps 14) ----------
const BACKUP_DIR = path.join(DATA_DIR, 'backups');
function backup() {
  try {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
    const file = path.join(BACKUP_DIR, `store-${new Date().toISOString().slice(0, 10)}.db`);
    if (fs.existsSync(file)) return;
    db.exec(`VACUUM INTO '${file.replace(/'/g, "''")}'`);
    const list = fs.readdirSync(BACKUP_DIR).filter((f) => f.endsWith('.db')).sort();
    list.slice(0, Math.max(0, list.length - 14)).forEach((f) => fs.unlinkSync(path.join(BACKUP_DIR, f)));
    console.log('Backup saved', file);
  } catch (e) {
    console.error('Backup failed', e.message);
  }
}

init(driver).then(() => {
  setTimeout(backup, 60e3).unref();
  setInterval(backup, 6 * 3600e3).unref();
  server.listen(PORT, HOST, async () => {
    console.log(`\n  Platform home:   http://localhost:${PORT}\n  Dashboard:       http://localhost:${PORT}/admin\n  Data folder:     ${DATA_DIR}\n`);
    const n = await geo.communesCount();
    console.log(n ? `  ${n} communes ready.` : '  Communes list not downloaded yet. Customers can still type their commune.');
  });
}).catch((e) => { console.error('Start failed:', e); process.exit(1); });

for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { server.close(); try { db.close(); } catch {} process.exit(0); });
