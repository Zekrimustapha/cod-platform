'use strict';
// Cloudflare Worker entry: same app as server.js, with D1 (database) and Workers AI (free images) bindings.
const { init, drainBg, D } = require('./db');
const { makeD1Driver } = require('./driver-d1');
const LAI = require('./landing-ai');
const app = require('./app');

const SCHEMA_VERSION = '5';
let ready = null;
async function ensureReady(env) {
  if (!ready) {
    ready = (async () => {
      const drv = makeD1Driver(env.DB);
      let skip = false;
      try { const r = await drv.get("SELECT value FROM meta WHERE key = 'schema'", []); skip = r && r.value === SCHEMA_VERSION; } catch {}
      if (skip) {
        await init({ ...drv, migrate: null, skipSchema: true });
      } else {
        await init(drv);
        await D.run("INSERT INTO meta(key, value) VALUES('schema', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", SCHEMA_VERSION);
      }
    })().catch((e) => { ready = null; throw e; });
  }
  return ready;
}

function makeRes() {
  return {
    statusCode: 200, headers: {}, body: null, headersSent: false,
    writeHead(status, headers) { this.statusCode = status; Object.assign(this.headers, headers || {}); this.headersSent = true; },
    setHeader(k, v) { this.headers[k] = v; },
    end(body) { this.body = body == null ? null : body; this.headersSent = true; }
  };
}

// Same-origin mirror of the free background-removal model files (some browsers/networks block huggingface.co).
const HF_OK = /^\/hf\/(onnx-community\/BiRefNet_lite-ONNX|d30social\/ormbg-ortweb)\/resolve\/main\/([\w./-]+\.(json|onnx|onnx_data))$/;
async function hfProxy(request, url, ctx) {
  const m = url.pathname.match(HF_OK);
  if (!m || m[2].includes('..')) return new Response('not found', { status: 404 });
  const cache = caches.default, key = new Request(url.origin + url.pathname);
  let r = await cache.match(key);
  if (!r) {
    const up = await fetch('https://huggingface.co/' + m[1] + '/resolve/main/' + m[2], { cf: { cacheEverything: true, cacheTtl: 2592000 } });
    if (!up.ok) return new Response('upstream ' + up.status, { status: 502 });
    const h = new Headers({ 'Content-Type': m[3] === 'json' ? 'application/json' : 'application/octet-stream', 'Cache-Control': 'public, max-age=2592000, immutable', 'Access-Control-Allow-Origin': '*' });
    const len = up.headers.get('content-length'); if (len) h.set('Content-Length', len);
    r = new Response(up.body, { status: 200, headers: h });
    if (m[3] === 'json') ctx.waitUntil(cache.put(key, r.clone()));
  }
  return r;
}

async function fetchHandler(request, env, ctx) {
  const u0 = new URL(request.url);
  if (u0.pathname.startsWith('/hf/') && request.method === 'GET') return hfProxy(request, u0, ctx);
  await ensureReady(env);
  LAI.setAiBinding(env.AI);
  const url = new URL(request.url);
  const headers = {};
  request.headers.forEach((v, k) => { headers[k.toLowerCase()] = v; });
  headers['x-forwarded-proto'] = url.protocol.replace(':', '');
  const req = { method: request.method, url: url.pathname + url.search, headers, socket: {}, _text: '' };
  if (!['GET', 'HEAD'].includes(request.method)) req._text = await request.text();
  const res = makeRes();
  await app.handle(req, res, url, { assets: async (rel) => (Object.prototype.hasOwnProperty.call(ASSETS, rel) ? ASSETS[rel] : null) });
  ctx.waitUntil(drainBg());
  const h = new Headers();
  for (const [k, v] of Object.entries(res.headers)) if (v != null && k.toLowerCase() !== 'content-length') h.set(k, String(v));
  const body = request.method === 'HEAD' || [204, 304].includes(res.statusCode) ? null : res.body;
  return new Response(body, { status: res.statusCode, headers: h });
}

module.exports = { fetchHandler };
