'use strict';
// AI landing page generator: understand the product → plan Algerian-style image panels → generate scene images.
const { getSetting } = require('./db');
const files = require('./files');

// On Cloudflare Workers the platform gets Workers AI as a binding (no token needed).
let AI_BINDING = null;
function setAiBinding(b) { AI_BINDING = b || null; }

const PANEL_TYPES = ['hook', 'problem', 'before_after', 'case', 'features', 'how_to', 'trust', 'offer', 'look', 'details', 'sizes'];
const PALETTES = {
  health: { primary: '#0F5C46', accent: '#F2A93B', dark: '#0B2A20' },
  beauty: { primary: '#9F1239', accent: '#F9A8D4', dark: '#2A0E17' },
  home: { primary: '#1D4ED8', accent: '#FACC15', dark: '#0F1B3D' },
  kids: { primary: '#EA580C', accent: '#FDE047', dark: '#3A1604' },
  men: { primary: '#1F2937', accent: '#D4A017', dark: '#0B0F14' },
  fashion: { primary: '#111111', accent: '#E8C9A0', dark: '#000000' },
  tech: { primary: '#0E7490', accent: '#A3E635', dark: '#06232B' },
  food: { primary: '#7C2D12', accent: '#F59E0B', dark: '#2B1006' }
};

const LANG_RULE = {
  dz: 'Algerian Darija written in Arabic script, warm and natural like Algerian Facebook sellers (examples of tone: "حاب ترتاح من…؟", "واش كاين داخل…", "جربها وشوف الفرق"). Short punchy lines.',
  ar: 'simple Modern Standard Arabic, warm, short lines, understood by Algerians.',
  fr: 'simple direct French for Algerian buyers, short lines.'
};

function planPrompt({ description, productName, price, lang, brief }) {
  return `You are the best cash-on-delivery landing page strategist in Algeria. Algerian COD landing pages are a vertical stack of 6-9 designed image panels with big Arabic text, viewed on phones from Facebook/TikTok ads. The order form comes right after the first panel.

Product name: ${productName || '(infer from the photo)'}
Price: ${price || '?'} DZD
Seller notes: ${description || '(none — infer everything from the photos: what the product is, its niche, who buys it, why)'}
${brief ? `CREATIVE BRIEF written by a product expert who studied the photos (trust it, it describes what is really in the photos):
${JSON.stringify(brief)}
Use the brief's angles, objections, audience and visual_description. Every scene_prompt must describe the product exactly like visual_description (same colour, shape, material, packaging).` : 'You receive one or more PHOTOS of the product: look at them carefully (product type, colour, material, packaging text, brand, who is shown) and base everything on what you SEE.'}

STEP 1 — understand from the photos: what the product is exactly, its niche, who buys it (gender, age range, situation), the main DESIRE or PAIN, the 2-3 objections an Algerian buyer has before ordering (is it original? does it really work? will it fit? is it worth the price? can I check before paying?), and the strongest selling angle.
STEP 2 — decide "visible_transformation": true ONLY if a camera can show the SAME person/object clearly worse before and clearly better after using it (skin, acne, spots, hair loss, teeth, stains / dirty surfaces, rust, scratches on a car, messy space that gets organised, body shaper, posture corrector). It is FALSE for clothes, shoes, bags, jewellery, watches, perfume, food, honey, dates, coffee, toys, kids items, phones, chargers, earphones, gadgets, kitchen tools, decor, gifts, and for pain / health products whose effect cannot be seen in a photo.
STEP 3 — build a page that CONVINCES and pushes to order, choosing the panels that fit THIS product. Allowed panel types: ${PANEL_TYPES.join(', ')}.
- Always start with "hook" (the outcome/desire the buyer wants, not the product name) and end with "offer". Use 6 to 9 panels.
- Use "before_after" ONLY when visible_transformation is true. Never more than one.
- Use "problem" only if the product really solves a pain the buyer feels; for desire products (fashion, perfume, gifts, food, decor) replace it with "case" (moments / occasions where they will use it) or "look".
- "features" = benefits for the buyer (what they gain), not technical specs. "how_to" only if usage is not obvious. "trust" answers the objections: check the product before paying, payment on delivery, delivery to every wilaya, exchange if a problem.
- Typical orders: visible beauty / cleaning: hook, problem, before_after, features, how_to, trust, offer. Pain / health (not visible): hook, problem, case, features, how_to, trust, offer. Gadgets / home / tech: hook, problem or case, features, how_to, trust, offer. Fashion / clothes / shoes / bags / jewellery (niche "fashion"): hook, look, details, case (occasions: weddings, Eid, outings, work), sizes, trust, offer — scene_prompt shows a North African model WEARING the item from image 0 (same colour, cut and details); talk about fabric, cut, comfort, elegance, sizes, colours — never "problems". Perfume / gifts: hook, look, details, case, trust, offer. Kids: hook, features (safety, quality), case, how_to, trust, offer. Food: hook, features (origin, taste, quality), case, trust, offer.
STEP 4 — write the text for each panel in ${LANG_RULE[lang] || LANG_RULE.dz}

Hard rules:
- Never invent statistics, numbers of customers, doctors, certifications, medical cure claims, or testimonials/reviews. No customer names.
- No emojis inside titles. Titles max 7 words. Bullets max 6 words each.
- scene_prompt is in ENGLISH for an image AI that RECEIVES THE PRODUCT PHOTO as "image 0": write it like "the product from image 0 ..." and describe where it is, who uses it and how (keep the product exactly as in the photo). Vary the scenes: close-up, in use, lifestyle, flat lay.
- Each scene_prompt: describe a realistic photo scene with Algerian / North African people and homes when people appear (modest clothing), the product clearly visible when relevant, natural light, vertical-friendly composition, and ALWAYS end with "no text, no letters, no words, no logos in the image".

Return ONLY JSON:
{
 "product_name": string,
 "niche": one of ${Object.keys(PALETTES).join('|')},
 "visible_transformation": true|false (see STEP 2),
 "objections": [2-3 short strings],
 "use_photos": true if the product is clothing / shoes / bags / jewellery (AI scenes would show the wrong item), else false,
 "audience": {"who": string, "gender": "women|men|all", "age": string},
 "pain_or_desire": string,
 "angle": string,
 "headline": string,
 "seo_title": string,
 "panels": [
   {"type": "hook", "title": string, "highlight": string (one word from title to color), "subtitle": string, "badge": string (2-3 words), "scene_prompt": string},
   {"type": "problem", "title": string, "bullets": [3 strings], "scene_prompt": string},
   {"type": "before_after", "title": string, "before_points": [3], "after_points": [3], "before_scene": string, "after_scene": string},
   {"type": "case", "title": string, "bullets": [3], "scene_prompt": string},
   {"type": "features", "title": string, "bullets": [4-6], "scene_prompt": string},
   {"type": "how_to", "title": string, "steps": [3 short strings]},
   {"type": "trust", "title": string},
   {"type": "look", "title": string, "subtitle": string},
   {"type": "details", "title": string, "bullets": [3 strings]},
   {"type": "sizes", "title": string, "bullets": [sizes or colours, up to 6 short strings]},
   {"type": "offer", "title": string, "subtitle": string, "scene_prompt": string}
 ]
}`;
}

// STAGE 1 — vision model studies the photos and writes a creative brief (no page yet).
function briefPrompt({ description, productName, price }) {
  return `You are a senior e-commerce product analyst for the Algerian cash-on-delivery market. Study the PHOTOS of the product very carefully (shape, colour, material, packaging, any written text or brand, size clues, who/what is shown) plus the seller notes, then write a creative brief another AI will use to build the landing page.

Product name: ${productName || '(infer from the photos)'}
Price: ${price || '?'} DZD
Seller notes: ${description || '(none)'}

Rules: describe only what you SEE or what the notes say; mark guesses with "(likely)". Never invent certifications, statistics or reviews.

Return ONLY JSON:
{
 "product_type": string (exact, e.g. "electric lint remover", "satin abaya with lace sleeves"),
 "product_name": string (short commercial name),
 "niche": one of ${Object.keys(PALETTES).join('|')},
 "visual_description": string in ENGLISH, 40-70 words, precise enough for an image AI to redraw it (colours, shape, material, parts, packaging, text printed on it),
 "features": [4-6 concrete features seen or stated],
 "benefits": [4-6 what the buyer gains from those features],
 "audience": {"who": string, "gender": "women|men|all", "age": string, "situation": string},
 "avatars": [2 short buyer profiles, e.g. "busy mother of 3 who hates ironing"],
 "pains": [2-3 pains it removes, empty if it is a desire product],
 "desires": [2-3 desires it fulfils],
 "objections": [3 doubts an Algerian buyer has before ordering COD],
 "angles": [3 different selling angles, one sentence each, strongest first],
 "usage_moments": [3 situations/occasions where it is used],
 "how_to_use": [3 short steps, empty if obvious],
 "visible_transformation": true ONLY if a camera can show the same person/object clearly worse before and better after (skin, hair, stains, rust, scratches, clutter, body shaper); false for clothes, shoes, bags, jewellery, perfume, food, toys, kids items, tech, kitchen tools, decor, gifts and non-visible health effects,
 "is_wearable": true if clothing / shoes / bags / jewellery / watches,
 "variants_seen": [colours or sizes visible or stated]
}`;
}
function cleanBrief(b) {
  if (!b || typeof b !== 'object') return null;
  const out = {
    product_type: clean(b.product_type, 120), product_name: clean(b.product_name, 100), niche: PALETTES[b.niche] ? b.niche : '',
    visual_description: clean(b.visual_description, 600), features: list(b.features, 6, 90), benefits: list(b.benefits, 6, 90),
    audience: { who: clean(b.audience?.who, 120), gender: clean(b.audience?.gender, 10), age: clean(b.audience?.age, 20), situation: clean(b.audience?.situation, 120) },
    avatars: list(b.avatars, 2, 120), pains: list(b.pains, 3, 100), desires: list(b.desires, 3, 100), objections: list(b.objections, 3, 100),
    angles: list(b.angles, 3, 160), usage_moments: list(b.usage_moments, 3, 100), how_to_use: list(b.how_to_use, 3, 80),
    visible_transformation: b.visible_transformation === true, is_wearable: b.is_wearable === true, variants_seen: list(b.variants_seen, 6, 40)
  };
  return out.product_type || out.features.length ? out : null;
}

// STAGE 2 — a bigger free text model (no image needed) writes the page from the brief.
const CF_WRITER_MODELS = ['@cf/openai/gpt-oss-120b', '@cf/meta/llama-3.3-70b-instruct-fp8-fast'];
function outText(out) {
  if (!out) return '';
  if (typeof out === 'string') return out;
  if (out.response !== undefined) return out.response;
  if (out.result && out.result.response !== undefined) return out.result.response;
  if (out.choices && out.choices[0]) return out.choices[0].message?.content || out.choices[0].text || '';
  if (Array.isArray(out.output)) return out.output.filter((o) => o.type === 'message').flatMap((o) => o.content || []).map((c) => c.text || '').join('');
  if (out.output_text) return out.output_text;
  return '';
}
async function writerAI(prompt) {
  const cfg = aiCfg();
  if ((cfg.provider === 'gemini' || cfg.provider === 'auto') && geminiUsable(cfg)) {
    try { return { j: await geminiText(cfg, prompt, []), model: 'gemini' }; } catch (e) { geminiFailed(); }
  }
  if (!AI_BINDING || !['auto', 'gemini', 'workers'].includes(cfg.provider)) return null;
  const sys = 'You answer with one valid JSON object only. No markdown.';
  for (const model of CF_WRITER_MODELS) {
    try {
      const body = /gpt-oss/.test(model)
        ? { instructions: sys, input: prompt, reasoning: { effort: 'low' }, max_output_tokens: 6000 }
        : { messages: [{ role: 'system', content: sys }, { role: 'user', content: prompt }], max_tokens: 3500, temperature: 0.7 };
      const out = await AI_BINDING.run(model, body);
      const r = (out && typeof out.response === 'object' && out.response) ? out.response : extractJson(outText(out));
      if (r && Array.isArray(r.panels) && r.panels.length) return { j: r, model };
    } catch (e) { /* next model */ }
  }
  return null;
}

const clean = (v, n = 120) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, n);
const list = (v, n, m = 60) => (Array.isArray(v) ? v : []).slice(0, n).map((x) => clean(typeof x === 'string' ? x : x && (x.title || x.text || x.label), m)).filter(Boolean);

// Guess the niche from words when the AI is not available (Arabic, Darija, French, English).
const NICHE_WORDS = {
  fashion: /robe|abaya|abaia|jilbab|djellaba|hijab|foulard|chemise|pantalon|jean|veste|manteau|jupe|ensemble|pyjama|chaussure|basket|sandale|talon|sac\b|pochette|montre|bijou|collier|bague|فستان|روب|عباية|عباءة|جلابة|جلابية|قندورة|كراكو|حجاب|خمار|قميص|سروال|جاكيت|معطف|تنورة|طقم|بيجامة|حذاء|صباط|سباط|كوتشي|صندل|حقيبة|ساك|ساعة|مجوهرات|خاتم|سلسلة|dress|shirt|shoe|bag|watch/i,
  beauty: /cr[eè]me|s[ée]rum|cheveu|peau|visage|maquillage|parfum|rouge|mascara|savon|shampo|كريم|سيروم|شعر|بشرة|وجه|مكياج|عطر|برفان|صابون|شامبو|تبييض|حب الشباب|تساقط/i,
  kids: /b[ée]b[ée]|enfant|jouet|poussette|couche|أطفال|طفل|بيبي|لعبة|ألعاب|حفاظات|رضيع/i,
  tech: /t[ée]l[ée]phone|chargeur|[ée]couteur|casque|smart|bluetooth|usb|cam[ée]ra|montre connect|هاتف|شاحن|سماعة|كاميرا|بلوتوث|ساعة ذكية/i,
  home: /cuisine|maison|nettoy|rangement|lampe|mixeur|po[eê]le|casserole|matelas|coussin|مطبخ|دار|بيت|تنظيف|ترتيب|مصباح|خلاط|طاوة|قدر|مطرح|وسادة|منزل/i,
  men: /barbe|homme|rasoir|لحية|رجال|حلاقة/i,
  food: /miel|dattes|huile d'olive|caf[ée]|th[ée]|عسل|تمر|زيت زيتون|قهوة|شاي/i
};
function guessNiche(text) {
  for (const [n, re] of Object.entries(NICHE_WORDS)) if (re.test(String(text || ''))) return n;
  return 'health';
}

const NO_BA = /robe|abaya|chaussure|sac\b|montre|bijou|parfum|miel|dattes|caf[ée]|jouet|t[ée]l[ée]phone|chargeur|[ée]couteur|فستان|عباية|حذاء|صباط|حقيبة|ساك|ساعة|مجوهرات|عطر|برفان|عسل|تمر|قهوة|لعبة|هاتف|شاحن|سماعة|perfume|dress|shoe|bag|watch|toy|phone|charger/i;
function normalizePlan(j, fallbackName, lang, hint) {
  hint = String(hint || '');
  const niche = PALETTES[j.niche] ? j.niche : guessNiche(hint + ' ' + (j.product_name || ''));
  let panels = (Array.isArray(j.panels) ? j.panels : []).filter((p) => p && PANEL_TYPES.includes(p.type)).slice(0, 9).map((p) => ({
    type: p.type,
    title: clean(p.title, 70), highlight: clean(p.highlight, 30), subtitle: clean(p.subtitle, 110), badge: clean(p.badge, 30),
    bullets: list(p.bullets, 6), before_points: list(p.before_points, 3), after_points: list(p.after_points, 3), steps: list(p.steps, 3, 70),
    scene_prompt: clean(p.scene_prompt, 600), before_scene: clean(p.before_scene, 600), after_scene: clean(p.after_scene, 600)
  }));
  if (!panels.length || panels[0].type !== 'hook') panels = fallbackPlan({ productName: fallbackName, lang, description: hint, niche }).panels;
  if (panels[panels.length - 1].type !== 'offer') panels.push(fallbackPlan({ productName: fallbackName, lang, niche }).panels.slice(-1)[0]);
  // Before/after only where a photo can SHOW the change (never fashion, food, kids, tech, perfume, gifts…).
  const allowBA = j.visible_transformation === true && ['beauty', 'health', 'home', 'men'].includes(niche) && !NO_BA.test(hint + ' ' + (j.product_name || ''));
  const desire = ['fashion', 'food', 'kids'].includes(niche);
  let seenBA = false;
  panels = panels.map((p) => {
    if (p.type === 'before_after' && (!allowBA || seenBA)) {
      return { ...p, type: desire ? 'case' : 'features', bullets: p.after_points.length ? p.after_points : p.bullets, scene_prompt: p.after_scene || p.scene_prompt, before_points: [], after_points: [], before_scene: '', after_scene: '' };
    }
    if (p.type === 'before_after') seenBA = true;
    if (p.type === 'problem' && niche === 'fashion') return { ...p, type: 'look', subtitle: p.bullets[0] || p.subtitle, bullets: [] };
    if (p.type === 'problem' && (niche === 'food' || /parfum|perfume|عطر|برفان/i.test(hint + ' ' + (j.product_name || '')))) return { ...p, type: 'case' };
    return p;
  });
  // no two identical panel types in a row
  panels = panels.filter((p, i) => i === 0 || p.type !== panels[i - 1].type);
  const usePhotos = j.use_photos === true || niche === 'fashion';
  if (usePhotos) panels.forEach((p) => { p.scene_prompt = ''; p.before_scene = ''; p.after_scene = ''; });
  return {
    use_photos: usePhotos,
    product_name: clean(j.product_name || fallbackName, 100), niche, palette: PALETTES[niche],
    audience: { who: clean(j.audience?.who, 120), gender: clean(j.audience?.gender, 10), age: clean(j.audience?.age, 20) },
    visible_transformation: allowBA, objections: list(j.objections, 3, 90),
    pain_or_desire: clean(j.pain_or_desire, 200), angle: clean(j.angle, 200), headline: clean(j.headline, 120), seo_title: clean(j.seo_title, 90), lang, panels
  };
}

function fallbackPlan({ productName, lang, description, niche }) {
  const n = productName || (lang === 'fr' ? 'Le produit' : 'المنتج');
  const fr = lang === 'fr';
  const dz = lang !== 'ar' && !fr;
  niche = PALETTES[niche] ? niche : guessNiche((productName || '') + ' ' + (description || ''));
  const P = (o) => ({ title: '', highlight: '', subtitle: '', badge: '', bullets: [], before_points: [], after_points: [], steps: [], scene_prompt: '', before_scene: '', after_scene: '', ...o });
  const scene = (s) => s + ', realistic photo, natural light, Algerian home, no text, no letters, no words, no logos in the image';
  const L3 = (a, b, c) => (fr ? a : dz ? b : c);
  const base = { product_name: n, niche, palette: PALETTES[niche], audience: { who: '', gender: 'all', age: '' }, pain_or_desire: clean(description, 200), angle: '', headline: n, seo_title: n, lang, use_photos: niche === 'fashion' };
  const trust = P({ type: 'trust', title: L3('Commandez sans risque', 'اطلب وانت مرتاح', 'اطلب بدون مخاطرة') });
  const offer = P({ type: 'offer', title: L3('Offre spéciale', 'عرض خاص اليوم', 'عرض خاص اليوم'), subtitle: L3('Paiement à la livraison', 'الخلاص عند الاستلام', 'الدفع عند الاستلام'), scene_prompt: niche === 'fashion' ? '' : scene('the product hero shot on an elegant background') });
  if (niche === 'fashion') {
    return { ...base, panels: [
      P({ type: 'hook', title: L3('Élégance et confort', 'أناقة وراحة في نفس الوقت', 'أناقة وراحة في آن واحد'), highlight: L3('Élégance', 'أناقة', 'أناقة'), subtitle: n, badge: L3('Nouvelle collection', 'كوليكسيون جديدة', 'تشكيلة جديدة') }),
      P({ type: 'look', title: L3('Un style qui vous ressemble', 'ستيل يليق بيك', 'إطلالة تليق بك'), subtitle: L3('Coupe soignée, tissu de qualité', 'قصة مدروسة وقماش راقي', 'قصة أنيقة وقماش راقٍ') }),
      P({ type: 'details', title: L3('Les détails font la différence', 'التفاصيل هي اللي تفرق', 'التفاصيل تصنع الفرق'), bullets: L3(['Tissu doux et respirant', 'Finitions soignées', 'Confortable toute la journée'], ['قماش رطب ومريح', 'خياطة متقونة', 'مريحة طول النهار'], ['قماش ناعم ومريح', 'خياطة متقنة', 'مريحة طوال اليوم']) }),
      P({ type: 'case', title: L3('Pour toutes les occasions', 'تلبسيها في كل مناسبة', 'مناسبة لكل المناسبات'), bullets: L3(['Fêtes et mariages', 'Sorties et visites', 'Aïd et soirées'], ['الأعراس والحفلات', 'الخرجات والزيارات', 'العيد والسهرات'], ['الأعراس والحفلات', 'الخرجات والزيارات', 'العيد والسهرات']) }),
      P({ type: 'sizes', title: L3('Tailles disponibles', 'المقاسات المتوفرة', 'المقاسات المتوفرة'), bullets: ['S', 'M', 'L', 'XL', 'XXL'] }),
      trust, offer
    ] };
  }
  if (niche === 'beauty') {
    return { ...base, panels: [
      P({ type: 'hook', title: L3('Révélez votre beauté naturelle', 'رجعي لبشرتك جمالها', 'استعيدي جمالك الطبيعي'), highlight: L3('beauté', 'جمالها', 'جمالك'), subtitle: n, badge: L3('Offre limitée', 'عرض محدود', 'عرض محدود'), scene_prompt: scene('a smiling North African woman with glowing skin holding a cosmetic product, bathroom') }),
      P({ type: 'problem', title: L3('Ça vous parle ?', 'تعرفي هاد الإحساس؟', 'هل تعانين من هذا؟'), bullets: L3(['Peau terne', 'Résultats qui ne durent pas', 'Produits qui déçoivent'], ['بشرة باهتة', 'نتيجة ما تدومش', 'منتجات ما نفعوش'], ['بشرة باهتة', 'نتائج لا تدوم', 'منتجات مخيبة']), scene_prompt: scene('a woman looking at her face in the mirror, unhappy') }),
      P({ type: 'before_after', title: L3('Avant / Après', 'شوفي الفرق', 'شاهدي الفرق'), before_points: L3(['Terne', 'Sèche', 'Fatiguée'], ['باهتة', 'ناشفة', 'عيانة'], ['باهتة', 'جافة', 'متعبة']), after_points: L3(['Éclatante', 'Douce', 'Fraîche'], ['مشرقة', 'نعومة', 'نضارة'], ['مشرقة', 'ناعمة', 'نضرة']), before_scene: scene('woman with dull tired skin, close-up'), after_scene: scene('same woman with fresh glowing skin, smiling, close-up') }),
      P({ type: 'features', title: L3('Pourquoi ' + n + ' ?', 'علاش ' + n + '؟', 'لماذا ' + n + '؟'), bullets: L3(['Texture légère', 'Facile à appliquer', 'Pour tous types de peau', 'Résultat visible'], ['خفيف على البشرة', 'ساهل في الاستعمال', 'لكل أنواع البشرة', 'نتيجة باينة'], ['قوام خفيف', 'سهل الاستعمال', 'لكل أنواع البشرة', 'نتيجة واضحة']), scene_prompt: scene('cosmetic product on a marble table with flowers, product photography') }),
      P({ type: 'how_to', title: L3('Mode d’emploi', 'كيفاش تستعمليه', 'طريقة الاستعمال'), steps: L3(['Nettoyez', 'Appliquez', 'Admirez le résultat'], ['نظفي بشرتك', 'حطي شوية', 'شوفي النتيجة'], ['نظفي البشرة', 'ضعي كمية قليلة', 'لاحظي النتيجة']) }),
      trust, offer
    ] };
  }
  if (niche === 'home' || niche === 'tech' || niche === 'men' || niche === 'kids' || niche === 'food') {
    const who = { home: 'a North African woman in a modern Algerian kitchen using the product', tech: 'a young Algerian man using the gadget in daily life', men: 'a confident Algerian man using the product', kids: 'a happy Algerian child playing safely with the product, mother nearby', food: 'the product served on a traditional Algerian table' }[niche];
    return { ...base, panels: [
      P({ type: 'hook', title: L3('Simplifiez-vous la vie', 'سهّل حياتك اليومية', 'سهّل حياتك اليومية'), highlight: L3('vie', 'حياتك', 'حياتك'), subtitle: n, badge: L3('Offre limitée', 'عرض محدود', 'عرض محدود'), scene_prompt: scene(who) }),
      niche === 'food' || niche === 'kids' ? P({ type: 'case', title: L3('Idéal pour', 'مثالي لـ', 'مثالي لـ'), bullets: L3(['Toute la famille', 'Chaque jour', 'Comme cadeau'], ['كل العائلة', 'كل يوم', 'هدية مميزة'], ['كل العائلة', 'الاستعمال اليومي', 'هدية مميزة']), scene_prompt: scene(who) })
        : P({ type: 'problem', title: L3('Fini les galères', 'كفاش ترتاح من التعب؟', 'وداعاً للمتاعب'), bullets: L3(['Perte de temps', 'Ça ne marche pas bien', 'Ça coûte cher'], ['تضييع الوقت', 'الحاجة ما تخدمش مليح', 'تخسر بزاف'], ['تضييع الوقت', 'نتيجة ضعيفة', 'تكاليف كثيرة']), scene_prompt: scene('a frustrated person struggling at home') }),
      P({ type: 'features', title: L3('Pourquoi ' + n + ' ?', 'علاش ' + n + '؟', 'لماذا ' + n + '؟'), bullets: L3(['Qualité solide', 'Facile à utiliser', 'Gain de temps', 'Garanti'], ['جودة قوية', 'ساهل في الاستعمال', 'يربحك الوقت', 'مضمون'], ['جودة عالية', 'سهل الاستعمال', 'يوفر الوقت', 'مضمون']), scene_prompt: scene('the product on a clean table, premium product photography') }),
      P({ type: 'how_to', title: L3('Comment l’utiliser', 'كيفاش تستعملو', 'طريقة الاستعمال'), steps: L3(['Branchez / ouvrez', 'Utilisez', 'Profitez'], ['حلّو', 'استعملو', 'استمتع'], ['افتحه', 'استعمله', 'استمتع']) }),
      trust, offer
    ] };
  }
  return { ...base, panels: [
    P({ type: 'hook', title: L3('Enfin une vraie solution', 'حاب ترتاح نهائياً؟', 'هل تبحث عن حل حقيقي؟'), highlight: L3('solution', 'ترتاح', 'حل'), subtitle: n, badge: L3('Offre limitée', 'عرض محدود', 'عرض محدود'), scene_prompt: scene('a happy relieved person holding the product') }),
    P({ type: 'problem', title: L3('Vous en avez assez ?', 'تعبت من هاد المشكل؟', 'هل تعبت من المشكلة؟'), bullets: L3(['Ça revient chaque jour', 'Rien ne marche', 'Ça gâche vos journées'], ['كل يوم نفس المشكل', 'جربت بزاف وما نفعش', 'راهو مخسرلك راحتك'], ['المشكلة تتكرر كل يوم', 'جربت حلولاً بلا فائدة', 'تؤثر على راحتك']), scene_prompt: scene('a tired worried person at home') }),
    P({ type: 'case', title: L3('Idéal pour vous si…', 'مناسب ليك إذا…', 'مناسب لك إذا…'), bullets: L3(['Vous voulez du confort', 'Vous manquez de temps', 'Vous voulez du résultat'], ['حاب ترتاح', 'ما عندكش الوقت', 'حاب نتيجة صح'], ['تبحث عن الراحة', 'وقتك ضيق', 'تريد نتيجة حقيقية']), scene_prompt: scene('a relaxed Algerian person at home using the product from image 0') }),
    P({ type: 'features', title: L3('Pourquoi ' + n + ' ?', 'علاش ' + n + '؟', 'لماذا ' + n + '؟'), bullets: L3(['Qualité contrôlée', 'Facile à utiliser', 'Résultat visible', 'Garanti'], ['جودة مضمونة', 'ساهل في الاستعمال', 'نتيجة باينة', 'مضمون'], ['جودة مضمونة', 'سهل الاستعمال', 'نتيجة واضحة', 'مضمون']), scene_prompt: scene('the product on a clean table, premium product photography') }),
    P({ type: 'how_to', title: L3('Comment l’utiliser', 'كيفاش تستعملو', 'طريقة الاستعمال'), steps: L3(['Ouvrez', 'Appliquez', 'Profitez'], ['حلّو', 'استعملو', 'استمتع بالنتيجة'], ['افتحه', 'استعمله', 'استمتع بالنتيجة']) }),
    trust, offer
  ] };
}

function extractJson(text) {
  const s = String(text || '');
  const a = s.indexOf('{');
  const b = s.lastIndexOf('}');
  if (a < 0 || b < a) throw new Error('AI did not return JSON');
  return JSON.parse(s.slice(a, b + 1));
}

// Settings saved before the autofill fix could contain e-mails/passwords in model fields: fall back to safe defaults.
function aiCfg() {
  const c = getSetting('ai');
  const ok = (v, def, pre) => { v = String(v || '').trim().replace(/^models\//, ''); return /^[a-z0-9][a-z0-9._\-\/:@]{1,80}$/i.test(v) && !v.includes('@gmail') && (!pre || v.startsWith(pre)) ? v : def; };
  return { ...c, geminiModel: /^gemini-(1\.5|2\.0|2\.5)-/.test(String(c.geminiModel || '')) ? 'gemini-flash-latest' : ok(c.geminiModel, 'gemini-flash-latest'), geminiImageModel: ok(c.geminiImageModel, 'gemini-2.5-flash-image'), cfImageModel: (c.modelV !== 2 && /flux-1-schnell/.test(c.cfImageModel || '')) ? '@cf/black-forest-labs/flux-2-klein-4b' : ok(c.cfImageModel, '@cf/black-forest-labs/flux-2-klein-4b', '@cf/'),
    cfAccountId: /^[a-f0-9]{32}$/i.test(String(c.cfAccountId || '').trim()) ? String(c.cfAccountId).trim() : '', geminiKey: String(c.geminiKey || '').trim(), cfApiToken: String(c.cfApiToken || '').trim() };
}

// Text + vision AI. "auto" = Gemini (free key) first, then Cloudflare Workers AI (free, no key, Llama 4 Scout vision).
const CF_TEXT_MODEL = '@cf/meta/llama-4-scout-17b-16e-instruct';
// Gemini is optional and can be slow (thinking models) or down: 35 s cap, then skip it for 15 min.
let GEM_SKIP_UNTIL = 0;
function geminiUsable(cfg) { return !!cfg.geminiKey && Date.now() > GEM_SKIP_UNTIL; }
function geminiFailed() { GEM_SKIP_UNTIL = Date.now() + 15 * 60e3; }
async function geminiText(cfg, prompt, images) {
  const parts = [{ text: prompt }];
  for (const im of images) parts.push({ inline_data: { mime_type: im.mime, data: im.data } });
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(cfg.geminiModel)}:generateContent?key=${encodeURIComponent(cfg.geminiKey)}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ contents: [{ parts }], generationConfig: { responseMimeType: 'application/json', temperature: 0.8 } }), signal: AbortSignal.timeout(35000)
  });
  const j = await r.json();
  if (j.error) throw new Error('Gemini: ' + j.error.message);
  return extractJson((j.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join(''));
}
async function workersText(prompt, images) {
  const content = [{ type: 'text', text: prompt }];
  for (const im of images.slice(0, 3)) content.push({ type: 'image_url', image_url: { url: `data:${im.mime};base64,${im.data}` } });
  const out = await AI_BINDING.run(CF_TEXT_MODEL, { messages: [{ role: 'system', content: 'You answer with one valid JSON object only.' }, { role: 'user', content }], max_tokens: 3500, temperature: 0.7 });
  const r = out && (out.response !== undefined ? out.response : out.result && out.result.response);
  if (r && typeof r === 'object') return r;
  return extractJson(r);
}
async function textAI(prompt, image) {
  const cfg = aiCfg();
  const images = (Array.isArray(image) ? image : image ? [image] : []).filter((x) => x && x.data);
  const errs = [];
  if ((cfg.provider === 'gemini' || cfg.provider === 'auto') && geminiUsable(cfg)) {
    try { return await geminiText(cfg, prompt, images); } catch (e) { geminiFailed(); errs.push('Gemini: ' + e.message); }
  }
  if ((cfg.provider === 'gemini' || cfg.provider === 'auto' || cfg.provider === 'workers') && AI_BINDING) {
    try { return await workersText(prompt, images); } catch (e) { errs.push('Workers AI: ' + e.message); }
  }
  if (cfg.provider === 'ollama') {
    const r = await fetch(cfg.ollamaUrl.replace(/\/$/, '') + '/api/chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: cfg.ollamaModel, stream: false, format: 'json', options: { temperature: 0.7 }, messages: [{ role: 'user', content: prompt, images: images.length ? images.map((x) => x.data) : undefined }] }),
      signal: AbortSignal.timeout(300000)
    });
    if (!r.ok) throw new Error('Ollama HTTP ' + r.status);
    return extractJson((await r.json()).message?.content);
  }
  throw new Error(errs.length ? errs.join(' | ') : 'no-ai');
}
function textProviderName() {
  const c = aiCfg();
  if ((c.provider === 'gemini' || c.provider === 'auto') && c.geminiKey) return 'gemini';
  if (c.provider !== 'ollama' && c.provider !== 'none' && AI_BINDING) return 'workers-ai';
  return c.provider === 'ollama' ? 'ollama' : 'none';
}

async function analyze({ image, images, description, productName, price, lang }) {
  lang = ['dz', 'ar', 'fr'].includes(lang) ? lang : getSetting('ai').defaultLang || 'dz';
  const imgs = (Array.isArray(images) && images.length ? images : image ? [image] : []).filter((x) => x && x.data).slice(0, 3);
  const hint = (productName || '') + ' ' + (description || '');
  // Two-stage: 1) vision brief from photos, 2) writer model builds the page from the brief.
  let brief = null;
  try { if (imgs.length || description) brief = cleanBrief(await textAI(briefPrompt({ description, productName, price }), imgs)); } catch (e) { /* single-stage below */ }
  if (brief) {
    const w = await writerAI(planPrompt({ description, productName: productName || brief.product_name, price, lang, brief }));
    if (w) {
      const j = { ...w.j };
      if (brief.visible_transformation === false) j.visible_transformation = false;
      if (brief.is_wearable) j.use_photos = true;
      if (!PALETTES[j.niche] && brief.niche) j.niche = brief.niche;
      const plan = normalizePlan(j, productName || brief.product_name, lang, hint + ' ' + brief.product_type);
      return { plan: { ...plan, brief, pipeline: 'brief→' + w.model }, provider: textProviderName() };
    }
  }
  try {
    const j = await textAI(planPrompt({ description, productName, price, lang, brief }), brief ? [] : imgs);
    const plan = normalizePlan(j, productName || (brief && brief.product_name), lang, hint + ' ' + (brief ? brief.product_type : ''));
    return { plan: brief ? { ...plan, brief, pipeline: 'brief→scout' } : plan, provider: textProviderName() };
  } catch (e) {
    return { plan: fallbackPlan({ productName, lang, description }), provider: 'template', warning: e.message === 'no-ai' ? 'AI text provider is off' : e.message };
  }
}

// Scene image (no text) — the platform draws the Arabic text on top.
// Returns { url, withProduct } — withProduct = the image model already drew the real product (no cut-out needed).
async function scene(args) {
  const r = await sceneRaw(args);
  return typeof r === 'string' ? { url: r, withProduct: false } : r;
}
const LIMIT_MSG = 'Free daily image limit reached (resets 01:00 Algeria time). Panels use the product photo for now.';
async function toB64Image(out) {
  if (!out) return null;
  if (typeof out === 'string') return out;
  if (typeof out.image === 'string') return out.image;
  if (out.result && typeof out.result.image === 'string') return out.result.image;
  if (out instanceof ArrayBuffer || ArrayBuffer.isView(out)) return require('./crypto').bytesToB64(new Uint8Array(out.buffer ? out.buffer : out));
  if (typeof out.getReader === 'function') return require('./crypto').bytesToB64(new Uint8Array(await new Response(out).arrayBuffer()));
  return null;
}
async function sceneRaw({ prompt, productUrl, refUrl, aspect = '1:1', storeId = null }) {
  const cfg = aiCfg();
  const saveImage = (bytes, ext) => files.saveBytes(storeId, bytes, ext === 'png' ? 'image/png' : 'image/jpeg');
  const saveB64 = (b64, ext) => files.saveBase64(storeId, b64, ext === 'png' ? 'image/png' : 'image/jpeg');
  if (cfg.imageProvider === 'cloudflare') {
    const useRest = !!(cfg.cfAccountId && cfg.cfApiToken);
    if (!AI_BINDING && !useRest) throw new Error('Add your free Cloudflare Account ID and API token in Platform → AI keys (super admin)');
    // FLUX.2 (klein / dev): sees the product photo (image 0) and draws the REAL product inside the scene.
    if (/flux-2/.test(cfg.cfImageModel) && (refUrl || !productUrl)) {
      try {
        const ref = refUrl ? await files.read(refUrl) : null;
        const p = (ref ? 'Use the exact product from image 0 — same shape, colours, label and packaging, clearly visible and sharp. ' : '') +
          String(prompt || '').replace(/no text[^.]*$/i, '').slice(0, 1400) + ' Photorealistic commercial photo, natural light, high detail. No added text, no letters, no watermark.';
        const [w, h] = aspect === '4:5' || aspect === '3:4' ? [768, 960] : aspect === '9:16' ? [720, 1280] : [1024, 1024];
        const form = new FormData();
        form.append('prompt', p); form.append('width', String(w)); form.append('height', String(h));
        if (ref) form.append('input_image_0', new Blob([ref.bytes], { type: ref.mime }), 'product.jpg');
        let b64;
        if (AI_BINDING && !useRest) {
          const fr = new Response(form);
          const out = await AI_BINDING.run(cfg.cfImageModel, { multipart: { body: fr.body, contentType: fr.headers.get('content-type') } });
          b64 = await toB64Image(out);
        } else {
          const r = await fetch(`https://api.cloudflare.com/client/v4/accounts/${encodeURIComponent(cfg.cfAccountId)}/ai/run/${cfg.cfImageModel}`, { method: 'POST', headers: { Authorization: 'Bearer ' + cfg.cfApiToken }, body: form, signal: AbortSignal.timeout(120000) });
          const ct = r.headers.get('content-type') || '';
          if (ct.startsWith('image/')) return { url: await saveImage(new Uint8Array(await r.arrayBuffer()), ct.includes('png') ? 'png' : 'jpg'), withProduct: !!ref };
          const j = await r.json().catch(() => ({}));
          if (!r.ok || j.success === false) throw new Error((j.errors && j.errors[0] && j.errors[0].message) || 'HTTP ' + r.status);
          b64 = await toB64Image(j.result || j);
        }
        if (!b64) throw new Error('no image returned');
        return { url: await saveB64(b64, 'jpg'), withProduct: !!ref };
      } catch (e) {
        if (/neuron|limit|quota|429|exceeded/i.test(e.message)) throw new Error(LIMIT_MSG);
        console.log('[flux-2] falling back to schnell:', e.message);
      }
    }
    // FLUX.1 schnell: cannot see the product photo → leave an empty spot, the platform places the real product photo on top.
    const p = String(prompt || '').replace(/no text[^.]*$/i, '').replace(/(the )?product (from|in) image 0/gi, 'a product').slice(0, 1500) +
      (productUrl ? '. Do NOT show any bottle, jar, box or package; leave a clean empty area in the lower middle where a product will be placed later.' : '') +
      ' Photorealistic, natural light, high detail. No text, no letters, no words, no watermark, no logos.';
    const steps = Math.min(8, Math.max(1, Number(cfg.cfSteps) || 6));
    const schnell = '@cf/black-forest-labs/flux-1-schnell';
    if (AI_BINDING && !useRest) {
      try {
        const out = await AI_BINDING.run(schnell, { prompt: p, steps });
        const b64 = await toB64Image(out);
        if (!b64) throw new Error('Workers AI returned no image');
        return saveB64(b64, 'jpg');
      } catch (e) {
        throw new Error(/neuron|limit|quota|429|exceeded/i.test(e.message) ? LIMIT_MSG : 'Workers AI: ' + e.message);
      }
    }
    const r = await fetch(`https://api.cloudflare.com/client/v4/accounts/${encodeURIComponent(cfg.cfAccountId)}/ai/run/${schnell}`, {
      method: 'POST', headers: { Authorization: 'Bearer ' + cfg.cfApiToken, 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: p, steps }), signal: AbortSignal.timeout(120000)
    });
    const ct = r.headers.get('content-type') || '';
    if (ct.startsWith('image/')) return saveImage(new Uint8Array(await r.arrayBuffer()), ct.includes('png') ? 'png' : 'jpg');
    const j = await r.json().catch(() => ({}));
    if (!r.ok || j.success === false) {
      const msg = (j.errors && j.errors[0] && j.errors[0].message) || 'HTTP ' + r.status;
      throw new Error(/neuron|limit|quota|429/i.test(msg + r.status) ? LIMIT_MSG : 'Cloudflare: ' + msg);
    }
    const b64 = await toB64Image(j.result);
    if (!b64) throw new Error('Cloudflare returned no image');
    return saveB64(b64, 'jpg');
  }
  const full = String(prompt || '').slice(0, 900) + (productUrl ? ' Use the product from the reference photo exactly as it looks (same packaging, colors and shape).' : '') + ' No text, no letters, no words, no watermark.';
  const prod = await files.read(productUrl);
  if (cfg.imageProvider === 'gemini') {
    if (!cfg.geminiKey) throw new Error('Add a Gemini API key in Platform → AI keys (super admin)');
    const parts = [{ text: full }];
    if (prod) parts.push({ inline_data: { mime_type: prod.mime, data: prod.b64 } });
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(cfg.geminiImageModel)}:generateContent?key=${encodeURIComponent(cfg.geminiKey)}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents: [{ parts }], generationConfig: { responseModalities: ['IMAGE'], imageConfig: { aspectRatio: aspect } } }), signal: AbortSignal.timeout(180000)
    });
    const j = await r.json();
    if (j.error) throw new Error('Gemini image: ' + j.error.message);
    const part = (j.candidates?.[0]?.content?.parts || []).find((p) => p.inlineData || p.inline_data);
    if (!part) throw new Error('Gemini returned no image (try again or change the prompt)');
    const d = part.inlineData || part.inline_data;
    return saveB64(d.data, (d.mimeType || d.mime_type || '').includes('png') ? 'png' : 'jpg');
  }
  if (cfg.imageProvider === 'openai') {
    if (!cfg.openaiKey) throw new Error('Add an OpenAI API key in Platform → AI keys (super admin)');
    let r;
    if (prod) {
      const fd = new FormData();
      fd.append('model', cfg.openaiImageModel);
      fd.append('prompt', full);
      fd.append('size', '1024x1024');
      fd.append('image', new Blob([prod.bytes], { type: prod.mime }), 'product.' + (prod.mime.split('/')[1] || 'jpg'));
      r = await fetch('https://api.openai.com/v1/images/edits', { method: 'POST', headers: { Authorization: 'Bearer ' + cfg.openaiKey }, body: fd, signal: AbortSignal.timeout(180000) });
    } else {
      r = await fetch('https://api.openai.com/v1/images/generations', { method: 'POST', headers: { Authorization: 'Bearer ' + cfg.openaiKey, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: cfg.openaiImageModel, prompt: full, size: '1024x1024' }), signal: AbortSignal.timeout(180000) });
    }
    const j = await r.json();
    if (j.error) throw new Error('OpenAI: ' + j.error.message);
    const b64 = j.data && j.data[0] && j.data[0].b64_json;
    if (!b64) throw new Error('OpenAI returned no image');
    return saveB64(b64, 'png');
  }
  throw new Error('Image AI is off — panels use your product photo');
}

function refImages() { const c = aiCfg(); return c.imageProvider === 'cloudflare' && /flux-2/.test(c.cfImageModel) && (!!AI_BINDING || (!!c.cfAccountId && !!c.cfApiToken)); }
// Per-provider check for the AI settings "Test" button (shows the real error, even when auto mode falls through).
async function testProviders() {
  const cfg = aiCfg(); const out = {};
  const P = 'Reply with JSON only: {"ok": true, "word": "<one Darija word meaning hello>"}';
  if (cfg.geminiKey) {
    const g0 = Date.now();
    try { const j = await geminiText(cfg, P, []); const ms = Date.now() - g0; out.gemini = { ok: true, model: cfg.geminiModel, detail: (ms > 15000 ? 'SLOW ' : '') + Math.round(ms / 1000) + ' s — ' + JSON.stringify(j).slice(0, 60) }; if (ms > 15000) geminiFailed(); else GEM_SKIP_UNTIL = 0; }
    catch (e) {
      let detail = e.message;
      if (/not found|404|not supported|400/i.test(detail)) {
        try {
          const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models?pageSize=100&key=' + encodeURIComponent(cfg.geminiKey), { signal: AbortSignal.timeout(15000) });
          const j = await r.json();
          const names = (j.models || []).filter((m) => /flash/.test(m.name) && (m.supportedGenerationMethods || []).includes('generateContent')).map((m) => m.name.replace('models/', ''));
          if (names.length) detail += ' — available Flash models: ' + names.slice(0, 8).join(', ');
        } catch (_) { /* ignore */ }
      }
      out.gemini = { ok: false, model: cfg.geminiModel, detail };
    }
  }
  if (AI_BINDING) {
    try { const j = await workersText(P, []); out.vision = { ok: true, model: CF_TEXT_MODEL, detail: JSON.stringify(j).slice(0, 80) }; }
    catch (e) { out.vision = { ok: false, model: CF_TEXT_MODEL, detail: e.message }; }
    for (const model of CF_WRITER_MODELS) {
      try {
        const body = /gpt-oss/.test(model) ? { instructions: 'JSON only.', input: P, reasoning: { effort: 'low' }, max_output_tokens: 300 } : { messages: [{ role: 'user', content: P }], max_tokens: 100 };
        const t = outText(await AI_BINDING.run(model, body));
        out.writer = { ok: !!t, model, detail: String(typeof t === 'string' ? t : JSON.stringify(t)).slice(0, 80) }; if (t) break;
      } catch (e) { out.writer = { ok: false, model, detail: e.message }; }
    }
  }
  return out;
}

module.exports = { testProviders, normalizePlan, refImages, aiCfg, setAiBinding, hasAiBinding: () => !!AI_BINDING, analyze, scene, textAI, PALETTES, PANEL_TYPES, fallbackPlan };
