'use strict';
// Platform-level public pages (marketing home, store unavailable).
const { getSetting } = require('./db');
const { esc } = require('./util');

const CSS = `
:root{--p:#0F5C46;--a:#F2A93B;--ink:#15201B;--bg:#F7F6F2;--card:#fff;--line:#e6e3da;--mut:#5b665f}
*{box-sizing:border-box}html,body{margin:0;overflow-x:hidden}body{font-family:Cairo,system-ui,sans-serif;background:var(--bg);color:var(--ink);line-height:1.6}
a{color:inherit}.wrap{max-width:1080px;margin:0 auto;padding:0 16px}
.top{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 0}
.logo{font-weight:800;font-size:20px;text-decoration:none;display:flex;align-items:center;gap:8px}
.logo i{width:30px;height:30px;border-radius:9px;background:var(--p);display:inline-grid;place-items:center;color:#fff;font-style:normal;font-size:16px}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:46px;padding:0 20px;border-radius:12px;background:var(--p);color:#fff;text-decoration:none;font-weight:700;border:0;font-family:inherit;font-size:15px}
.btn.ghost{background:transparent;color:var(--ink);border:1.5px solid var(--line)}.btn.acc{background:var(--a);color:#1d1400}
.hero{padding:34px 0 26px;text-align:center}.hero h1{font-size:clamp(28px,7vw,48px);line-height:1.25;margin:0 0 12px}
.hero h1 em{font-style:normal;color:var(--p)}.hero p{font-size:clamp(16px,4.2vw,19px);color:var(--mut);margin:0 auto 22px;max-width:620px}
.cta{display:flex;gap:10px;justify-content:center;flex-wrap:wrap}
.chips{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:18px}.chips span{background:#fff;border:1px solid var(--line);border-radius:99px;padding:4px 12px;font-size:13px;color:var(--mut)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px;margin:26px 0}
.card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:18px}.card b{display:block;font-size:17px;margin-bottom:4px}.card small{color:var(--mut);font-size:14px}
.card .ic{width:40px;height:40px;border-radius:12px;background:#e7f1ec;color:var(--p);display:grid;place-items:center;font-size:20px;margin-bottom:10px}
h2{font-size:clamp(22px,5.4vw,30px);text-align:center;margin:40px 0 6px}.sub{text-align:center;color:var(--mut);margin:0 0 10px}
.steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin:20px 0}
.steps div{background:#fff;border:1px solid var(--line);border-radius:16px;padding:16px;position:relative}.steps .n{width:30px;height:30px;border-radius:50%;background:var(--a);display:grid;place-items:center;font-weight:800;margin-bottom:6px}
.band{background:var(--p);color:#fff;border-radius:22px;padding:28px 18px;text-align:center;margin:40px 0}.band h2{margin:0 0 8px;color:#fff}.band p{opacity:.85;margin:0 0 18px}
footer{color:var(--mut);font-size:13px;text-align:center;padding:24px 0 40px;display:grid;gap:10px;border-top:1px solid var(--line);margin-top:30px}
.nav{display:none;gap:18px;font-weight:600}.nav a{text-decoration:none;color:var(--mut)}.row{display:flex;gap:8px;align-items:center}
.btn.big{min-height:54px;padding:0 26px;font-size:17px}
.kicker{display:inline-block;background:#e7f1ec;color:var(--p);font-weight:700;font-size:13px;padding:5px 12px;border-radius:99px;margin-bottom:12px}
.hero{display:grid;gap:30px;align-items:center;text-align:start;padding:26px 0 30px}
.hero-txt h1{font-size:clamp(30px,7.4vw,52px)}.hero-txt p{margin:0 0 22px}.hero .cta{justify-content:flex-start}
.ticks{list-style:none;padding:0;margin:18px 0 0;display:flex;gap:14px;flex-wrap:wrap;color:var(--mut);font-size:14px}.ticks li:before{content:"✓ ";color:var(--p);font-weight:800}
.hero-vis{position:relative;display:grid;place-items:center;padding:10px 0}
.phone{width:250px;height:500px;border-radius:38px;background:#111;padding:10px;box-shadow:0 30px 60px rgba(15,92,70,.25)}
.scr{width:100%;height:100%;border-radius:30px;background:#fff;overflow:hidden;display:flex;flex-direction:column}
.m-top{display:flex;justify-content:space-between;align-items:center;padding:10px 12px;font-size:11px}.m-top span{border:1px solid var(--p);color:var(--p);border-radius:99px;padding:1px 7px}
.m-hero{height:200px;background:linear-gradient(160deg,#0b2a20,#0F5C46);color:#fff;padding:14px;position:relative;display:flex;flex-direction:column;justify-content:flex-end}.m-hero b{font-size:22px;line-height:1.3}
.m-badge{position:absolute;top:12px;inset-inline-start:12px;background:var(--a);color:#1d1400;font-size:10px;font-weight:800;padding:2px 8px;border-radius:99px}
.m-form{padding:10px;display:grid;gap:7px}.m-offer{display:flex;justify-content:space-between;border:1.5px solid var(--line);border-radius:10px;padding:7px 9px;font-size:12px}.m-offer.on{border-color:var(--p);background:#eef6f2}
.m-form i{height:26px;border:1px solid var(--line);border-radius:8px}.m-btn{background:var(--p);color:#fff;text-align:center;border-radius:10px;padding:9px;font-weight:800;font-size:13px}
.float{position:absolute;background:#fff;border:1px solid var(--line);border-radius:12px;padding:8px 12px;font-size:13px;font-weight:700;box-shadow:0 10px 30px rgba(0,0,0,.08)}
.f1{top:60px;inset-inline-end:0;color:var(--p)}.f2{bottom:70px;inset-inline-start:0;color:#9A1C12}
.logos{display:flex;gap:10px 22px;flex-wrap:wrap;justify-content:center;align-items:center;padding:18px;border:1px solid var(--line);border-radius:16px;background:#fff;color:var(--mut);margin:10px 0 20px}.logos b{color:var(--ink);font-size:16px;opacity:.75}
.split{display:grid;gap:22px;align-items:center;margin:46px 0;background:#fff;border:1px solid var(--line);border-radius:22px;padding:24px}.split h2.l{text-align:start;margin:0 0 8px}.mut{color:var(--mut)}
.mini{padding-inline-start:20px;color:var(--mut)}.mini li{margin:6px 0}
.panels-demo{display:grid;gap:10px}.pd{border-radius:16px;padding:22px 18px;color:#fff;display:grid;gap:4px}.pd b{font-size:20px}.pd span{opacity:.85;font-size:14px}
.p1{background:linear-gradient(140deg,#2a2a2a,#111)}.p2{background:linear-gradient(140deg,#0F5C46,#0b2a20)}.p3{background:linear-gradient(140deg,#1d1400,#3a2a00);border:2px solid var(--a)}
.cmp{background:#fff;border:1px solid var(--line);border-radius:16px;overflow:hidden;margin:16px 0}.cmp-h,.cmp-r{display:grid;grid-template-columns:1fr 90px 110px;gap:8px;padding:12px 14px;align-items:center}
.cmp-h{background:#f3f1ea;font-weight:800;font-size:14px}.cmp-h .us{color:var(--p)}.cmp-r{border-top:1px solid var(--line);font-size:14px}.cmp-r .ok{color:var(--p);font-weight:900;font-size:18px}.cmp-r .no{color:#b42318;font-weight:800}.cmp-r .meh{color:var(--mut);font-size:12px}
.steps small{display:block;color:var(--mut)}.steps b{display:block}
.faq{display:grid;gap:8px;margin:16px 0}.faq details{background:#fff;border:1px solid var(--line);border-radius:14px;padding:12px 16px}.faq summary{font-weight:700;cursor:pointer}.faq p{color:var(--mut);margin:8px 0 0}
@media(min-width:860px){.nav{display:flex}.hero{grid-template-columns:1.15fr .85fr;padding:50px 0 40px}.split{grid-template-columns:1fr 1fr;padding:36px}}
.mid{min-height:70vh;display:grid;place-items:center;text-align:center;padding:30px 16px}
`;

function shell(title, body, desc = '') {
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>${esc(title)}</title><meta name="description" content="${esc(desc)}"><meta name="theme-color" content="#0F5C46">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet" media="print" onload="this.media='all'">
<style>${CSS}</style></head><body>${body}</body></html>`;
}

function homePage() {
  const P = getSetting('platform');
  const name = esc(P.name);
  const signup = P.signupMode !== 'closed';
  const cta = signup ? '<a class="btn acc big" href="/admin/#signup">أنشئ متجرك مجاناً</a>' : '';
  const ic = (d) => `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  const I = {
    ai: ic('<path d="M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>'),
    form: ic('<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>'),
    truck: ic('<path d="M3 7h11v9H3z"/><path d="M14 10h4l3 3v3h-7"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/>'),
    shield: ic('<path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>'),
    chart: ic('<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>'),
    phone: ic('<path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a1 1 0 01-1 1A16 16 0 014 5a1 1 0 011-1z"/>'),
    palette: ic('<circle cx="12" cy="12" r="9"/><circle cx="8" cy="10" r="1.2"/><circle cx="12" cy="7.5" r="1.2"/><circle cx="16" cy="10" r="1.2"/><path d="M12 21a3 3 0 010-6h2a3 3 0 003-3"/>'),
    target: ic('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>')
  };
  const feats = [
    [I.ai, 'صفحات هبوط بالذكاء الاصطناعي', 'صورة المنتج وسطرين وصف ← صفحة كاملة بالدارجة: صور مصممة، عروض، وفورم الطلب بعد أول صورة. ستايل خاص لكل نيش: ملابس، تجميل، صحة، دار…'],
    [I.form, 'فورم طلب تتحكم فيه', 'زيد، نحّي، سمّي الخانات كيما تحب، خلي واحدة إجبارية ولا لا. رقم الهاتف أرقام فقط، وملخص الطلب يبان للزبون قبل التأكيد.'],
    [I.truck, 'ربط مع شركات التوصيل', 'بعث الطلبيات بكليك واحد ورجع رقم التتبع والحالة أوتوماتيك: Yalidine، Guepex، ZR Express، Noest، وشركات EcoTrack.'],
    [I.shield, 'حماية من الطلبات المزيفة', 'حظر IP أوتوماتيكي، قائمة سوداء للأرقام، دمج الطلبات المكررة، نقطة ثقة لكل زبون، وفخ للروبوتات.'],
    [I.target, 'بيكسلات ذكية', 'عدة بيكسلات Meta وTikTok وSnap وGoogle، مع Conversions API. تقدر تبعث “Purchase” غير كي تأكد الطلب أو كي يتسلم — إعلانات تتعلم من الزبائن الحقيقيين.'],
    [I.chart, 'الربح الحقيقي للإعلانات', 'ربط Meta Ads: تكلفة الطلب المؤكد والمسلّم، نقطة التعادل، والربح الصافي لكل حملة: زيد، راقب، أوقف.'],
    [I.phone, 'تأكيد الطلبيات', 'حالة كل طلب بقائمة وحدة، اتصال وواتساب بكليك، تاريخ كل طلب، فريق بأدوار (مؤكد، مخزن، إعلانات).'],
    [I.palette, 'ثيمات حقيقية لمتجرك', 'Classic، Bold، Minimal، Boutique للملابس، Market، Fresh — كل ثيم بتصميم مختلف، باش متجرك ما يشبهش للآخرين.']
  ];
  const steps = [['أنشئ حسابك', 'اسم المتجر ورابطه، في دقيقة.'], ['زيد منتجك', 'صورة، سعر، عروض 1/2/3 قطع.'], ['ولّد الصفحة واعلن', 'انسخ رابط الإعلان وابدأ تستقبل الطلبيات.']];
  const rows = [
    ['صفحات هبوط بالدارجة بالذكاء الاصطناعي', true, false],
    ['ربط شركات التوصيل الجزائرية', true, 'غالباً مدفوع'],
    ['حظر IP ضد هجمات الطلبات المزيفة', true, false],
    ['Purchase للإعلانات عند التأكيد أو التسليم', true, false],
    ['حساب الربح الصافي لكل حملة', true, false],
    ['محاكي أرباح COD مدمج', true, false],
    ['بدون عمولة على الطلبيات', true, 'أحياناً']
  ];
  const faq = [
    ['هل المنصة مجانية؟', 'نعم، مجانية خلال الفترة التجريبية بدون عمولة على الطلبيات.'],
    ['هل نحتاج نعرف البرمجة؟', 'لا. كل شيء من لوحة التحكم: المنتجات، الصفحات، التصميم، الفورم والإعدادات.'],
    ['كيفاش نربط شركة التوصيل؟', 'من الإعدادات ← شركة التوصيل: تختار الشركة وتحط مفاتيح الـ API تاعك، وتبعث الطلبيات بكليك.'],
    ['واش نقدر نستعمل البيكسل تاعي؟', 'أكيد. تقدر تزيد عدة بيكسلات Meta وTikTok وSnap وGoogle، وكل صفحة هبوط تقدر يكون عندها بيكسل خاص.'],
    ['كيفاش نحمي روحي من الطلبات المزيفة؟', 'المنصة تحظر الـ IP اللي يبعث بزاف طلبيات، تحط الأرقام المشبوهة في القائمة السوداء، وتعطيك نقطة ثقة لكل زبون حسب تاريخ التسليم.'],
    ['وين تتخزن المعلومات؟', 'في قاعدة بيانات آمنة خاصة بالمنصة. كل متجر يشوف غير معلوماته، ومفاتيح الـ API ما تبانش كاملة.']
  ];
  const mock = `<div class="phone"><div class="scr">
      <div class="m-top"><b>متجري</b><span>الدفع عند الاستلام</span></div>
      <div class="m-hero"><span class="m-badge">عرض محدود</span><b>أناقة وراحة<br>في نفس الوقت</b></div>
      <div class="m-form"><div class="m-offer on"><span>قطعتان</span><b>⁦6 900⁩ دج</b></div><div class="m-offer"><span>قطعة</span><b>⁦3 900⁩ دج</b></div><i></i><i></i><i></i><div class="m-btn">تأكيد الطلب</div></div>
    </div></div>`;
  const body = `<div class="wrap">
<header class="top"><a class="logo" href="/"><i>◆</i>${name}</a><nav class="nav"><a href="#features">المميزات</a><a href="#how">كيف تبدأ</a><a href="#faq">أسئلة</a></nav><div class="row"><a class="btn ghost" href="/admin/">دخول</a>${signup ? '<a class="btn" href="/admin/#signup">ابدأ</a>' : ''}</div></header>
<section class="hero">
  <div class="hero-txt">
    <span class="kicker">منصة جزائرية للبيع بالدفع عند الاستلام</span>
    <h1>متجرك وصفحات هبوط <em>تبيع</em><br>— في دقائق، بدون برمجة</h1>
    <p>${esc(P.tagline)}. صفحات هبوط بالدارجة بالذكاء الاصطناعي، تأكيد الطلبيات، شركات التوصيل، البيكسلات وأرباح إعلاناتك — كلها في مكان واحد.</p>
    <div class="cta">${cta}<a class="btn ghost big" href="/admin/">لديّ حساب</a></div>
    <ul class="ticks"><li>مجاني في الفترة التجريبية</li><li>بدون عمولة</li><li>دارجة · عربية · فرنسية</li></ul>
  </div>
  <div class="hero-vis">${mock}<div class="float f1">✓ طلب جديد — ⁦6 900⁩ دج</div><div class="float f2">IP مشبوه تم حظره</div></div>
</section>
<section class="logos"><span>مربوطة مع</span><b>Yalidine</b><b>Guepex</b><b>ZR Express</b><b>Noest</b><b>EcoTrack</b><b>Meta</b><b>TikTok</b></section>
<h2 id="features">كل ما يحتاجه بائع COD في الجزائر</h2><p class="sub">مبنية على المشاكل الحقيقية للسوق: الطلبات المزيفة، الإرجاع، والإعلانات اللي تحرق الميزانية.</p>
<div class="grid">${feats.map((f) => `<div class="card"><div class="ic">${f[0]}</div><b>${esc(f[1])}</b><small>${esc(f[2])}</small></div>`).join('')}</div>
<section class="split">
  <div><span class="kicker">مولّد صفحات الهبوط</span><h2 class="l">من صورة واحدة إلى صفحة كاملة</h2><p class="mut">الذكاء الاصطناعي يفهم النيش والجمهور والمشكل، ويختار ترتيب الصور اللي يبيع أكثر. الملابس تاخذ صورك أنت، المنتجات الأخرى تاخذ مشاهد واقعية. النص بالعربي يتكتب فوق الصور دايماً صحيح وتقدر تعدلو.</p>
  <ol class="mini"><li>ارفع الصورة واكتب سطرين</li><li>راجع النصوص والترتيب</li><li>اضغط “إنشاء” وانسخ رابط الإعلان</li></ol></div>
  <div class="panels-demo"><div class="pd p1"><b>تعبت من هاد المشكل؟</b></div><div class="pd p2"><b>شوف الفرق</b><span>قبل · بعد</span></div><div class="pd p3"><b>عرض خاص اليوم</b><span>الدفع عند الاستلام</span></div></div>
</section>
<h2 id="how">كيف تبدأ؟</h2><p class="sub">ثلاث خطوات وتكون صفحتك جاهزة للإعلان</p>
<div class="steps">${steps.map((x, i) => `<div><span class="n">${i + 1}</span><b>${esc(x[0])}</b><small>${esc(x[1])}</small></div>`).join('')}</div>
<h2>علاش ${name}؟</h2>
<div class="cmp"><div class="cmp-h"><span></span><span class="us">${name}</span><span>منصات أخرى</span></div>${rows.map((r) => `<div class="cmp-r"><span>${esc(r[0])}</span><span class="ok">✓</span><span class="${r[2] === false ? 'no' : 'meh'}">${r[2] === false ? '✕' : esc(r[2])}</span></div>`).join('')}</div>
<h2 id="faq">أسئلة شائعة</h2>
<div class="faq">${faq.map((f) => `<details><summary>${esc(f[0])}</summary><p>${esc(f[1])}</p></details>`).join('')}</div>
<section class="band"><h2>جاهز تبيع؟</h2><p>${P.signupMode === 'invite' ? 'التسجيل حالياً بكود دعوة — اطلبه منا.' : 'أنشئ متجرك الآن، مجاناً.'}</p>${cta}
${P.supportPhone ? `<p style="margin-top:14px">واتساب: <a href="https://wa.me/${esc(String(P.supportPhone).replace(/\D/g, '').replace(/^0/, '213'))}" style="color:#fff">${esc(P.supportPhone)}</a></p>` : ''}</section>
<footer><div><b>${name}</b><br><small>${esc(P.tagline)}</small></div><div><a href="/admin/">دخول</a>${signup ? ' · <a href="/admin/#signup">إنشاء متجر</a>' : ''}${P.supportEmail ? ' · <a href="mailto:' + esc(P.supportEmail) + '">' + esc(P.supportEmail) + '</a>' : ''}</div><small>© ${new Date().getFullYear()} ${name}</small></footer></div>`;
  return shell(P.name + ' — ' + P.tagline, body, P.tagline);
}

function unavailable() {
  const P = getSetting('platform');
  return shell('غير متاح', `<div class="mid"><div><h1 style="margin:0 0 8px">هذا المتجر غير متاح حالياً</h1><p style="color:var(--mut)">Cette boutique est momentanément indisponible.</p><a class="btn ghost" href="/">${esc(P.name)}</a></div></div>`);
}

function notFound() {
  const P = getSetting('platform');
  return shell('404', `<div class="mid"><div><h1 style="margin:0 0 8px">404</h1><a class="btn ghost" href="/">${esc(P.name)}</a></div></div>`);
}

module.exports = { homePage, unavailable, notFound };
