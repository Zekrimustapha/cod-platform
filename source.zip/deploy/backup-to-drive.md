# Off-server backups (free)

The server keeps a daily copy of the database in `data/backups` (14 days).
Copy it somewhere else once a week, from your PC:

```
scp -r ubuntu@YOUR_SERVER_IP:~/cod-store/data/backups ./platform-backups
scp -r ubuntu@YOUR_SERVER_IP:~/cod-store/data/uploads ./platform-uploads
```

Or in the dashboard: Platform owner → Settings → Account & backup → **Full platform database**.
