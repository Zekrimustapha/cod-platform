'use strict';
// Uploaded images live in the database (works the same on a PC and on Cloudflare D1, no extra storage service).
const { D } = require('./db');
const { randomHex, bytesToB64, b64ToBytes } = require('./crypto');
const { httpError } = require('./util');

const EXT = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif', 'video/mp4': 'mp4' };
const MIME = Object.fromEntries(Object.entries(EXT).map(([m, e]) => [e, m]));
const MAX = 1400 * 1024; // D1 rows are limited to ~2 MB (base64 adds 33%)

async function saveBase64(storeId, b64, mime) {
  const ext = EXT[mime];
  if (!ext) throw httpError(400, 'Only JPG, PNG, WebP, GIF images or MP4 video');
  b64 = String(b64 || '').replace(/\s/g, '');
  const size = Math.floor((b64.length * 3) / 4);
  if (!size) throw httpError(400, 'Empty file');
  if (size > MAX) throw httpError(413, 'File too large (max 1.4 MB). Images are compressed automatically; videos must be short.');
  const id = Date.now().toString(36) + randomHex(5);
  await D.run('INSERT INTO files(id, store_id, mime, size, data, created_at) VALUES(?,?,?,?,?,?)', id, storeId || null, mime, size, b64, new Date().toISOString());
  return '/uploads/' + id + '.' + ext;
}
async function saveDataUrl(storeId, dataUrl, mime) {
  const m = String(dataUrl || '').match(/^data:([^;]+);base64,(.*)$/s);
  return m ? saveBase64(storeId, m[2], m[1]) : saveBase64(storeId, dataUrl, mime);
}
async function saveBytes(storeId, bytes, mime) {
  return saveBase64(storeId, bytesToB64(bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes)), mime);
}
// '/uploads/<id>.<ext>' → { mime, bytes } or null
async function read(url) {
  const m = String(url || '').match(/^\/uploads\/([a-z0-9]+)\.([a-z0-9]+)$/);
  if (!m) return null;
  const row = await D.get('SELECT mime, data FROM files WHERE id = ?', m[1]);
  if (!row) return null;
  return { mime: row.mime, b64: row.data, bytes: b64ToBytes(row.data) };
}

module.exports = { saveBase64, saveDataUrl, saveBytes, read, MIME };
