/* Landing design system v3 \u2014 CODE decides the look, the AI only fills content.
   One style preset per page, seamless sections (shared seam colour + continuous pattern),
   fixed blueprints per section type, fit-to-zone text (never clipped), real cut-out placement.
   Panels3.render(panel, o) -> Promise<{ url, h, overflow: [fieldName\u2026] }>
   o: { style, lang, cutout, photo, bgA, life, price, oldPrice, offers, pageY, photos[] } */
(function () {
  'use strict';
  var W = 1080, SEAM = 90;
  var PRESETS = {
    luxe_amber: { bg: ['#0E0A05', '#2A1806'], accent: '#F5A524', text: '#FFFFFF', text2: '#FFE3A3', pattern: 'honeycomb', icon: 'hex', font: 'Cairo', tw: 900, glow: true, rays: true, dark: true },
    luxe_dark: { bg: ['#0B0B0F', '#1C1C24'], accent: '#D4AF37', text: '#FFFFFF', text2: '#E9E2C8', pattern: 'rays', icon: 'circle', font: 'Cairo', tw: 900, glow: true, rays: true, dark: true },
    fresh_clean: { bg: ['#FFFFFF', '#E9F7EF'], accent: '#16A34A', text: '#0F2A1C', text2: '#2F5A43', pattern: 'leaves', icon: 'circle', font: 'Tajawal', tw: 800, glow: false, rays: false, dark: false },
    bold_promo: { bg: ['#B91C1C', '#7F1010'], accent: '#FACC15', text: '#FFFFFF', text2: '#FFE9A8', pattern: 'stripes', icon: 'circle', font: 'Changa', tw: 800, glow: true, rays: false, burst: true, dark: true },
    soft_beauty: { bg: ['#FFF1F2', '#FBCFE8'], accent: '#BE185D', text: '#3B0A1E', text2: '#7A2E4E', pattern: 'bokeh', icon: 'circle', font: 'Tajawal', tw: 800, glow: true, rays: false, dark: false },
    tech_neon: { bg: ['#06142B', '#0B2545'], accent: '#22D3EE', text: '#FFFFFF', text2: '#BDEFFA', pattern: 'grid', icon: 'square', font: 'Changa', tw: 700, glow: true, rays: false, dark: true },
    kids_fun: { bg: ['#FFF7E6', '#FFE4B5'], accent: '#F97316', text: '#3A1604', text2: '#7A3A12', pattern: 'confetti', icon: 'circle', font: 'Cairo', tw: 800, glow: false, rays: false, dark: false },
    fashion_editorial: { bg: ['#F7F2EA', '#EFE6D8'], accent: '#111111', gold: '#C9A227', text: '#111111', text2: '#4A4238', pattern: 'frame', icon: 'diamond', font: 'El Messiri', tw: 700, glow: false, rays: false, dark: false }
  };
  var HEIGHTS = { hook: 1350, features: 1200, inside: 1200, 'case': 1150, how_to: 1000, guarantee_strip: 260, problem: 1100, pain_chips: 1100, bundle: 1100, offer: 1350, cta: 1350, look: 1350, details: 1200, sizes: 1000, before_after: 1200, trust: 1000 };
  var L = {
    dz: { cod: '\u0627\u0644\u062e\u0644\u0627\u0635 \u0639\u0646\u062f \u0627\u0644\u0627\u0633\u062a\u0644\u0627\u0645', deliv: '\u062a\u0648\u0635\u064a\u0644 \u0644\u0640 58 \u0648\u0644\u0627\u064a\u0629', call: '\u0646\u0639\u064a\u0637\u0648\u0644\u0643 \u0642\u0628\u0644 \u0645\u0627 \u0646\u0628\u0639\u062b\u0648', exch: '\u0627\u0633\u062a\u0628\u062f\u0627\u0644 \u0645\u0636\u0645\u0648\u0646', order: '\u0627\u0637\u0644\u0628 \u062f\u0631\u0643', special: '\u0639\u0631\u0636 \u062e\u0627\u0635', cur: '\u062f\u062c', buy2: '\u0627\u0634\u0631\u064a {n} \u0648\u0648\u0641\u0651\u0631 {s} \u062f\u062c', bundle: '{n} \u062d\u0628\u0627\u062a \u0628\u0640 {p} \u062f\u062c', sizesLbl: '\u0627\u0644\u0645\u0642\u0627\u0633\u0627\u062a \u0627\u0644\u0645\u062a\u0648\u0641\u0631\u0629', step: '\u0627\u0644\u062e\u0637\u0648\u0629', before: '\u0642\u0628\u0644', after: '\u0628\u0639\u062f', footer: '\u0627\u0644\u062e\u0644\u0627\u0635 \u0639\u0646\u062f \u0627\u0644\u0627\u0633\u062a\u0644\u0627\u0645 \u00b7 \u062a\u0648\u0635\u064a\u0644 \u0644\u0640 58 \u0648\u0644\u0627\u064a\u0629', strip: ['\u0627\u0644\u062e\u0644\u0627\u0635 \u0639\u0646\u062f \u0627\u0644\u0627\u0633\u062a\u0644\u0627\u0645', '\u062a\u0648\u0635\u064a\u0644 58 \u0648\u0644\u0627\u064a\u0629', '\u0645\u0643\u0627\u0644\u0645\u0629 \u062a\u0623\u0643\u064a\u062f', '\u0627\u0633\u062a\u0628\u062f\u0627\u0644 \u0645\u0636\u0645\u0648\u0646'] },
    ar: { cod: '\u0627\u0644\u062f\u0641\u0639 \u0639\u0646\u062f \u0627\u0644\u0627\u0633\u062a\u0644\u0627\u0645', deliv: '\u062a\u0648\u0635\u064a\u0644 \u0644\u0640 58 \u0648\u0644\u0627\u064a\u0629', call: '\u0645\u0643\u0627\u0644\u0645\u0629 \u062a\u0623\u0643\u064a\u062f \u0642\u0628\u0644 \u0627\u0644\u0625\u0631\u0633\u0627\u0644', exch: '\u0627\u0633\u062a\u0628\u062f\u0627\u0644 \u0645\u0636\u0645\u0648\u0646', order: '\u0627\u0637\u0644\u0628 \u0627\u0644\u0622\u0646', special: '\u0639\u0631\u0636 \u062e\u0627\u0635', cur: '\u062f\u062c', buy2: '\u0627\u0634\u062a\u0631\u0650 {n} \u0648\u0648\u0641\u0651\u0631 {s} \u062f\u062c', bundle: '{n} \u0642\u0637\u0639 \u0628\u0640 {p} \u062f\u062c', sizesLbl: '\u0627\u0644\u0645\u0642\u0627\u0633\u0627\u062a \u0627\u0644\u0645\u062a\u0648\u0641\u0631\u0629', step: '\u0627\u0644\u062e\u0637\u0648\u0629', before: '\u0642\u0628\u0644', after: '\u0628\u0639\u062f', footer: '\u0627\u0644\u062f\u0641\u0639 \u0639\u0646\u062f \u0627\u0644\u0627\u0633\u062a\u0644\u0627\u0645 \u00b7 \u062a\u0648\u0635\u064a\u0644 \u0644\u0640 58 \u0648\u0644\u0627\u064a\u0629', strip: ['\u0627\u0644\u062f\u0641\u0639 \u0639\u0646\u062f \u0627\u0644\u0627\u0633\u062a\u0644\u0627\u0645', '\u062a\u0648\u0635\u064a\u0644 58 \u0648\u0644\u0627\u064a\u0629', '\u0645\u0643\u0627\u0644\u0645\u0629 \u062a\u0623\u0643\u064a\u062f', '\u0627\u0633\u062a\u0628\u062f\u0627\u0644 \u0645\u0636\u0645\u0648\u0646'] },
    fr: { cod: 'Paiement \u00e0 la livraison', deliv: 'Livraison 58 wilayas', call: 'Appel de confirmation', exch: '\u00c9change garanti', order: 'Commander', special: 'Offre sp\u00e9ciale', cur: 'DA', buy2: 'Achetez {n}, \u00e9conomisez {s} DA', bundle: '{n} pi\u00e8ces : {p} DA', sizesLbl: 'Tailles disponibles', step: '\u00c9tape', before: 'Avant', after: 'Apr\u00e8s', footer: 'Paiement \u00e0 la livraison \u00b7 Livraison 58 wilayas', strip: ['Paiement livraison', 'Livraison 58 wilayas', 'Appel confirmation', '\u00c9change garanti'] }
  };

  // ---------- fonts / images ----------
  var fontsReady = {};
  function ensureFont(font) {
    if (fontsReady[font]) return fontsReady[font];
    var q = { Cairo: 'Cairo:wght@600;700;800;900', Tajawal: 'Tajawal:wght@500;700;800', 'El Messiri': 'El+Messiri:wght@500;600;700', Changa: 'Changa:wght@500;700;800' }[font] || 'Cairo:wght@600;700;800;900';
    if (!document.querySelector('link[data-f3="' + font + '"]')) { var link = document.createElement('link'); link.rel = 'stylesheet'; link.setAttribute('data-f3', font); link.href = 'https://fonts.googleapis.com/css2?family=' + q + '&display=swap'; document.head.appendChild(link); }
    fontsReady[font] = Promise.race([Promise.all(['500', '700', '800', '900'].map(function (w) { return document.fonts.load(w + ' 60px "' + font + '"', '\u0627\u0628\u062a'); })), new Promise(function (r) { setTimeout(r, 5000); })]).catch(function () {});
    return fontsReady[font];
  }
  var imgCache = {};
  function loadImg(url) {
    if (!url) return Promise.resolve(null);
    if (!imgCache[url]) imgCache[url] = new Promise(function (res) { var i = new Image(); i.onload = function () { res(i); }; i.onerror = function () { delete imgCache[url]; res(null); }; i.src = url; });
    return imgCache[url];
  }

  // ---------- colour helpers ----------
  function rgb(h) { h = String(h || '#000').replace('#', ''); return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]; }
  function rgba(h, a) { var c = rgb(h); return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; }
  function mix(a, b, t) { var x = rgb(a), y = rgb(b); return '#' + [0, 1, 2].map(function (i) { return ('0' + Math.round(x[i] + (y[i] - x[i]) * t).toString(16)).slice(-2); }).join(''); }
  function seamColor(P) { return mix(P.bg[0], P.bg[1], 0.55); }
  function rr(c, x, y, w, h, r) { r = Math.min(r, w / 2, h / 2); c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function lin(c, x, y, w, h, stops) { var g = c.createLinearGradient(0, y, 0, y + h); stops.forEach(function (s) { g.addColorStop(s[0], s[1]); }); c.fillStyle = g; c.fillRect(x, y, w, h); }
  // cover-draw with a vertical focus (0 = top, .5 = centre); zoom > 1 re-crops (used for the offer re-use of BG-A)
  function cover(c, img, x, y, w, h, fy, zoom, fx) {
    if (!img) return false;
    var iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height;
    var s = Math.max(w / iw, h / ih) * (zoom || 1), dw = iw * s, dh = ih * s;
    var ox = x + (w - dw) * (fx == null ? 0.5 : fx), oy = y + (h - dh) * (fy == null ? 0.5 : fy);
    c.save(); c.beginPath(); c.rect(x, y, w, h); c.clip(); c.drawImage(img, ox, oy, dw, dh); c.restore();
    return true;
  }

  // ---------- section base: seamless background + continuous pattern ----------
  function base(c, H, P, pageY) {
    var X = seamColor(P);
    lin(c, 0, 0, W, H, [[0, X], [Math.min(0.3, SEAM / H), P.bg[0]], [Math.max(0.7, 1 - SEAM / H), P.bg[1]], [1, X]]);
    pattern(c, H, P, pageY || 0);
  }
  // fade the top and bottom SEAM px to the shared seam colour (after photos are drawn)
  function seams(c, H, P) {
    var X = seamColor(P);
    lin(c, 0, 0, W, SEAM, [[0, X], [1, rgba(X, 0)]]);
    lin(c, 0, H - SEAM, W, SEAM, [[0, rgba(X, 0)], [1, X]]);
  }
  function rand(seed) { var x = Math.sin(seed * 9301 + 49297) * 233280; return x - Math.floor(x); }
  function pattern(c, H, P, pageY) {
    c.save();
    var k = P.pattern;
    if (k === 'honeycomb') {
      c.strokeStyle = rgba(P.accent, 0.07); c.lineWidth = 2;
      var r = 35, hw = Math.sqrt(3) * r, vh = 1.5 * r;
      var row0 = Math.floor(pageY / vh) - 1, rows = Math.ceil(H / vh) + 2;
      for (var ri = row0; ri < row0 + rows; ri++) {
        var y = ri * vh - pageY, off = (ri % 2 ? hw / 2 : 0);
        for (var x = -hw + off; x < W + hw; x += hw) hexPath(c, x, y, r, true);
      }
      sparkles(c, H, P, pageY, 25);
    } else if (k === 'rays') {
      c.globalAlpha = 0.05; c.fillStyle = P.accent;
      for (var i = -6; i < 14; i++) { var x0 = i * 160 - ((pageY * 0.3) % 160); c.beginPath(); c.moveTo(x0, 0); c.lineTo(x0 + 60, 0); c.lineTo(x0 + 60 + H * 0.5, H); c.lineTo(x0 + H * 0.5, H); c.closePath(); c.fill(); }
      c.globalAlpha = 1; sparkles(c, H, P, pageY, 18);
    } else if (k === 'leaves') {
      c.fillStyle = rgba(P.accent, 0.08);
      var start = Math.floor(pageY / 700) - 1;
      for (var n = start; n < start + Math.ceil(H / 700) + 2; n++) { var yy = n * 700 - pageY; leaf(c, 40, yy + 120, 150, -0.6); leaf(c, W - 40, yy + 470, 170, 2.5); }
    } else if (k === 'stripes') {
      c.strokeStyle = 'rgba(255,255,255,.06)'; c.lineWidth = 26;
      for (var s = -H; s < W + H; s += 90) { var sx = s - (pageY % 90); c.beginPath(); c.moveTo(sx, 0); c.lineTo(sx + H, H); c.stroke(); }
    } else if (k === 'bokeh') {
      dots(c, H, pageY, 14, function (x, y, rr2) { c.fillStyle = rgba(P.accent, 0.1); c.beginPath(); c.arc(x, y, 30 + rr2 * 70, 0, Math.PI * 2); c.fill(); });
    } else if (k === 'grid') {
      c.strokeStyle = rgba(P.accent, 0.08); c.lineWidth = 1.5;
      for (var gx = 0; gx <= W; gx += 60) { c.beginPath(); c.moveTo(gx, 0); c.lineTo(gx, H); c.stroke(); }
      for (var gy = -(pageY % 60); gy <= H; gy += 60) { c.beginPath(); c.moveTo(0, gy); c.lineTo(W, gy); c.stroke(); }
    } else if (k === 'confetti') {
      var cols = [P.accent, '#22C55E', '#3B82F6', '#EC4899', '#FACC15'];
      dots(c, H, pageY, 40, function (x, y, rr2, i) { c.fillStyle = rgba(cols[i % cols.length], 0.35); c.beginPath(); c.arc(x, y, 6 + rr2 * 8, 0, Math.PI * 2); c.fill(); });
    } else if (k === 'frame') {
      c.strokeStyle = rgba(P.text, 0.18); c.lineWidth = 2; c.strokeRect(36, -4, W - 72, H + 8);
    }
    c.restore();
  }
  // deterministic dots in page coordinates (continuous across sections)
  function dots(c, H, pageY, perBlock, draw) {
    var B = 900, b0 = Math.floor(pageY / B), b1 = Math.floor((pageY + H) / B);
    for (var b = b0; b <= b1; b++) for (var i = 0; i < perBlock; i++) {
      var x = rand(b * 131 + i * 7.13) * W, y = b * B + rand(b * 71 + i * 3.7) * B - pageY;
      if (y > -120 && y < H + 120) draw(x, y, rand(b * 17 + i), i);
    }
  }
  function sparkles(c, H, P, pageY, n) {
    dots(c, H, pageY, n, function (x, y, r) { var s = 3 + r * 6; c.fillStyle = rgba(P.accent, 0.35 + r * 0.4); c.beginPath(); c.moveTo(x, y - s * 2); c.lineTo(x + s * 0.5, y - s * 0.5); c.lineTo(x + s * 2, y); c.lineTo(x + s * 0.5, y + s * 0.5); c.lineTo(x, y + s * 2); c.lineTo(x - s * 0.5, y + s * 0.5); c.lineTo(x - s * 2, y); c.lineTo(x - s * 0.5, y - s * 0.5); c.closePath(); c.fill(); });
  }
  function hexPath(c, x, y, r, stroke) { c.beginPath(); for (var i = 0; i < 6; i++) { var a = Math.PI / 6 + i * Math.PI / 3; c[i ? 'lineTo' : 'moveTo'](x + r * Math.cos(a), y + r * Math.sin(a)); } c.closePath(); if (stroke) c.stroke(); }
  function leaf(c, x, y, s, rot) { c.save(); c.translate(x, y); c.rotate(rot); c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(s * 0.5, -s * 0.45, s, 0); c.quadraticCurveTo(s * 0.5, s * 0.45, 0, 0); c.fill(); c.restore(); }

  // ---------- text engine: bidi runs + fit-to-zone (never clipped) ----------
  var ARABIC = /[\u0600-\u06ff]/;
  function tokens(str, rtl) {
    var words = String(str || '').replace(/[\u2066-\u2069]/g, '').replace(/(\d)[\u202f ](?=\d{3}\b)/g, '$1\u00a0').trim().split(/[ \t\n]+/).filter(Boolean);
    if (!rtl) return words.map(function (w) { return { t: w, ltr: true }; });
    var out = [];
    words.forEach(function (w) {
      // split Arabic punctuation (؟ ، ؛) and !?.: off a Latin/number word so "Elina؟" stays LTR + "؟"
      var m = w.match(/^(.*?)([\u061f\u060c\u061b!?.,:]+)$/), core = m && m[1] ? m[1] : w, pun = m && m[1] ? m[2] : '';
      var prev = out.length && out[out.length - 1].ltr;
      var ltr = !ARABIC.test(core) && (/[A-Za-z0-9%]/.test(core) || (prev && /^[-\u2013\u2014\/+&\u00d7x.:]+$/.test(core)));
      if (ltr && prev) out[out.length - 1].t += ' ' + core; else out.push({ t: ltr ? core : w, ltr: ltr });
      if (ltr && pun) out.push({ t: pun, ltr: false, glue: true });
    });
    return out;
  }
  function fontStr(o, size) { return (o.weight || 800) + ' ' + size + 'px "' + o.font + '", Cairo, Tahoma, sans-serif'; }
  function tw(c, tk) { return c.measureText(tk.ltr ? '\u2066' + tk.t + '\u2069' : tk.t).width; }
  function wrap(c, toks, maxW, space) {
    var lines = [], cur = [], wsum = 0;
    toks.forEach(function (t) { var w = tw(c, t); var add = cur.length ? (t.glue ? 0 : space) + w : w; if (cur.length && !t.glue && wsum + add > maxW) { lines.push(cur); cur = [t]; wsum = w; } else { cur.push(t); wsum += add; } });
    if (cur.length) lines.push(cur);
    // balance: avoid a single short word alone on the last line
    if (lines.length > 1 && lines[lines.length - 1].length === 1 && lines[lines.length - 2].length > 2) { var mv = lines[lines.length - 2].pop(); lines[lines.length - 1].unshift(mv); }
    return lines;
  }
  // measure \u2192 wrap \u2264 maxLines \u2192 shrink by 2 px down to min. Returns layout; never truncates.
  function fit(c, str, o) {
    var toks = tokens(str, o.rtl), size = o.size, min = o.min || Math.round(o.size * 0.66), lines, maxW = o.maxW;
    for (; size >= min; size -= 2) {
      c.font = fontStr(o, size);
      lines = wrap(c, toks, maxW, c.measureText(' ').width);
      var widest = Math.max.apply(null, lines.map(function (ln) { return ln.reduce(function (a, t) { return a + tw(c, t); }, 0); }));
      if (lines.length <= (o.maxLines || 2) && widest <= maxW && lines.length * size * (o.lh || 1.22) <= (o.maxH || 1e9)) return { lines: lines, size: size, ok: true };
    }
    size = min; c.font = fontStr(o, size); lines = wrap(c, toks, maxW, c.measureText(' ').width);
    return { lines: lines, size: size, ok: false };
  }
  // draws text in a zone; o.align: center | start (start = right edge for RTL). Returns {h, ok}
  function textBox(c, str, o) {
    if (!str) return { h: 0, ok: true };
    var f = fit(c, str, o), lh = f.size * (o.lh || 1.22), hl = String(o.highlight || '').trim();
    c.font = fontStr(o, f.size); c.textBaseline = 'top'; c.direction = o.rtl ? 'rtl' : 'ltr';
    var space = c.measureText(' ').width, total = f.lines.length * lh, y0 = o.y + (o.vAlign === 'middle' && o.maxH ? Math.max(0, (o.maxH - total) / 2) : 0);
    f.lines.forEach(function (ln, i) {
      var y = y0 + i * lh, wsum = ln.reduce(function (a, t) { return a + tw(c, t); }, 0) + space * (ln.length - 1 - ln.filter(function (t, j) { return j && t.glue; }).length), x;
      var align = o.align || 'center';
      // x is the starting edge: right edge for RTL, left edge for LTR
      if (align === 'center') x = o.rtl ? o.cx + wsum / 2 : o.cx - wsum / 2;
      else x = o.rtl ? o.x + o.maxW : o.x;
      ln.forEach(function (t, j) {
        if (t.glue && j) x = o.rtl ? x + space : x - space; // punctuation sticks to the previous word
        var w = tw(c, t), clean = t.t.replace(/[\u061f?!.,\u060c:]/g, '');
        var isHl = hl && (clean === hl.replace(/[\u061f?!.,\u060c:]/g, '') || (t.ltr && t.t.split(' ').indexOf(hl) >= 0));
        if (o.shadow) { c.shadowColor = 'rgba(0,0,0,.5)'; c.shadowBlur = 16; c.shadowOffsetY = 3; }
        c.fillStyle = isHl ? o.hlColor : o.color; c.textAlign = o.rtl ? 'right' : 'left';
        c.fillText(t.ltr && o.rtl ? '\u2066' + t.t + '\u2069' : t.t, x, y);
        c.shadowColor = 'transparent'; c.shadowBlur = 0; c.shadowOffsetY = 0;
        x = o.rtl ? x - w - space : x + w + space;
      });
    });
    return { h: total, ok: f.ok, size: f.size };
  }
  function fmt(n) { return '\u2066' + String(Math.round(n || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, '\u202f') + '\u2069'; }

  // ---------- icons ----------
  function check(c, x, y, r, color) { c.strokeStyle = color; c.lineWidth = r * 0.24; c.lineCap = 'round'; c.lineJoin = 'round'; c.beginPath(); c.moveTo(x - r * 0.42, y + r * 0.02); c.lineTo(x - r * 0.1, y + r * 0.34); c.lineTo(x + r * 0.45, y - r * 0.3); c.stroke(); }
  function icon(c, P, x, y, r) {
    c.save();
    if (P.icon === 'hex') { c.fillStyle = P.accent; hexPath(c, x, y, r * 1.08); c.fill(); check(c, x, y, r, '#1A1206'); }
    else if (P.icon === 'square') { rr(c, x - r, y - r, r * 2, r * 2, r * 0.45); c.fillStyle = P.accent; c.fill(); check(c, x, y, r, '#06142B'); }
    else if (P.icon === 'diamond') { c.fillStyle = P.accent; c.beginPath(); c.moveTo(x, y - r * 0.7); c.lineTo(x + r * 0.7, y); c.lineTo(x, y + r * 0.7); c.lineTo(x - r * 0.7, y); c.closePath(); c.fill(); }
    else { c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fillStyle = P.accent; c.fill(); check(c, x, y, r, P.dark ? '#111' : '#fff'); }
    c.restore();
  }
  // simple line glyphs for the guarantee strip
  function glyph(c, kind, x, y, s, color) {
    c.save(); c.strokeStyle = color; c.fillStyle = color; c.lineWidth = s * 0.09; c.lineJoin = 'round'; c.lineCap = 'round';
    if (kind === 'cash') { rr(c, x - s * 0.5, y - s * 0.3, s, s * 0.6, s * 0.08); c.stroke(); c.beginPath(); c.arc(x, y, s * 0.14, 0, Math.PI * 2); c.stroke(); }
    else if (kind === 'truck') { c.strokeRect(x - s * 0.5, y - s * 0.25, s * 0.6, s * 0.4); c.beginPath(); c.moveTo(x + s * 0.1, y - s * 0.1); c.lineTo(x + s * 0.35, y - s * 0.1); c.lineTo(x + s * 0.5, y + s * 0.05); c.lineTo(x + s * 0.5, y + s * 0.15); c.lineTo(x + s * 0.1, y + s * 0.15); c.stroke(); c.beginPath(); c.arc(x - s * 0.3, y + s * 0.22, s * 0.09, 0, Math.PI * 2); c.arc(x + s * 0.3, y + s * 0.22, s * 0.09, 0, Math.PI * 2); c.fill(); }
    else if (kind === 'phone') { rr(c, x - s * 0.22, y - s * 0.42, s * 0.44, s * 0.84, s * 0.1); c.stroke(); c.beginPath(); c.arc(x, y + s * 0.3, s * 0.04, 0, Math.PI * 2); c.fill(); }
    else { c.beginPath(); c.arc(x, y, s * 0.36, 0.3, Math.PI * 1.7); c.stroke(); c.beginPath(); c.moveTo(x + s * 0.36 * Math.cos(0.3) + s * 0.12, y + s * 0.36 * Math.sin(0.3) - s * 0.02); c.lineTo(x + s * 0.36 * Math.cos(0.3), y + s * 0.36 * Math.sin(0.3)); c.lineTo(x + s * 0.36 * Math.cos(0.3) - s * 0.02, y + s * 0.36 * Math.sin(0.3) - s * 0.14); c.stroke(); }
    c.restore();
  }

  // ---------- product placement (C.4) ----------
  // zone {x,y,w,h}; factor = share of zone height; base on the surface line at 78% of the zone
  function place(c, k, zone, factor, opts) {
    opts = opts || {}; var P = k.P;
    var img = k.cut, cx = zone.x + zone.w / 2, baseY = opts.baseY || (zone.y + zone.h * 0.78);
    if (!img) return photoFrame(c, k, zone);
    var iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height;
    var h = zone.h * factor, w = iw * (h / ih), maxW = Math.min(W * 0.7, zone.w * 0.95);
    if (w > maxW) { w = maxW; h = ih * (w / iw); }
    var x = cx - w / 2, y = baseY - h;
    c.save();
    if (P.glow && opts.glow !== false) {
      var R = Math.max(w, h) * 0.85, g = c.createRadialGradient(cx, y + h * 0.5, R * 0.05, cx, y + h * 0.5, R);
      g.addColorStop(0, rgba(P.accent, 0.5)); g.addColorStop(0.5, rgba(P.accent, 0.16)); g.addColorStop(1, rgba(P.accent, 0)); c.fillStyle = g; c.fillRect(cx - R, y + h * 0.5 - R, R * 2, R * 2);
      if (P.rays) { c.save(); c.translate(cx, y + h * 0.5); c.globalAlpha = 0.12; c.fillStyle = P.accent; for (var i = 0; i < 16; i++) { c.rotate(Math.PI / 8); c.beginPath(); c.moveTo(0, 0); c.lineTo(R * 1.2, -R * 0.06); c.lineTo(R * 1.2, R * 0.06); c.closePath(); c.fill(); } c.restore(); }
    }
    if (P.burst && opts.glow !== false) { c.save(); c.translate(cx, y + h * 0.5); c.fillStyle = rgba(P.accent, 0.9); c.beginPath(); var n = 22, R1 = Math.max(w, h) * 0.62, R0 = R1 * 0.82; for (var j = 0; j < n * 2; j++) { var a = j * Math.PI / n, rr2 = j % 2 ? R0 : R1; c[j ? 'lineTo' : 'moveTo'](Math.cos(a) * rr2, Math.sin(a) * rr2); } c.closePath(); c.fill(); c.restore(); }
    // contact shadow: ellipse 60% of product width, black 35%, blur 18
    c.save(); c.filter = 'blur(18px)'; c.fillStyle = 'rgba(0,0,0,.35)'; c.beginPath(); c.ellipse(cx, baseY - 2, w * 0.3, Math.max(10, w * 0.06), 0, 0, Math.PI * 2); c.fill(); c.restore();
    c.shadowColor = 'rgba(0,0,0,.35)'; c.shadowBlur = 34; c.shadowOffsetY = 14;
    c.drawImage(img, x, y, w, h);
    c.restore();
    return { x: x, y: y, w: w, h: h };
  }
  // fallback when no cut-out (or fashion photo mode): seller photo in a rounded frame matching the preset
  function photoFrame(c, k, zone, img, fy) {
    img = img || k.photo; var P = k.P; if (!img) return null;
    c.save(); c.shadowColor = P.dark ? 'rgba(0,0,0,.55)' : 'rgba(60,40,20,.22)'; c.shadowBlur = 40; c.shadowOffsetY = 16;
    rr(c, zone.x, zone.y, zone.w, zone.h, 32); c.fillStyle = P.dark ? mix(P.bg[0], P.accent, 0.25) : '#FFFFFF'; c.fill(); c.restore();
    c.save(); rr(c, zone.x + 8, zone.y + 8, zone.w - 16, zone.h - 16, 26); c.clip(); cover(c, img, zone.x + 8, zone.y + 8, zone.w - 16, zone.h - 16, fy == null ? 0.3 : fy); c.restore();
    if (P.pattern === 'frame') { c.save(); c.strokeStyle = rgba(P.gold || P.accent, 0.9); c.lineWidth = 2; rr(c, zone.x - 10, zone.y - 10, zone.w + 20, zone.h + 20, 38); c.stroke(); c.restore(); }
    return zone;
  }
  function chip(c, k, str, cx, y, o) {
    o = o || {}; var P = k.P, size = o.size || 34;
    c.font = fontStr({ font: P.font, weight: 800 }, size); c.direction = k.rtl ? 'rtl' : 'ltr';
    var label = /[A-Za-z0-9]/.test(str) && k.rtl && ARABIC.test(str) ? str : str;
    var w = Math.min(o.maxW || 900, c.measureText(label).width + 64), h = size * 1.8;
    while (c.measureText(label).width + 64 > w && size > 24) { size -= 2; c.font = fontStr({ font: P.font, weight: 800 }, size); }
    rr(c, cx - w / 2, y, w, h, h / 2); c.fillStyle = o.bg || P.accent; c.fill();
    if (o.stroke) { c.strokeStyle = o.stroke; c.lineWidth = 2; c.stroke(); }
    c.fillStyle = o.color || (P.dark ? '#111' : '#fff'); c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(label, cx, y + h / 2 + 2);
    return { w: w, h: h };
  }
  function chipRow(c, k, items, y, o) {
    o = o || {}; var size = o.size || 34, gap = 18, P = k.P;
    c.font = fontStr({ font: P.font, weight: 800 }, size);
    var ws = items.map(function (s) { return c.measureText(s).width + 64; }), total = ws.reduce(function (a, b) { return a + b; }, 0) + gap * (items.length - 1);
    var x = k.rtl ? W / 2 + total / 2 : W / 2 - total / 2;
    items.forEach(function (s, i) { var cx = k.rtl ? x - ws[i] / 2 : x + ws[i] / 2; chip(c, k, s, cx, y, { bg: o.bgs ? o.bgs[i] : undefined, color: o.colors ? o.colors[i] : undefined, size: size }); x = k.rtl ? x - ws[i] - gap : x + ws[i] + gap; });
  }
  // bullets in one column inside a box; spreads them to fill the height; returns overflow flag
  function bulletCol(c, k, items, box, o) {
    o = o || {}; var P = k.P, n = Math.max(1, items.length), slot = box.h / n, ok = true, r = o.icon || 22;
    items.forEach(function (b, i) {
      var y = box.y + i * slot, tx = k.rtl ? box.x : box.x + r * 2 + 18, tWidth = box.w - r * 2 - 18;
      var f = fit(c, b, { font: P.font, weight: 700, size: o.size || 40, min: o.min || 30, maxLines: 2, maxW: tWidth, rtl: k.rtl });
      var th = f.lines.length * f.size * 1.22, ty = y + (slot - th) / 2;
      icon(c, P, k.rtl ? box.x + box.w - r : box.x + r, ty + f.size * 0.62, r);
      var res = textBox(c, b, { x: tx, y: ty, maxW: tWidth, size: f.size, min: f.size, font: P.font, weight: 700, color: o.color || P.text, rtl: k.rtl, align: 'start', maxLines: 2 });
      if (!res.ok) ok = false;
    });
    return ok;
  }
  function title(c, k, p, y, o) {
    o = o || {}; var P = k.P;
    return textBox(c, p.title, { cx: W / 2, x: 70, y: y, maxW: o.maxW || W - 140, maxH: o.maxH, vAlign: 'middle', size: o.size || 80, min: o.min || 56, maxLines: 2, font: P.font, weight: P.tw, color: o.color || P.text, hlColor: o.hl || (P.gold || P.accent), highlight: p.highlight, rtl: k.rtl, shadow: o.shadow });
  }

  // ---------- blueprints ----------
  var B = {};
  B.hook = function (c, p, k) {
    var H = 1350, P = k.P, of = [];
    base(c, H, P, k.pageY);
    if (k.bgA) {
      cover(c, k.bgA, 0, 0, W, H, 0.55);
      if (P.dark) { lin(c, 0, 0, W, 560, [[0, 'rgba(0,0,0,.82)'], [0.75, 'rgba(0,0,0,.35)'], [1, 'rgba(0,0,0,0)']]); lin(c, 0, H - 320, W, 320, [[0, 'rgba(0,0,0,0)'], [1, 'rgba(0,0,0,.55)']]); }
      else { lin(c, 0, 0, W, 560, [[0, 'rgba(255,255,255,.9)'], [0.75, 'rgba(255,255,255,.45)'], [1, 'rgba(255,255,255,0)']]); }
      pattern(c, H, P, k.pageY);
    }
    if (k.photoMode && k.photo) photoFrame(c, k, { x: 150, y: 500, w: 780, h: 660 }, k.photo, 0.25);
    else place(c, k, { x: 0, y: 520, w: W, h: 630 }, 0.48, {});
    if (k.hasOffer) chip(c, k, k.t.special, k.rtl ? 150 : W - 150, 30, { size: 30 });
    if (!title(c, k, p, 90, { size: 96, min: 64, maxH: 290, shadow: P.dark }).ok) of.push('title');
    if (p.subtitle && !textBox(c, p.subtitle, { cx: W / 2, x: 80, y: 390, maxW: W - 160, maxH: 80, size: 44, min: 32, maxLines: 1, font: P.font, weight: 700, color: P.text2, rtl: k.rtl, shadow: P.dark }).ok) of.push('subtitle');
    chipRow(c, k, [k.t.cod, k.t.deliv], 1205, { size: 32, bgs: [P.dark ? 'rgba(255,255,255,.95)' : P.text, P.gold || P.accent], colors: [P.dark ? P.bg[0] : '#fff', P.dark ? '#111' : '#fff'] });
    seams(c, H, P);
    return of;
  };
  B.features = function (c, p, k) {
    var H = 1200, P = k.P, of = [];
    base(c, H, P, k.pageY);
    if (k.bgA) { c.save(); c.globalAlpha = P.dark ? 0.35 : 0.22; cover(c, k.bgA, 0, 0, W, H, 0.8, 1.15, k.rtl ? 0.2 : 0.8); c.restore(); lin(c, 0, 0, W, H, [[0, rgba(P.bg[0], 0.55)], [1, rgba(P.bg[1], 0.55)]]); pattern(c, H, P, k.pageY); }
    if (!title(c, k, p, 70, { size: 76, min: 54, maxH: 160 }).ok) of.push('title');
    var prodZone = k.rtl ? { x: 560, y: 260, w: 460, h: 920 } : { x: 60, y: 260, w: 460, h: 920 };
    if (k.photoMode && k.photo) photoFrame(c, k, { x: prodZone.x, y: 300, w: 440, h: 640 }, k.photo, 0.3);
    else place(c, k, prodZone, 0.4, { baseY: 980 });
    var box = k.rtl ? { x: 60, y: 280, w: 480, h: 820 } : { x: 540, y: 280, w: 480, h: 820 };
    if (!bulletCol(c, k, (p.bullets || []).slice(0, 6), box, { size: 40, min: 30, icon: 22 })) of.push('bullets');
    seams(c, H, P);
    return of;
  };
  B.inside = B.features;
  B.details = function (c, p, k) {
    var H = 1200, P = k.P, of = [];
    base(c, H, P, k.pageY);
    if (!title(c, k, p, 70, { size: 76, min: 54, maxH: 160 }).ok) of.push('title');
    var ph = k.photos && k.photos.length ? k.photos : [k.photo];
    if (k.photoMode && ph[0]) {
      photoFrame(c, k, { x: k.rtl ? 470 : 70, y: 270, w: 540, h: 560 }, ph[0], 0.3);
      photoFrame(c, k, { x: k.rtl ? 70 : 640, y: 270, w: 370, h: 270 }, ph[1 % ph.length], 0.3);
      photoFrame(c, k, { x: k.rtl ? 70 : 640, y: 560, w: 370, h: 270 }, ph[2 % ph.length], 0.6);
      if (!bulletCol(c, k, (p.bullets || []).slice(0, 3), { x: 90, y: 870, w: W - 180, h: 270 }, { size: 38, min: 28, icon: 18 })) of.push('bullets');
    } else {
      place(c, k, { x: k.rtl ? 560 : 60, y: 260, w: 460, h: 900 }, 0.5, { baseY: 980 });
      if (!bulletCol(c, k, (p.bullets || []).slice(0, 6), k.rtl ? { x: 60, y: 280, w: 480, h: 820 } : { x: 540, y: 280, w: 480, h: 820 }, { size: 40, min: 30, icon: 22 })) of.push('bullets');
    }
    seams(c, H, P);
    return of;
  };
  B['case'] = function (c, p, k) {
    var H = 1150, P = k.P, of = [];
    base(c, H, P, k.pageY);
    if (!title(c, k, p, 60, { size: 74, min: 52, maxH: 150 }).ok) of.push('title');
    var fr = { x: 60, y: 230, w: W - 120, h: 590 };
    var img = k.life || (k.photoMode ? k.photo : null);
    if (img) photoFrame(c, k, fr, img, 0.3);
    else place(c, k, { x: 0, y: 230, w: W, h: 590 }, 0.62, { baseY: 790 });
    if (!bulletCol(c, k, (p.bullets || []).slice(0, 3), { x: 110, y: 850, w: W - 220, h: 260 }, { size: 40, min: 30, icon: 22 })) of.push('bullets');
    seams(c, H, P);
    return of;
  };
  B.how_to = function (c, p, k) {
    var H = 1000, P = k.P, of = [];
    base(c, H, P, k.pageY);
    if (!title(c, k, p, 50, { size: 72, min: 50, maxH: 140 }).ok) of.push('title');
    if (k.photoMode && k.photo) photoFrame(c, k, { x: W / 2 - 150, y: 200, w: 300, h: 320 }, k.photo, 0.3);
    else place(c, k, { x: W / 2 - 300, y: 200, w: 600, h: 360 }, 300 / 360, { baseY: 510 });
    var steps = (p.steps || []).slice(0, 3), y0 = 560, slot = 130;
    steps.forEach(function (s, i) {
      var y = y0 + i * slot;
      c.save(); rr(c, 70, y, W - 140, 110, 30); c.fillStyle = P.dark ? 'rgba(255,255,255,.07)' : 'rgba(255,255,255,.75)'; c.fill(); c.restore();
      var nx = k.rtl ? W - 130 : 130; c.beginPath(); c.arc(nx, y + 55, 34, 0, Math.PI * 2); c.fillStyle = P.gold || P.accent; c.fill();
      c.font = fontStr({ font: P.font, weight: 800 }, 40); c.fillStyle = P.dark ? '#111' : '#fff'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(String(i + 1), nx, y + 57);
      var r = textBox(c, s, { x: k.rtl ? 110 : 190, y: y + 14, maxW: W - 300, maxH: 82, vAlign: 'middle', size: 40, min: 28, maxLines: 2, font: P.font, weight: 700, color: P.text, rtl: k.rtl, align: 'start' });
      if (!r.ok) of.push('steps');
    });
    seams(c, H, P);
    return of;
  };
  B.guarantee_strip = function (c, p, k) {
    var H = 260, P = k.P;
    base(c, H, P, k.pageY);
    c.save(); rr(c, 40, 40, W - 80, H - 80, 36); c.fillStyle = P.dark ? 'rgba(255,255,255,.06)' : 'rgba(255,255,255,.7)'; c.fill(); c.strokeStyle = rgba(P.gold || P.accent, 0.4); c.lineWidth = 2; c.stroke(); c.restore();
    var kinds = ['cash', 'truck', 'phone', 'swap'], labels = k.t.strip, cw = (W - 80) / 4;
    labels.forEach(function (lb, i) {
      var idx = k.rtl ? i : i, cx = k.rtl ? W - 40 - cw * idx - cw / 2 : 40 + cw * idx + cw / 2;
      c.beginPath(); c.arc(cx, 102, 34, 0, Math.PI * 2); c.fillStyle = rgba(P.gold || P.accent, P.dark ? 0.18 : 0.14); c.fill();
      glyph(c, kinds[i], cx, 102, 40, P.gold || P.accent);
      textBox(c, lb, { cx: cx, x: cx - cw / 2 + 8, y: 148, maxW: cw - 16, size: 26, min: 20, maxLines: 2, font: P.font, weight: 800, color: P.text, rtl: k.rtl });
    });
    return [];
  };
  B.trust = function (c, p, k) {
    var H = 1000, P = k.P, of = [];
    base(c, H, P, k.pageY);
    if (!title(c, k, p, 60, { size: 72, min: 50, maxH: 150 }).ok) of.push('title');
    var tiles = [k.t.cod, k.t.deliv, k.t.call, k.t.exch], kinds = ['cash', 'truck', 'phone', 'swap'];
    tiles.forEach(function (s, i) {
      var col = i % 2, row = Math.floor(i / 2), x = 80 + col * 470, y = 260 + row * 340;
      c.save(); rr(c, x, y, 450, 300, 36); c.fillStyle = P.dark ? 'rgba(255,255,255,.07)' : 'rgba(255,255,255,.8)'; c.fill(); c.restore();
      glyph(c, kinds[i], x + 225, y + 95, 70, P.gold || P.accent);
      textBox(c, s, { cx: x + 225, x: x + 20, y: y + 170, maxW: 410, size: 38, min: 28, maxLines: 2, font: P.font, weight: 800, color: P.text, rtl: k.rtl });
    });
    seams(c, H, P);
    return of;
  };
  B.problem = function (c, p, k) {
    var H = 1100, P = k.P, of = [];
    base(c, H, P, k.pageY);
    if (!title(c, k, p, 70, { size: 76, min: 54, maxH: 170 }).ok) of.push('title');
    var chips = (p.chips && p.chips.length ? p.chips : p.bullets || []).slice(0, 4);
    var rows = [chips.slice(0, 2), chips.slice(2, 4)].filter(function (r) { return r.length; });
    rows.forEach(function (r, i) { chipRow(c, k, r, 290 + i * 100, { size: 34, bgs: r.map(function () { return P.dark ? 'rgba(255,255,255,.1)' : '#fff'; }), colors: r.map(function () { return P.text; }) }); });
    var ph = (k.photos || []).slice(0, 4);
    if (ph.length >= 2) ph.slice(0, 4).forEach(function (u, i) { var col = i % 2, row = Math.floor(i / 2); photoFrame(c, k, { x: 90 + col * 460, y: 520 + row * 280, w: 440, h: 260 }, u, 0.4); });
    else place(c, k, { x: 0, y: 500, w: W, h: 560 }, 0.6, { baseY: 1010 });
    seams(c, H, P);
    return of;
  };
  B.pain_chips = B.problem;
  B.bundle = function (c, p, k) {
    var H = 1100, P = k.P, of = [];
    base(c, H, P, k.pageY);
    var b = (k.offers || []).filter(function (o) { return o.qty >= 2; }).sort(function (a, b2) { return a.qty - b2.qty; })[0];
    var n = b ? Math.min(3, b.qty) : 2;
    if (!title(c, k, p.title ? p : { title: k.t.buy2.replace('{n}', b ? b.qty : 2).replace('{s}', b ? fmt(b.qty * k.price - b.price) : ''), highlight: '' }, 70, { size: 76, min: 54, maxH: 170 }).ok) of.push('title');
    var zw = W / n;
    for (var i = 0; i < n; i++) place(c, k, { x: i * zw, y: 300, w: zw, h: 520 }, 0.8, { baseY: 780, glow: i === Math.floor(n / 2) });
    if (b) {
      c.save(); rr(c, 140, 840, W - 280, 200, 40); c.fillStyle = P.dark ? 'rgba(255,255,255,.95)' : '#fff'; c.fill(); c.restore();
      textBox(c, k.t.bundle.replace('{n}', b.qty).replace('{p}', fmt(b.price)), { cx: W / 2, x: 160, y: 880, maxW: W - 320, size: 64, min: 40, maxLines: 1, font: P.font, weight: 900, color: P.dark ? P.bg[0] : P.text, rtl: k.rtl });
      var save = b.qty * k.price - b.price;
      if (save > 0) textBox(c, k.t.buy2.replace('{n}', b.qty).replace('{s}', fmt(save)), { cx: W / 2, x: 160, y: 965, maxW: W - 320, size: 36, min: 28, maxLines: 1, font: P.font, weight: 800, color: P.dark ? '#B45309' : P.accent, rtl: k.rtl });
    }
    seams(c, H, P);
    return of;
  };
  B.offer = function (c, p, k) {
    var H = 1350, P = k.P, of = [];
    base(c, H, P, k.pageY);
    if (k.bgA) { cover(c, k.bgA, 0, 0, W, H, 0.7, 1.25, 0.5); c.fillStyle = P.dark ? 'rgba(0,0,0,.6)' : 'rgba(255,255,255,.62)'; c.fillRect(0, 0, W, H); pattern(c, H, P, k.pageY); }
    if (k.hasOffer && !/\u0639\u0631\u0636|offre/i.test(p.title)) chip(c, k, k.t.special, W / 2, 40, { size: 32 });
    if (!title(c, k, p, 110, { size: 84, min: 58, maxH: 200, shadow: P.dark }).ok) of.push('title');
    if (k.photoMode && k.photo) photoFrame(c, k, { x: W / 2 - 230, y: 330, w: 460, h: 440 }, k.photo, 0.25);
    else place(c, k, { x: 0, y: 330, w: W, h: 460 }, 0.8, { baseY: 770 });
    var py = 800, hasOld = k.oldPrice > k.price;
    // dark presets: dark glass card so the price can be the pure accent colour (spec C.3)
    c.save(); rr(c, 110, py, W - 220, 290, 44); c.fillStyle = P.dark ? 'rgba(0,0,0,.55)' : '#FFFFFF'; c.shadowColor = 'rgba(0,0,0,.25)'; c.shadowBlur = 30; c.fill(); c.restore();
    if (P.dark) { c.save(); rr(c, 110, py, W - 220, 290, 44); c.lineWidth = 3; c.strokeStyle = rgba(P.gold || P.accent, 0.85); c.stroke(); c.restore(); }
    var cur = ' ' + k.t.cur, y = py + 26;
    c.textAlign = 'center'; c.textBaseline = 'top'; c.direction = k.rtl ? 'rtl' : 'ltr';
    if (hasOld) { c.font = fontStr({ font: P.font, weight: 700 }, 50); c.fillStyle = '#9AA0A6'; var os = fmt(k.oldPrice) + cur; c.fillText(os, W / 2, y); var ow = c.measureText(os).width; c.fillStyle = '#D93025'; c.fillRect(W / 2 - ow / 2 - 8, y + 30, ow + 16, 5); y += 66; } else y += 18;
    c.font = fontStr({ font: P.font, weight: 900 }, 120); c.fillStyle = P.dark ? (P.gold || P.accent) : (P.pattern === 'frame' ? '#111' : mix(P.accent, '#000', 0.1)); c.fillText(fmt(k.price) + cur, W / 2, y);
    var b = (k.offers || []).filter(function (o) { return o.qty === 2; })[0];
    if (b) textBox(c, k.t.bundle.replace('{n}', 2).replace('{p}', fmt(b.price)), { cx: W / 2, x: 140, y: py + 220, maxW: W - 280, size: 38, min: 28, maxLines: 1, font: P.font, weight: 800, color: P.dark ? P.text2 : '#333', rtl: k.rtl });
    c.save(); rr(c, 200, 1125, W - 400, 110, 55); c.fillStyle = P.gold || P.accent; c.shadowColor = rgba(P.gold || P.accent, 0.5); c.shadowBlur = 30; c.fill(); c.restore();
    textBox(c, k.t.order, { cx: W / 2, x: 220, y: 1148, maxW: W - 440, size: 52, min: 38, maxLines: 1, font: P.font, weight: 900, color: P.pattern === 'frame' ? '#fff' : (P.dark ? '#111' : '#fff'), rtl: k.rtl });
    textBox(c, k.t.footer, { cx: W / 2, x: 60, y: 1262, maxW: W - 120, size: 32, min: 24, maxLines: 1, font: P.font, weight: 700, color: P.text2, rtl: k.rtl });
    seams(c, H, P);
    return of;
  };
  B.cta = B.offer;
  B.look = function (c, p, k) {
    var H = 1350, P = k.P, of = [];
    base(c, H, P, k.pageY);
    if (!title(c, k, p, 70, { size: 80, min: 56, maxH: 180 }).ok) of.push('title');
    if (p.subtitle && !textBox(c, p.subtitle, { cx: W / 2, x: 90, y: 260, maxW: W - 180, size: 40, min: 30, maxLines: 2, font: P.font, weight: 600, color: P.text2, rtl: k.rtl }).ok) of.push('subtitle');
    if (k.photo) photoFrame(c, k, { x: 120, y: 380, w: W - 240, h: 900 }, k.photo, 0.2); else place(c, k, { x: 0, y: 380, w: W, h: 900 }, 0.8, { baseY: 1240 });
    seams(c, H, P);
    return of;
  };
  B.sizes = function (c, p, k) {
    var H = 1000, P = k.P, of = [];
    base(c, H, P, k.pageY);
    if (k.photo) photoFrame(c, k, { x: k.rtl ? 60 : W - 460, y: 120, w: 400, h: 760 }, k.photo, 0.25);
    var tx = k.rtl ? 500 : 80, tw2 = 500;
    if (!textBox(c, p.title, { cx: tx + tw2 / 2, x: tx, y: 140, maxW: tw2, maxH: 200, vAlign: 'middle', size: 66, min: 46, maxLines: 2, font: P.font, weight: P.tw, color: P.text, hlColor: P.gold || P.accent, highlight: p.highlight, rtl: k.rtl }).ok) of.push('title');
    textBox(c, k.t.sizesLbl, { cx: tx + tw2 / 2, x: tx, y: 370, maxW: tw2, size: 34, min: 26, maxLines: 1, font: P.font, weight: 700, color: P.text2, rtl: k.rtl });
    // Latin-only, LTR, centred equal chips that wrap to new rows
    var items = (p.bullets || []).map(function (s) { var m = String(s).match(/[A-Za-z0-9][A-Za-z0-9\/\-+ ]*/g); return m ? m.join(' ').trim() : ''; }).filter(Boolean).slice(0, 8);
    if (!items.length) items = ['S', 'M', 'L', 'XL'];
    c.font = fontStr({ font: 'Cairo', weight: 800 }, 40);
    var cw = Math.max(110, Math.max.apply(null, items.map(function (s) { return c.measureText(s).width + 50; }))), gap = 18, perRow = Math.max(1, Math.floor((tw2 + gap) / (cw + gap)));
    items.forEach(function (s, i) {
      var row = Math.floor(i / perRow), col = i % perRow, inRow = Math.min(perRow, items.length - row * perRow), rowW = inRow * cw + (inRow - 1) * gap;
      var x = tx + (tw2 - rowW) / 2 + col * (cw + gap), y = 440 + row * 100;
      rr(c, x, y, cw, 80, 40); c.fillStyle = i === 1 ? (P.text) : '#fff'; c.fill(); c.strokeStyle = P.text; c.lineWidth = 2.5; c.stroke();
      c.fillStyle = i === 1 ? '#fff' : P.text; c.textAlign = 'center'; c.textBaseline = 'middle'; c.direction = 'ltr'; c.font = fontStr({ font: 'Cairo', weight: 800 }, 40); c.fillText(s, x + cw / 2, y + 42);
    });
    seams(c, H, P);
    return of;
  };
  B.before_after = function (c, p, k) {
    var H = 1200, P = k.P, of = [];
    base(c, H, P, k.pageY);
    if (!title(c, k, p, 50, { size: 70, min: 50, maxH: 150 }).ok) of.push('title');
    var half = (W - 150) / 2, top = 230, ih = 560;
    photoFrame(c, k, { x: 60, y: top, w: half, h: ih }, k.scene || k.photo, 0.4);
    photoFrame(c, k, { x: 90 + half, y: top, w: half, h: ih }, k.scene2 || k.photo, 0.4);
    chip(c, k, k.t.before, 60 + half / 2, top + 20, { bg: '#D93025', color: '#fff', size: 34 });
    chip(c, k, k.t.after, 90 + half * 1.5, top + 20, { bg: '#16A34A', color: '#fff', size: 34 });
    if (!bulletCol(c, k, (p.after_points || p.bullets || []).slice(0, 3), { x: 110, y: 830, w: W - 220, h: 320 }, { size: 38, min: 28 })) of.push('bullets');
    seams(c, H, P);
    return of;
  };

  // ---------- render ----------
  function render(panel, o) {
    var P = PRESETS[o.style] || PRESETS.fresh_clean, type = B[panel.type] ? panel.type : 'features';
    var photoMode = !!panel._photoMode || !!o.photoMode;
    return Promise.all([ensureFont(P.font), ensureFont('Cairo'), loadImg(o.cutout), loadImg(photoMode ? (panel.scene || o.photo) : o.photo), loadImg(o.bgA), loadImg(panel.type === 'case' ? (o.life || panel.life) : ''), loadImg(panel.scene), loadImg(panel.scene2)].concat((o.photos || []).slice(0, 4).map(loadImg))).then(function (r) {
      var H = HEIGHTS[type] || 1080, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
      var c = cv.getContext('2d'), lang = o.lang || 'dz';
      var k = { P: P, t: L[lang] || L.dz, rtl: lang !== 'fr', cut: photoMode ? null : r[2], photo: r[3], bgA: photoMode ? null : r[4], life: r[5], scene: r[6], scene2: r[7], photos: r.slice(8).filter(Boolean),
        price: o.price || 0, oldPrice: o.oldPrice || 0, offers: o.offers || [], pageY: o.pageY || 0, photoMode: photoMode, hasOffer: !!o.hasOffer };
      if (!k.photos.length && k.photo) k.photos = [k.photo];
      var p = { title: panel.title || '', highlight: panel.highlight || '', subtitle: panel.subtitle || '', bullets: panel.bullets || [], steps: panel.steps || [], chips: panel.chips || [], before_points: panel.before_points || [], after_points: panel.after_points || [] };
      var overflow = B[type](c, p, k) || [];
      var url = cv.toDataURL('image/webp', 0.82);
      if (url.indexOf('data:image/webp') !== 0) url = cv.toDataURL('image/jpeg', 0.85);
      return { url: url, h: H, overflow: overflow };
    });
  }
  function pageLayout(panels) { var y = 0; return panels.map(function (p) { var top = y; y += HEIGHTS[p.type] || 1080; return top; }); }
  // stack rendered section images into one tall image (for ads / WhatsApp)
  function stack(urls, width) {
    width = width || 1080;
    return Promise.all(urls.map(loadImg)).then(function (imgs) {
      imgs = imgs.filter(Boolean); var s = width / 1080, H = imgs.reduce(function (a, i) { return a + (i.naturalHeight || i.height) * s; }, 0);
      var cv = document.createElement('canvas'); cv.width = width; cv.height = Math.round(H); var c = cv.getContext('2d'), y = 0;
      imgs.forEach(function (i) { var h = (i.naturalHeight || i.height) * s; c.drawImage(i, 0, y, width, h); y += h; });
      return new Promise(function (res) { cv.toBlob(res, 'image/jpeg', 0.86); });
    });
  }
  window.Panels3 = { render: render, presets: PRESETS, heights: HEIGHTS, pageLayout: pageLayout, stack: stack, seamColor: function (k) { return seamColor(PRESETS[k] || PRESETS.fresh_clean); } };
})();
