'use strict';
const { D, prime, getSetting, productRow, landingRow, storeBySlug } = require('./db');
const U = require('./util');
const V = require('./views');
const O = require('./orders');
const geo = require('./geo');
const PF = require('./platform');

const BOT = /bot|crawl|spider|facebookexternalhit|preview|slurp|bingpreview|headless/i;

async function liveProducts(sid) {
  return (await D.all('SELECT * FROM products WHERE store_id = ? AND live = 1 ORDER BY sort, id DESC', sid)).map(productRow);
}

// Which store does this request belong to?
//  1) subdomain:  <slug>.<baseDomain>
//  2) path:       /s/<slug>/...
//  3) legacy root /l/… /p/… → the platform's first store (keeps old ad links working)
async function resolve(req, url) {
  const P = getSetting('platform');
  const host = String(req.headers.host || '').toLowerCase().replace(/:\d+$/, '');
  const base = String(P.baseDomain || '').toLowerCase().replace(/^\.+|\/.*$/g, '');
  if (base && host.endsWith('.' + base)) {
    const sub = host.slice(0, -(base.length + 1));
    if (sub && sub !== 'www' && sub !== 'app' && !sub.includes('.')) return { store: await storeBySlug(sub), base: '', path: url.pathname, slug: sub };
  }
  const m = url.pathname.match(/^\/s\/([a-z0-9-]{2,40})(\/.*)?$/);
  if (m) return { store: await storeBySlug(m[1]), base: '/s/' + m[1], path: m[2] || '/', slug: m[1] };
  if (/^\/(l|p)\/|^\/api\/(order|abandoned)/.test(url.pathname)) {
    const first = await D.get('SELECT * FROM stores ORDER BY id LIMIT 1');
    return { store: first || null, base: '', path: url.pathname, legacy: true };
  }
  return { platform: true, path: url.pathname };
}

async function handle(req, res, url) {
  const m = req.method;
  let mm;

  // Shared, store-independent endpoints
  if (m === 'GET' && (mm = url.pathname.match(/^\/api\/communes\/(\d{1,2})$/))) {
    return U.json(res, 200, { communes: await geo.communesFor(mm[1].padStart(2, '0')) }, { 'Cache-Control': 'public, max-age=86400' });
  }
  if (m === 'GET' && url.pathname === '/health') return U.json(res, 200, { ok: true });

  await prime(0);
  const r = await resolve(req, url);
  if (r.platform) {
    if (m === 'GET' && r.path === '/') return U.html(res, 200, PF.homePage(), { 'Cache-Control': 'no-cache' });
    if (m === 'GET' && (r.path === '/signup' || r.path === '/register')) return U.redirect(res, '/admin/#signup');
    if (m === 'GET' && r.path === '/login') return U.redirect(res, '/admin/');
    if (m === 'GET' && r.path === '/robots.txt') return U.send(res, 200, 'User-agent: *\nDisallow: /admin\nDisallow: /api\n', { 'Content-Type': 'text/plain' });
    return null;
  }
  if (!r.store) return U.html(res, 404, PF.notFound());
  if (r.store.status !== 'active') return U.html(res, 503, PF.unavailable());

  const sid = r.store.id;
  const frameOk = url.searchParams.get('preview') === '1' ? { 'X-Frame-Options': null } : {};
  const B = r.base;
  const p = r.path;
  await prime(sid);
  V.setCtx(sid, B);
  let theme = getSetting('theme', sid);
  // Live preview from the design page (not saved): ?preview=1&th=<base64 json>
  if (url.searchParams.get('preview') === '1' && url.searchParams.get('th')) {
    try {
      const o = JSON.parse(decodeURIComponent(escape(atob(url.searchParams.get('th').replace(/-/g, '+').replace(/_/g, '/')))));
      const t2 = { ...theme };
      for (const k of ['primary', 'accent', 'ink', 'bg']) if (/^#[0-9a-fA-F]{6}$/.test(o[k] || '')) t2[k] = o[k];
      for (const k of ['layout', 'font', 'template', 'preset']) if (typeof o[k] === 'string' && o[k].length < 40) t2[k] = o[k];
      if (o.radius !== undefined) t2.radius = Math.max(0, Math.min(28, Number(o.radius) || 0));
      if (o.cols) t2.cols = Math.max(2, Math.min(5, Number(o.cols) || 4));
      theme = t2;
    } catch {}
  }
  const store = getSetting('store', sid);

  if (m === 'GET' && (p === '/' || p === '')) {
    if (!B && !r.slug) return null;
    return U.html(res, 200, V.homePage({ products: (await liveProducts(sid)), theme, store, q: U.str(url.searchParams.get('q'), 60), cat: U.str(url.searchParams.get('cat'), 60) }), { 'Cache-Control': 'no-cache', ...frameOk });
  }

  if (m === 'GET' && (mm = p.match(/^\/p\/([a-z0-9-]+)$/))) {
    const product = productRow((await D.get('SELECT * FROM products WHERE store_id = ? AND slug = ? AND live = 1', sid, mm[1])));
    if (!product) return U.html(res, 404, V.notFound(theme, store));
    const related = (await liveProducts(sid)).filter((x) => x.id !== product.id && (!product.category || x.category === product.category)).slice(0, 4);
    return U.html(res, 200, V.productPage({ product, related, theme, store }), { 'Cache-Control': 'no-cache' });
  }

  if (m === 'GET' && (mm = p.match(/^\/l\/([a-z0-9-]+)$/))) {
    const landing = landingRow((await D.get('SELECT * FROM landings WHERE store_id = ? AND slug = ?', sid, mm[1])));
    const preview = url.searchParams.get('preview') === '1';
    if (!landing || (!landing.live && !preview)) return U.html(res, 404, V.notFound(theme, store));
    const product = productRow((await D.get('SELECT * FROM products WHERE id = ? AND store_id = ?', landing.product_id, sid)));
    if (!product) return U.html(res, 404, V.notFound(theme, store));
    const ck = U.parseCookies(req)['lv' + landing.id];
    const headers = { 'Cache-Control': 'no-cache', ...frameOk };
    if (!preview && !ck && !BOT.test(req.headers['user-agent'] || '')) {
      (await D.run('UPDATE landings SET visits = visits + 1 WHERE id = ?', landing.id));
      await O.bumpStat(landing.id, 'visits');
      headers['Set-Cookie'] = `lv${landing.id}=1; Path=/; Max-Age=86400; SameSite=Lax`;
    }
    return U.html(res, 200, V.landingPage({ landing, product, theme, store, url }), headers);
  }

  if (m === 'POST' && p === '/api/order') {
    const ip = U.clientIp(req);
    if (!U.rateLimit('order:' + ip, 8, 10 * 60e3)) throw U.httpError(429, 'Too many orders, try again later');
    const body = await U.readJson(req, 32 * 1024);
    if (body.website) return U.json(res, 200, { ok: true, id: 0, token: '', total: 0 }); // honeypot: pretend success
    try {
      const out = await O.createOrder(sid, body, { ip, ua: req.headers['user-agent'] });
      return U.json(res, 200, { ok: true, id: out.order.id, token: out.order.public_token, total: out.order.total, merged: out.merged });
    } catch (e) {
      if (e.blocked) return U.json(res, 200, { ok: true, id: 0, token: '', total: 0 }); // blocked IP: look like success, save nothing
      if (e.status === 400) return U.json(res, 400, { ok: false, field: e.message });
      throw e;
    }
  }

  if (m === 'POST' && (mm = p.match(/^\/api\/order\/(\d+)\/upsell$/))) {
    const body = await U.readJson(req, 8 * 1024);
    const o = (await D.get('SELECT landing_id FROM orders WHERE id = ? AND store_id = ? AND public_token = ?', U.int(mm[1]), sid, String(body.token || '')));
    if (!o || !o.landing_id) throw U.httpError(404, 'Not found');
    const l = landingRow((await D.get('SELECT content FROM landings WHERE id = ? AND store_id = ?', o.landing_id, sid)));
    const up = l && l.content.upsell;
    if (!up) throw U.httpError(400, 'No upsell');
    const saved = await O.addUpsell(sid, mm[1], body.token, up.title, up.price);
    return U.json(res, 200, { ok: true, total: saved.total });
  }

  if (m === 'POST' && p === '/api/abandoned') {
    const ip = U.clientIp(req);
    if (!U.rateLimit('ab:' + ip, 30, 10 * 60e3)) return U.json(res, 200, { ok: true });
    const b = await U.readJson(req, 8 * 1024);
    const session = U.str(b.session, 64);
    const phone = U.normalizePhone(b.phone);
    if (!session || !phone) return U.json(res, 200, { ok: true });
    const pid = U.int(b.product_id) || null;
    if (pid && !(await D.get('SELECT 1 FROM products WHERE id = ? AND store_id = ?', pid, sid))) return U.json(res, 200, { ok: true });
    const now = U.nowIso();
    (await D.run(`INSERT INTO abandoned(store_id, created_at, updated_at, session, name, phone, wilaya, commune, product_id, landing_id) VALUES(?,?,?,?,?,?,?,?,?,?)
      ON CONFLICT(session) DO UPDATE SET updated_at=excluded.updated_at, name=excluded.name, phone=excluded.phone, wilaya=excluded.wilaya, commune=excluded.commune
      WHERE abandoned.status = 'open' AND abandoned.store_id = excluded.store_id`, sid, now, now, session, U.str(b.name, 80), phone, U.str(b.wilaya, 40), U.str(b.commune, 80), pid, U.int(b.landing_id) || null));
    return U.json(res, 200, { ok: true });
  }

  const origin = url.origin + B;
  if (m === 'GET' && p === '/robots.txt') return U.send(res, 200, 'User-agent: *\nDisallow: /admin\nDisallow: /api\nSitemap: ' + origin + '/sitemap.xml\n', { 'Content-Type': 'text/plain' });
  if (m === 'GET' && p === '/sitemap.xml') {
    const urls = ['/', ...(await liveProducts(sid)).map((x) => '/p/' + x.slug)];
    return U.send(res, 200, `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls.map((u) => `<url><loc>${U.esc(origin + u)}</loc></url>`).join('')}</urlset>`, { 'Content-Type': 'application/xml' });
  }
  if (B || r.slug) return U.html(res, 404, V.notFound(theme, store));
  return null;
}

module.exports = { handle, resolve, notFound: (res) => U.html(res, 404, PF.notFound()) };
