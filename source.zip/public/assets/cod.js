(function () {
  'use strict';
  var ss = {
    get: function (k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { sessionStorage.setItem(k, v); } catch (e) {} }
  };
  function cookie(name) { var m = document.cookie.match(new RegExp('(?:^|; )' + name + '=([^;]*)')); return m ? decodeURIComponent(m[1]) : ''; }
  function money(n, cur) { return String(Math.round(n || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' ' + cur; }
  function track(ev, data, id) {
    try { if (window.fbq) window.fbq('track', ev, data || {}, id ? { eventID: id } : undefined); } catch (e) {}
    try { if (window.ttq) window.ttq.track(ev === 'Purchase' ? 'CompletePayment' : ev === 'InitiateCheckout' ? 'InitiateCheckout' : ev, data || {}); } catch (e) {}
  }

  // UTM / click ids: keep the first ones of this visit.
  var qs = new URLSearchParams(location.search);
  ['utm_source', 'utm_campaign', 'utm_content'].forEach(function (k) { if (qs.get(k) && !ss.get(k)) ss.set(k, qs.get(k)); });
  if (!ss.get('sid')) ss.set('sid', Math.random().toString(36).slice(2) + Date.now().toString(36));

  function normPhone(v) {
    var d = String(v || '').replace(/[^0-9+]/g, '').replace(/^\+/, '');
    if (d.indexOf('00213') === 0) d = '0' + d.slice(5); else if (d.indexOf('213') === 0) d = '0' + d.slice(3);
    if (/^[567][0-9]{8}$/.test(d)) d = '0' + d;
    return /^0[567][0-9]{8}$/.test(d) ? d : null;
  }

  function setupPick(root, opts) {
    var btn = root.querySelector('.pick-btn'), pop = root.querySelector('.pick-pop'), search = root.querySelector('.pick-search'), list = root.querySelector('.pick-list');
    var items = [], value = null;
    function render() {
      var q = (search.value || '').trim().toLowerCase();
      list.innerHTML = '';
      items.filter(function (it) { return !q || it.search.indexOf(q) >= 0; }).slice(0, 400).forEach(function (it) {
        var b = document.createElement('button');
        b.type = 'button'; b.className = 'pick-item' + (it.value === value ? ' on' : ''); b.setAttribute('role', 'option');
        b.textContent = it.label;
        if (it.sub) { var s = document.createElement('small'); s.textContent = it.sub; b.appendChild(s); }
        b.addEventListener('click', function () { choose(it); });
        list.appendChild(b);
      });
    }
    function open(v) {
      pop.hidden = !v; btn.setAttribute('aria-expanded', v ? 'true' : 'false');
      if (v) { search.value = ''; render(); setTimeout(function () { search.focus(); }, 30); }
    }
    function choose(it) {
      value = it.value; btn.querySelector('span').textContent = it.label; btn.classList.add('set'); open(false); opts.onChange(it);
    }
    btn.addEventListener('click', function () { open(pop.hidden); });
    search.addEventListener('input', render);
    search.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') open(false);
      if (e.key === 'Enter') { e.preventDefault(); var f = list.querySelector('.pick-item'); if (f) f.click(); }
    });
    document.addEventListener('click', function (e) { if (!root.contains(e.target)) open(false); });
    return {
      setItems: function (arr) { items = arr; value = null; btn.querySelector('span').textContent = opts.placeholder; btn.classList.remove('set'); },
      reset: function (ph) { value = null; btn.querySelector('span').textContent = ph || opts.placeholder; btn.classList.remove('set'); }
    };
  }

  function initForm(form) {
    var D = JSON.parse(form.querySelector('.cod-data').textContent);
    var T = D.t;
    var $ = function (s) { return form.querySelector(s); };
    var nameEl = form.querySelector('input[name=name]');
    var wilayaInput = form.querySelector('input[name=wilaya]');
    var communeInput = form.querySelector('input[name=commune]');
    var communePick = form.querySelector('[data-pick=commune]');
    var current = { wilaya: null };
    var checkoutTracked = false;

    function selected(name) { var el = form.querySelector('input[name=' + name + ']:checked'); return el ? el.value : null; }
    function offer() { var q = Number(selected('quantity') || 1); for (var i = 0; i < D.offers.length; i++) if (D.offers[i].qty === q) return D.offers[i]; return D.offers[0]; }
    function fee() {
      if (!current.wilaya) return 0;
      var v = selected('delivery') === 'home' ? current.wilaya.home : current.wilaya.desk;
      return v == null ? 0 : v;
    }
    function updateTotal() {
      var o = offer();
      $('[data-total]').textContent = money(o.price + fee(), T.currency);
      var dz = $('[data-fee=desk]'), hm = $('[data-fee=home]');
      if (current.wilaya) {
        if (dz) dz.textContent = current.wilaya.desk ? '+ ' + money(current.wilaya.desk, T.currency) : T.free;
        if (hm) hm.textContent = current.wilaya.home ? '+ ' + money(current.wilaya.home, T.currency) : T.free;
      } else if (hm) {
        var h = D.wilayas.length ? Math.min.apply(null, D.wilayas.map(function (w) { return w.home || 0; })) : 0;
        hm.textContent = h ? '+ ' + money(h, T.currency) : '';
      }
    }
    function syncRadios(group, cls) {
      form.querySelectorAll('input[name=' + group + ']').forEach(function (inp) {
        inp.closest('.' + cls).classList.toggle('on', inp.checked);
      });
    }
    form.addEventListener('change', function (e) {
      var n = e.target.name;
      if (n === 'quantity') syncRadios('quantity', 'offer');
      if (n === 'delivery') syncRadios('delivery', 'dv');
      if (n === 'variant') { syncRadios('variant', 'variant'); setErr('variant', ''); }
      updateTotal();
    });

    function setErr(field, msg) {
      var el = form.querySelector('[data-err=' + field + ']');
      if (el) el.textContent = msg || '';
      var f = el && el.closest('.field');
      if (f) f.classList.toggle('bad', !!msg);
    }

    var wilayaPick = setupPick(form.querySelector('[data-pick=wilaya]'), {
      placeholder: T.chooseWilaya,
      onChange: function (it) {
        current.wilaya = it.w; wilayaInput.value = it.value; setErr('wilaya', '');
        loadCommunes(it.value); updateTotal(); saveAbandoned();
        if (!checkoutTracked) { checkoutTracked = true; track('InitiateCheckout', { content_name: D.contentName, currency: 'DZD', value: offer().price }); }
      }
    });
    wilayaPick.setItems(D.wilayas.map(function (w) {
      var label = w.code + ' - ' + (D.lang === 'fr' ? w.fr : w.ar);
      return { value: w.code, label: label, sub: D.lang === 'fr' ? w.ar : w.fr, search: (w.code + ' ' + w.ar + ' ' + w.fr).toLowerCase(), w: w };
    }));
    var cPick = setupPick(communePick, { placeholder: T.chooseCommune, onChange: function (it) { communeInput.value = it.value; setErr('commune', ''); saveAbandoned(); } });

    function loadCommunes(code) {
      communeInput.value = '';
      communeInput.placeholder = T.typeCommune;
      fetch('/api/communes/' + code).then(function (r) { return r.json(); }).then(function (j) {
        var list = (j.communes || []);
        if (list.length) {
          cPick.setItems(list.map(function (c) { var l = D.lang === 'fr' ? (c.fr || c.ar) : c.ar; return { value: l, label: l, sub: D.lang === 'fr' ? c.ar : c.fr, search: (c.ar + ' ' + c.fr).toLowerCase() }; }));
          communePick.hidden = false; communeInput.type = 'hidden';
        } else {
          communePick.hidden = true; communeInput.type = 'text';
        }
      }).catch(function () { communePick.hidden = true; communeInput.type = 'text'; });
    }

    var abTimer = null;
    function saveAbandoned() {
      clearTimeout(abTimer);
      abTimer = setTimeout(function () {
        var phone = normPhone(form.phone.value);
        if (!phone) return;
        fetch((D.base || '') + '/api/abandoned', { method: 'POST', headers: { 'Content-Type': 'application/json' }, keepalive: true, body: JSON.stringify({
          session: ss.get('sid'), name: nameEl.value, phone: phone, wilaya: wilayaInput.value, commune: communeInput.value, product_id: D.productId, landing_id: D.landingId
        }) }).catch(function () {});
      }, 900);
    }
    form.phone.addEventListener('input', function () { setErr('phone', ''); saveAbandoned(); });
    nameEl.addEventListener('input', function () { setErr('name', ''); });
    form.phone.addEventListener('focus', function () { if (!checkoutTracked) { checkoutTracked = true; track('InitiateCheckout', { content_name: D.contentName, currency: 'DZD', value: offer().price }); } });
    communeInput.addEventListener('input', function () { setErr('commune', ''); });

    var lastOrder = null;
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var phone = normPhone(form.phone.value);
      var ok = true;
      if (nameEl.value.trim().length < 2) { setErr('name', T.errName); ok = false; }
      if (!phone) { setErr('phone', T.errPhone); ok = false; }
      if (!wilayaInput.value) { setErr('wilaya', T.errWilaya); ok = false; }
      if (!communeInput.value.trim()) { setErr('commune', T.errCommune); ok = false; }
      if (D.variants.length > 1 && !selected('variant')) { setErr('variant', T.errVariant); ok = false; }
      if (!ok) { var bad = form.querySelector('.field.bad'); if (bad) bad.scrollIntoView({ behavior: 'smooth', block: 'center' }); return; }
      var btn = form.querySelector('button[type=submit]');
      btn.disabled = true; btn.textContent = T.sending;
      var errBox = form.querySelector('.form-err'); errBox.hidden = true;
      fetch((D.base || '') + '/api/order', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
        name: nameEl.value.trim(), phone: phone, wilaya: wilayaInput.value, commune: communeInput.value.trim(), delivery: selected('delivery') || 'desk',
        quantity: Number(selected('quantity') || 1), variant: selected('variant') || '', product_id: D.productId, landing_id: D.landingId,
        utm_source: ss.get('utm_source') || '', utm_campaign: ss.get('utm_campaign') || '', utm_content: ss.get('utm_content') || '',
        session: ss.get('sid'), page_url: location.href, fbc: cookie('_fbc'), fbp: cookie('_fbp'), website: form.website.value
      }) }).then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); }).then(function (res) {
        if (!res.ok || !res.j.ok) {
          var f = res.j && res.j.field;
          if (f === 'phone') setErr('phone', T.errPhone); else if (f === 'wilaya' || f === 'delivery') setErr('wilaya', T.errWilaya); else if (f === 'commune') setErr('commune', T.errCommune); else if (f === 'variant') setErr('variant', T.errVariant); else if (f === 'name') setErr('name', T.errName);
          else { errBox.textContent = (res.j && res.j.error) || T.error; errBox.hidden = false; }
          btn.disabled = false; btn.textContent = T.confirm; return;
        }
        lastOrder = res.j;
        if (res.j.id && !res.j.merged) track(D.purchaseEvent || 'Purchase', { content_name: D.contentName, content_ids: [String(D.productId)], content_type: 'product', currency: 'DZD', value: res.j.total }, 'order-' + res.j.id);
        form.querySelector('[data-step=form]').hidden = true;
        var done = form.querySelector('[data-step=done]');
        done.hidden = false;
        done.querySelector('[data-done-title]').textContent = T.thanks;
        done.querySelector('[data-done-sub]').textContent = T.thanksSub.replace('{phone}', phone);
        done.querySelector('[data-done-total]').textContent = money(res.j.total, T.currency);
        form.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }).catch(function () {
        errBox.textContent = T.error; errBox.hidden = false; btn.disabled = false; btn.textContent = T.confirm;
      });
    });

    form.querySelectorAll('[data-up]').forEach(function (b) {
      b.addEventListener('click', function () {
        var box = form.querySelector('[data-upsell]');
        if (b.getAttribute('data-up') === 'no' || !lastOrder || !lastOrder.id) { box.remove(); return; }
        b.disabled = true;
        fetch((D.base || '') + '/api/order/' + lastOrder.id + '/upsell', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token: lastOrder.token }) })
          .then(function (r) { return r.json(); }).then(function (j) {
            if (j.ok) { form.querySelector('[data-done-total]').textContent = money(j.total, T.currency); track('AddToCart', { currency: 'DZD', value: D.upsell.price }); }
            box.remove();
          }).catch(function () { box.remove(); });
      });
    });

    if (D.variants.length === 1) { var only = form.querySelector('input[name=variant]'); if (only) only.checked = true; }
    syncRadios('quantity', 'offer'); updateTotal();
    track('ViewContent', { content_name: D.contentName, content_ids: [String(D.productId)], content_type: 'product', currency: 'DZD', value: offer().price });
  }

  document.querySelectorAll('[data-cod]').forEach(initForm);

  // Sticky bar hides while the form is on screen.
  var sticky = document.querySelector('.sticky'), formEl = document.getElementById('order');
  if (sticky && formEl && 'IntersectionObserver' in window) {
    new IntersectionObserver(function (en) { sticky.classList.toggle('hide', en[0].isIntersecting); }, { threshold: 0.15 }).observe(formEl);
  }

  // Before / after slider
  document.querySelectorAll('[data-ba]').forEach(function (ba) {
    var after = ba.querySelector('.ba-after'), inner = after.querySelector('img'), range = ba.parentNode.querySelector('.ba-range');
    function size() { inner.style.width = ba.offsetWidth + 'px'; }
    size(); window.addEventListener('resize', size);
    if (range) range.addEventListener('input', function () { after.style.width = (100 - Number(range.value)) + '%'; });
  });

  // Product gallery
  document.querySelectorAll('[data-gal]').forEach(function (g) {
    var main = g.querySelector('.pp-main img');
    g.querySelectorAll('.pp-thumbs button').forEach(function (b) {
      b.addEventListener('click', function () {
        if (main) main.src = b.getAttribute('data-src');
        g.querySelectorAll('.pp-thumbs button').forEach(function (x) { x.classList.toggle('on', x === b); });
      });
    });
  });

  // Tabs
  document.querySelectorAll('[data-tabs]').forEach(function (t) {
    t.querySelectorAll('[data-tab]').forEach(function (b) {
      b.addEventListener('click', function () {
        var k = b.getAttribute('data-tab');
        t.querySelectorAll('[data-tab]').forEach(function (x) { x.setAttribute('aria-selected', x === b ? 'true' : 'false'); });
        t.querySelectorAll('[data-panel]').forEach(function (p) { p.hidden = p.getAttribute('data-panel') !== k; });
      });
    });
  });
})();
