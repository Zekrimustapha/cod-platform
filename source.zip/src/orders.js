'use strict';
const { D, getSetting, productRow, orderRow, parseJson, bg } = require('./db');
const { normalizePhone, token, nowIso, httpError, str, int, ipKey } = require('./util');
const geo = require('./geo');
const integ = require('./integrations');

const STATUSES = ['new', 'noanswer', 'callback', 'confirmed', 'shipped', 'delivered', 'returned', 'cancelled'];
const STATUS_LABELS = { new: 'New', noanswer: 'No answer', callback: 'Call back later', confirmed: 'Confirmed', shipped: 'Shipped', delivered: 'Delivered', returned: 'Returned', cancelled: 'Cancelled' };

function deliveryFee(sid, code, type) {
  const d = getSetting('delivery', sid);
  const w = geo.wilayaByCode(code);
  const f = (d.fees && (d.fees[code] || (w && d.fees[w.parent]))) || {};
  if (f.active === false) return null;
  if (type === 'home') return d.homeEnabled === false ? null : int(f.home ?? d.defaultHome, d.defaultHome);
  return d.deskEnabled === false ? null : int(f.desk ?? d.defaultDesk, d.defaultDesk);
}

function priceFor(product, qty, variantName) {
  const offers = (product.offers || []).filter((o) => int(o.qty) > 0 && int(o.price) > 0);
  const o = offers.find((x) => int(x.qty) === qty);
  const base = o ? int(o.price) : product.price * qty;
  // A variant with its own price shifts every quantity offer by (variant price - product price) per piece.
  const v = variantName ? (product.variants || []).find((x) => x.name === variantName) : null;
  const delta = v && int(v.price) > 0 ? int(v.price) - int(product.price) : 0;
  return Math.max(0, base + delta * qty);
}
// Is this product / variant out of stock? (stock -1 on a product = not tracked)
function outOfStock(product, variantName) {
  if ((product.variants || []).length) { const v = product.variants.find((x) => x.name === variantName); return !!v && int(v.stock) <= 0; }
  return product.stock !== undefined && product.stock !== null && Number(product.stock) === 0;
}
// Stock moves when an order is confirmed, and comes back when it is cancelled / returned.
async function moveStock(sid, productId, variantName, delta) {
  const p = await D.get('SELECT id, variants, stock FROM products WHERE id = ? AND store_id = ?', productId, sid);
  if (!p) return;
  const vs = parseJson(p.variants, []);
  if (vs.length) {
    const v = vs.find((x) => x.name === variantName);
    if (!v) return;
    v.stock = Math.max(0, int(v.stock) + delta);
    await D.run('UPDATE products SET variants = ? WHERE id = ?', JSON.stringify(vs), p.id);
  } else if (Number(p.stock ?? -1) >= 0) {
    await D.run('UPDATE products SET stock = MAX(0, stock + ?) WHERE id = ?', delta, p.id);
  }
}

async function customerScore(sid, phone) {
  const r = (await D.get(`SELECT SUM(status='delivered') AS d, SUM(status='returned') AS r, COUNT(*) AS n FROM orders WHERE store_id = ? AND phone = ?`, sid, phone));
  const closed = (r.d || 0) + (r.r || 0);
  return { delivered: r.d || 0, returned: r.r || 0, orders: r.n || 0, score: closed ? Math.round(((r.d || 0) / closed) * 100) : null };
}

async function bumpStat(landingId, field) {
  if (!landingId) return;
  const date = nowIso().slice(0, 10);
  (await D.run(`INSERT INTO landing_stats(landing_id, date, visits, orders) VALUES(?, ?, ?, ?)
    ON CONFLICT(landing_id, date) DO UPDATE SET ${field} = ${field} + 1`, landingId, date, field === 'visits' ? 1 : 0, field === 'orders' ? 1 : 0));
}

async function createOrder(sid, input, meta = {}) {
  const store = getSetting('delivery', sid);
  const fraud = getSetting('fraud', sid);
  const name = str(input.name, 80);
  if (name.length < 2) throw httpError(400, 'name');
  const phone = normalizePhone(input.phone);
  if (!phone) throw httpError(400, 'phone');
  const w = geo.wilayaByCode(input.wilaya, store.wilayaMode);
  if (!w) throw httpError(400, 'wilaya');
  const commune = str(input.commune, 80);
  if (!commune) throw httpError(400, 'commune');
  const delivery = input.delivery === 'home' ? 'home' : 'desk';
  const fee = deliveryFee(sid, w.code, delivery);
  if (fee === null) throw httpError(400, 'delivery');
  const product = productRow((await D.get('SELECT * FROM products WHERE id = ? AND store_id = ? AND live = 1', int(input.product_id), sid)));
  if (!product) throw httpError(400, 'product');
  const qty = Math.min(20, Math.max(1, int(input.quantity, 1)));
  let variant = str(input.variant, 80);
  if (product.variants.length > 1 && !product.variants.some((v) => v.name === variant)) throw httpError(400, 'variant');
  if (product.variants.length === 1) variant = product.variants[0].name || '';
  const soldOut = outOfStock(product, variant);
  if (soldOut && !product.preorder) throw httpError(400, product.variants.length ? 'variant' : 'soldout');
  let landingId = int(input.landing_id) || null;
  if (landingId && !(await D.get('SELECT 1 FROM landings WHERE id = ? AND store_id = ?', landingId, sid))) landingId = null;
  const items = priceFor(product, qty, variant);
  const now = nowIso();
  const flags = [];
  if (soldOut) flags.push('preorder');

  // Fields configured by the store owner (Settings → Order form)
  const formCfg = getSetting('form', sid);
  const cfgFields = (formCfg.fields || []).filter((f) => f && f.on);
  const isReq = (k) => cfgFields.some((f) => f.key === k && f.req);
  const address = str(input.address, 200);
  if (isReq('address') && address.length < 3) throw httpError(400, 'address');
  const custNote = str(input.note, 300);
  if (isReq('note') && !custNote) throw httpError(400, 'note');
  const phone2 = input.phone2 ? normalizePhone(input.phone2) || '' : '';
  if (isReq('phone2') && !phone2) throw httpError(400, 'phone2');
  const extra = {};
  for (const f of cfgFields.filter((x) => /^c_[a-z0-9]{1,20}$/.test(x.key))) {
    const v = str(input.extra && input.extra[f.key], 300);
    if (f.req && !v) throw httpError(400, f.key);
    if (v) extra[f.label || f.key] = v;
  }

  // IP protection: fake-order attacks change phone numbers, not their connection.
  const ipk = ipKey(meta.ip, fraud.blockIpv6Range !== false);
  if (ipk) {
    const blocked = await D.get('SELECT ip FROM ip_blocklist WHERE store_id = ? AND ip = ?', sid, ipk);
    if (blocked) {
      await D.run('UPDATE ip_blocklist SET hits = hits + 1 WHERE store_id = ? AND ip = ?', sid, ipk);
      throw Object.assign(new Error('blocked'), { status: 403, blocked: true });
    }
    const like = ipk.endsWith('::/64') ? ipk.replace('::/64', ':') + '%' : ipk;
    const ipToday = (await D.get(`SELECT COUNT(*) n FROM orders WHERE store_id = ? AND ip LIKE ? AND created_at > ?`, sid, like, new Date(Date.now() - 864e5).toISOString())).n;
    const lim = Number(fraud.maxPerIpDay) || 0;
    if (lim > 0 && ipToday >= lim) {
      flags.push('ip_limit');
      if (fraud.autoBlockIp !== false) await D.run('INSERT OR IGNORE INTO ip_blocklist(store_id, ip, reason, created_at) VALUES(?,?,?,?)', sid, ipk, `auto: ${ipToday + 1} orders in 24 h`, now);
    }
  }

  const black = (await D.get('SELECT phone FROM blacklist WHERE store_id = ? AND phone = ?', sid, phone));
  if (black) flags.push('blacklisted');

  // Merge duplicates: same phone + product still being handled.
  const since = new Date(Date.now() - (fraud.mergeHours || 24) * 3600e3).toISOString();
  const dup = (await D.get(`SELECT * FROM orders WHERE store_id = ? AND phone = ? AND product_id = ? AND created_at > ? AND status IN ('new','noanswer','callback') ORDER BY id DESC LIMIT 1`, sid, phone, product.id, since));
  if (dup && !black) {
    const h = parseJson(dup.history, []);
    h.push({ at: now, by: 'customer', action: 'ordered again (merged)', detail: `qty ${qty}` });
    (await D.run('UPDATE orders SET history = ?, updated_at = ? WHERE id = ?', JSON.stringify(h), now, dup.id));
    return { order: orderRow(dup), merged: true };
  }

  const today = now.slice(0, 10);
  const todayCount = (await D.get('SELECT COUNT(*) AS n FROM orders WHERE store_id = ? AND phone = ? AND substr(created_at,1,10) = ?', sid, phone, today)).n;
  if (todayCount >= (fraud.maxPerDay || 3)) flags.push('too_many_today');
  const sc = await customerScore(sid, phone);
  if (sc.score !== null && sc.score < (fraud.flagScore || 50) && sc.delivered + sc.returned >= 2) flags.push('low_score');

  const order = {
    store_id: sid, public_token: token(18), created_at: now, updated_at: now, name, phone, wilaya_code: w.code, wilaya_name: w.ar, commune,
    address, phone2, extra: Object.keys(extra).length ? JSON.stringify(extra) : '', note: custNote ? 'Client: ' + custNote : '', delivery, product_id: product.id, product_name: product.name, landing_id: landingId, variant,
    quantity: qty, items_price: items, delivery_fee: fee, total: items + fee, unit_cost: product.cost || 0,
    status: black ? 'cancelled' : 'new', source: landingId ? 'landing' : 'store',
    utm_source: str(input.utm_source, 60), utm_campaign: str(input.utm_campaign, 120), utm_content: str(input.utm_content, 120),
    flags: flags.join(','), ip: str(meta.ip, 60), user_agent: str(meta.ua, 300),
    history: JSON.stringify([{ at: now, by: 'customer', action: 'created', detail: black ? 'phone is blacklisted' : '' }])
  };
  const cols = Object.keys(order);
  const r = await D.run(`INSERT INTO orders(${cols.join(',')}) VALUES(${cols.map(() => '?').join(',')})`, ...cols.map((c) => order[c]));
  const id = Number(r.lastInsertRowid);
  if (input.session) await D.run(`UPDATE abandoned SET status = 'converted', updated_at = ? WHERE store_id = ? AND session = ?`, now, sid, str(input.session, 64));
  await bumpStat(landingId, 'orders');
  const saved = orderRow((await D.get('SELECT * FROM orders WHERE id = ?', id)));
  if (!black) {
    bg(integ.pushToSheets('created', saved));
    const landing = landingId ? (await D.get('SELECT pixel_meta FROM landings WHERE id = ?', landingId)) : null;
    const tr = getSetting('tracking', sid);
    const onPlace = !tr.purchaseOn || tr.purchaseOn === 'placed';
    const pxExtra = { ip: meta.ip, ua: meta.ua, url: str(input.page_url, 300), fbc: str(input.fbc, 200), fbp: str(input.fbp, 200) };
    // Keep what the server events need later (purchase on confirmed / delivered)
    await D.run('UPDATE orders SET pixel_sent = ? WHERE id = ?', JSON.stringify({ placed: onPlace ? 'purchase' : 'lead', x: pxExtra }), id);
    bg(integ.metaCapi({ pixelId: landing && landing.pixel_meta, eventName: onPlace ? tr.purchaseEvent || 'Purchase' : 'Lead', eventId: 'order-' + id, order: saved, extra: pxExtra }));
  }
  return { order: saved, merged: false };
}

async function addUpsell(sid, id, publicToken, upsellTitle, upsellPrice) {
  const o = (await D.get('SELECT * FROM orders WHERE id = ? AND store_id = ? AND public_token = ?', int(id), sid, String(publicToken || '')));
  if (!o) throw httpError(404, 'order');
  if (o.upsell) return orderRow(o);
  if (Date.now() - Date.parse(o.created_at) > 30 * 60e3) throw httpError(400, 'expired');
  const h = parseJson(o.history, []);
  h.push({ at: nowIso(), by: 'customer', action: 'accepted upsell', detail: upsellTitle });
  (await D.run('UPDATE orders SET upsell = ?, upsell_price = ?, total = total + ?, history = ?, updated_at = ? WHERE id = ?', str(upsellTitle, 120), int(upsellPrice), int(upsellPrice), JSON.stringify(h), nowIso(), o.id));
  return orderRow((await D.get('SELECT * FROM orders WHERE id = ?', o.id)));
}

async function updateOrder(sid, id, patch, user) {
  const o = (await D.get('SELECT * FROM orders WHERE id = ? AND store_id = ?', int(id), sid));
  if (!o) throw httpError(404, 'Order not found');
  const h = parseJson(o.history, []);
  const set = {};
  const by = user ? user.name : 'system';
  const now = nowIso();
  if (patch.status !== undefined && patch.status !== o.status) {
    if (!STATUSES.includes(patch.status)) throw httpError(400, 'Bad status');
    set.status = patch.status;
    if (patch.status === 'noanswer') set.attempts = o.attempts + 1;
    if (patch.status === 'confirmed' && !o.agent_id && user) set.agent_id = user.id;
    h.push({ at: now, by, action: 'status', detail: `${STATUS_LABELS[o.status]} → ${STATUS_LABELS[patch.status]}` });
  }
  for (const k of ['name', 'commune', 'address', 'variant', 'note', 'tracking', 'courier']) {
    if (patch[k] !== undefined && String(patch[k]) !== String(o[k] ?? '')) {
      set[k] = str(patch[k], k === 'note' ? 1000 : 200);
      if (k !== 'note') h.push({ at: now, by, action: 'edit', detail: k });
    }
  }
  if (patch.phone !== undefined) {
    const p = normalizePhone(patch.phone);
    if (!p) throw httpError(400, 'Bad phone');
    if (p !== o.phone) { set.phone = p; h.push({ at: now, by, action: 'edit', detail: 'phone' }); }
  }
  if (patch.wilaya_code !== undefined && patch.wilaya_code !== o.wilaya_code) {
    const w = geo.wilayaByCode(patch.wilaya_code, 69);
    if (!w) throw httpError(400, 'Bad wilaya');
    set.wilaya_code = w.code; set.wilaya_name = w.ar;
  }
  if (patch.delivery !== undefined || patch.quantity !== undefined || set.wilaya_code || set.variant !== undefined) {
    const delivery = (patch.delivery || o.delivery) === 'home' ? 'home' : 'desk';
    const qty = Math.min(20, Math.max(1, int(patch.quantity ?? o.quantity, 1)));
    const product = productRow((await D.get('SELECT * FROM products WHERE id = ?', o.product_id)));
    const items = product ? priceFor(product, qty, set.variant !== undefined ? set.variant : o.variant) : o.items_price;
    const fee = deliveryFee(sid, set.wilaya_code || o.wilaya_code, delivery) ?? o.delivery_fee;
    Object.assign(set, { delivery, quantity: qty, items_price: items, delivery_fee: fee, total: items + fee + (o.upsell_price || 0) });
  }
  if (patch.total !== undefined && int(patch.total) > 0 && int(patch.total) !== o.total) {
    set.total = int(patch.total);
    h.push({ at: now, by, action: 'edit', detail: 'total → ' + set.total });
  }
  if (patch.addNote) h.push({ at: now, by, action: 'call note', detail: str(patch.addNote, 300) });
  // Inventory: take stock on confirmation, give it back on cancel / return.
  const st = set.status;
  if (st && o.product_id) {
    const taking = ['confirmed', 'shipped', 'delivered'].includes(st), giving = ['cancelled', 'returned'].includes(st);
    if (taking && !o.stock_taken) { await moveStock(sid, o.product_id, set.variant ?? o.variant, -(set.quantity || o.quantity)); set.stock_taken = 1; }
    if (giving && o.stock_taken) { await moveStock(sid, o.product_id, o.variant, o.quantity); set.stock_taken = 0; }
  }
  if (!Object.keys(set).length && !patch.addNote) return orderRow(o);
  set.history = JSON.stringify(h);
  set.updated_at = now;
  const keys = Object.keys(set);
  (await D.run(`UPDATE orders SET ${keys.map((k) => k + ' = ?').join(', ')} WHERE id = ?`, ...keys.map((k) => set[k]), o.id));
  const saved = orderRow((await D.get('SELECT * FROM orders WHERE id = ?', o.id)));
  if (set.status === 'returned') {
    const limit = getSetting('fraud', sid).autoBlacklistReturns || 0;
    if (limit > 0) {
      const n = (await D.get(`SELECT COUNT(*) AS n FROM orders WHERE store_id = ? AND phone = ? AND status = 'returned'`, sid, saved.phone)).n;
      if (n >= limit) (await D.run('INSERT OR IGNORE INTO blacklist(store_id, phone, reason, created_at) VALUES(?,?,?,?)', sid, saved.phone, `${n} refused deliveries (auto)`, now));
    }
  }
  if (set.status) bg(integ.pushToSheets('status', saved));
  // Report the Purchase to ad platforms only when the order is really confirmed / delivered (better optimisation for COD).
  if (set.status) {
    const tr = getSetting('tracking', sid);
    const want = tr.purchaseOn === 'confirmed' ? ['confirmed', 'shipped', 'delivered'] : tr.purchaseOn === 'delivered' ? ['delivered'] : [];
    if (want.includes(set.status)) {
      const ps = parseJson(saved.pixel_sent, {});
      if (ps.placed === 'lead' && !ps.purchase) {
        ps.purchase = now;
        await D.run('UPDATE orders SET pixel_sent = ? WHERE id = ?', JSON.stringify(ps), saved.id);
        const landing = saved.landing_id ? await D.get('SELECT pixel_meta FROM landings WHERE id = ?', saved.landing_id) : null;
        bg(integ.metaCapi({ pixelId: landing && landing.pixel_meta, eventName: 'Purchase', eventId: 'purchase-' + saved.id, order: saved, extra: ps.x || {} }));
      }
    }
    if (set.status === 'confirmed' && getSetting('couriers', sid).autoPush && !saved.tracking) {
      const C = require('./couriers');
      bg(C.pushOrder(sid, saved.id).catch((e) => console.log('[courier]', e.message)));
    }
  }
  return saved;
}

module.exports = { STATUSES, STATUS_LABELS, createOrder, addUpsell, updateOrder, deliveryFee, priceFor, customerScore, bumpStat };
