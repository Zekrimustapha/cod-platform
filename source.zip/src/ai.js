'use strict';
const { getSetting } = require('./db');

const LANGS = {
  ar: 'Modern Standard Arabic, simple and warm, for Algerian buyers',
  dz: 'Algerian Darija written in Arabic script (natural, the way Algerians talk on Facebook)',
  fr: 'French, simple and direct, for Algerian buyers'
};
const ANGLES = {
  auto: 'pick the strongest angle for this product',
  pain: 'pain / problem: start from the daily problem, then the relief',
  result: 'result / transformation: before vs after',
  gift: 'gift: a perfect present for a loved one',
  urgency: 'limited offer: honest scarcity, no fake timers'
};

function buildPrompt({ description, productName, price, lang, angle }) {
  return `You write high-converting cash-on-delivery landing pages for the Algerian market.
Product name: ${productName || '(infer from photo and description)'}
Price: ${price || '?'} DZD
Seller description: ${description}
Language: ${LANGS[lang] || LANGS.ar}
Selling angle: ${ANGLES[angle] || ANGLES.auto}

Rules:
- Mobile readers, very short lines. Concrete benefits, no vague hype.
- Never invent statistics, medical claims, certifications, reviews, testimonials or customer names.
- No emojis. No fake countdowns.
- Payment is cash on delivery, delivery to all wilayas.

Return ONLY valid JSON with exactly these keys:
{
 "product_name": string,
 "hook": string (one question that touches the customer's pain or desire, max 12 words),
 "headline": string (the result the customer wants, max 10 words),
 "subheadline": string (one sentence),
 "bullets": [3 short benefit strings],
 "problem": {"title": string, "pains": [3 strings in the customer's words], "bridge": string},
 "benefits": [4 objects {"title": string, "text": string}],
 "comparison": [4 short strings: what this product has that cheap alternatives don't],
 "steps": [3 objects {"title": string, "text": string} explaining how to use it],
 "faq": [4 objects {"q": string, "a": string} about use, results, delivery, exchange],
 "final_cta": string (one closing line),
 "badge": string (2-3 words for a corner badge),
 "seo_title": string
}`;
}

function clean(v, max = 300) {
  return String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
}
function arr(v, n, map) {
  const a = Array.isArray(v) ? v : [];
  return a.slice(0, n).map(map);
}

function normalize(j, fallbackName) {
  return {
    product_name: clean(j.product_name || fallbackName, 120),
    hook: clean(j.hook, 160),
    headline: clean(j.headline, 160),
    subheadline: clean(j.subheadline, 260),
    bullets: arr(j.bullets, 3, (x) => clean(x, 120)),
    problem: { title: clean(j.problem?.title, 140), pains: arr(j.problem?.pains, 3, (x) => clean(x, 160)), bridge: clean(j.problem?.bridge, 200) },
    benefits: arr(j.benefits, 4, (x) => ({ title: clean(x?.title, 80), text: clean(x?.text, 200) })),
    comparison: arr(j.comparison, 4, (x) => clean(typeof x === 'string' ? x : x?.label, 90)),
    steps: arr(j.steps, 3, (x) => ({ title: clean(x?.title, 80), text: clean(x?.text, 200) })),
    faq: arr(j.faq, 4, (x) => ({ q: clean(x?.q, 140), a: clean(x?.a, 400) })),
    final_cta: clean(j.final_cta, 160),
    badge: clean(j.badge, 30),
    seo_title: clean(j.seo_title, 90)
  };
}

function extractJson(text) {
  const s = String(text || '');
  const a = s.indexOf('{');
  const b = s.lastIndexOf('}');
  if (a < 0 || b < a) throw new Error('AI did not return JSON');
  return JSON.parse(s.slice(a, b + 1));
}

async function viaOllama(cfg, prompt, image) {
  const r = await fetch(cfg.ollamaUrl.replace(/\/$/, '') + '/api/chat', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: cfg.ollamaModel, stream: false, format: 'json', options: { temperature: 0.7 },
      messages: [{ role: 'user', content: prompt, images: image ? [image.data] : undefined }] }),
    signal: AbortSignal.timeout(240000)
  });
  if (!r.ok) throw new Error('Ollama HTTP ' + r.status + ' — is Ollama running and is the model "' + cfg.ollamaModel + '" pulled?');
  const j = await r.json();
  return extractJson(j.message?.content);
}

async function viaGemini(cfg, prompt, image) {
  if (!cfg.geminiKey) throw new Error('Add your free Gemini API key in Platform → AI keys (super admin)');
  const parts = [{ text: prompt }];
  if (image) parts.push({ inline_data: { mime_type: image.mime, data: image.data } });
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(cfg.geminiModel)}:generateContent?key=${encodeURIComponent(cfg.geminiKey)}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ contents: [{ parts }], generationConfig: { responseMimeType: 'application/json', temperature: 0.8 } }),
    signal: AbortSignal.timeout(120000)
  });
  const j = await r.json();
  if (j.error) throw new Error('Gemini: ' + j.error.message);
  return extractJson(j.candidates?.[0]?.content?.parts?.map((p) => p.text).join(''));
}

// Works with no AI at all: a solid structure the seller edits.
function template({ description, productName, lang }) {
  const name = productName || 'المنتج';
  const d = clean(description, 200);
  if (lang === 'fr') {
    return normalize({
      product_name: name, hook: 'Vous cherchez une vraie solution ?', headline: name + ' : le résultat que vous attendez',
      subheadline: d || 'Qualité garantie, paiement à la livraison.', bullets: ['Résultat visible', 'Facile à utiliser', 'Qualité contrôlée'],
      problem: { title: 'Vous en avez assez ?', pains: ['Le problème revient chaque jour', 'Vous avez tout essayé', 'Ça gâche votre quotidien'], bridge: "C'est pour ça que nous proposons " + name + '.' },
      benefits: [{ title: 'Efficace', text: 'Pensé pour un vrai résultat.' }, { title: 'Simple', text: "Prêt à l'emploi." }, { title: 'Durable', text: 'Matériaux de qualité.' }, { title: 'Garanti', text: 'Échange si problème.' }],
      comparison: ['Qualité contrôlée', 'Paiement à la livraison', 'Échange possible', 'Service client joignable'],
      steps: [{ title: 'Commandez', text: 'Remplissez le formulaire.' }, { title: 'Confirmez', text: 'Nous vous appelons.' }, { title: 'Recevez', text: 'Payez à la livraison.' }],
      faq: [{ q: 'Comment payer ?', a: 'En espèces à la livraison.' }, { q: 'Délai de livraison ?', a: '24 à 72 h selon la wilaya.' }, { q: 'Puis-je échanger ?', a: 'Oui si le produit arrive défectueux.' }, { q: 'Comment l’utiliser ?', a: 'Les instructions sont incluses.' }],
      final_cta: 'Commandez maintenant, payez à la réception.', badge: 'Offre limitée', seo_title: name + ' — Algérie, paiement à la livraison'
    }, name);
  }
  return normalize({
    product_name: name, hook: 'هل تبحث عن حل حقيقي؟', headline: name + ' — النتيجة التي تنتظرها',
    subheadline: d || 'جودة مضمونة والدفع عند الاستلام.', bullets: ['نتيجة واضحة', 'سهل الاستعمال', 'جودة مضمونة'],
    problem: { title: 'هل تعبت من نفس المشكلة؟', pains: ['المشكلة تتكرر كل يوم', 'جرّبت حلولاً كثيرة دون فائدة', 'تؤثر على راحتك اليومية'], bridge: 'لهذا اخترنا لك ' + name + '.' },
    benefits: [{ title: 'فعّال', text: 'مصمم لنتيجة حقيقية.' }, { title: 'سهل', text: 'جاهز للاستعمال مباشرة.' }, { title: 'متين', text: 'مواد عالية الجودة.' }, { title: 'مضمون', text: 'استبدال إذا وصلك معيباً.' }],
    comparison: ['جودة مراقبة', 'الدفع عند الاستلام', 'إمكانية الاستبدال', 'خدمة زبائن متوفرة'],
    steps: [{ title: 'اطلب', text: 'املأ الاستمارة في دقيقة.' }, { title: 'نؤكد', text: 'نتصل بك لتأكيد الطلب.' }, { title: 'استلم', text: 'ادفع عند الاستلام.' }],
    faq: [{ q: 'كيف أدفع؟', a: 'نقداً عند الاستلام.' }, { q: 'كم يستغرق التوصيل؟', a: 'من 24 إلى 72 ساعة حسب الولاية.' }, { q: 'هل يمكنني الاستبدال؟', a: 'نعم إذا وصلك المنتج معيباً.' }, { q: 'كيف أستعمله؟', a: 'طريقة الاستعمال مرفقة مع المنتج.' }],
    final_cta: 'اطلب الآن وادفع عند الاستلام.', badge: 'عرض محدود', seo_title: name + ' — الجزائر، الدفع عند الاستلام'
  }, name);
}

async function generate(input) {
  const cfg = require('./landing-ai').aiCfg();
  const prompt = buildPrompt(input);
  const image = input.image && input.image.data ? input.image : null;
  if (cfg.provider === 'none') return { content: template(input), provider: 'template' };
  try {
    const j = cfg.provider === 'gemini' ? await viaGemini(cfg, prompt, image) : await viaOllama(cfg, prompt, image);
    const n = normalize(j, input.productName);
    if (!n.headline || n.benefits.length < 2) throw new Error('AI answer was incomplete');
    return { content: n, provider: cfg.provider };
  } catch (e) {
    return { content: template(input), provider: 'template', warning: e.message };
  }
}

module.exports = { generate, template };
