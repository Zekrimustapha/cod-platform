'use strict';
// Usage: npm run reset-password -- you@email.com NewPassword123
const { driver } = require('../src/driver-node');
const { init, D } = require('../src/db');
const { hashPassword } = require('../src/crypto');
const [email, pass] = process.argv.slice(2);
(async () => {
  if (!email || !pass || pass.length < 8) {
    console.log('Usage: npm run reset-password -- you@email.com NewPassword123   (8+ characters)');
    process.exit(1);
  }
  await init(driver);
  const r = await D.run('UPDATE users SET pass_hash = ?, active = 1 WHERE email = ?', await hashPassword(pass), email.toLowerCase());
  if (!r.changes) { console.log('No user with that email.'); process.exit(1); }
  await D.run('DELETE FROM sessions WHERE user_id = (SELECT id FROM users WHERE email = ?)', email.toLowerCase());
  console.log('Password changed for', email);
})();
