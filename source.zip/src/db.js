'use strict';
// Runtime-neutral data layer. A driver (Node SQLite file or Cloudflare D1) is plugged in at start.
// Every query is async: D.get / D.all / D.run.
const { randomHex } = require('./crypto');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS stores (
  id INTEGER PRIMARY KEY AUTOINCREMENT, slug TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active', ai_daily_images INTEGER NOT NULL DEFAULT 30, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT, store_id INTEGER REFERENCES stores(id) ON DELETE CASCADE,
  name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, pass_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'agent', is_super INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS store_settings (store_id INTEGER NOT NULL REFERENCES stores(id) ON DELETE CASCADE, key TEXT NOT NULL, value TEXT NOT NULL, PRIMARY KEY (store_id, key));
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT, store_id INTEGER NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  name TEXT NOT NULL, slug TEXT NOT NULL, short_desc TEXT DEFAULT '', description TEXT DEFAULT '', specs TEXT DEFAULT '',
  price INTEGER NOT NULL DEFAULT 0, old_price INTEGER DEFAULT 0, cost INTEGER DEFAULT 0, category TEXT DEFAULT '',
  images TEXT NOT NULL DEFAULT '[]', offers TEXT NOT NULL DEFAULT '[]', variants TEXT NOT NULL DEFAULT '[]',
  live INTEGER NOT NULL DEFAULT 1, seo_title TEXT DEFAULT '', sort INTEGER DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
  UNIQUE (store_id, slug)
);
CREATE TABLE IF NOT EXISTS landings (
  id INTEGER PRIMARY KEY AUTOINCREMENT, store_id INTEGER NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  title TEXT NOT NULL, slug TEXT NOT NULL, lang TEXT DEFAULT 'ar', content TEXT NOT NULL DEFAULT '{}',
  pixel_meta TEXT DEFAULT '', pixel_tiktok TEXT DEFAULT '', live INTEGER NOT NULL DEFAULT 1, ai INTEGER NOT NULL DEFAULT 0, visits INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, UNIQUE (store_id, slug)
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT, store_id INTEGER NOT NULL REFERENCES stores(id) ON DELETE CASCADE, public_token TEXT NOT NULL,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL,
  wilaya_code TEXT NOT NULL, wilaya_name TEXT NOT NULL, commune TEXT NOT NULL, address TEXT DEFAULT '', delivery TEXT NOT NULL DEFAULT 'desk',
  product_id INTEGER REFERENCES products(id) ON DELETE SET NULL, product_name TEXT DEFAULT '', landing_id INTEGER, variant TEXT DEFAULT '',
  quantity INTEGER NOT NULL DEFAULT 1, items_price INTEGER NOT NULL DEFAULT 0, delivery_fee INTEGER NOT NULL DEFAULT 0, upsell TEXT DEFAULT '', upsell_price INTEGER NOT NULL DEFAULT 0,
  total INTEGER NOT NULL DEFAULT 0, unit_cost INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'new', attempts INTEGER NOT NULL DEFAULT 0,
  note TEXT DEFAULT '', agent_id INTEGER, tracking TEXT DEFAULT '', courier TEXT DEFAULT '', source TEXT DEFAULT '',
  utm_source TEXT DEFAULT '', utm_campaign TEXT DEFAULT '', utm_content TEXT DEFAULT '', flags TEXT DEFAULT '', ip TEXT DEFAULT '', user_agent TEXT DEFAULT '',
  history TEXT NOT NULL DEFAULT '[]'
);
CREATE INDEX IF NOT EXISTS idx_orders_store_created ON orders(store_id, created_at);
CREATE INDEX IF NOT EXISTS idx_orders_store_status ON orders(store_id, status);
CREATE INDEX IF NOT EXISTS idx_orders_store_phone ON orders(store_id, phone);
CREATE INDEX IF NOT EXISTS idx_orders_store_campaign ON orders(store_id, utm_campaign);
CREATE TABLE IF NOT EXISTS abandoned (
  id INTEGER PRIMARY KEY AUTOINCREMENT, store_id INTEGER NOT NULL REFERENCES stores(id) ON DELETE CASCADE, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
  session TEXT NOT NULL UNIQUE, name TEXT DEFAULT '', phone TEXT DEFAULT '', wilaya TEXT DEFAULT '', commune TEXT DEFAULT '', product_id INTEGER, landing_id INTEGER,
  status TEXT NOT NULL DEFAULT 'open'
);
CREATE TABLE IF NOT EXISTS blacklist (store_id INTEGER NOT NULL REFERENCES stores(id) ON DELETE CASCADE, phone TEXT NOT NULL, reason TEXT DEFAULT '', created_at TEXT NOT NULL, PRIMARY KEY (store_id, phone));
CREATE TABLE IF NOT EXISTS ad_spend (
  store_id INTEGER NOT NULL REFERENCES stores(id) ON DELETE CASCADE, date TEXT NOT NULL, campaign_id TEXT NOT NULL, campaign_name TEXT DEFAULT '', platform TEXT DEFAULT 'meta',
  spend_usd REAL NOT NULL DEFAULT 0, impressions INTEGER DEFAULT 0, clicks INTEGER DEFAULT 0, results INTEGER DEFAULT 0, PRIMARY KEY (store_id, date, campaign_id)
);
CREATE TABLE IF NOT EXISTS landing_stats (landing_id INTEGER NOT NULL, date TEXT NOT NULL, visits INTEGER NOT NULL DEFAULT 0, orders INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (landing_id, date));
CREATE TABLE IF NOT EXISTS ip_blocklist (store_id INTEGER NOT NULL REFERENCES stores(id) ON DELETE CASCADE, ip TEXT NOT NULL, reason TEXT DEFAULT '', hits INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, PRIMARY KEY (store_id, ip));
CREATE TABLE IF NOT EXISTS files (id TEXT PRIMARY KEY, store_id INTEGER, mime TEXT NOT NULL, size INTEGER NOT NULL DEFAULT 0, data TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS ai_usage (store_id INTEGER NOT NULL, date TEXT NOT NULL, images INTEGER NOT NULL DEFAULT 0, analyses INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (store_id, date));
`;

const PLATFORM_KEYS = ['ai', 'platform'];

const DEFAULTS = {
  platform: {
    name: 'منصتي', tagline: 'أنشئ متجرك للدفع عند الاستلام في دقائق', signupMode: 'invite', inviteCode: '', baseDomain: '', maxStores: 10, supportPhone: '', supportEmail: ''
  },
  store: {
    name: 'متجري', tagline: 'منتجات مضمونة · الدفع عند الاستلام', phone: '', whatsapp: '', facebook: '', instagram: '', tiktok: '',
    hours: '09:00 – 20:00', returnPolicy: 'استبدال مجاني إذا وصلك المنتج معيباً.', announcement: 'الدفع عند الاستلام · توصيل إلى كل الولايات',
    heroTitle: 'منتجات مضمونة تحلّ مشكلتك', heroSub: 'اطلب في دقيقة، نتصل بك للتأكيد، وتدفع فقط عند الاستلام.', heroImage: '',
    deliveryTime: 'من 24 إلى 72 ساعة حسب الولاية', categories: []
  },
  theme: { preset: 'emerald', layout: 'classic', primary: '#0F5C46', accent: '#F2A93B', ink: '#15201B', bg: '#F7F6F2', font: 'Cairo', radius: 16, template: 'story', cols: 4, logo: '', buttonStyle: 'solid' },
  delivery: { wilayaMode: 58, defaultDesk: 0, defaultHome: 400, fees: {}, courier: 'manual', deskEnabled: true, homeEnabled: true },
  costs: { courierPerDelivered: 400, confirmPerDelivered: 100, returnFee: 0, usdRate: 255, packaging: 0 },
  fraud: { mergeHours: 24, maxPerDay: 3, autoBlacklistReturns: 2, flagScore: 50, maxPerIpDay: 4, autoBlockIp: true, blockIpv6Range: true },
  tracking: {
    metaPixel: '', metaCapiToken: '', metaTestCode: '', tiktokPixel: '', purchaseEvent: 'Purchase',
    // v2: several pixels per platform + when the Purchase is reported
    meta: [], tiktok: [], snapPixel: '', googleTag: '', googleAdsLabel: '',
    purchaseOn: 'placed', // placed | confirmed | delivered (server Conversions API)
    events: { PageView: true, ViewContent: true, InitiateCheckout: true, AddPaymentInfo: false, Lead: false }
  },
  form: {
    title: '', subtitle: '', button: '', showOffers: true, showSummary: true, showTrust: true,
    fields: [
      { key: 'name', on: true, req: true, label: '', ph: '' },
      { key: 'phone', on: true, req: true, label: '', ph: '' },
      { key: 'phone2', on: false, req: false, label: '', ph: '' },
      { key: 'wilaya', on: true, req: true, label: '' },
      { key: 'commune', on: true, req: true, label: '' },
      { key: 'address', on: false, req: false, label: '', ph: '' },
      { key: 'note', on: false, req: false, label: '', ph: '' }
    ]
  },
  couriers: {
    provider: 'none', apiId: '', apiToken: '', apiKey: '', userGuid: '', host: '', fromWilaya: '16', autoPush: false, stopdeskDefault: false, weight: 1
  },
  integrations: { sheetsUrl: '', metaAdsToken: '', metaAdAccount: '', graphVersion: 'v21.0' },
  ai: {
    provider: 'auto', ollamaUrl: 'http://127.0.0.1:11434', ollamaModel: 'gemma3:4b', geminiKey: '', geminiModel: 'gemini-2.5-flash',
    imageProvider: 'cloudflare', cfAccountId: '', cfApiToken: '', cfImageModel: '@cf/black-forest-labs/flux-2-klein-4b', modelV: 2, cfSteps: 6,
    geminiImageModel: 'gemini-2.5-flash-image', openaiKey: '', openaiImageModel: 'gpt-image-1', defaultLang: 'dz'
  }
};
const SECRET_FIELDS = { tracking: ['metaCapiToken'], integrations: ['metaAdsToken'], couriers: ['apiToken', 'apiKey'], ai: ['geminiKey', 'openaiKey', 'cfApiToken'] };
const STORE_KEYS = Object.keys(DEFAULTS).filter((k) => !PLATFORM_KEYS.includes(k));

let driver = null;
const D = {
  get: (sql, ...p) => driver.get(sql, p),
  all: (sql, ...p) => driver.all(sql, p),
  run: (sql, ...p) => driver.run(sql, p),
  exec: (sql) => driver.exec(sql),
  kind: () => driver.kind
};

async function init(drv) {
  driver = drv;
  if (driver.migrate) await driver.migrate(SCHEMA);
  if (!drv.skipSchema) {
    for (const stmt of SCHEMA.split(';').map((x) => x.trim()).filter(Boolean)) await D.run(stmt);
    // Columns added after the first release (ignored when they already exist).
    for (const [t, c] of [['orders', "extra TEXT DEFAULT ''"], ['orders', "courier_status TEXT DEFAULT ''"], ['orders', "pixel_sent TEXT DEFAULT ''"], ['orders', "phone2 TEXT DEFAULT ''"]]) {
      try { await D.run(`ALTER TABLE ${t} ADD COLUMN ${c}`); } catch {}
    }
  }
  // Make sure the platform has an invite code.
  await primePlatform();
  const p = getSetting('platform');
  if (!p.inviteCode) { p.inviteCode = randomHex(4).toUpperCase(); await setSetting('platform', p); }
}

// ---------- settings (cached; primed at the start of every request) ----------
const cache = { platform: null, stores: new Map() };
function readVal(raw, key) {
  const def = DEFAULTS[key] || {};
  if (raw == null) return structuredClone(def);
  try { return { ...structuredClone(def), ...JSON.parse(raw) }; } catch { return structuredClone(def); }
}
async function primePlatform() {
  const rows = await D.all('SELECT key, value FROM settings');
  cache.platform = Object.fromEntries(rows.map((r) => [r.key, r.value]));
}
async function prime(storeId) {
  await primePlatform();
  if (storeId) {
    const rows = await D.all('SELECT key, value FROM store_settings WHERE store_id = ?', storeId);
    const st = await D.get('SELECT name FROM stores WHERE id = ?', storeId);
    cache.stores.set(Number(storeId), { map: Object.fromEntries(rows.map((r) => [r.key, r.value])), name: st ? st.name : '' });
  }
}
// Platform keys ignore storeId; store keys need a primed store id.
function getSetting(key, storeId) {
  if (PLATFORM_KEYS.includes(key)) return readVal(cache.platform && cache.platform[key], key);
  if (!storeId) throw new Error('getSetting(' + key + ') needs a store id');
  const c = cache.stores.get(Number(storeId));
  const out = readVal(c && c.map[key], key);
  if (key === 'store' && c && !(key in c.map) && c.name) out.name = c.name;
  return out;
}
async function setSetting(key, value, storeId) {
  const raw = JSON.stringify(value);
  if (PLATFORM_KEYS.includes(key)) {
    await D.run('INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', key, raw);
    if (cache.platform) cache.platform[key] = raw;
    return;
  }
  if (!storeId) throw new Error('setSetting(' + key + ') needs a store id');
  await D.run('INSERT INTO store_settings(store_id, key, value) VALUES(?, ?, ?) ON CONFLICT(store_id, key) DO UPDATE SET value = excluded.value', storeId, key, raw);
  if (key === 'store' && value.name) await D.run('UPDATE stores SET name = ? WHERE id = ?', String(value.name).slice(0, 80), storeId);
  const c = cache.stores.get(Number(storeId)) || { map: {}, name: '' };
  c.map[key] = raw;
  if (key === 'store' && value.name) c.name = value.name;
  cache.stores.set(Number(storeId), c);
}
function storeSettings(storeId) {
  const out = {};
  for (const k of STORE_KEYS) out[k] = getSetting(k, storeId);
  return out;
}

function parseJson(s, def) {
  try { return s ? JSON.parse(s) : def; } catch { return def; }
}
function productRow(p) {
  if (!p) return null;
  return { ...p, images: parseJson(p.images, []), offers: parseJson(p.offers, []), variants: parseJson(p.variants, []), live: !!p.live };
}
function landingRow(l) {
  if (!l) return null;
  return { ...l, content: parseJson(l.content, {}), live: !!l.live, ai: !!l.ai };
}
function orderRow(o) {
  if (!o) return null;
  return { ...o, history: parseJson(o.history, []) };
}
async function storeById(id) {
  return (await D.get('SELECT * FROM stores WHERE id = ?', id)) || null;
}
async function storeBySlug(slug) {
  return (await D.get('SELECT * FROM stores WHERE slug = ?', String(slug || '').toLowerCase())) || null;
}

// Background work (Sheets, Conversions API): Workers must keep the request alive until it finishes.
const pending = new Set();
function bg(promise) {
  const p = Promise.resolve(promise).catch((e) => console.log('[bg]', e && e.message)).finally(() => pending.delete(p));
  pending.add(p);
}
function drainBg() { return Promise.allSettled([...pending]); }

module.exports = { SECRET_FIELDS, D, init, SCHEMA, DEFAULTS, PLATFORM_KEYS, STORE_KEYS, prime, getSetting, setSetting, storeSettings, parseJson, productRow, landingRow, orderRow, storeById, storeBySlug, bg, drainBg };
