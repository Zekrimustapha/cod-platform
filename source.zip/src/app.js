'use strict';
// Shared request router — used by the Node server (server.js) and the Cloudflare Worker (worker-entry.js).
const U = require('./util');
const api = require('./api');
const pub = require('./public');
const files = require('./files');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.mp4': 'video/mp4', '.woff2': 'font/woff2'
};
const mimeOf = (p) => MIME[(p.match(/\.[a-z0-9]+$/i) || [''])[0].toLowerCase()] || 'application/octet-stream';

// assets: async (relPath under /public) => string | Uint8Array | null
// legacyUpload: optional async (name) => boolean (Node serves old files from data/uploads)
async function handle(req, res, url, { assets, legacyUpload }) {
  const p = url.pathname;
  const GET = req.method === 'GET' || req.method === 'HEAD';
  try {
    if (GET && p.startsWith('/assets/')) {
      const body = await assets('assets/' + p.slice(8));
      if (body != null) return U.send(res, 200, body, { 'Content-Type': mimeOf(p), 'Cache-Control': 'public, max-age=3600' });
    }
    if (GET && p.startsWith('/uploads/')) {
      if (legacyUpload && (await legacyUpload(req, res, p.slice(9)))) return;
      const f = await files.read(p);
      if (!f) return U.send(res, 404, 'Not found');
      const headers = { 'Content-Type': f.mime, 'Cache-Control': 'public, max-age=31536000, immutable' };
      if (f.mime === 'image/svg+xml') headers['Content-Security-Policy'] = "default-src 'none'";
      return U.send(res, 200, f.bytes, headers);
    }
    if (p === '/admin') return U.redirect(res, '/admin/');
    if (GET && (p === '/admin/' || p.startsWith('/admin/'))) {
      const rel = p === '/admin/' ? 'index.html' : p.slice(7);
      const body = await assets('admin/' + rel);
      if (body != null) return U.send(res, 200, body, { 'Content-Type': mimeOf(rel), 'Cache-Control': 'no-cache' });
    }
    if (p.startsWith('/api/admin')) return await api.handle(req, res, url);
    const handled = await pub.handle(req, res, url);
    if (handled === null && !res.headersSent) return pub.notFound(res);
  } catch (e) {
    const status = e.status || 500;
    if (status >= 500) console.error(new Date().toISOString(), req.method, p, e);
    if (!res.headersSent) {
      if (p.startsWith('/api/') || p.includes('/api/')) U.json(res, status, { error: status >= 500 ? 'Server error' : e.message });
      else U.send(res, status, status >= 500 ? 'Server error' : e.message, { 'Content-Type': 'text/plain; charset=utf-8' });
    }
  }
}

module.exports = { handle, mimeOf };
