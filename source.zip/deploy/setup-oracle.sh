#!/usr/bin/env bash
# One-time setup on a fresh Ubuntu 22.04/24.04 server (Oracle Cloud Always Free, ARM or AMD).
# Usage (on the server, inside the project folder):  sudo bash deploy/setup-oracle.sh
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
APP_USER="${SUDO_USER:-ubuntu}"

echo "==> Installing Node.js 22"
if ! command -v node >/dev/null || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 22 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
node -v

echo "==> Installing cloudflared"
if ! command -v cloudflared >/dev/null; then
  ARCH=$(dpkg --print-architecture)
  curl -fsSL -o /tmp/cloudflared.deb "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${ARCH}.deb"
  dpkg -i /tmp/cloudflared.deb
fi

echo "==> Swap (1 GB servers need it)"
if ! swapon --show | grep -q swap; then
  fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
  echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

echo "==> Service"
mkdir -p "$APP_DIR/data"
chown -R "$APP_USER":"$APP_USER" "$APP_DIR"
sed -e "s#__APP_DIR__#$APP_DIR#g" -e "s#__USER__#$APP_USER#g" "$APP_DIR/deploy/platform.service" > /etc/systemd/system/platform.service
systemctl daemon-reload
systemctl enable --now platform
sleep 2
systemctl --no-pager status platform | head -5
curl -s http://127.0.0.1:3000/health && echo
echo
echo "Done. The platform runs on port 3000 (only reachable from this server)."
echo "Next: connect the Cloudflare Tunnel — see README section 'Free 24/7 server'."
