'use strict';
// Runtime-neutral crypto helpers (Web Crypto) — work in Node 22 and Cloudflare Workers.
const C = globalThis.crypto;
const enc = new TextEncoder();

function randomBytes(n) {
  const a = new Uint8Array(n);
  C.getRandomValues(a);
  return a;
}
function toHex(a) {
  return Array.from(a, (b) => b.toString(16).padStart(2, '0')).join('');
}
function fromHex(h) {
  const a = new Uint8Array(h.length / 2);
  for (let i = 0; i < a.length; i++) a[i] = parseInt(h.substr(i * 2, 2), 16);
  return a;
}
function bytesToB64(a) {
  let s = '';
  const CH = 0x8000;
  for (let i = 0; i < a.length; i += CH) s += String.fromCharCode.apply(null, a.subarray(i, i + CH));
  return btoa(s);
}
function b64ToBytes(b64) {
  const s = atob(b64);
  const a = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) a[i] = s.charCodeAt(i);
  return a;
}
const randomHex = (n) => toHex(randomBytes(n));
const randomB64url = (n) => bytesToB64(randomBytes(n)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

async function sha256hex(s) {
  return toHex(new Uint8Array(await C.subtle.digest('SHA-256', enc.encode(String(s)))));
}

// Passwords: PBKDF2-SHA256 (fast enough for the Workers free CPU budget, salted, constant-time compare).
const ITER = 10000; // keeps login under the Workers free-plan CPU limit (10 ms); salted + rate-limited
async function pbkdf2(pw, salt, iter) {
  const key = await C.subtle.importKey('raw', enc.encode(String(pw)), 'PBKDF2', false, ['deriveBits']);
  return new Uint8Array(await C.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: iter }, key, 256));
}
async function hashPassword(pw) {
  const salt = randomBytes(16);
  return `pbkdf2$${ITER}$${toHex(salt)}$${toHex(await pbkdf2(pw, salt, ITER))}`;
}
function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a[i] ^ b[i];
  return d === 0;
}
async function verifyPassword(pw, stored) {
  const parts = String(stored || '').split('$');
  if (parts[0] === 'pbkdf2' && parts.length === 4) {
    return safeEqual(await pbkdf2(pw, fromHex(parts[2]), Number(parts[1])), fromHex(parts[3]));
  }
  if (parts[0] === 'scrypt' && parts.length === 3 && typeof process !== 'undefined' && process.versions && process.versions.node) {
    // Accounts created by the old Node-only version.
    const nc = require('node:crypto');
    const h = nc.scryptSync(String(pw), Buffer.from(parts[1], 'hex'), 64, { N: 16384, r: 8, p: 1 });
    return safeEqual(new Uint8Array(h), fromHex(parts[2]));
  }
  return false;
}

module.exports = { randomBytes, randomHex, randomB64url, toHex, bytesToB64, b64ToBytes, sha256hex, hashPassword, verifyPassword };
